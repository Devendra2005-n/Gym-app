# GYM Flow – Supabase (online mode) setup

The app now talks to Supabase project **gymflow-ai** (`https://qkedgztqvzoldgpawlyw.supabase.co`).
`www/config.js` holds the project URL and the **publishable** key (safe inside the app). Never put a secret/service_role key there.
To go back to fully-offline mode, set `supabaseUrl: ''` in `www/config.js`.

## 1. One-time Supabase dashboard steps (cannot be done from code)
1. **Authentication → Providers → Google**: enable it. Put your Google *Web* client ID and secret.
2. In the same Google provider box, add the same Web client ID under **Authorized Client IDs**
   (the Android app sends a Google ID token). If sign-in fails with a nonce error, tick **Skip nonce checks**.
3. **Authentication → Providers → Email / Policies**: turn on **Leaked password protection** (Pro plan feature).
4. Google Cloud Console: Android OAuth client (package `com.gymflow.ai`, your SHA-1) + Web client; paste the Web client ID in `www/config.js` → `googleWebClientId` (see GOOGLE_SIGNIN_SETUP.md).

## 2. Add a gym staff user (owner / receptionist / trainer)
The person signs in with Google once, then run in SQL editor (replace e-mail and gym id):
```sql
insert into public.gym_users (id, gym_id, full_name, role)
select id, '<GYM_ID>', 'Owner Name', 'owner' from auth.users where lower(email) = lower('owner@gmail.com');
```
Roles: `owner` (everything), `receptionist` (members, check-in, payments), `trainer` (read-only on members/workouts).
The app screens are the owner screens for every staff role; the **server** blocks what a role may not do.

## 3. Members
The front desk registers the member **with the member's Google e-mail**. When the member signs in with that Google account,
`claim_member_profile()` links the account to the record. Two member records must not share one e-mail
(currently two demo members share `nimbalkardevendra7@gmail.com`; change one so linking is not "ambiguous").

## 4. How money works (honest limits)
UPI does not call the app back. So: member pays via QR/UPI app → taps **"Yes, I paid"** → a *claim* is saved
(amount = plan price from the server, optional UTR) → the desk sees **"Member payments to confirm"** → checks the
money in the UPI/bank app → taps **Confirm** → server records payment, starts/renews membership, creates the invoice number.
Fully automatic recording needs a payment gateway (Razorpay/Cashfree) + webhook Edge Function calling `record_payment`.

## 5. Check-in
Owner shows the QR (code from the server, changes every 5 minutes). Member scans it or types the 8 characters →
`self_check_in`. 8 wrong tries in 10 minutes are blocked. Owner can also check in by member card QR or manually.

## 6. Internet
Online mode needs internet for registering, payments, check-in and settings (a clear "No internet" message is shown;
nothing is faked locally). Workouts/weight/water/goals are queued on the phone and synced later.

## 7. Tests
- `supabase/tests/10_backend_tests.sql` – ~120 database assertions (RLS, roles, tenant isolation, RPCs, claims).
- `node test/core.test.js` – app logic.
- Migrations live in `supabase/migrations/` (0002–0005, all already applied to the live project).

## 8. One login page, sign-up, and who becomes owner
- There is no "Owner / Member" chooser any more. Everyone uses **Continue with Google**.
- If the Google account is in `gym_users` (staff) → owner screens. Anyone else → member page.
- Currently the only staff/owner account is **nimbalkardevendra7@gmail.com**. No other e-mail can become owner from the app.
- **Create account** tab: name + mobile, then Google. Server function `register_self` adds the verified Google e-mail as a *member* of the gym
  (never staff). If the front desk already added that e-mail, the existing record is linked instead.
- A mobile number already used by another member is refused ("ask the front desk").
- Migration `0006_self_signup.sql` (already applied live).

## 9. Online payments
See `RAZORPAY_SETUP.md`. Migration `0007_gateway_orders.sql` and Edge Functions `rzp-create-order`, `rzp-webhook` are already live.
