-- LOCAL TEST ONLY. Recreates what the live Supabase project "gymflow-ai" already had
-- (tables, helper functions, policies) plus a minimal fake auth schema, so that
-- migrations/0002_app_backend.sql can be tested on plain Postgres. Never run on Supabase.
create schema if not exists extensions; create schema if not exists auth;
create function extensions.uuid_generate_v4() returns uuid language sql as $$ select gen_random_uuid() $$;
do $$ begin
  create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls;
exception when duplicate_object then null; end $$;
create table auth.users(id uuid primary key default gen_random_uuid(), email text, email_confirmed_at timestamptz default now());
create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true),'')::uuid $$;
grant usage on schema public, auth to anon, authenticated;
alter default privileges in schema public grant all on tables to anon, authenticated;
alter default privileges in schema public grant all on functions to anon, authenticated;
alter default privileges in schema public grant all on sequences to anon, authenticated;

create table public.gyms(id uuid primary key default extensions.uuid_generate_v4(), name text not null, owner_name text not null, phone text, email text not null unique, address text, city text, logo_url text, subscription_plan text default 'basic', is_active boolean default true, created_at timestamptz default now(), updated_at timestamptz default now());
create table public.gym_users(id uuid primary key default extensions.uuid_generate_v4(), user_id uuid not null references auth.users(id), gym_id uuid not null references public.gyms(id), role text not null check (role in ('owner','receptionist','trainer')), is_active boolean default true, created_at timestamptz default now(), unique(user_id, gym_id));
create table public.members(id uuid primary key default extensions.uuid_generate_v4(), gym_id uuid not null references public.gyms(id), full_name text not null, phone text not null, email text, date_of_birth date, gender text check (gender in ('male','female','other')), address text, photo_url text, emergency_contact text, health_notes text, join_date date default current_date, is_active boolean default true, created_at timestamptz default now(), updated_at timestamptz default now());
create table public.plans(id uuid primary key default extensions.uuid_generate_v4(), gym_id uuid not null references public.gyms(id), name text not null, duration_days int not null, price numeric not null, description text, includes_pt boolean default false, is_active boolean default true, created_at timestamptz default now());
create table public.memberships(id uuid primary key default extensions.uuid_generate_v4(), gym_id uuid not null references public.gyms(id), member_id uuid not null references public.members(id), plan_id uuid not null references public.plans(id), start_date date not null default current_date, end_date date not null, status text default 'active' check (status in ('active','expired','cancelled','paused')), created_by uuid references auth.users(id), created_at timestamptz default now(), updated_at timestamptz default now());
create table public.payments(id uuid primary key default extensions.uuid_generate_v4(), gym_id uuid not null references public.gyms(id), member_id uuid not null references public.members(id), membership_id uuid references public.memberships(id), amount numeric not null, payment_date date default current_date, payment_method text check (payment_method in ('cash','upi','card','bank_transfer','online')), reference_no text, notes text, received_by uuid references auth.users(id), created_at timestamptz default now());
create table public.notifications(id uuid primary key default extensions.uuid_generate_v4(), gym_id uuid not null references public.gyms(id), member_id uuid references public.members(id), type text not null, channel text default 'whatsapp', recipient text not null, message text not null, status text default 'pending' check (status in ('pending','sent','failed','delivered')), sent_at timestamptz, error_msg text, created_at timestamptz default now());
create table public.audit_logs(id uuid primary key default extensions.uuid_generate_v4(), gym_id uuid references public.gyms(id), user_id uuid references auth.users(id), action text not null, table_name text, record_id uuid, old_data jsonb, new_data jsonb, ip_address text, created_at timestamptz default now());
create table public.attendance(id uuid primary key default gen_random_uuid(), gym_id uuid not null references public.gyms(id), member_id uuid not null references public.members(id), membership_id uuid references public.memberships(id), check_in_at timestamptz not null default now(), check_out_at timestamptz, attendance_date date not null default ((now() at time zone 'Asia/Kolkata')::date), source text not null default 'manual', recorded_by uuid, notes text, created_at timestamptz not null default now());
create index attendance_gym_date_idx on public.attendance(gym_id, attendance_date);
create unique index attendance_one_per_day on public.attendance(member_id, attendance_date);

create function public.get_my_gym_id() returns uuid language sql stable security definer as $$ select gym_id from gym_users where user_id = auth.uid() and is_active = true limit 1 $$;
create function public.get_my_role() returns text language sql stable security definer as $$ select role from gym_users where user_id = auth.uid() and is_active = true limit 1 $$;

do $$ declare t text; begin foreach t in array array['gyms','gym_users','members','plans','memberships','payments','notifications','audit_logs','attendance'] loop execute format('alter table public.%I enable row level security', t); end loop; end $$;
create policy audit_logs_insert_any on audit_logs for insert with check (gym_id = get_my_gym_id());
create policy gym_owners_view_audit on audit_logs for select using (gym_id = get_my_gym_id() and get_my_role()='owner');
create policy owners_manage_gym_users on gym_users for all using (gym_id = get_my_gym_id() and get_my_role()='owner');
create policy users_view_own_gym_users on gym_users for select using (gym_id = get_my_gym_id());
create policy owners_update_own_gym on gyms for update using (id = get_my_gym_id() and get_my_role()='owner');
create policy users_view_own_gym on gyms for select using (id = get_my_gym_id());
create policy gym_owners_delete_members on members for delete using (gym_id = get_my_gym_id() and get_my_role()='owner');
create policy gym_staff_add_members on members for insert with check (gym_id = get_my_gym_id());
create policy gym_staff_update_members on members for update using (gym_id = get_my_gym_id());
create policy gym_staff_view_own_members on members for select using (gym_id = get_my_gym_id());
create policy gym_staff_manage_memberships on memberships for insert with check (gym_id = get_my_gym_id());
create policy gym_staff_update_memberships on memberships for update using (gym_id = get_my_gym_id());
create policy gym_staff_view_own_memberships on memberships for select using (gym_id = get_my_gym_id());
create policy gym_staff_add_notifications on notifications for insert with check (gym_id = get_my_gym_id());
create policy gym_staff_view_own_notifications on notifications for select using (gym_id = get_my_gym_id());
create policy gym_staff_add_payments on payments for insert with check (gym_id = get_my_gym_id());
create policy gym_staff_view_own_payments on payments for select using (gym_id = get_my_gym_id());
create policy gym_owners_manage_plans on plans for all using (gym_id = get_my_gym_id() and get_my_role()='owner');
create policy gym_staff_view_own_plans on plans for select using (gym_id = get_my_gym_id());
