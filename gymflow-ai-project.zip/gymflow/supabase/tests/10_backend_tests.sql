-- Role / RLS / RPC tests. Works on plain Postgres (after 00_local_baseline + 0002) and on Supabase.
-- Everything runs in ONE statement and ends with an exception, so nothing is ever committed.
-- Expected last message:  ALL TESTS PASSED (rolled back on purpose)
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$
begin perform set_config('request.jwt.claim.sub', u::text, true); execute 'set local role authenticated'; end $$;
create or replace function pg_temp.as_admin() returns void language plpgsql as $$
begin perform set_config('request.jwt.claim.sub', '', true); execute 'reset role'; end $$;
create or replace function pg_temp.fails(q text, code text) returns boolean language plpgsql as $$
begin execute q; return false;
exception when others then if sqlstate = code then return true; end if; raise exception 'wrong error % (%): %', sqlstate, sqlerrm, q; end $$;
create or replace function pg_temp.cnt(q text) returns bigint language plpgsql as $$
declare n bigint; begin execute 'select count(*) from (' || q || ') t' into n; return n; end $$;

do $$
declare
  ga uuid := gen_random_uuid(); gb uuid := gen_random_uuid();
  uo uuid := gen_random_uuid(); ur uuid := gen_random_uuid(); ut uuid := gen_random_uuid();
  um1 uuid := gen_random_uuid(); um2 uuid := gen_random_uuid(); uo2 uuid := gen_random_uuid(); ux uuid := gen_random_uuid();
  m1 uuid; m2 uuid; b1 uuid; plan uuid; plan_b uuid;
  p public.payments; p2 public.payments; j jsonb; j2 jsonb; yr text := extract(year from (now() at time zone 'Asia/Kolkata'))::text;
begin
  -- ---------- setup as admin
  insert into auth.users(id, email, email_confirmed_at) select v.id, v.e, now() from (values (uo,'owner@x.com'),(ur,'rec@x.com'),(ut,'tr@x.com'),(um1,'M1@x.com'),(um2,'m2@x.com'),(uo2,'owner2@x.com'),(ux,'nobody@x.com')) as v(id,e);
  insert into public.gyms(id,name,owner_name,email,invoice_prefix) values (ga,'Test Gym A','Oa','a@test.com','TA'),(gb,'Test Gym B','Ob','b@test.com','TB');
  insert into public.gym_users(user_id,gym_id,role) values (uo,ga,'owner'),(ur,ga,'receptionist'),(ut,ga,'trainer'),(uo2,gb,'owner');
  insert into public.plans(gym_id,name,duration_days,price) values (ga,'Monthly',30,1000) returning id into plan;
  insert into public.plans(gym_id,name,duration_days,price) values (gb,'B plan',30,500) returning id into plan_b;
  insert into public.members(gym_id,full_name,phone,email) values (ga,'Member One','111','m1@x.com') returning id into m1;
  insert into public.members(gym_id,full_name,phone,email) values (ga,'Member Two','222','m2@x.com') returning id into m2;
  insert into public.members(gym_id,full_name,phone,email) values (gb,'Other Gym','333','b1@x.com') returning id into b1;

  -- ---------- staff roles + payments + invoice numbers
  perform pg_temp.as_user(uo);
  assert (public.app_context()->>'role') = 'owner', 'owner context';
  p := public.record_payment(m1, 500, 'cash');
  assert p.invoice_no = 'TA-'||yr||'-0001', 'first invoice no, got '||coalesce(p.invoice_no,'null');
  assert p.received_by = uo, 'received_by is the caller';
  perform pg_temp.as_user(ur);
  p2 := public.record_payment(m2, 250, 'upi', null, 'UTR1');
  assert p2.invoice_no = 'TA-'||yr||'-0002', 'second invoice no';
  assert pg_temp.fails(format('select public.record_payment(%L, 0, %L)', m1, 'cash'), '22023'), 'zero amount rejected';
  assert pg_temp.fails(format('select public.record_payment(%L, 10, %L)', m1, 'bitcoin'), '23514'), 'bad method rejected';
  perform pg_temp.as_user(ut);
  assert pg_temp.fails(format('select public.record_payment(%L, 10, %L)', m1, 'cash'), '42501'), 'trainer cannot take payments';
  assert pg_temp.cnt('select 1 from public.payments') = 0, 'trainer sees no payments';
  assert pg_temp.cnt('select 1 from public.members') = 2, 'trainer sees gym members';

  -- direct insert into payments is closed for everyone (RPC only)
  perform pg_temp.as_user(uo);
  assert pg_temp.fails(format('insert into public.payments(gym_id,member_id,amount) values (%L,%L,5)', ga, m1), '42501'), 'direct payment insert blocked';
  assert pg_temp.cnt('select 1 from public.payments') = 2, 'owner sees both payments';

  -- ---------- renew membership
  j := public.renew_membership(m1, plan, 'cash');
  assert (j->'membership'->>'end_date')::date = (j->'membership'->>'start_date')::date + 29, 'end = start + 29 (30 days incl.)';
  assert (j->'payment'->>'amount')::numeric = 1000 and (j->'payment'->>'invoice_no') = 'TA-'||yr||'-0003', 'renew payment + invoice';
  j2 := public.renew_membership(m1, plan, 'upi', 900);
  assert (j2->'membership'->>'start_date')::date = (j->'membership'->>'end_date')::date + 1, 'second renewal extends';
  assert pg_temp.fails(format('select public.renew_membership(%L,%L)', m1, plan_b), 'P0002'), 'other gym plan rejected';

  -- ---------- tenant isolation
  perform pg_temp.as_user(uo2);
  assert pg_temp.cnt('select 1 from public.members') = 1, 'owner B sees only own members';
  assert pg_temp.cnt('select 1 from public.payments') = 0 and pg_temp.cnt('select 1 from public.memberships') = 0, 'owner B sees nothing of A';
  assert pg_temp.fails(format('select public.record_payment(%L, 10, %L)', m1, 'cash'), 'P0002'), 'cannot pay for other gym member';
  assert pg_temp.fails(format('select public.check_in(%L)', m1), 'P0002'), 'cannot check in other gym member';
  update public.gyms set upi_id = 'hack@upi' where id = ga;
  perform pg_temp.as_admin();
  assert (select upi_id from public.gyms where id = ga) is null, 'owner B cannot edit gym A';
  perform pg_temp.as_user(uo);
  assert pg_temp.fails(format('insert into public.memberships(gym_id,member_id,plan_id,end_date) values (%L,%L,%L,current_date)', ga, b1, plan), '23514'), 'membership with other-gym member blocked';
  assert pg_temp.fails(format('update public.gyms set subscription_plan = %L where id = %L', 'enterprise', ga), '42501'), 'owner cannot change own subscription';
  update public.gyms set upi_id = 'fitness@upi', invoice_footer = 'Thanks' where id = ga;
  assert (public.my_gym()->>'upi_id') = 'fitness@upi', 'owner can edit invoice settings';

  -- ---------- member login claim
  perform pg_temp.as_user(ux);
  assert (public.claim_member_profile()->>'status') = 'not_found', 'unknown email not linked';
  assert (public.app_context()->>'role') is null, 'stranger has no role';
  assert pg_temp.cnt('select 1 from public.members') = 0, 'stranger sees nothing';
  perform pg_temp.as_user(um1);
  assert (public.claim_member_profile()->>'status') = 'linked', 'M1@x.com matches m1@x.com (case-insensitive)';
  assert (public.claim_member_profile()->>'status') = 'already_linked', 'second claim is idempotent';
  assert (public.app_context()->>'role') = 'member' and (public.app_context()->>'member_id')::uuid = m1, 'member context';
  perform pg_temp.as_user(um2);
  assert (public.claim_member_profile()->>'status') = 'linked', 'second member linked';

  -- ---------- member isolation
  perform pg_temp.as_user(um1);
  assert pg_temp.cnt('select 1 from public.members') = 1, 'member sees only self';
  assert pg_temp.cnt('select 1 from public.payments') = 3, 'member sees only own payments (3)';
  assert pg_temp.cnt('select 1 from public.memberships') = 2, 'member sees own memberships';
  assert pg_temp.cnt('select 1 from public.plans') = 1, 'member sees own gym plans only';
  assert pg_temp.cnt('select 1 from public.gym_users') = 0 and pg_temp.cnt('select 1 from public.audit_logs') = 0
     and pg_temp.cnt('select 1 from public.notifications') = 0 and pg_temp.cnt('select 1 from public.gyms') = 0, 'staff-only tables closed to members';
  assert pg_temp.fails(format('insert into public.members(gym_id,full_name,phone) values (%L,%L,%L)', ga, 'x', '1'), '42501'), 'member cannot add members';
  assert pg_temp.fails(format('select public.record_payment(%L, 5, %L)', m1, 'cash'), '42501'), 'member cannot record payments';
  assert pg_temp.fails('select public.owner_dashboard()', '42501'), 'member cannot open owner dashboard';
  assert pg_temp.fails('select public.expire_memberships()', '42501'), 'expire job not callable by users';
  assert (public.my_gym()->>'name') = 'Test Gym A', 'member can read own gym card';
  delete from public.payments;
  perform pg_temp.as_admin();
  assert (select count(*) from public.payments where gym_id = ga) = 4, 'member cannot delete payments';
  -- linking guard
  perform pg_temp.as_user(ur);
  assert pg_temp.fails(format('update public.members set user_id = %L where id = %L', ux, m2), '42501'), 'staff cannot link logins by hand';
  assert pg_temp.fails(format('insert into public.members(gym_id,full_name,phone,user_id) values (%L,%L,%L,%L)', ga, 'y', '9', ux), '42501'), 'staff cannot insert pre-linked member';

  -- ---------- attendance
  perform pg_temp.as_user(um1);
  assert (public.check_in()->>'status') = 'checked_in', 'member self check-in';
  assert (public.check_in()->>'status') = 'already_checked_in', 'one check-in per day';
  perform pg_temp.as_user(um2);
  assert pg_temp.fails('select public.check_in()', 'P0001'), 'member without plan cannot self check-in';
  perform pg_temp.as_user(ur);
  j := public.check_in(m2);
  assert (j->>'status') = 'checked_in' and (j->>'membership_active')::boolean = false, 'staff check-in flags missing plan';
  assert pg_temp.cnt('select 1 from public.attendance') = 2, 'staff sees gym attendance';
  perform pg_temp.as_user(um1);
  assert pg_temp.cnt('select 1 from public.attendance') = 1, 'member sees own attendance only';

  -- ---------- tracking + weekly report
  insert into public.workout_logs(gym_id,member_id,exercise,minutes,kcal) values (ga,m1,'Squats',30,240);
  insert into public.weight_logs(gym_id,member_id,weight_kg) values (ga,m1,72.5);
  insert into public.water_logs(gym_id,member_id,ml) values (ga,m1,500);
  insert into public.member_goals(member_id,gym_id,weekly_workouts,water_ml) values (m1,ga,4,3000);
  assert pg_temp.fails(format('insert into public.workout_logs(gym_id,member_id,exercise,minutes) values (%L,%L,%L,10)', ga, m2, 'x'), '42501'), 'cannot log for another member';
  assert pg_temp.fails(format('insert into public.workout_logs(gym_id,member_id,exercise,minutes) values (%L,%L,%L,10)', gb, m1, 'x'), '23514'), 'cannot log into another gym';
  assert pg_temp.fails(format('insert into public.workout_logs(gym_id,member_id,exercise,minutes) values (%L,%L,%L,-5)', ga, m1, 'x'), '23514'), 'negative minutes rejected';
  j := public.weekly_report();
  assert (j->'totals'->>'workouts')::int = 1 and (j->'totals'->>'minutes')::numeric = 30 and (j->'totals'->>'kcal')::numeric = 240, 'weekly totals';
  assert (j->'totals'->>'gym_visits')::int = 1 and (j->'totals'->>'est_fat_loss_kg')::numeric = 0.03, 'visits + fat estimate';
  assert jsonb_array_length(j->'days') = 7 and (j->'weight'->>'end')::numeric = 72.5, '7 days + weight';
  assert (j->'goals'->>'weekly_workouts')::int = 4, 'goals included';
  assert pg_temp.fails(format('select public.weekly_report(%L)', m2), '42501'), 'member cannot read another report';
  perform pg_temp.as_user(um2);
  assert pg_temp.cnt('select 1 from public.workout_logs') = 0, 'member 2 cannot see member 1 logs';
  perform pg_temp.as_user(ut);
  assert pg_temp.cnt('select 1 from public.workout_logs') = 1, 'trainer sees member logs';
  assert (public.weekly_report(m1)->'totals'->>'workouts')::int = 1, 'trainer can open report';
  perform pg_temp.as_user(ur);
  assert pg_temp.cnt('select 1 from public.workout_logs') = 0, 'receptionist does not see workout logs';

  -- ---------- dashboard
  perform pg_temp.as_user(uo);
  j := public.owner_dashboard();
  assert (j->>'active_members')::int = 2 and (j->>'with_active_plan')::int = 1 and (j->>'without_plan')::int = 1, 'dashboard counts';
  assert (j->>'today_checkins')::int = 2 and (j->>'today_revenue')::numeric = 2650, 'dashboard checkins + revenue';
  perform pg_temp.as_user(ut);
  assert (public.owner_dashboard()->>'month_revenue') is null, 'trainer gets no revenue';

  -- ---------- audit + anon + expiry job
  perform pg_temp.as_user(uo);
  assert pg_temp.cnt('select 1 from public.audit_logs where table_name = ''payments''') = 4, 'audit trail for payments';
  perform pg_temp.as_admin();
  execute 'set local role anon';
  assert pg_temp.fails('select 1 from public.members', '42501'), 'anon has no table access';
  assert pg_temp.fails('select public.app_context()', '42501'), 'anon cannot call RPC';
  perform pg_temp.as_admin();
  update public.memberships set end_date = current_date - 5 where member_id = m1 and start_date = (select min(start_date) from public.memberships where member_id = m1);
  assert public.expire_memberships() >= 1, 'expiry job marks old memberships';

  raise exception 'ALL TESTS PASSED (rolled back on purpose)';
end $$;
