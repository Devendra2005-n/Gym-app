-- Role / RLS / RPC tests. Works on plain Postgres (after 00_local_baseline + 0002) and on Supabase.
-- Everything runs in ONE statement and ends with an exception, so nothing is ever committed.
-- Expected last message:  ALL TESTS PASSED (rolled back on purpose)
create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$
begin perform set_config('request.jwt.claim.sub', u::text, true); execute 'set local role authenticated'; end $$;
create or replace function pg_temp.as_admin() returns void language plpgsql as $$
begin perform set_config('request.jwt.claim.sub', '', true); execute 'reset role'; end $$;
create or replace function pg_temp.fails(q text, code text) returns boolean language plpgsql as $$
begin execute q; return false;
exception when others then if sqlstate = code then return true; end if; raise exception 'wrong error % (%): %', sqlstate, sqlerrm, q; end $$;
create or replace function pg_temp.cnt(q text) returns bigint language plpgsql as $$
declare n bigint; begin execute 'select count(*) from (' || q || ') t' into n; return n; end $$;

do $$
declare
  ga uuid := gen_random_uuid(); gb uuid := gen_random_uuid();
  uo uuid := gen_random_uuid(); ur uuid := gen_random_uuid(); ut uuid := gen_random_uuid();
  um1 uuid := gen_random_uuid(); um2 uuid := gen_random_uuid(); uo2 uuid := gen_random_uuid(); ux uuid := gen_random_uuid();
  m1 uuid; m2 uuid; b1 uuid; plan uuid; plan_b uuid;
  p public.payments; p2 public.payments; j jsonb; j2 jsonb; code text; i int; u2 uuid := gen_random_uuid(); yr text := extract(year from (now() at time zone 'Asia/Kolkata'))::text;
begin
  -- ---------- setup as admin
  insert into auth.users(id, email, email_confirmed_at) select v.id, v.e, now() from (values (uo,'owner@x.com'),(ur,'rec@x.com'),(ut,'tr@x.com'),(um1,'M1@x.com'),(um2,'m2@x.com'),(uo2,'owner2@x.com'),(ux,'nobody@x.com')) as v(id,e);
  insert into public.gyms(id,name,owner_name,email,invoice_prefix) values (ga,'Test Gym A','Oa','a@test.com','TA'),(gb,'Test Gym B','Ob','b@test.com','TB');
  insert into public.gym_users(user_id,gym_id,role) values (uo,ga,'owner'),(ur,ga,'receptionist'),(ut,ga,'trainer'),(uo2,gb,'owner');
  insert into public.plans(gym_id,name,duration_days,price) values (ga,'Monthly',30,1000) returning id into plan;
  insert into public.plans(gym_id,name,duration_days,price) values (gb,'B plan',30,500) returning id into plan_b;
  insert into public.members(gym_id,full_name,phone,email) values (ga,'Member One','111','m1@x.com') returning id into m1;
  insert into public.members(gym_id,full_name,phone,email) values (ga,'Member Two','222','m2@x.com') returning id into m2;
  insert into public.members(gym_id,full_name,phone,email) values (gb,'Other Gym','333','b1@x.com') returning id into b1;

  -- ---------- staff roles + payments + invoice numbers
  perform pg_temp.as_user(uo);
  assert (public.app_context()->>'role') = 'owner', 'owner context';
  p := public.record_payment(m1, 500, 'cash');
  assert p.invoice_no = 'TA-'||yr||'-0001', 'first invoice no, got '||coalesce(p.invoice_no,'null');
  assert p.received_by = uo, 'received_by is the caller';
  perform pg_temp.as_user(ur);
  p2 := public.record_payment(m2, 250, 'upi', null, 'UTR1');
  assert p2.invoice_no = 'TA-'||yr||'-0002', 'second invoice no';
  assert pg_temp.fails(format('select public.record_payment(%L, 0, %L)', m1, 'cash'), '22023'), 'zero amount rejected';
  assert pg_temp.fails(format('select public.record_payment(%L, 10, %L)', m1, 'bitcoin'), '23514'), 'bad method rejected';
  perform pg_temp.as_user(ut);
  assert pg_temp.fails(format('select public.record_payment(%L, 10, %L)', m1, 'cash'), '42501'), 'trainer cannot take payments';
  assert pg_temp.cnt('select 1 from public.payments') = 0, 'trainer sees no payments';
  assert pg_temp.cnt('select 1 from public.members') = 2, 'trainer sees gym members';

  -- direct insert into payments is closed for everyone (RPC only)
  perform pg_temp.as_user(uo);
  assert pg_temp.fails(format('insert into public.payments(gym_id,member_id,amount) values (%L,%L,5)', ga, m1), '42501'), 'direct payment insert blocked';
  assert pg_temp.cnt('select 1 from public.payments') = 2, 'owner sees both payments';

  -- ---------- renew membership
  j := public.renew_membership(m1, plan, 'cash');
  assert (j->'membership'->>'end_date')::date = (j->'membership'->>'start_date')::date + 29, 'end = start + 29 (30 days incl.)';
  assert (j->'payment'->>'amount')::numeric = 1000 and (j->'payment'->>'invoice_no') = 'TA-'||yr||'-0003', 'renew payment + invoice';
  j2 := public.renew_membership(m1, plan, 'upi', 900);
  assert (j2->'membership'->>'start_date')::date = (j->'membership'->>'end_date')::date + 1, 'second renewal extends';
  assert pg_temp.fails(format('select public.renew_membership(%L,%L)', m1, plan_b), 'P0002'), 'other gym plan rejected';

  -- ---------- tenant isolation
  perform pg_temp.as_user(uo2);
  assert pg_temp.cnt('select 1 from public.members') = 1, 'owner B sees only own members';
  assert pg_temp.cnt('select 1 from public.payments') = 0 and pg_temp.cnt('select 1 from public.memberships') = 0, 'owner B sees nothing of A';
  assert pg_temp.fails(format('select public.record_payment(%L, 10, %L)', m1, 'cash'), 'P0002'), 'cannot pay for other gym member';
  assert pg_temp.fails(format('select public.check_in(%L)', m1), 'P0002'), 'cannot check in other gym member';
  update public.gyms set upi_id = 'hack@upi' where id = ga;
  perform pg_temp.as_admin();
  assert (select upi_id from public.gyms where id = ga) is null, 'owner B cannot edit gym A';
  perform pg_temp.as_user(uo);
  assert pg_temp.fails(format('insert into public.memberships(gym_id,member_id,plan_id,end_date) values (%L,%L,%L,current_date)', ga, b1, plan), '42501'), 'memberships cannot be inserted directly';
  assert pg_temp.fails(format('update public.gyms set subscription_plan = %L where id = %L', 'enterprise', ga), '42501'), 'owner cannot change own subscription';
  update public.gyms set upi_id = 'fitness@upi', invoice_footer = 'Thanks' where id = ga;
  assert (public.my_gym()->>'upi_id') = 'fitness@upi', 'owner can edit invoice settings';

  -- ---------- member login claim
  perform pg_temp.as_user(ux);
  assert (public.claim_member_profile()->>'status') = 'not_found', 'unknown email not linked';
  assert (public.app_context()->>'role') is null, 'stranger has no role';
  assert pg_temp.cnt('select 1 from public.members') = 0, 'stranger sees nothing';
  perform pg_temp.as_user(um1);
  assert (public.claim_member_profile()->>'status') = 'linked', 'M1@x.com matches m1@x.com (case-insensitive)';
  assert (public.claim_member_profile()->>'status') = 'already_linked', 'second claim is idempotent';
  assert (public.app_context()->>'role') = 'member' and (public.app_context()->>'member_id')::uuid = m1, 'member context';
  perform pg_temp.as_user(um2);
  assert (public.claim_member_profile()->>'status') = 'linked', 'second member linked';

  -- ---------- member isolation
  perform pg_temp.as_user(um1);
  assert pg_temp.cnt('select 1 from public.members') = 1, 'member sees only self';
  assert pg_temp.cnt('select 1 from public.payments') = 3, 'member sees only own payments (3)';
  assert pg_temp.cnt('select 1 from public.memberships') = 2, 'member sees own memberships';
  assert pg_temp.cnt('select 1 from public.plans') = 1, 'member sees own gym plans only';
  assert pg_temp.cnt('select 1 from public.gym_users') = 0 and pg_temp.cnt('select 1 from public.audit_logs') = 0
     and pg_temp.cnt('select 1 from public.notifications') = 0 and pg_temp.cnt('select 1 from public.gyms') = 0, 'staff-only tables closed to members';
  assert pg_temp.fails(format('insert into public.members(gym_id,full_name,phone) values (%L,%L,%L)', ga, 'x', '1'), '42501'), 'member cannot add members';
  assert pg_temp.fails(format('select public.record_payment(%L, 5, %L)', m1, 'cash'), '42501'), 'member cannot record payments';
  assert pg_temp.fails('select public.owner_dashboard()', '42501'), 'member cannot open owner dashboard';
  assert pg_temp.fails('select public.expire_memberships()', '42501'), 'expire job not callable by users';
  assert (public.my_gym()->>'name') = 'Test Gym A', 'member can read own gym card';
  assert pg_temp.fails('delete from public.payments', '42501'), 'member cannot delete payments';
  perform pg_temp.as_admin();
  assert (select count(*) from public.payments where gym_id = ga) = 4, 'payments untouched';
  -- linking guard
  perform pg_temp.as_user(ur);
  assert pg_temp.fails(format('update public.members set user_id = %L where id = %L', ux, m2), '42501'), 'staff cannot link logins by hand';
  assert pg_temp.fails(format('insert into public.members(gym_id,full_name,phone,user_id) values (%L,%L,%L,%L)', ga, 'y', '9', ux), '42501'), 'staff cannot insert pre-linked member';

  -- ---------- attendance
  -- self check-in only with the code shown at the gym
  perform pg_temp.as_user(ur);
  j := public.gym_checkin_code(); code := j->>'code';
  assert length(code) = 8 and (j->>'seconds_left')::int between 0 and 300, 'staff can read the gym code';
  perform pg_temp.as_user(um1);
  assert pg_temp.fails('select public.gym_checkin_code()', '42501'), 'member cannot read the gym code';
  assert pg_temp.fails(format('select public.check_in(%L)', m1), '42501'), 'member cannot use the desk check-in';
  assert (public.self_check_in('WRONG123')->>'status') = 'bad_code', 'wrong code rejected';
  assert (public.self_check_in(code)->>'status') = 'checked_in', 'member self check-in with code';
  assert (public.self_check_in(lower(substr(code,1,4)) || ' ' || substr(code,5))->>'status') = 'already_checked_in', 'one check-in per day (code is case/space tolerant)';
  perform pg_temp.as_user(um2);
  assert (public.self_check_in(code)->>'status') = 'expired', 'member without plan cannot check in';
  perform pg_temp.as_user(ur);
  j := public.check_in(m2);
  assert (j->>'status') = 'expired', 'desk check-in warns about expired plan';
  j := public.check_in(m2, true);
  assert (j->>'status') = 'checked_in' and (j->>'membership_active')::boolean = false, 'desk can force a check-in';
  assert pg_temp.cnt('select 1 from public.attendance') = 2, 'staff sees gym attendance';
  assert pg_temp.fails(format('insert into public.attendance(gym_id,member_id) values (%L,%L)', ga, m1), '42501'), 'attendance cannot be inserted directly';
  assert pg_temp.fails('update public.attendance set check_in_at = now()', '42501'), 'attendance cannot be edited directly';
  j := public.check_out((select id from public.attendance where member_id = m2));
  assert (j->>'status') = 'checked_out', 'check-out';
  perform pg_temp.as_user(um1);
  assert pg_temp.cnt('select 1 from public.attendance') = 1, 'member sees own attendance only';
  perform pg_temp.as_user(um2);
  for i in 1..8 loop perform public.self_check_in('BAD' || i); end loop;
  assert (public.self_check_in(code)->>'status') = 'too_many_attempts', 'guessing the code is throttled';
  perform pg_temp.as_user(um1);

  -- ---------- tracking + weekly report
  insert into public.workout_logs(gym_id,member_id,exercise,minutes,kcal) values (ga,m1,'Squats',30,240);
  insert into public.weight_logs(gym_id,member_id,weight_kg) values (ga,m1,72.5);
  insert into public.water_logs(gym_id,member_id,ml) values (ga,m1,500);
  insert into public.member_goals(member_id,gym_id,weekly_workouts,water_ml) values (m1,ga,4,3000);
  assert pg_temp.fails(format('insert into public.workout_logs(gym_id,member_id,exercise,minutes) values (%L,%L,%L,10)', ga, m2, 'x'), '42501'), 'cannot log for another member';
  assert pg_temp.fails(format('insert into public.workout_logs(gym_id,member_id,exercise,minutes) values (%L,%L,%L,10)', gb, m1, 'x'), '23514'), 'cannot log into another gym';
  assert pg_temp.fails(format('insert into public.workout_logs(gym_id,member_id,exercise,minutes) values (%L,%L,%L,-5)', ga, m1, 'x'), '23514'), 'negative minutes rejected';
  j := public.weekly_report();
  assert (j->'totals'->>'workouts')::int = 1 and (j->'totals'->>'minutes')::numeric = 30 and (j->'totals'->>'kcal')::numeric = 240, 'weekly totals';
  assert (j->'totals'->>'gym_visits')::int = 1 and (j->'totals'->>'est_fat_loss_kg')::numeric = 0.03, 'visits + fat estimate';
  assert jsonb_array_length(j->'days') = 7 and (j->'weight'->>'end')::numeric = 72.5, '7 days + weight';
  assert (j->'goals'->>'weekly_workouts')::int = 4, 'goals included';
  assert pg_temp.fails(format('select public.weekly_report(%L)', m2), '42501'), 'member cannot read another report';
  perform pg_temp.as_user(um2);
  assert pg_temp.cnt('select 1 from public.workout_logs') = 0, 'member 2 cannot see member 1 logs';
  perform pg_temp.as_user(ut);
  assert pg_temp.cnt('select 1 from public.workout_logs') = 1, 'trainer sees member logs';
  assert (public.weekly_report(m1)->'totals'->>'workouts')::int = 1, 'trainer can open report';
  perform pg_temp.as_user(ur);
  assert pg_temp.cnt('select 1 from public.workout_logs') = 0, 'receptionist does not see workout logs';

  -- ---------- dashboard
  perform pg_temp.as_user(uo);
  j := public.owner_dashboard();
  assert (j->>'active_members')::int = 2 and (j->>'with_active_plan')::int = 1 and (j->>'without_plan')::int = 1, 'dashboard counts';
  assert (j->>'today_checkins')::int = 2 and (j->>'today_revenue')::numeric = 2650, 'dashboard checkins + revenue';
  perform pg_temp.as_user(ut);
  assert (public.owner_dashboard()->>'month_revenue') is null, 'trainer gets no revenue';

  -- ---------- strict role matrix
  perform pg_temp.as_user(ut);
  assert pg_temp.fails(format('insert into public.members(gym_id,full_name,phone) values (%L,%L,%L)', ga, 'T', '9000000001'), '42501') , 'trainer cannot add members';
  assert pg_temp.cnt('select 1 from public.members where phone = ''111''') = 1, 'trainer can read members';
  update public.members set full_name = 'Hacked' where id = m1;
  perform pg_temp.as_admin();
  assert (select full_name from public.members where id = m1) = 'Member One', 'trainer cannot edit members (0 rows)';
  perform pg_temp.as_user(ur);
  update public.members set full_name = 'Member 1 Renamed' where id = m1;
  perform pg_temp.as_admin();
  assert (select full_name from public.members where id = m1) = 'Member 1 Renamed', 'receptionist can edit members';
  perform pg_temp.as_user(ur);
  delete from public.members where id = m2;
  perform pg_temp.as_admin();
  assert exists (select 1 from public.members where id = m2), 'receptionist cannot delete members';
  perform pg_temp.as_user(ur);
  assert pg_temp.fails('update public.memberships set end_date = current_date + 999', '42501'), 'memberships cannot be edited directly';
  assert pg_temp.fails(format('insert into public.audit_logs(gym_id,action) values (%L,%L)', ga, 'forged'), '42501'), 'audit log cannot be forged';
  assert pg_temp.cnt('select 1 from public.audit_logs') = 0, 'only owner reads audit';
  assert pg_temp.fails(format('insert into public.plans(gym_id,name,duration_days,price) values (%L,%L,30,1)', ga, 'cheap'), '42501'), 'receptionist cannot create plans';
  assert pg_temp.fails('select * from public.gym_secrets', '42501') and pg_temp.fails('select * from public.invoice_counters', '42501') and pg_temp.fails('select * from public.rpc_throttle', '42501'), 'secret tables unreadable';
  assert not has_table_privilege('authenticated', 'public.members', 'TRUNCATE') and not has_table_privilege('authenticated', 'public.payments', 'INSERT'), 'no truncate / payment insert privilege';
  j := public.register_member('Rina Shah', '+91 98765 43210', 'Rina@X.com', plan);
  assert (j->>'status') = 'created' and (j->'payment') = 'null'::jsonb and (j->'membership'->>'status') = 'active', 'register_member creates member + plan, no payment';
  assert (public.register_member('Rina Shah', '9876543210', 'rina2@x.com', plan)->>'status') = 'duplicate', 'duplicate phone with active plan';
  assert (public.register_member('Other Person', '9123456789', 'rina@x.com', plan)->>'status') = 'email_taken', 'duplicate email rejected';
  assert pg_temp.fails(format('select public.register_member(%L,%L,%L,%L)', 'X', '123', 'a@b.co', plan), '22023'), 'bad input rejected';
  j := public.register_member('Paid Joiner', '9000011111', 'paid@x.com', plan, true, 'upi', 'UTR9');
  assert (j->'payment'->>'amount')::numeric = 1000 and (j->'payment'->>'invoice_no') like 'TA-%', 'register with payment';
  perform pg_temp.as_user(ut);
  assert pg_temp.fails(format('select public.register_member(%L,%L,%L,%L)', 'Nope Nope', '9000022222', 'n@x.com', plan), '42501'), 'trainer cannot register';
  perform pg_temp.as_user(ur);
  assert pg_temp.fails(format('select public.set_membership_status(%L, %L)', (select id from public.memberships limit 1), 'cancelled'), '42501'), 'receptionist cannot cancel plans';
  perform pg_temp.as_user(uo);
  assert (public.set_membership_status((select id from public.memberships where member_id = m1 order by start_date limit 1), 'paused')->>'status') = 'paused', 'owner can pause a plan';
  -- last owner guard
  assert pg_temp.fails(format('update public.gym_users set is_active = false where user_id = %L', uo), '23514'), 'cannot remove the only owner';
  insert into public.gym_users(user_id, gym_id, role) values (um2, ga, 'trainer');
  assert pg_temp.fails(format('update public.gym_users set gym_id = %L where user_id = %L', gb, um2), '42501'), 'cannot move staff across gyms';
  update public.gym_users set role = 'receptionist' where user_id = um2;
  assert (select role from public.gym_users where user_id = um2) = 'receptionist', 'owner manages staff';
  perform pg_temp.as_user(uo2);
  assert pg_temp.cnt('select 1 from public.gym_users') = 1, 'owner B sees only own staff';
  perform pg_temp.as_user(um1);
  assert pg_temp.fails(format('insert into public.workout_logs(gym_id,member_id,exercise,minutes,logged_at) values (%L,%L,%L,10,now() + interval ''10 days'')', ga, m1, 'x'), '23514'), 'future workout rejected';
  assert pg_temp.fails(format('insert into public.gym_users(user_id,gym_id,role) values (%L,%L,%L)', um1, ga, 'owner'), '42501'), 'member cannot make themselves staff';

  -- ---------- payment claims (member says "I paid", staff confirms)
  perform pg_temp.as_user(um1);
  assert pg_temp.fails(format('insert into public.payment_claims(gym_id,member_id,plan_id,amount) values (%L,%L,%L,1)', ga, m1, plan), '42501'), 'claims cannot be inserted directly';
  assert pg_temp.fails(format('select public.submit_payment_claim(%L, %L)', plan, 'bad utr!'), '22023'), 'bad UTR rejected';
  j := public.submit_payment_claim(plan, 'UTR123456789');
  assert (j->>'status') = 'submitted' and (j->'claim'->>'amount')::numeric = 1000, 'claim amount comes from the plan price';
  assert (public.submit_payment_claim(plan)->>'status') = 'already_pending', 'one pending claim per member';
  assert pg_temp.cnt('select 1 from public.payment_claims') = 1, 'member sees own claim';
  assert pg_temp.fails(format('select public.resolve_payment_claim(%L, true)', (j->'claim'->>'id')::uuid), '42501'), 'member cannot confirm own claim';
  perform pg_temp.as_user(ux);
  assert pg_temp.cnt('select 1 from public.payment_claims') = 0, 'unrelated user sees no claims';
  perform pg_temp.as_user(ut);
  assert pg_temp.cnt('select 1 from public.payment_claims') = 0, 'trainer sees no claims';
  perform pg_temp.as_user(uo2);
  assert pg_temp.fails(format('select public.resolve_payment_claim(%L, true)', (j->'claim'->>'id')::uuid), 'P0002'), 'other gym cannot resolve';
  perform pg_temp.as_user(ur);
  assert pg_temp.cnt('select 1 from public.payment_claims where status = ''pending''') = 1, 'receptionist sees pending claims';
  j2 := public.resolve_payment_claim((j->'claim'->>'id')::uuid, true);
  assert (j2->>'status') = 'confirmed' and (j2->'payment'->>'invoice_no') like 'TA-%' and (j2->'payment'->>'reference_no') = 'UTR123456789', 'confirm records payment + invoice';
  assert (public.resolve_payment_claim((j->'claim'->>'id')::uuid, true)->>'status') = 'already_confirmed', 'confirm is idempotent';
  perform pg_temp.as_user(um1);
  j := public.submit_payment_claim(plan);
  perform pg_temp.as_user(uo);
  assert (public.resolve_payment_claim((j->'claim'->>'id')::uuid, false)->>'status') = 'rejected', 'owner can reject';
  assert pg_temp.cnt('select 1 from public.payments where gym_id = ' || quote_literal(ga)) = 6, 'only confirmed claim created a payment';

  -- ---------- audit + anon + expiry job
  perform pg_temp.as_user(uo);
  assert pg_temp.cnt('select 1 from public.audit_logs where table_name = ''payments''') = 6, 'audit trail for payments';
  perform pg_temp.as_admin();
  execute 'set local role anon';
  assert pg_temp.fails('select 1 from public.members', '42501'), 'anon has no table access';
  assert pg_temp.fails('select public.app_context()', '42501'), 'anon cannot call RPC';
  perform pg_temp.as_admin();
  update public.memberships set end_date = current_date - 5 where member_id = m1 and status = 'active';
  assert public.expire_memberships() >= 1, 'expiry job marks old memberships';

  raise exception 'ALL TESTS PASSED (rolled back on purpose)';
end $$;
