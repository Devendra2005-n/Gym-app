# GYM Flow backend (Supabase / Postgres)

Project: `gymflow-ai` (ap-southeast-2). URL `https://qkedgztqvzoldgpawlyw.supabase.co` (the anon/publishable key is safe in the app; never put the service-role key in the app).

## Files
- `migrations/0002_app_backend.sql`, `0003_function_search_path.sql` – already applied on the live project. Additive: existing gyms/members/plans/memberships data untouched.
- `tests/00_local_baseline.sql` – local-only copy of the pre-existing schema (for plain Postgres).
- `tests/10_backend_tests.sql` – 60+ assertions (roles, RLS, RPC). Runs in one transaction that always rolls back; last message must be `ALL TESTS PASSED`.

## Roles
| Who | How identified | Can do |
|---|---|---|
| owner | `gym_users.role='owner'` | everything in own gym, payments, plans, staff, dashboard |
| receptionist | `gym_users.role='receptionist'` | members, memberships, payments, attendance |
| trainer | `gym_users.role='trainer'` | members, attendance, member workout logs; no payments |
| member | `members.user_id = auth.uid()` | only own profile, plan, payments, attendance, logs |
Every row has `gym_id`; one gym can never read another gym's rows.

## Functions the app calls (`supabase.rpc(name, args)`)
`app_context()` role + gym + member id · `claim_member_profile()` link Google login to member by verified email · `my_gym()` · `renew_membership(p_member_id,p_plan_id,p_method,p_amount,p_start)` membership + payment + invoice no · `record_payment(...)` · `check_in(p_member_id?)` (member: self, staff: any) · `owner_dashboard()` · `weekly_report(p_member_id?, p_week_start?)`.
Direct table access (RLS-protected): members, plans, memberships, attendance (staff); workout_logs, weight_logs, water_logs, member_goals (member own rows).

## Onboarding
- New staff: owner adds a `gym_users` row (user must have signed in once).
- New member: staff adds the member **with e-mail**; when that person signs in with the same Google e-mail the app calls `claim_member_profile()`.
- New gym: created by the platform admin (SQL / future Super Admin panel), not self-serve.

## Still to do on the dashboard (cannot be done from SQL)
Enable Google provider (Authentication → Providers), add the Android redirect, enable leaked-password protection, upgrade to Pro before going live.
