-- Automatic WhatsApp invoice: one delivery record per payment so an invoice is never sent twice.
create table if not exists public.invoice_deliveries (
  payment_id uuid primary key references public.payments(id) on delete cascade,
  gym_id uuid not null references public.gyms(id) on delete cascade,
  status text not null check (status in ('sending', 'sent', 'failed', 'not_configured', 'no_phone')),
  attempts int not null default 1,
  wa_message_id text,
  error text check (error is null or char_length(error) <= 500),
  updated_at timestamptz not null default now());
create index if not exists invoice_deliveries_gym_idx on public.invoice_deliveries(gym_id, updated_at desc);
alter table public.invoice_deliveries enable row level security;
create policy invoice_deliveries_staff_view on public.invoice_deliveries for select to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner', 'receptionist'));
revoke all on public.invoice_deliveries from anon, authenticated;
grant select on public.invoice_deliveries to authenticated;

-- Called only by the send-invoice Edge Function (service role). True = this caller should send now.
create or replace function public.claim_invoice_delivery(p_payment uuid, p_force boolean default false) returns boolean
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_gym uuid; v_n int;
begin
  select gym_id into v_gym from payments where id = p_payment;
  if v_gym is null then return false; end if;
  insert into invoice_deliveries(payment_id, gym_id, status) values (p_payment, v_gym, 'sending') on conflict do nothing;
  get diagnostics v_n = row_count;
  if v_n = 1 then return true; end if;
  update invoice_deliveries set status = 'sending', attempts = attempts + 1, error = null, updated_at = now()
   where payment_id = p_payment
     and ( (status in ('failed', 'not_configured', 'no_phone') and p_force)
        or (status = 'sending' and updated_at < now() - interval '5 minutes') );   -- a crashed attempt may be retaken
  get diagnostics v_n = row_count;
  return v_n = 1;
end $$;
revoke all on function public.claim_invoice_delivery(uuid, boolean) from public, anon, authenticated;
grant execute on function public.claim_invoice_delivery(uuid, boolean) to service_role;
