-- Trigger function: only the trigger needs it, nobody should call it through the API.
revoke execute on function public.gallery_same_gym() from public, anon, authenticated;
