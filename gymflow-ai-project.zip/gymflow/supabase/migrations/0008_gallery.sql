-- Gym gallery: owner creates sections (Zumba, Functional...) and adds photos/videos; members and other staff can only view.
create table if not exists public.gallery_sections (
  id uuid primary key default gen_random_uuid(),
  gym_id uuid not null references public.gyms(id) on delete cascade,
  name text not null check (char_length(btrim(name)) between 1 and 40),
  created_at timestamptz not null default now());
create unique index if not exists gallery_sections_name_uq on public.gallery_sections(gym_id, lower(btrim(name)));
create table if not exists public.gallery_items (
  id uuid primary key default gen_random_uuid(),
  gym_id uuid not null references public.gyms(id) on delete cascade,
  section_id uuid not null references public.gallery_sections(id) on delete cascade,
  kind text not null check (kind in ('photo', 'video')),
  path text not null check (path like gym_id::text || '/%' and char_length(path) < 200),
  caption text check (caption is null or char_length(caption) <= 120),
  size_bytes bigint check (size_bytes is null or size_bytes between 1 and 52428800),
  created_at timestamptz not null default now());
create index if not exists gallery_items_section_idx on public.gallery_items(section_id, created_at desc);

create or replace function public.gallery_same_gym() returns trigger language plpgsql
security definer set search_path = public, pg_temp as $$
begin
  if not exists (select 1 from gallery_sections where id = new.section_id and gym_id = new.gym_id) then
    raise exception 'section belongs to another gym' using errcode = '23514'; end if;
  return new;
end $$;
drop trigger if exists trg_gallery_same_gym on public.gallery_items;
create trigger trg_gallery_same_gym before insert or update on public.gallery_items for each row execute function public.gallery_same_gym();

alter table public.gallery_sections enable row level security;
alter table public.gallery_items enable row level security;
-- everyone in the gym (all staff roles and members) may view
create policy gallery_sections_view on public.gallery_sections for select to authenticated
  using (gym_id = coalesce(get_my_gym_id(), my_member_gym_id()));
create policy gallery_items_view on public.gallery_items for select to authenticated
  using (gym_id = coalesce(get_my_gym_id(), my_member_gym_id()));
-- only the owner changes anything
create policy gallery_sections_owner_ins on public.gallery_sections for insert to authenticated
  with check (gym_id = get_my_gym_id() and has_staff_role('owner'));
create policy gallery_sections_owner_upd on public.gallery_sections for update to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner')) with check (gym_id = get_my_gym_id());
create policy gallery_sections_owner_del on public.gallery_sections for delete to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner'));
create policy gallery_items_owner_ins on public.gallery_items for insert to authenticated
  with check (gym_id = get_my_gym_id() and has_staff_role('owner'));
create policy gallery_items_owner_upd on public.gallery_items for update to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner')) with check (gym_id = get_my_gym_id());
create policy gallery_items_owner_del on public.gallery_items for delete to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner'));
revoke all on public.gallery_sections, public.gallery_items from anon, authenticated;
grant select on public.gallery_sections, public.gallery_items to authenticated;
grant insert (gym_id, name), update (name), delete on public.gallery_sections to authenticated;
grant insert (gym_id, section_id, kind, path, caption, size_bytes), update (caption), delete on public.gallery_items to authenticated;
