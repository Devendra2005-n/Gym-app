-- GYM Flow backend v2: strict RLS + least privilege + server-side check-in code.
-- Principle: clients may only read what their role needs; money, memberships and attendance change ONLY through RPCs.

----------------------------------------------------------------- columns / tables
alter table public.gyms
  add column if not exists payee_name text,
  add column if not exists gstin text check (gstin is null or gstin ~ '^[0-9A-Z]{15}$'),
  add column if not exists gst_pct numeric check (gst_pct is null or gst_pct between 0 and 28);
alter table public.workout_logs add column if not exists client_id text;
create unique index if not exists workout_logs_client_key on public.workout_logs(member_id, client_id) where client_id is not null;
create unique index if not exists members_gym_phone_key on public.members(gym_id, phone);
-- (email uniqueness is enforced inside register_member(); the live data already had two members with one e-mail)

create table if not exists public.gym_secrets (
  gym_id uuid primary key references public.gyms(id) on delete cascade,
  checkin_secret text not null default (gen_random_uuid()::text || gen_random_uuid()::text));
insert into public.gym_secrets(gym_id) select id from public.gyms on conflict do nothing;
create table if not exists public.rpc_throttle (
  id bigserial primary key, user_id uuid not null, kind text not null, at timestamptz not null default now());
create index if not exists rpc_throttle_idx on public.rpc_throttle(user_id, kind, at);
alter table public.gym_secrets  enable row level security;   -- no policies, no grants: definer functions only
alter table public.rpc_throttle enable row level security;

----------------------------------------------------------------- guards
create or replace function public.guard_last_owner() returns trigger language plpgsql
security definer set search_path = public, pg_temp as $$
begin
  if auth.uid() is not null and old.role = 'owner' and old.is_active
     and (tg_op = 'DELETE' or new.role <> 'owner' or not new.is_active) then
    if not exists (select 1 from gym_users where gym_id = old.gym_id and role = 'owner' and is_active and id <> old.id) then
      raise exception 'a gym must keep at least one active owner' using errcode = '23514'; end if;
  end if;
  return case when tg_op = 'DELETE' then old else new end;
end $$;
drop trigger if exists trg_last_owner on public.gym_users;
create trigger trg_last_owner before update or delete on public.gym_users for each row execute function public.guard_last_owner();

create or replace function public.guard_log_time() returns trigger language plpgsql
set search_path = public, pg_temp as $$
declare t timestamptz := case when tg_table_name = 'weight_logs' then (to_jsonb(new)->>'logged_on')::timestamptz else (to_jsonb(new)->>'logged_at')::timestamptz end;
begin
  if auth.uid() is not null and (t < now() - interval '60 days' or t > now() + interval '1 day') then
    raise exception 'log date is out of range' using errcode = '23514'; end if;
  return new;
end $$;
do $$ declare t text; begin
  foreach t in array array['workout_logs','water_logs','weight_logs'] loop
    execute format('drop trigger if exists trg_log_time on public.%I', t);
    execute format('create trigger trg_log_time before insert or update on public.%I for each row execute function public.guard_log_time()', t);
  end loop; end $$;

----------------------------------------------------------------- RLS: rebuilt from scratch
do $$ declare r record; begin
  for r in select tablename, policyname from pg_policies where schemaname = 'public' loop
    execute format('drop policy %I on public.%I', r.policyname, r.tablename);
  end loop; end $$;

create policy gyms_staff_select on public.gyms for select to authenticated using (id = get_my_gym_id());
create policy gyms_owner_update on public.gyms for update to authenticated
  using (id = get_my_gym_id() and has_staff_role('owner')) with check (id = get_my_gym_id() and has_staff_role('owner'));

create policy gym_users_select on public.gym_users for select to authenticated
  using (user_id = auth.uid() or (gym_id = get_my_gym_id() and has_staff_role('owner')));
create policy gym_users_owner_insert on public.gym_users for insert to authenticated with check (gym_id = get_my_gym_id() and has_staff_role('owner'));
create policy gym_users_owner_update on public.gym_users for update to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner')) with check (gym_id = get_my_gym_id() and has_staff_role('owner'));
create policy gym_users_owner_delete on public.gym_users for delete to authenticated using (gym_id = get_my_gym_id() and has_staff_role('owner'));

create policy plans_staff_select  on public.plans for select to authenticated using (gym_id = get_my_gym_id());
create policy plans_member_select on public.plans for select to authenticated using (gym_id = my_member_gym_id());
create policy plans_owner_insert  on public.plans for insert to authenticated with check (gym_id = get_my_gym_id() and has_staff_role('owner'));
create policy plans_owner_update  on public.plans for update to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner')) with check (gym_id = get_my_gym_id() and has_staff_role('owner'));
create policy plans_owner_delete  on public.plans for delete to authenticated using (gym_id = get_my_gym_id() and has_staff_role('owner'));

create policy members_staff_select on public.members for select to authenticated using (gym_id = get_my_gym_id());
create policy members_self_select  on public.members for select to authenticated using (user_id = auth.uid());
create policy members_front_insert on public.members for insert to authenticated with check (gym_id = get_my_gym_id() and has_staff_role('owner', 'receptionist'));
create policy members_front_update on public.members for update to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner', 'receptionist')) with check (gym_id = get_my_gym_id() and has_staff_role('owner', 'receptionist'));
create policy members_owner_delete on public.members for delete to authenticated using (gym_id = get_my_gym_id() and has_staff_role('owner'));

create policy memberships_staff_select on public.memberships for select to authenticated using (gym_id = get_my_gym_id());
create policy memberships_self_select  on public.memberships for select to authenticated using (member_id = my_member_id());

create policy payments_front_select on public.payments for select to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner', 'receptionist'));
create policy payments_self_select  on public.payments for select to authenticated using (member_id = my_member_id());

create policy attendance_staff_select on public.attendance for select to authenticated using (gym_id = get_my_gym_id());
create policy attendance_self_select  on public.attendance for select to authenticated using (member_id = my_member_id());
create policy attendance_owner_delete on public.attendance for delete to authenticated using (gym_id = get_my_gym_id() and has_staff_role('owner'));

create policy notifications_front_select on public.notifications for select to authenticated using (gym_id = get_my_gym_id() and has_staff_role('owner', 'receptionist'));
create policy notifications_front_insert on public.notifications for insert to authenticated with check (gym_id = get_my_gym_id() and has_staff_role('owner', 'receptionist'));

create policy audit_owner_select on public.audit_logs for select to authenticated using (gym_id = get_my_gym_id() and has_staff_role('owner'));

do $$ declare t text; begin
  foreach t in array array['workout_logs','weight_logs','water_logs','member_goals'] loop
    execute format($p$create policy %I on public.%I for all to authenticated using (member_id = my_member_id())
        with check (member_id = my_member_id() and gym_id = my_member_gym_id())$p$, t || '_member_own', t);
    execute format($p$create policy %I on public.%I for select to authenticated
        using (gym_id = get_my_gym_id() and has_staff_role('owner', 'trainer'))$p$, t || '_staff_select', t);
  end loop; end $$;

----------------------------------------------------------------- table privileges (least privilege)
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
grant select on public.gyms, public.gym_users, public.plans, public.members, public.memberships, public.payments, public.attendance,
  public.notifications, public.audit_logs, public.workout_logs, public.weight_logs, public.water_logs, public.member_goals to authenticated;
grant update (name, owner_name, phone, address, city, logo_url, upi_id, payee_name, gstin, gst_pct, invoice_prefix, invoice_footer) on public.gyms to authenticated;
grant insert (user_id, gym_id, role) on public.gym_users to authenticated;
grant update (role, is_active) on public.gym_users to authenticated;
grant delete on public.gym_users to authenticated;
grant insert, update, delete on public.plans to authenticated;
grant insert (gym_id, full_name, phone, email, date_of_birth, gender, address, photo_url, emergency_contact, health_notes, join_date, is_active) on public.members to authenticated;
grant update (full_name, phone, email, date_of_birth, gender, address, photo_url, emergency_contact, health_notes, join_date, is_active) on public.members to authenticated;
grant delete on public.members to authenticated;
grant delete on public.attendance to authenticated;
grant insert on public.notifications to authenticated;
grant insert, update, delete on public.workout_logs, public.weight_logs, public.water_logs, public.member_goals to authenticated;
alter default privileges in schema public revoke all on tables from anon, authenticated;
alter default privileges in schema public revoke all on sequences from anon, authenticated;
alter default privileges in schema public revoke execute on functions from anon, public;

----------------------------------------------------------------- RPC changes
drop function if exists public.check_in(uuid, text);

create or replace function public._gym_secret(p_gym uuid) returns text
language plpgsql security definer set search_path = public, pg_temp as $$
declare s text;
begin
  insert into gym_secrets(gym_id) values (p_gym) on conflict do nothing;
  select checkin_secret into s from gym_secrets where gym_id = p_gym;
  return s;
end $$;

create or replace function public._code_for(p_gym uuid, p_bucket bigint) returns text
language sql stable security definer set search_path = public, pg_temp
as $$ select substr(upper(md5(public._gym_secret(p_gym) || ':' || p_bucket)), 1, 8) $$;

create or replace function public._do_check_in(p_member members, p_source text, p_force boolean) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare ms memberships; a attendance; v_today date := ist_today();
begin
  select * into a from attendance where member_id = p_member.id and attendance_date = v_today;
  if found then
    return jsonb_build_object('status', 'already_checked_in', 'member_id', p_member.id, 'member_name', p_member.full_name,
      'time', to_char(a.check_in_at at time zone 'Asia/Kolkata', 'HH24:MI')); end if;
  select * into ms from memberships where member_id = p_member.id and status = 'active' and start_date <= v_today and end_date >= v_today
    order by end_date desc limit 1;
  if ms.id is null and not p_force then
    return jsonb_build_object('status', 'expired', 'member_id', p_member.id, 'member_name', p_member.full_name); end if;
  insert into attendance(gym_id, member_id, membership_id, source, recorded_by)
  values (p_member.gym_id, p_member.id, ms.id, p_source, auth.uid())
  on conflict (member_id, attendance_date) do nothing returning * into a;
  if a.id is null then select * into a from attendance where member_id = p_member.id and attendance_date = v_today; end if;
  return jsonb_build_object('status', 'checked_in', 'member_id', p_member.id, 'member_name', p_member.full_name,
    'membership_active', ms.id is not null, 'time', to_char(a.check_in_at at time zone 'Asia/Kolkata', 'HH24:MI'));
end $$;

-- staff desk: check a member in (manual / scanned member card)
create or replace function public.check_in(p_member_id uuid, p_force boolean default false, p_source text default 'manual') returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare m members;
begin
  if not has_staff_role('owner', 'receptionist', 'trainer') then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into m from members where id = p_member_id and gym_id = get_my_gym_id() and is_active;
  if not found then raise exception 'member not found' using errcode = 'P0002'; end if;
  return _do_check_in(m, case when p_source in ('manual', 'card') then p_source else 'manual' end, coalesce(p_force, false));
end $$;

-- staff phone shows this QR/code; it changes every 5 minutes
create or replace function public.gym_checkin_code() returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare g uuid := get_my_gym_id(); b bigint := floor(extract(epoch from now()) / 300)::bigint;
begin
  if g is null or not has_staff_role('owner', 'receptionist', 'trainer') then raise exception 'not allowed' using errcode = '42501'; end if;
  return jsonb_build_object('code', _code_for(g, b), 'bucket', b, 'seconds_left', ((b + 1) * 300 - floor(extract(epoch from now())))::int,
                            'gym', (select name from gyms where id = g));
end $$;

-- member scans the gym QR; the server checks the code, so a member cannot check in from home
create or replace function public.self_check_in(p_code text) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare m members; v_user uuid := auth.uid(); v_code text; b bigint := floor(extract(epoch from now()) / 300)::bigint;
begin
  if v_user is null then raise exception 'not authenticated' using errcode = '28000'; end if;
  select * into m from members where user_id = v_user and is_active;
  if not found then raise exception 'no member profile' using errcode = 'P0002'; end if;
  delete from rpc_throttle where at < now() - interval '1 day';
  if (select count(*) from rpc_throttle where user_id = v_user and kind = 'bad_code' and at > now() - interval '10 minutes') >= 8 then
    return jsonb_build_object('status', 'too_many_attempts'); end if;
  v_code := upper(regexp_replace(coalesce(p_code, ''), '[^A-Za-z0-9]', '', 'g'));
  if v_code = '' or not (v_code = _code_for(m.gym_id, b) or v_code = _code_for(m.gym_id, b - 1)) then
    insert into rpc_throttle(user_id, kind) values (v_user, 'bad_code');
    return jsonb_build_object('status', 'bad_code'); end if;
  return _do_check_in(m, 'self', false);
end $$;

create or replace function public.check_out(p_attendance_id uuid) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare a attendance;
begin
  if not has_staff_role('owner', 'receptionist', 'trainer') then raise exception 'not allowed' using errcode = '42501'; end if;
  update attendance set check_out_at = now() where id = p_attendance_id and gym_id = get_my_gym_id() and check_out_at is null returning * into a;
  if a.id is null then raise exception 'visit not found or already checked out' using errcode = 'P0002'; end if;
  return jsonb_build_object('status', 'checked_out', 'attendance_id', a.id);
end $$;

create or replace function public.register_member(p_name text, p_phone text, p_email text, p_plan_id uuid,
  p_collect boolean default false, p_method text default 'cash', p_reference text default null) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare g uuid := get_my_gym_id(); v_name text := regexp_replace(btrim(coalesce(p_name, '')), '\s+', ' ', 'g');
        v_phone text := regexp_replace(coalesce(p_phone, ''), '\D', '', 'g'); v_email text := lower(btrim(coalesce(p_email, '')));
        m members; v_new boolean := false; r jsonb;
begin
  if not has_staff_role('owner', 'receptionist') then raise exception 'not allowed' using errcode = '42501'; end if;
  if length(v_phone) = 12 and left(v_phone, 2) = '91' then v_phone := right(v_phone, 10); end if;
  if length(v_name) < 2 or length(v_name) > 80 then raise exception 'name must be 2 to 80 characters' using errcode = '22023'; end if;
  if v_phone !~ '^[6-9][0-9]{9}$' then raise exception 'phone must be a 10-digit Indian mobile number' using errcode = '22023'; end if;
  if v_email !~ '^[^\s@]+@[^\s@]+\.[^\s@]+$' then raise exception 'email is not valid' using errcode = '22023'; end if;
  if not exists (select 1 from plans where id = p_plan_id and gym_id = g and is_active) then raise exception 'plan not found' using errcode = 'P0002'; end if;
  select * into m from members where gym_id = g and phone = v_phone;
  if not found and exists (select 1 from members where gym_id = g and lower(email) = v_email) then
    return jsonb_build_object('status', 'email_taken'); end if;
  if found then
    if exists (select 1 from memberships where member_id = m.id and status = 'active' and end_date >= ist_today()) then
      return jsonb_build_object('status', 'duplicate', 'member', jsonb_build_object('id', m.id, 'full_name', m.full_name, 'phone', m.phone)); end if;
  else
    begin
      insert into members(gym_id, full_name, phone, email) values (g, v_name, v_phone, v_email) returning * into m;
      v_new := true;
    exception when unique_violation then
      return jsonb_build_object('status', 'email_taken'); end;
  end if;
  r := renew_membership(m.id, p_plan_id, coalesce(p_method, 'cash'), case when p_collect then null else 0 end, null, p_reference, null);
  return jsonb_build_object('status', case when v_new then 'created' else 'renewed_existing' end,
    'member', to_jsonb(m) - 'health_notes' - 'user_id', 'membership', r->'membership', 'payment', r->'payment');
end $$;

create or replace function public.set_membership_status(p_id uuid, p_status text) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare ms memberships;
begin
  if not has_staff_role('owner') then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_status not in ('active', 'paused', 'cancelled') then raise exception 'status must be active, paused or cancelled' using errcode = '22023'; end if;
  update memberships set status = p_status where id = p_id and gym_id = get_my_gym_id() returning * into ms;
  if ms.id is null then raise exception 'membership not found' using errcode = 'P0002'; end if;
  return to_jsonb(ms);
end $$;

create or replace function public.my_gym() returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select to_jsonb(g) from (select id, name, phone, address, city, upi_id, payee_name, gstin, gst_pct, invoice_prefix, invoice_footer
                           from gyms where id = coalesce(get_my_gym_id(), my_member_gym_id())) g $$;

----------------------------------------------------------------- function privileges (only these are callable by signed-in users)
do $$ declare f record; begin
  for f in select p.oid::regprocedure sig, p.proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.prokind = 'f' loop
    execute format('revoke execute on function %s from public, anon', f.sig);
    if f.proname in ('app_context','my_gym','claim_member_profile','record_payment','renew_membership','check_in','gym_checkin_code','self_check_in',
                     'check_out','register_member','set_membership_status','owner_dashboard','weekly_report',
                     'get_my_gym_id','get_my_role','has_staff_role','my_member_id','my_member_gym_id','ist_today') then
      execute format('grant execute on function %s to authenticated', f.sig);
    else
      execute format('revoke execute on function %s from authenticated', f.sig);
    end if;
    execute format('grant execute on function %s to service_role', f.sig);
  end loop; end $$;
