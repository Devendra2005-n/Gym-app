-- Self sign-up: a verified Google account becomes a MEMBER of the gym automatically.
-- Staff status is never granted here (only gym_users rows, added by the platform admin).
create or replace function public.register_self(p_name text, p_phone text) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_email text; v_conf timestamptz; v_gym uuid; c jsonb; m members;
        v_name text := btrim(coalesce(p_name, '')); v_phone text := regexp_replace(coalesce(p_phone, ''), '\D', '', 'g');
begin
  if auth.uid() is null then raise exception 'not authenticated' using errcode = '28000'; end if;
  c := claim_member_profile();                       -- already a member / staff / matching e-mail on file
  if (c->>'status') in ('linked', 'already_linked', 'staff', 'email_not_verified', 'ambiguous') then return c; end if;
  select email, email_confirmed_at into v_email, v_conf from auth.users where id = auth.uid();
  if char_length(v_name) < 2 or char_length(v_name) > 80 then raise exception 'name must be 2 to 80 characters' using errcode = '22023'; end if;
  if length(v_phone) > 10 then v_phone := right(v_phone, 10); end if;
  if v_phone !~ '^[6-9][0-9]{9}$' then raise exception 'enter a valid 10-digit mobile number' using errcode = '22023'; end if;
  select id into v_gym from gyms where is_active order by created_at limit 1;
  if v_gym is null then raise exception 'gym not found' using errcode = 'P0002'; end if;
  if exists (select 1 from members where gym_id = v_gym and phone = v_phone) then
    return jsonb_build_object('status', 'phone_taken'); end if;
  perform set_config('gymflow.claiming', 'on', true);
  insert into members(gym_id, full_name, phone, email, user_id, join_date) values (v_gym, v_name, v_phone, lower(v_email), auth.uid(), public.ist_today()) returning * into m;
  perform set_config('gymflow.claiming', 'off', true);
  return jsonb_build_object('status', 'created', 'member_id', m.id, 'gym_id', m.gym_id);
end $$;
revoke execute on function public.register_self(text, text) from public, anon;
grant execute on function public.register_self(text, text) to authenticated;
