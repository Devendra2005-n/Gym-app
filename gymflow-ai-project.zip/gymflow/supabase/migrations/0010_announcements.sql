-- Gym announcements: owner posts, everyone in the gym (staff + members) can read. Members get repeating reminders in the app.
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  gym_id uuid not null references public.gyms(id) on delete cascade,
  title text not null check (char_length(btrim(title)) between 1 and 80),
  body text not null check (char_length(btrim(body)) between 1 and 2000),
  ends_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now());
create index if not exists announcements_gym_idx on public.announcements(gym_id, created_at desc);

create or replace function public.announcements_touch() returns trigger language plpgsql
set search_path = public, pg_temp as $$
begin new.updated_at := now(); return new; end $$;
drop trigger if exists trg_announcements_touch on public.announcements;
create trigger trg_announcements_touch before update on public.announcements for each row execute function public.announcements_touch();

alter table public.announcements enable row level security;
create policy announcements_view on public.announcements for select to authenticated
  using (gym_id = coalesce(get_my_gym_id(), my_member_gym_id()));
create policy announcements_owner_ins on public.announcements for insert to authenticated
  with check (gym_id = get_my_gym_id() and has_staff_role('owner'));
create policy announcements_owner_upd on public.announcements for update to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner')) with check (gym_id = get_my_gym_id());
create policy announcements_owner_del on public.announcements for delete to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner'));
revoke all on public.announcements from anon, authenticated;
grant select on public.announcements to authenticated;
grant insert (gym_id, title, body, ends_at), update (title, body, ends_at), delete on public.announcements to authenticated;
