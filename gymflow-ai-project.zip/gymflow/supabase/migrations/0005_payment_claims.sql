-- Member says "I paid" -> owner / receptionist verifies the money arrived and confirms with one tap.
-- Amount always comes from the plan price on the server, so a member cannot invent an amount.
create table if not exists public.payment_claims (
  id uuid primary key default gen_random_uuid(),
  gym_id uuid not null references public.gyms(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete cascade,
  plan_id uuid not null references public.plans(id),
  amount numeric not null check (amount > 0),
  utr text check (utr is null or utr ~ '^[A-Za-z0-9]{6,30}$'),
  status text not null default 'pending' check (status in ('pending', 'confirmed', 'rejected')),
  payment_id uuid references public.payments(id),
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  resolved_by uuid references auth.users(id));
create unique index if not exists payment_claims_one_pending on public.payment_claims(member_id) where status = 'pending';
create index if not exists payment_claims_gym_idx on public.payment_claims(gym_id, status, created_at desc);
alter table public.payment_claims enable row level security;
drop trigger if exists trg_same_gym on public.payment_claims;
create trigger trg_same_gym before insert or update on public.payment_claims for each row execute function public.enforce_same_gym();
create policy payment_claims_front_select on public.payment_claims for select to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner', 'receptionist'));
create policy payment_claims_self_select on public.payment_claims for select to authenticated using (member_id = my_member_id());
revoke all on public.payment_claims from anon, authenticated;
grant select on public.payment_claims to authenticated;

create or replace function public.submit_payment_claim(p_plan_id uuid, p_utr text default null) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare m members; pl plans; c payment_claims; v_utr text := nullif(btrim(coalesce(p_utr, '')), '');
begin
  select * into m from members where user_id = auth.uid() and is_active;
  if not found then raise exception 'no member profile' using errcode = 'P0002'; end if;
  select * into pl from plans where id = p_plan_id and gym_id = m.gym_id and is_active;
  if not found then raise exception 'plan not found' using errcode = 'P0002'; end if;
  if v_utr is not null and v_utr !~ '^[A-Za-z0-9]{6,30}$' then raise exception 'UTR must be 6 to 30 letters/digits' using errcode = '22023'; end if;
  if exists (select 1 from payment_claims where member_id = m.id and status = 'pending') then
    return jsonb_build_object('status', 'already_pending'); end if;
  insert into payment_claims(gym_id, member_id, plan_id, amount, utr) values (m.gym_id, m.id, pl.id, pl.price, v_utr) returning * into c;
  return jsonb_build_object('status', 'submitted', 'claim', to_jsonb(c));
end $$;

create or replace function public.resolve_payment_claim(p_id uuid, p_approve boolean) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare c payment_claims; r jsonb;
begin
  if not has_staff_role('owner', 'receptionist') then raise exception 'not allowed' using errcode = '42501'; end if;
  select * into c from payment_claims where id = p_id and gym_id = get_my_gym_id() for update;
  if not found then raise exception 'claim not found' using errcode = 'P0002'; end if;
  if c.status <> 'pending' then return jsonb_build_object('status', 'already_' || c.status); end if;
  if p_approve then
    r := renew_membership(c.member_id, c.plan_id, 'upi', c.amount, null, c.utr, 'Member payment confirmed');
    update payment_claims set status = 'confirmed', payment_id = (r->'payment'->>'id')::uuid, resolved_at = now(), resolved_by = auth.uid() where id = c.id returning * into c;
    return jsonb_build_object('status', 'confirmed', 'claim', to_jsonb(c), 'membership', r->'membership', 'payment', r->'payment');
  end if;
  update payment_claims set status = 'rejected', resolved_at = now(), resolved_by = auth.uid() where id = c.id returning * into c;
  return jsonb_build_object('status', 'rejected', 'claim', to_jsonb(c));
end $$;

revoke execute on function public.submit_payment_claim(uuid, text), public.resolve_payment_claim(uuid, boolean) from public, anon;
grant execute on function public.submit_payment_claim(uuid, text), public.resolve_payment_claim(uuid, boolean) to authenticated, service_role;
