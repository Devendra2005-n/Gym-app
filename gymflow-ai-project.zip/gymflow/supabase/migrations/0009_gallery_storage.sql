-- Private storage bucket for gallery files. Folder = gym id. View: anyone in the gym. Upload/delete: owner only.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('gym-gallery', 'gym-gallery', false, 52428800,
  array['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm', 'video/quicktime'])
on conflict (id) do update set public = false, file_size_limit = 52428800, allowed_mime_types = excluded.allowed_mime_types;

create policy gallery_obj_view on storage.objects for select to authenticated
  using (bucket_id = 'gym-gallery' and (storage.foldername(name))[1] = coalesce(public.get_my_gym_id(), public.my_member_gym_id())::text);
create policy gallery_obj_owner_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'gym-gallery' and (storage.foldername(name))[1] = public.get_my_gym_id()::text and public.has_staff_role('owner'));
create policy gallery_obj_owner_delete on storage.objects for delete to authenticated
  using (bucket_id = 'gym-gallery' and (storage.foldername(name))[1] = public.get_my_gym_id()::text and public.has_staff_role('owner'));
