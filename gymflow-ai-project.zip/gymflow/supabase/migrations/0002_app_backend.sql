-- GYM Flow backend v1 (additive; keeps all existing data).
-- Roles: staff = gym_users (owner / receptionist / trainer);  member = members.user_id -> auth.users.
-- Members are NOT in gym_users, so the existing staff policies never match them.

----------------------------------------------------------------- helpers
create or replace function public.ist_today() returns date language sql stable
as $$ select (now() at time zone 'Asia/Kolkata')::date $$;

create or replace function public.has_staff_role(variadic p_roles text[]) returns boolean
language sql stable security definer set search_path = public, pg_temp
as $$ select exists (select 1 from gym_users where user_id = auth.uid() and is_active and role = any (p_roles)) $$;

----------------------------------------------------------------- schema additions
alter table public.members  add column if not exists user_id uuid references auth.users(id) on delete set null;
alter table public.gyms     add column if not exists upi_id text,
                            add column if not exists invoice_prefix text not null default 'INV',
                            add column if not exists invoice_footer text;
alter table public.payments add column if not exists invoice_no text;

update public.gyms set invoice_prefix = 'FA' where name = 'Fitness Arena' and invoice_prefix = 'INV';

create unique index if not exists members_user_id_key       on public.members(user_id) where user_id is not null;
create index        if not exists members_gym_email_idx     on public.members(gym_id, lower(email));
create unique index if not exists gym_users_one_active_gym  on public.gym_users(user_id) where is_active;
create unique index if not exists payments_invoice_no_key   on public.payments(gym_id, invoice_no) where invoice_no is not null;
create index        if not exists memberships_member_idx    on public.memberships(member_id, status, end_date);
create index        if not exists payments_gym_date_idx     on public.payments(gym_id, payment_date);

create table if not exists public.invoice_counters (
  gym_id uuid not null references public.gyms(id) on delete cascade,
  yr int not null, last_no int not null default 0,
  primary key (gym_id, yr));
alter table public.invoice_counters enable row level security;   -- no policies: only definer functions touch it

create table if not exists public.workout_logs (
  id uuid primary key default gen_random_uuid(),
  gym_id uuid not null references public.gyms(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete cascade,
  exercise text not null check (length(exercise) between 1 and 120),
  minutes numeric not null check (minutes > 0 and minutes <= 600),
  kcal numeric not null default 0 check (kcal >= 0 and kcal <= 5000),
  logged_at timestamptz not null default now(),
  created_at timestamptz not null default now());
create index if not exists workout_logs_member_idx on public.workout_logs(member_id, logged_at desc);

create table if not exists public.weight_logs (
  id uuid primary key default gen_random_uuid(),
  gym_id uuid not null references public.gyms(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete cascade,
  weight_kg numeric not null check (weight_kg between 20 and 400),
  logged_on date not null default public.ist_today(),
  created_at timestamptz not null default now(),
  unique (member_id, logged_on));

create table if not exists public.water_logs (
  id uuid primary key default gen_random_uuid(),
  gym_id uuid not null references public.gyms(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete cascade,
  ml int not null check (ml between 1 and 5000),
  logged_at timestamptz not null default now());
create index if not exists water_logs_member_idx on public.water_logs(member_id, logged_at desc);

create table if not exists public.member_goals (
  member_id uuid primary key references public.members(id) on delete cascade,
  gym_id uuid not null references public.gyms(id) on delete cascade,
  weekly_workouts int check (weekly_workouts between 0 and 14),
  water_ml int check (water_ml between 0 and 10000),
  calories_goal int check (calories_goal between 0 and 10000),
  target_weight_kg numeric check (target_weight_kg between 20 and 400),
  updated_at timestamptz not null default now());

create or replace function public.my_member_id() returns uuid
language sql stable security definer set search_path = public, pg_temp
as $$ select id from members where user_id = auth.uid() and is_active limit 1 $$;

create or replace function public.my_member_gym_id() returns uuid
language sql stable security definer set search_path = public, pg_temp
as $$ select gym_id from members where user_id = auth.uid() and is_active limit 1 $$;



----------------------------------------------------------------- integrity triggers
create or replace function public.set_updated_at_trg() returns trigger language plpgsql
as $$ begin new.updated_at := now(); return new; end $$;
drop trigger if exists trg_updated_at on public.members;     create trigger trg_updated_at before update on public.members     for each row execute function public.set_updated_at_trg();
drop trigger if exists trg_updated_at on public.memberships; create trigger trg_updated_at before update on public.memberships for each row execute function public.set_updated_at_trg();
drop trigger if exists trg_updated_at on public.gyms;        create trigger trg_updated_at before update on public.gyms        for each row execute function public.set_updated_at_trg();
drop trigger if exists trg_updated_at on public.member_goals;create trigger trg_updated_at before update on public.member_goals for each row execute function public.set_updated_at_trg();

-- a member row can only be linked to a login through claim_member_profile() (or by an admin with no JWT)
create or replace function public.guard_member_user_id() returns trigger language plpgsql
set search_path = public, pg_temp as $$
begin
  if auth.uid() is not null and coalesce(current_setting('gymflow.claiming', true), '') <> 'on' then
    if (tg_op = 'INSERT' and new.user_id is not null) or (tg_op = 'UPDATE' and new.user_id is distinct from old.user_id) then
      raise exception 'members.user_id can only be set by claim_member_profile()' using errcode = '42501';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists trg_guard_user_id on public.members;
create trigger trg_guard_user_id before insert or update on public.members for each row execute function public.guard_member_user_id();

-- a gym owner may not change billing fields of their own gym
create or replace function public.guard_gym_billing() returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and (new.subscription_plan is distinct from old.subscription_plan
     or new.is_active is distinct from old.is_active or new.email is distinct from old.email) then
    raise exception 'billing fields are managed by the platform admin' using errcode = '42501';
  end if;
  return new;
end $$;
drop trigger if exists trg_guard_gym on public.gyms;
create trigger trg_guard_gym before update on public.gyms for each row execute function public.guard_gym_billing();

-- every row that points at member / plan / membership must stay inside the same gym
create or replace function public.enforce_same_gym() returns trigger language plpgsql
security definer set search_path = public, pg_temp as $$
declare j jsonb := to_jsonb(new);
begin
  if j->>'member_id' is not null and not exists
     (select 1 from members where id = (j->>'member_id')::uuid and gym_id = new.gym_id) then
    raise exception 'member belongs to another gym' using errcode = '23514'; end if;
  if j->>'plan_id' is not null and not exists
     (select 1 from plans where id = (j->>'plan_id')::uuid and gym_id = new.gym_id) then
    raise exception 'plan belongs to another gym' using errcode = '23514'; end if;
  if j->>'membership_id' is not null and not exists
     (select 1 from memberships where id = (j->>'membership_id')::uuid and gym_id = new.gym_id
        and member_id = (j->>'member_id')::uuid) then
    raise exception 'membership does not belong to this member' using errcode = '23514'; end if;
  return new;
end $$;
do $$ declare t text; begin
  foreach t in array array['memberships','payments','attendance','notifications','workout_logs','weight_logs','water_logs','member_goals'] loop
    execute format('drop trigger if exists trg_same_gym on public.%I', t);
    execute format('create trigger trg_same_gym before insert or update on public.%I for each row execute function public.enforce_same_gym()', t);
  end loop; end $$;

-- audit trail written by the database itself
create or replace function public.audit_row() returns trigger language plpgsql
security definer set search_path = public, pg_temp as $$
declare r jsonb := case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end;
begin
  insert into audit_logs(gym_id, user_id, action, table_name, record_id, old_data, new_data)
  values ((r->>'gym_id')::uuid, auth.uid(), tg_op, tg_table_name, (r->>'id')::uuid,
          case when tg_op <> 'INSERT' then to_jsonb(old) end,
          case when tg_op <> 'DELETE' then to_jsonb(new) end);
  return null;
end $$;
do $$ declare t text; begin
  foreach t in array array['members','memberships','payments','plans','gym_users'] loop
    execute format('drop trigger if exists trg_audit on public.%I', t);
    execute format('create trigger trg_audit after insert or update or delete on public.%I for each row execute function public.audit_row()', t);
  end loop; end $$;

----------------------------------------------------------------- RLS
-- payments: only owner / receptionist read; rows are created ONLY through record_payment()/renew_membership()
drop policy if exists gym_staff_add_payments       on public.payments;
drop policy if exists gym_staff_view_own_payments  on public.payments;
create policy payments_staff_view on public.payments for select to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner','receptionist'));
create policy payments_member_view_own on public.payments for select to authenticated
  using (member_id = my_member_id());

-- members (self)
create policy members_view_self on public.members for select to authenticated using (user_id = auth.uid());
-- memberships / plans (self)
create policy memberships_member_view_own on public.memberships for select to authenticated using (member_id = my_member_id());
create policy plans_member_view on public.plans for select to authenticated using (gym_id = my_member_gym_id());

-- attendance: had RLS but no policies at all
create policy attendance_staff_view   on public.attendance for select to authenticated using (gym_id = get_my_gym_id());
create policy attendance_staff_insert on public.attendance for insert to authenticated with check (gym_id = get_my_gym_id());
create policy attendance_staff_update on public.attendance for update to authenticated using (gym_id = get_my_gym_id()) with check (gym_id = get_my_gym_id());
create policy attendance_owner_delete on public.attendance for delete to authenticated using (gym_id = get_my_gym_id() and has_staff_role('owner'));
create policy attendance_member_view  on public.attendance for select to authenticated using (member_id = my_member_id());

-- member-owned tracking tables
do $$ declare t text; begin
  foreach t in array array['workout_logs','weight_logs','water_logs','member_goals'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format($p$create policy %I on public.%I for all to authenticated
        using (member_id = my_member_id())
        with check (member_id = my_member_id() and gym_id = my_member_gym_id())$p$, t||'_member_own', t);
    execute format($p$create policy %I on public.%I for select to authenticated
        using (gym_id = get_my_gym_id() and has_staff_role('owner','trainer'))$p$, t||'_staff_view', t);
  end loop; end $$;

----------------------------------------------------------------- RPC
create or replace function public._next_invoice_no(p_gym uuid) returns text
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_year int := extract(year from (now() at time zone 'Asia/Kolkata'))::int; v_no int; v_prefix text;
begin
  insert into invoice_counters(gym_id, yr, last_no) values (p_gym, v_year, 1)
  on conflict (gym_id, yr) do update set last_no = invoice_counters.last_no + 1
  returning last_no into v_no;
  select coalesce(nullif(invoice_prefix, ''), 'INV') into v_prefix from gyms where id = p_gym;
  return v_prefix || '-' || v_year || '-' || lpad(v_no::text, 4, '0');
end $$;

create or replace function public.app_context() returns jsonb
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare s gym_users; m members;
begin
  select * into s from gym_users where user_id = auth.uid() and is_active limit 1;
  if found then return jsonb_build_object('role', s.role, 'gym_id', s.gym_id, 'member_id', null); end if;
  select * into m from members where user_id = auth.uid() and is_active limit 1;
  if found then return jsonb_build_object('role', 'member', 'gym_id', m.gym_id, 'member_id', m.id, 'full_name', m.full_name); end if;
  return jsonb_build_object('role', null);
end $$;

create or replace function public.my_gym() returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select to_jsonb(g) from (select id, name, phone, address, city, upi_id, invoice_prefix, invoice_footer
                           from gyms where id = coalesce(get_my_gym_id(), my_member_gym_id())) g $$;

create or replace function public.claim_member_profile() returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_email text; v_conf timestamptz; v_ids uuid[]; m members;
begin
  if auth.uid() is null then raise exception 'not authenticated' using errcode = '28000'; end if;
  select * into m from members where user_id = auth.uid() and is_active limit 1;
  if found then return jsonb_build_object('status', 'already_linked', 'member_id', m.id, 'gym_id', m.gym_id); end if;
  if exists (select 1 from gym_users where user_id = auth.uid() and is_active) then
    return jsonb_build_object('status', 'staff'); end if;
  select email, email_confirmed_at into v_email, v_conf from auth.users where id = auth.uid();
  if v_email is null or v_conf is null then return jsonb_build_object('status', 'email_not_verified'); end if;
  select array_agg(id) into v_ids from members where user_id is null and is_active and lower(email) = lower(v_email);
  if v_ids is null then return jsonb_build_object('status', 'not_found'); end if;
  if cardinality(v_ids) > 1 then return jsonb_build_object('status', 'ambiguous'); end if;
  perform set_config('gymflow.claiming', 'on', true);
  update members set user_id = auth.uid() where id = v_ids[1] and user_id is null returning * into m;
  perform set_config('gymflow.claiming', 'off', true);
  return jsonb_build_object('status', 'linked', 'member_id', m.id, 'gym_id', m.gym_id);
end $$;

create or replace function public.record_payment(p_member_id uuid, p_amount numeric, p_method text,
  p_membership_id uuid default null, p_reference text default null, p_notes text default null)
returns public.payments language plpgsql security definer set search_path = public, pg_temp as $$
declare v_gym uuid := get_my_gym_id(); r payments;
begin
  if not has_staff_role('owner', 'receptionist') then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'amount must be positive' using errcode = '22023'; end if;
  if p_method is null then raise exception 'payment method required' using errcode = '22023'; end if;
  if not exists (select 1 from members where id = p_member_id and gym_id = v_gym) then
    raise exception 'member not found' using errcode = 'P0002'; end if;
  insert into payments(gym_id, member_id, membership_id, amount, payment_method, reference_no, notes, received_by, invoice_no, payment_date)
  values (v_gym, p_member_id, p_membership_id, p_amount, p_method, p_reference, p_notes, auth.uid(), _next_invoice_no(v_gym), ist_today())
  returning * into r;
  return r;
end $$;

create or replace function public.renew_membership(p_member_id uuid, p_plan_id uuid, p_method text default 'cash',
  p_amount numeric default null, p_start date default null, p_reference text default null, p_notes text default null)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare v_gym uuid := get_my_gym_id(); v_plan plans; v_next date; v_start date; v_amount numeric; ms memberships; pay payments;
begin
  if not has_staff_role('owner', 'receptionist') then raise exception 'not allowed' using errcode = '42501'; end if;
  if not exists (select 1 from members where id = p_member_id and gym_id = v_gym and is_active) then
    raise exception 'member not found' using errcode = 'P0002'; end if;
  select * into v_plan from plans where id = p_plan_id and gym_id = v_gym and is_active;
  if not found then raise exception 'plan not found' using errcode = 'P0002'; end if;
  select max(end_date) + 1 into v_next from memberships
   where member_id = p_member_id and status = 'active' and end_date >= ist_today();
  v_start := coalesce(p_start, greatest(ist_today(), coalesce(v_next, ist_today())));
  v_amount := coalesce(p_amount, v_plan.price);
  if v_amount < 0 then raise exception 'amount cannot be negative' using errcode = '22023'; end if;
  insert into memberships(gym_id, member_id, plan_id, start_date, end_date, status, created_by)
  values (v_gym, p_member_id, p_plan_id, v_start, v_start + v_plan.duration_days - 1, 'active', auth.uid())
  returning * into ms;
  if v_amount > 0 then
    pay := record_payment(p_member_id, v_amount, p_method, ms.id, p_reference, p_notes);
  end if;
  return jsonb_build_object('membership', to_jsonb(ms), 'payment', to_jsonb(pay));
end $$;

create or replace function public.check_in(p_member_id uuid default null, p_source text default null)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare m members; ms memberships; a attendance; v_today date := ist_today();
begin
  if auth.uid() is null then raise exception 'not authenticated' using errcode = '28000'; end if;
  if p_member_id is null then
    select * into m from members where user_id = auth.uid() and is_active;
    if not found then raise exception 'no member profile' using errcode = 'P0002'; end if;
  else
    if not has_staff_role('owner', 'receptionist', 'trainer') then raise exception 'not allowed' using errcode = '42501'; end if;
    select * into m from members where id = p_member_id and gym_id = get_my_gym_id() and is_active;
    if not found then raise exception 'member not found' using errcode = 'P0002'; end if;
  end if;
  select * into ms from memberships where member_id = m.id and status = 'active'
     and start_date <= v_today and end_date >= v_today order by end_date desc limit 1;
  if ms.id is null and p_member_id is null then raise exception 'membership_expired' using errcode = 'P0001'; end if;
  insert into attendance(gym_id, member_id, membership_id, source, recorded_by)
  values (m.gym_id, m.id, ms.id, case when p_member_id is null then 'self' else coalesce(p_source, 'manual') end, auth.uid())
  on conflict (member_id, attendance_date) do nothing returning * into a;
  if a.id is null then
    select * into a from attendance where member_id = m.id and attendance_date = v_today;
    return jsonb_build_object('status', 'already_checked_in', 'membership_active', ms.id is not null, 'attendance', to_jsonb(a));
  end if;
  return jsonb_build_object('status', 'checked_in', 'membership_active', ms.id is not null, 'attendance', to_jsonb(a));
end $$;

create or replace function public.owner_dashboard() returns jsonb
language plpgsql stable security definer set search_path = public, pg_temp as $$
declare g uuid := get_my_gym_id(); d date := ist_today(); money boolean := has_staff_role('owner', 'receptionist');
begin
  if g is null then raise exception 'not allowed' using errcode = '42501'; end if;
  return jsonb_build_object(
    'active_members',  (select count(*) from members where gym_id = g and is_active),
    'with_active_plan',(select count(distinct member_id) from memberships where gym_id = g and status = 'active' and start_date <= d and end_date >= d),
    'expiring_7d',     (select count(distinct member_id) from memberships where gym_id = g and status = 'active' and end_date between d and d + 7),
    'without_plan',    (select count(*) from members m where m.gym_id = g and m.is_active and not exists
                         (select 1 from memberships s where s.member_id = m.id and s.status = 'active' and s.end_date >= d)),
    'today_checkins',  (select count(*) from attendance where gym_id = g and attendance_date = d),
    'today_revenue',   case when money then (select coalesce(sum(amount), 0) from payments where gym_id = g and payment_date = d) end,
    'month_revenue',   case when money then (select coalesce(sum(amount), 0) from payments where gym_id = g and payment_date >= date_trunc('month', d)::date) end);
end $$;

create or replace function public.weekly_report(p_member_id uuid default null, p_week_start date default null)
returns jsonb language plpgsql stable security definer set search_path = public, pg_temp as $$
declare v_member uuid := coalesce(p_member_id, my_member_id()); v_gym uuid; v_ws date; v_we date;
        v_days jsonb; v_goals jsonb; v_w0 numeric; v_w1 numeric; v_min numeric; v_kcal numeric; v_cnt int;
begin
  if v_member is null then raise exception 'no member profile' using errcode = 'P0002'; end if;
  select gym_id into v_gym from members where id = v_member;
  if v_gym is null then raise exception 'member not found' using errcode = 'P0002'; end if;
  if not (v_member = my_member_id() or (v_gym = get_my_gym_id() and has_staff_role('owner', 'trainer'))) then
    raise exception 'not allowed' using errcode = '42501'; end if;
  v_ws := coalesce(p_week_start, date_trunc('week', ist_today())::date);
  v_we := v_ws + 6;
  select jsonb_agg(jsonb_build_object('date', d::date,
           'minutes', coalesce(w.minutes, 0), 'kcal', coalesce(w.kcal, 0), 'workouts', coalesce(w.cnt, 0),
           'checked_in', exists (select 1 from attendance a where a.member_id = v_member and a.attendance_date = d::date)) order by d)
    into v_days
    from generate_series(v_ws, v_we, interval '1 day') d
    left join (select (logged_at at time zone 'Asia/Kolkata')::date as day, sum(minutes) as minutes, sum(kcal) as kcal, count(*) as cnt
                 from workout_logs where member_id = v_member group by 1) w on w.day = d::date;
  select coalesce(sum(minutes), 0), coalesce(sum(kcal), 0), count(*) into v_min, v_kcal, v_cnt
    from workout_logs where member_id = v_member and (logged_at at time zone 'Asia/Kolkata')::date between v_ws and v_we;
  select weight_kg into v_w0 from weight_logs where member_id = v_member and logged_on < v_ws order by logged_on desc limit 1;
  select weight_kg into v_w1 from weight_logs where member_id = v_member and logged_on <= v_we order by logged_on desc limit 1;
  select to_jsonb(g) - 'member_id' - 'gym_id' into v_goals from member_goals g where member_id = v_member;
  return jsonb_build_object('week_start', v_ws, 'week_end', v_we, 'days', v_days,
    'totals', jsonb_build_object('minutes', v_min, 'kcal', v_kcal, 'workouts', v_cnt,
        'gym_visits', (select count(*) from attendance where member_id = v_member and attendance_date between v_ws and v_we),
        'est_fat_loss_kg', round(v_kcal / 7700, 2)),
    'weight', jsonb_build_object('start', v_w0, 'end', v_w1, 'change', case when v_w0 is not null and v_w1 is not null then round(v_w1 - v_w0, 1) end),
    'goals', v_goals);
end $$;

create or replace function public.expire_memberships() returns int
language plpgsql security definer set search_path = public, pg_temp as $$
declare n int;
begin
  update memberships set status = 'expired' where status = 'active' and end_date < ist_today();
  get diagnostics n = row_count; return n;
end $$;

----------------------------------------------------------------- privileges
revoke all on all tables in schema public from anon;
do $$ declare f record; begin
  for f in select p.oid::regprocedure sig, p.proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.prokind = 'f' loop
    execute format('revoke execute on function %s from public, anon', f.sig);
    if f.proname in ('app_context','my_gym','claim_member_profile','record_payment','renew_membership','check_in',
                     'owner_dashboard','weekly_report','get_my_gym_id','get_my_role','has_staff_role','my_member_id','my_member_gym_id','ist_today') then
      execute format('grant execute on function %s to authenticated', f.sig);
    else
      execute format('revoke execute on function %s from authenticated', f.sig);
    end if;
    execute format('grant execute on function %s to service_role', f.sig);
  end loop; end $$;

-- nightly expiry (Supabase has pg_cron; skipped silently elsewhere)
do $$ begin
  create extension if not exists pg_cron;
  perform cron.schedule('gymflow-expire-memberships', '30 18 * * *', 'select public.expire_memberships()');
exception when others then raise notice 'pg_cron not available: %', sqlerrm; end $$;
