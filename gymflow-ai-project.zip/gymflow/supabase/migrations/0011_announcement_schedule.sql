-- Owner controls when members are notified: start day, times per day, and the time window each day.
alter table public.announcements
  add column if not exists starts_on date,
  add column if not exists per_day smallint not null default 3 check (per_day between 1 and 8),
  add column if not exists notify_from time not null default '09:00',
  add column if not exists notify_to time not null default '21:00';
alter table public.announcements drop constraint if exists announcements_window_chk;
alter table public.announcements add constraint announcements_window_chk check (notify_to >= notify_from);
grant insert (starts_on, per_day, notify_from, notify_to), update (starts_on, per_day, notify_from, notify_to) on public.announcements to authenticated;
