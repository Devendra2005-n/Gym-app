-- Online payments through Razorpay (Payment Links). The server decides the amount from the plan price;
-- only the Razorpay webhook (service_role, signature checked in the Edge Function) can mark an order paid.
create table if not exists public.payment_orders (
  id uuid primary key default gen_random_uuid(),
  gym_id uuid not null references public.gyms(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete cascade,
  plan_id uuid not null references public.plans(id),
  amount numeric not null check (amount > 0),
  provider text not null default 'razorpay',
  provider_ref text unique,                 -- payment link id (plink_...)
  provider_payment_id text unique,          -- pay_...
  short_url text,
  status text not null default 'created' check (status in ('created', 'paid', 'expired')),
  payment_id uuid references public.payments(id),
  created_at timestamptz not null default now(),
  paid_at timestamptz);
create index if not exists payment_orders_member_idx on public.payment_orders(member_id, created_at desc);
alter table public.payment_orders enable row level security;
create policy payment_orders_self_select on public.payment_orders for select to authenticated using (member_id = my_member_id());
create policy payment_orders_front_select on public.payment_orders for select to authenticated
  using (gym_id = get_my_gym_id() and has_staff_role('owner', 'receptionist'));
revoke all on public.payment_orders from anon, authenticated;
grant select on public.payment_orders to authenticated;

-- Member asks to pay for a plan: validates and returns what the Edge Function needs to create the link.
create or replace function public.prepare_gateway_order(p_plan_id uuid) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare m members; pl plans; o payment_orders;
begin
  select * into m from members where user_id = auth.uid() and is_active;
  if not found then raise exception 'no member profile' using errcode = 'P0002'; end if;
  select * into pl from plans where id = p_plan_id and gym_id = m.gym_id and is_active;
  if not found then raise exception 'plan not found' using errcode = 'P0002'; end if;
  -- recent unpaid link for the same plan is reused (stops link spam)
  select * into o from payment_orders where member_id = m.id and plan_id = pl.id and status = 'created'
    and short_url is not null and created_at > now() - interval '30 minutes' order by created_at desc limit 1;
  if found then return jsonb_build_object('reuse', true, 'order_id', o.id, 'short_url', o.short_url); end if;
  if (select count(*) from payment_orders where member_id = m.id and created_at > now() - interval '1 hour') >= 5 then
    raise exception 'too many payment attempts, try again later' using errcode = '54000'; end if;
  insert into payment_orders(gym_id, member_id, plan_id, amount) values (m.gym_id, m.id, pl.id, pl.price) returning * into o;
  return jsonb_build_object('reuse', false, 'order_id', o.id, 'amount', pl.price, 'plan_name', pl.name, 'member_name', m.full_name, 'phone', m.phone, 'email', m.email);
end $$;

create or replace function public.attach_gateway_link(p_order_id uuid, p_ref text, p_url text) returns void
language sql security definer set search_path = public, pg_temp as $$
  update payment_orders set provider_ref = p_ref, short_url = p_url where id = p_order_id and status = 'created' and provider_ref is null;
$$;

-- Called only by the webhook after the signature was verified. Idempotent.
create or replace function public.apply_gateway_payment(p_ref text, p_payment_id text, p_amount_paise bigint, p_method text) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare o payment_orders; v_plan plans; v_next date; v_start date; ms memberships; pay payments;
begin
  select * into o from payment_orders where provider_ref = p_ref for update;
  if not found then return jsonb_build_object('status', 'unknown_order'); end if;
  if o.status = 'paid' then return jsonb_build_object('status', 'already_paid', 'payment_id', o.payment_id); end if;
  if p_amount_paise is distinct from (o.amount * 100)::bigint then
    return jsonb_build_object('status', 'amount_mismatch'); end if;
  select * into v_plan from plans where id = o.plan_id;
  select max(end_date) + 1 into v_next from memberships where member_id = o.member_id and status = 'active' and end_date >= ist_today();
  v_start := greatest(ist_today(), coalesce(v_next, ist_today()));
  insert into memberships(gym_id, member_id, plan_id, start_date, end_date, status)
    values (o.gym_id, o.member_id, o.plan_id, v_start, v_start + v_plan.duration_days - 1, 'active') returning * into ms;
  insert into payments(gym_id, member_id, membership_id, amount, payment_method, reference_no, notes, invoice_no, payment_date)
    values (o.gym_id, o.member_id, ms.id, o.amount, coalesce(nullif(p_method, ''), 'upi'), p_payment_id, 'Online payment (Razorpay)', _next_invoice_no(o.gym_id), ist_today()) returning * into pay;
  update payment_orders set status = 'paid', provider_payment_id = p_payment_id, payment_id = pay.id, paid_at = now() where id = o.id;
  return jsonb_build_object('status', 'paid', 'payment_id', pay.id, 'membership_id', ms.id);
end $$;

revoke execute on function public.prepare_gateway_order(uuid), public.attach_gateway_link(uuid, text, text), public.apply_gateway_payment(text, text, bigint, text) from public, anon, authenticated;
grant execute on function public.prepare_gateway_order(uuid) to authenticated, service_role;
grant execute on function public.attach_gateway_link(uuid, text, text), public.apply_gateway_payment(text, text, bigint, text) to service_role;
