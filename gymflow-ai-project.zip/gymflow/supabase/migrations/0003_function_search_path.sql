-- Pin search_path on helper/trigger functions (Supabase security advisor).
alter function public.guard_gym_billing()   set search_path = public, pg_temp;
alter function public.ist_today()           set search_path = public, pg_temp;
alter function public.set_updated_at_trg()  set search_path = public, pg_temp;
alter function public.get_my_gym_id()       set search_path = public, pg_temp;
alter function public.get_my_role()         set search_path = public, pg_temp;
