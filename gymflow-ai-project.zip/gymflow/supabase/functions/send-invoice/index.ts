// Sends the payment invoice (PDF) to the member on WhatsApp using the official WhatsApp Cloud API (Meta).
// Called by: rzp-webhook (online payments, with the service key) and by the app after staff record a payment / confirm a claim (with the staff login).
// Secrets: WA_TOKEN, WA_PHONE_NUMBER_ID, optional WA_TEMPLATE (default invoice_receipt), WA_LANG (default en).
// If the secrets are missing nothing breaks: the delivery is just marked "not_configured".
import { createClient } from "npm:@supabase/supabase-js@2";
import { buildInvoicePdf, Invoice } from "./invoice_pdf.ts";

const GRAPH = "https://graph.facebook.com/v21.0";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Content-Type": "application/json" };
const json = (o: unknown, s = 200) => new Response(JSON.stringify(o), { status: s, headers: cors });
function safeEqual(a: string, b: string) { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; }
const inr = (n: number) => "Rs. " + Number(n).toLocaleString("en-IN", { maximumFractionDigits: 2 });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL")!, svcKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const svc = createClient(url, svcKey);
  const token = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  let body: any; try { body = await req.json(); } catch { return json({ error: "bad json" }, 400); }
  const paymentId = String(body?.payment_id ?? ""), force = body?.force === true;
  if (!/^[0-9a-f-]{36}$/i.test(paymentId)) return json({ error: "payment_id required" }, 400);

  // who is calling: our own server code (service key) or a signed-in staff member of the same gym
  const { data: pay } = await svc.from("payments").select("*").eq("id", paymentId).maybeSingle();
  if (!pay) return json({ error: "payment not found" }, 404);
  let trusted = token.length > 20 && safeEqual(token, svcKey);
  if (!trusted) {
    const { data: u } = await svc.auth.getUser(token);
    if (!u?.user) return json({ error: "not signed in" }, 401);
    const { data: st } = await svc.from("gym_users").select("role").eq("user_id", u.user.id).eq("gym_id", pay.gym_id).eq("is_active", true).maybeSingle();
    if (!st || !["owner", "receptionist"].includes(st.role)) return json({ error: "not allowed" }, 403);
    trusted = true;
  }

  const { data: claim } = await svc.rpc("claim_invoice_delivery", { p_payment: paymentId, p_force: force });
  if (!claim) { const { data: cur } = await svc.from("invoice_deliveries").select("status").eq("payment_id", paymentId).maybeSingle(); return json({ status: cur?.status ?? "unknown", skipped: true }); }

  const done = async (status: string, extra: Record<string, unknown> = {}) => {
    await svc.from("invoice_deliveries").update({ status, updated_at: new Date().toISOString(), ...extra }).eq("payment_id", paymentId);
    return json({ status, ...extra });
  };
  try {
    const waToken = Deno.env.get("WA_TOKEN"), waPhone = Deno.env.get("WA_PHONE_NUMBER_ID");
    if (!waToken || !waPhone) return await done("not_configured");
    const [{ data: member }, { data: gym }, { data: ms }] = await Promise.all([
      svc.from("members").select("full_name, phone").eq("id", pay.member_id).maybeSingle(),
      svc.from("gyms").select("name, phone, address, gstin, gst_pct, invoice_footer").eq("id", pay.gym_id).maybeSingle(),
      pay.membership_id ? svc.from("memberships").select("start_date, end_date, plan_id").eq("id", pay.membership_id).maybeSingle() : Promise.resolve({ data: null }),
    ]);
    const phone = String(member?.phone ?? "").replace(/\D/g, "").slice(-10);
    if (!/^[6-9][0-9]{9}$/.test(phone)) return await done("no_phone");
    const { data: plan } = ms?.plan_id ? await svc.from("plans").select("name").eq("id", ms.plan_id).maybeSingle() : { data: null };

    const g = Number(gym?.gst_pct) || 0, total = Number(pay.amount), base = g ? Math.round(total / (1 + g / 100) * 100) / 100 : total;
    const inv: Invoice = {
      no: pay.invoice_no ?? paymentId.slice(0, 8).toUpperCase(), date: pay.payment_date,
      gym: { name: gym?.name ?? "Gym", address: gym?.address ?? "", phone: gym?.phone ?? "", gstin: gym?.gstin ?? "" },
      member: { name: member?.full_name ?? "Member", phone }, item: plan ? plan.name + " membership" : (pay.notes || "Gym fee"),
      period: ms ? { from: ms.start_date, to: ms.end_date } : null, method: pay.payment_method, ref: pay.reference_no ?? "",
      gst_pct: g, base, tax: g ? Math.round((total - base) * 100) / 100 : 0, total, footer: gym?.invoice_footer ?? "Thank you for training with us!",
    };
    const pdf = await buildInvoicePdf(inv), filename = `Invoice-${inv.no}.pdf`.replace(/[^A-Za-z0-9._-]+/g, "_");

    const fd = new FormData();
    fd.append("messaging_product", "whatsapp"); fd.append("type", "application/pdf");
    fd.append("file", new Blob([pdf], { type: "application/pdf" }), filename);
    const up = await fetch(`${GRAPH}/${waPhone}/media`, { method: "POST", headers: { Authorization: `Bearer ${waToken}` }, body: fd });
    const upj = await up.json().catch(() => ({}));
    if (!up.ok || !upj.id) return await done("failed", { error: String(upj?.error?.message ?? `media upload ${up.status}`).slice(0, 400) });

    const params = [inv.member.name, inr(inv.total), inv.item, inv.gym.name, inv.no].map((t) => ({ type: "text", text: String(t).replace(/[\n\t]+/g, " ").slice(0, 100) }));
    const msg = await fetch(`${GRAPH}/${waPhone}/messages`, {
      method: "POST", headers: { Authorization: `Bearer ${waToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        messaging_product: "whatsapp", to: "91" + phone, type: "template",
        template: { name: Deno.env.get("WA_TEMPLATE") ?? "invoice_receipt", language: { code: Deno.env.get("WA_LANG") ?? "en" },
          components: [{ type: "header", parameters: [{ type: "document", document: { id: upj.id, filename } }] }, { type: "body", parameters: params }] },
      }),
    });
    const mj = await msg.json().catch(() => ({}));
    if (!msg.ok) return await done("failed", { error: String(mj?.error?.message ?? `send ${msg.status}`).slice(0, 400) });
    return await done("sent", { wa_message_id: mj?.messages?.[0]?.id ?? null });
  } catch (e) {
    return await done("failed", { error: String((e as Error).message ?? e).slice(0, 400) });
  }
});
