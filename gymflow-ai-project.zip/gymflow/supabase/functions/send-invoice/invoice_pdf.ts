// Builds the same invoice the app makes, but on the server, so it can be attached to the WhatsApp message.
import { PDFDocument, StandardFonts, rgb } from "npm:pdf-lib@1.17.1";

export type Invoice = {
  no: string; date: string; gym: { name: string; address: string; phone: string; gstin: string };
  member: { name: string; phone: string }; item: string; period: { from: string; to: string } | null;
  method: string; ref: string; gst_pct: number; base: number; tax: number; total: number; footer: string;
};
const GREEN = rgb(0.1, 0.55, 0.25), INK = rgb(0.1, 0.1, 0.1), MUTE = rgb(0.45, 0.45, 0.48), LINE = rgb(0.85, 0.85, 0.87);
const rs = (n: number) => "Rs. " + Number(n).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
export function pdfDate(iso: string) { const d = String(iso).slice(0, 10).split("-"); return d.length === 3 ? `${+d[2]} ${MON[+d[1] - 1]} ${d[0]}` : String(iso); }
// the standard PDF fonts only know basic Latin letters
const clean = (t: string) => String(t ?? "").replace(/[^\x20-\x7E]/g, "?");

export async function buildInvoicePdf(v: Invoice): Promise<Uint8Array> {
  const doc = await PDFDocument.create(), page = doc.addPage([595.28, 841.89]);
  const f = await doc.embedFont(StandardFonts.Helvetica), b = await doc.embedFont(StandardFonts.HelveticaBold);
  const H = 841.89, mm = (x: number) => x * 2.8346, Y = (y: number) => H - mm(y);
  const text = (t: string, x: number, y: number, o: { size?: number; bold?: boolean; color?: any; right?: boolean; center?: boolean } = {}) => {
    const font = o.bold ? b : f, size = o.size ?? 10, s = clean(t), w = font.widthOfTextAtSize(s, size);
    page.drawText(s, { x: o.right ? mm(x) - w : o.center ? mm(x) - w / 2 : mm(x), y: Y(y), size, font, color: o.color ?? INK });
  };
  const line = (y: number) => page.drawLine({ start: { x: mm(14), y: Y(y) }, end: { x: mm(196), y: Y(y) }, thickness: 0.7, color: LINE });
  page.drawRectangle({ x: 0, y: Y(30), width: 595.28, height: mm(30), color: rgb(0.13, 0.14, 0.15) });
  text("INVOICE / PAYMENT RECEIPT", 14, 18, { size: 16, bold: true, color: rgb(0.8, 1, 0.2) }); text(v.no, 196, 18, { size: 11, right: true, color: rgb(1, 1, 1) });
  text(v.gym.name, 14, 42, { size: 12, bold: true });
  let y = 48;
  for (const t of [v.gym.address, v.gym.phone ? "Phone: " + v.gym.phone : "", v.gym.gstin ? "GSTIN: " + v.gym.gstin : ""]) if (t) { text(t, 14, y, { color: MUTE }); y += 5; }
  text("Invoice no", 140, 42, { bold: true }); text("Date", 140, 48, { bold: true }); text(v.no, 196, 42, { right: true }); text(pdfDate(v.date), 196, 48, { right: true });
  y = Math.max(y, 62) + 4; line(y); y += 8;
  text("BILLED TO", 14, y, { size: 9, bold: true, color: MUTE }); y += 6; text(v.member.name, 14, y, { size: 12, bold: true }); y += 5.5;
  if (v.member.phone) { text("Phone: " + v.member.phone, 14, y); y += 5; } y += 6;
  page.drawRectangle({ x: mm(14), y: Y(y + 9), width: mm(182), height: mm(9), color: rgb(0.957, 0.957, 0.96) });
  text("Description", 17, y + 6, { bold: true }); text("Amount", 193, y + 6, { bold: true, right: true }); y += 16;
  text(v.item, 17, y); text(rs(v.base), 193, y, { right: true }); y += 5.5;
  if (v.period) { text("Valid " + pdfDate(v.period.from) + " to " + pdfDate(v.period.to), 17, y, { size: 9, color: MUTE }); y += 5; }
  y += 4; line(y); y += 7;
  if (v.gst_pct) { text(`GST ${v.gst_pct}% (included in total)`, 17, y); text(rs(v.tax), 193, y, { right: true }); y += 7; }
  text("Total paid", 17, y, { size: 13, bold: true }); text(rs(v.total), 193, y, { size: 13, bold: true, right: true, color: GREEN }); y += 9;
  text("Payment mode: " + v.method.toUpperCase() + (v.ref ? "   Ref: " + v.ref : ""), 17, y); y += 7;
  text("PAID", 17, y, { bold: true, color: GREEN });
  text(v.footer || "", 105, 270, { center: true, color: MUTE }); text("This is a computer-generated invoice and needs no signature.", 105, 276, { size: 8, center: true, color: MUTE });
  return await doc.save();
}
