// Member taps "Pay online" -> returns a Razorpay Payment Link. Amount is taken from the plan price on the server.
// Secrets needed (Supabase -> Edge Functions -> Secrets): RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET
import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405);
  try {
    const auth = req.headers.get("Authorization") ?? "";
    if (!auth.startsWith("Bearer ")) return json({ error: "not signed in" }, 401);
    const { plan_id } = await req.json().catch(() => ({}));
    if (!plan_id) return json({ error: "plan_id required" }, 400);

    const url = Deno.env.get("SUPABASE_URL")!;
    const asUser = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
    const asService = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    const { data: prep, error: pe } = await asUser.rpc("prepare_gateway_order", { p_plan_id: plan_id });
    if (pe) return json({ error: pe.message }, pe.code === "P0002" ? 404 : pe.code === "54000" ? 429 : 400);
    if (prep.reuse) return json({ order_id: prep.order_id, short_url: prep.short_url, reused: true });

    const keyId = Deno.env.get("RAZORPAY_KEY_ID"), keySecret = Deno.env.get("RAZORPAY_KEY_SECRET");
    if (!keyId || !keySecret) return json({ error: "Online payment is not configured yet." }, 503);

    const phone = String(prep.phone ?? "").replace(/\D/g, "").slice(-10);
    const customer: Record<string, string> = { name: String(prep.member_name ?? "Member").slice(0, 50) };
    if (/^[6-9]\d{9}$/.test(phone)) customer.contact = "+91" + phone;
    if (prep.email && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(prep.email)) customer.email = prep.email;

    const body = {
      amount: Math.round(Number(prep.amount) * 100),
      currency: "INR",
      accept_partial: false,
      description: `${prep.plan_name} membership`,
      reference_id: prep.order_id,
      customer,
      notify: { sms: false, email: false },
      reminder_enable: false,
      notes: { order_id: prep.order_id },
      expire_by: Math.floor(Date.now() / 1000) + 40 * 60,
    };
    const r = await fetch("https://api.razorpay.com/v1/payment_links", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Basic " + btoa(`${keyId}:${keySecret}`) },
      body: JSON.stringify(body),
    });
    const link = await r.json();
    if (!r.ok) {
      console.error("razorpay error", r.status, JSON.stringify(link?.error ?? link));
      return json({ error: "Could not start the payment. Please try again." }, 502);
    }
    await asService.rpc("attach_gateway_link", { p_order_id: prep.order_id, p_ref: link.id, p_url: link.short_url });
    return json({ order_id: prep.order_id, short_url: link.short_url });
  } catch (e) {
    console.error(e);
    return json({ error: "Something went wrong." }, 500);
  }
});
