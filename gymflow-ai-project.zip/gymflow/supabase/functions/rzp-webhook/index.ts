// Razorpay -> us. Verifies the signature, then marks the order paid, starts the membership and creates the invoice.
// Deployed with verify_jwt = false (Razorpay has no Supabase login); the HMAC signature is the authentication.
// Secrets: RAZORPAY_WEBHOOK_SECRET (the secret you type when you create the webhook in the Razorpay dashboard)
import { createClient } from "npm:@supabase/supabase-js@2";

const enc = new TextEncoder();
async function hmacHex(secret: string, data: string) {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(data));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function safeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}
const methodMap: Record<string, string> = { upi: "upi", card: "card", netbanking: "bank_transfer" };

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("method not allowed", { status: 405 });
  const secret = Deno.env.get("RAZORPAY_WEBHOOK_SECRET");
  if (!secret) return new Response("webhook not configured", { status: 503 });
  const raw = await req.text();
  const sig = req.headers.get("x-razorpay-signature") ?? "";
  if (!safeEqual(sig, await hmacHex(secret, raw))) return new Response("bad signature", { status: 401 });

  let ev: any;
  try { ev = JSON.parse(raw); } catch { return new Response("bad json", { status: 400 }); }
  if (ev.event !== "payment_link.paid") return new Response("ignored", { status: 200 });

  const link = ev.payload?.payment_link?.entity, pay = ev.payload?.payment?.entity;
  if (!link?.id || !pay?.id) return new Response("missing data", { status: 200 });

  const svc = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data, error } = await svc.rpc("apply_gateway_payment", {
    p_ref: link.id, p_payment_id: pay.id, p_amount_paise: pay.amount, p_method: methodMap[pay.method] ?? "online",
  });
  if (error) { console.error("apply failed", error.message); return new Response("retry", { status: 500 }); } // Razorpay retries
  if (data?.status === "unknown_order" || data?.status === "amount_mismatch") console.error("webhook refused:", data.status, link.id);
  // Online payment done: send the invoice PDF on WhatsApp (never blocks or fails the webhook; the log table records the result).
  if (data?.status === "paid" && data?.payment_id) {
    const job = fetch(`${Deno.env.get("SUPABASE_URL")}/functions/v1/send-invoice`, {
      method: "POST", headers: { Authorization: `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}`, "Content-Type": "application/json" },
      body: JSON.stringify({ payment_id: data.payment_id }),
    }).catch((e) => console.error("send-invoice call failed", e?.message));
    // @ts-ignore EdgeRuntime exists on Supabase Edge Functions
    if (typeof EdgeRuntime !== "undefined" && EdgeRuntime.waitUntil) EdgeRuntime.waitUntil(job); else await job;
  }
  return new Response(JSON.stringify(data), { status: 200, headers: { "Content-Type": "application/json" } });
});
