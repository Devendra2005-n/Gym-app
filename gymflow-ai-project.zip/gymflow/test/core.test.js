const assert = require('assert');
const C = require('../www/core.js');

function mem() { const d = {}; return { getItem: k => d[k] || null, setItem: (k, v) => { d[k] = v; } }; }
const fixed = () => new Date('2026-11-16T10:00:00Z');
let passed = 0;
function t(name, fn) { try { fn(); passed++; console.log('ok   ' + name); } catch (e) { console.log('FAIL ' + name + '\n     ' + e.message); process.exitCode = 1; } }

const store = new C.Store(mem(), fixed);
const bot = new C.Assistant(store);

t('India date helper', () => {
  assert.strictEqual(C.todayIST('2026-11-16T20:00:00Z'), '2026-11-17'); // 01:30 IST next day
  assert.strictEqual(store.today(), '2026-11-16');
});
t('phone cleaning', () => {
  assert.strictEqual(C.cleanPhone('+91 98765-43210'), '9876543210');
  assert.strictEqual(C.cleanPhone('09876543210'), '9876543210');
});
t('registration rejects bad input', () => {
  const r = store.register({ name: '', phone: '123', email: 'nope', plan_id: 'x' });
  assert.strictEqual(r.ok, false); assert.strictEqual(r.errors.length, 4);
});
t('registration rejects inactive plan', () => {
  store.state.plans[0].active = false;
  const r = store.register({ name: 'Test User', phone: '9000000001', email: 'a@b.co', plan_id: 'plan_monthly' });
  store.state.plans[0].active = true;
  assert.strictEqual(r.ok, false);
});
t('registration creates member + membership, no payment', () => {
  const before = store.state.payments.length;
  const r = store.register({ name: '  Asha   Rane ', phone: '+91 90000 00001', email: ' ASHA@Mail.COM ', plan_id: 'plan_quarterly' });
  assert.strictEqual(r.ok, true); assert.strictEqual(r.member.phone, '9000000001'); assert.strictEqual(r.member.email, 'asha@mail.com');
  assert.strictEqual(r.membership.start_date, '2026-11-16'); assert.strictEqual(r.membership.end_date, '2027-02-14');
  assert.strictEqual(store.state.payments.length, before);
});
t('duplicate active phone is blocked', () => {
  const r = store.register({ name: 'Asha Rane', phone: '9000000001', email: 'asha@mail.com', plan_id: 'plan_monthly' });
  assert.strictEqual(r.ok, false); assert.strictEqual(r.code, 'duplicate');
});
t('existing member without active membership gets a new membership, not a new member', () => {
  const expired = store.expiryReport(0, 'expired')[0];
  const count = store.state.members.length;
  const r = store.register({ name: expired.name, phone: expired.phone, email: 'x@y.com', plan_id: 'plan_monthly' });
  assert.strictEqual(r.ok, true); assert.strictEqual(r.code, 'renewed_existing');
  assert.strictEqual(store.state.members.length, count);
});
t('search returns at most 10, by name/phone/email', () => {
  assert.ok(store.searchMembers('patil').length >= 2);
  assert.strictEqual(store.searchMembers('rohan')[0].name, 'Rohan Patil');
  assert.ok(store.searchMembers('rohan.patil@example').length === 1);
  assert.ok(store.searchMembers('a').length <= 10);
});
t('payment lookup totals', () => {
  const m = store.searchMembers('rohan')[0], p = store.paymentLookup(m.id);
  assert.strictEqual(p.total_paid, p.payments.reduce((s, x) => s + x.amount, 0));
  assert.ok(p.last_payment);
});
t('revenue defaults to this month and splits correctly', () => {
  const r = store.revenueReport();
  assert.strictEqual(r.from, '2026-11-01');
  assert.strictEqual(r.total, r.by_method.reduce((s, x) => s + x.amount, 0));
  assert.strictEqual(r.total, r.by_day.reduce((s, x) => s + x.amount, 0));
});
t('expiry report windows', () => {
  store.state.memberships.forEach(() => {});
  store.expiryReport(7).forEach(r => assert.ok(r.days_left >= 0 && r.days_left <= 7));
  store.expiryReport(0, 'expired').forEach(r => assert.ok(r.days_left < 0));
});
t('attendance whole gym vs one member', () => {
  const all = store.attendanceReport('2026-10-01', '2026-11-16');
  const m = store.searchMembers('rohan')[0];
  const one = store.attendanceReport('2026-10-01', '2026-11-16', m.id);
  assert.ok(all.total_visits >= one.total_visits);
});
t('assistant refuses writes', () => {
  assert.ok(/read-only/i.test(bot.ask('Register a new member Ravi')));
  assert.ok(/read-only/i.test(bot.ask('delete Rohan Patil')));
});
t('assistant keeps health notes private', () => {
  assert.ok(/private/i.test(bot.ask("What are Rohan's health notes?")));
});
t('assistant answers revenue / expiry', () => {
  assert.ok(/Revenue for this month/.test(bot.ask('revenue this month')));
  assert.ok(/Expiring|No memberships expiring/.test(bot.ask('who expires in the next 10 days?')));
  assert.ok(/Expired memberships|No expired/.test(bot.ask('show already expired members')));
});
t('assistant asks which member when several match, then resolves', () => {
  const q = bot.ask('payments of patil');
  assert.ok(/Which one/.test(q), q);
  const a = bot.ask('1');
  assert.ok(/Payments for/.test(a), a);
});
t('assistant single-member lookup never leaks health notes', () => {
  const a = bot.ask('find Rohan Patil');
  assert.ok(/Rohan Patil/.test(a)); assert.ok(!/Private note/.test(a));
});
t('assistant keeps only last 10 messages', () => {
  for (let i = 0; i < 12; i++) bot.ask('revenue today');
  assert.strictEqual(bot.history.length, 10);
});
t('export/import roundtrip', () => {
  const s2 = new C.Store(mem(), fixed); s2.importJSON(store.exportJSON());
  assert.strictEqual(s2.state.members.length, store.state.members.length);
});
// ---------- v2 features: QR attendance, payments, UPI, FAQ ----------
const qrgen = require('../www/vendor/qrcode.js');
let jsQR = require('../www/vendor/jsQR.js'); jsQR = jsQR.default || jsQR;
function renderQR(text) {
  const q = qrgen(0, 'M'); q.addData(text); q.make();
  const n = q.getModuleCount(), scale = 6, quiet = 4, size = (n + quiet * 2) * scale;
  const data = new Uint8ClampedArray(size * size * 4).fill(255);
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) {
    for (let y = 0; y < scale; y++) for (let x = 0; x < scale; x++) {
      const i = (((r + quiet) * scale + y) * size + (c + quiet) * scale + x) * 4; data[i] = data[i + 1] = data[i + 2] = 0;
    }
  }
  return { data, size };
}
const s2 = new C.Store(mem(), fixed);
const rohan = s2.searchMembers('rohan')[0];
const expiredOne = s2.expiryReport(0, 'expired')[0];

t('member QR text survives generate -> scan round trip', () => {
  const txt = C.memberQRText(rohan), img = renderQR(txt);
  const res = jsQR(img.data, img.size, img.size);
  assert.ok(res, 'jsQR could not read the code'); assert.strictEqual(res.data, txt);
  assert.strictEqual(s2.parseQR(res.data).id, rohan.id);
});
t('QR with wrong phone or junk is rejected', () => {
  assert.strictEqual(s2.parseQR('GF1|' + rohan.id + '|9999999999'), null);
  assert.strictEqual(s2.parseQR('hello'), null);
  assert.strictEqual(s2.scanCheckIn('hello').code, 'invalid_qr');
});
t('check-in records IST time once per day', () => {
  const before = s2.state.attendance.length;
  s2.state.attendance = s2.state.attendance.filter(a => !(a.member_id === rohan.id && a.visit_date === '2026-11-16'));
  const r = s2.scanCheckIn(C.memberQRText(rohan));
  assert.strictEqual(r.ok, true); assert.strictEqual(r.time, '15:30');
  const again = s2.checkIn(rohan.id);
  assert.strictEqual(again.ok, false); assert.strictEqual(again.code, 'already'); assert.strictEqual(again.time, '15:30');
  assert.ok(s2.todayAttendance().list.some(x => x.member_id === rohan.id && x.time === '15:30'));
});
t('expired member is blocked unless forced', () => {
  s2.state.attendance = s2.state.attendance.filter(a => !(a.member_id === expiredOne.member_id && a.visit_date === '2026-11-16'));
  assert.strictEqual(s2.checkIn(expiredOne.member_id).code, 'expired');
  const f = s2.checkIn(expiredOne.member_id, { force: true });
  assert.strictEqual(f.ok, true); assert.strictEqual(f.expired, true);
});
t('attendance report has hourly distribution', () => {
  const r = s2.attendanceReport('2026-10-01', '2026-11-16');
  assert.strictEqual(r.by_hour.length, 24); assert.strictEqual(r.by_hour.reduce((a, b) => a + b, 0), r.total_visits);
});
t('UPI links are well formed', () => {
  const o = { pa: 'gym@okhdfc', pn: 'Fitness Arena', am: 1000, tn: 'Monthly Basic', tr: 'GFabc' };
  assert.strictEqual(C.upiLink(o), 'upi://pay?pa=gym@okhdfc&pn=Fitness%20Arena&am=1000.00&cu=INR&tn=Monthly%20Basic&tr=GFabc');
  assert.ok(C.gpayLink(o).indexOf('tez://upi/pay?pa=gym@okhdfc') === 0);
  assert.ok(C.validUpiId('gym@okhdfc') && C.validUpiId('98100.00000@ybl') && !C.validUpiId('gym') && !C.validUpiId('a b@c'));
  assert.ok(C.validAmount(1000) && C.validAmount(99.5) && !C.validAmount(0) && !C.validAmount(-5) && !C.validAmount(10.123) && !C.validAmount('x'));
});
t('settings validate UPI id', () => {
  assert.throws(() => s2.setSettings({ upi_id: 'bad', payee_name: 'Gym' }));
  s2.setSettings({ upi_id: 'gym@okhdfc', payee_name: 'Fitness Arena' });
  assert.strictEqual(s2.state.settings.upi_id, 'gym@okhdfc');
});
t('recordPayment validates and shows in revenue', () => {
  assert.strictEqual(s2.recordPayment({ member_id: 'nope', amount: 100, method: 'upi' }).ok, false);
  assert.strictEqual(s2.recordPayment({ member_id: rohan.id, amount: 0, method: 'upi' }).ok, false);
  assert.strictEqual(s2.recordPayment({ member_id: rohan.id, amount: 100, method: 'bitcoin' }).ok, false);
  const before = s2.revenueReport().total;
  const r = s2.recordPayment({ member_id: rohan.id, amount: 1500, method: 'upi', ref: 'UTR123' });
  assert.strictEqual(r.ok, true); assert.strictEqual(s2.revenueReport().total, before + 1500);
  assert.strictEqual(s2.recentPayments(1)[0].amount, 1500);
});
t('payment with renew extends from current end date', () => {
  const ms = s2.membershipLookup(rohan.id)[0];
  const r = s2.recordPayment({ member_id: rohan.id, amount: 1000, method: 'cash', plan_id: 'plan_monthly', renew: true });
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.membership.start_date, C.addDays(ms.end_date, 1));
  assert.strictEqual(r.membership.end_date, C.addDays(r.membership.start_date, 30));
});
t('renew for an expired member starts today', () => {
  const r = s2.recordPayment({ member_id: expiredOne.member_id, amount: 1000, method: 'card', plan_id: 'plan_monthly', renew: true });
  assert.strictEqual(r.membership.start_date, '2026-11-16');
});
t('FAQ add / remove', () => {
  assert.throws(() => s2.addFaq('hi', ''));
  const f = s2.addFaq('Is parking available?', 'Yes, free parking for members.');
  assert.strictEqual(s2.state.faqs.length, 1);
  s2.removeFaq(f.id); assert.strictEqual(s2.state.faqs.length, 0);
});
t('old v1 saved data gains settings/faqs and keeps its records', () => {
  const old = new C.Store(mem(), fixed); const snap = JSON.parse(old.exportJSON());
  delete snap.settings; delete snap.faqs;
  const storage = mem(); storage.setItem('gymflow.v1', JSON.stringify(snap));
  const s3 = new C.Store(storage, fixed);
  assert.strictEqual(s3.state.members.length, snap.members.length);
  assert.strictEqual(s3.state.settings.payee_name, 'Fitness Arena'); assert.deepStrictEqual(s3.state.faqs, []);
});
t('clear/reset keep payment settings and custom FAQs', () => {
  s2.addFaq('Keep me please?', 'Yes.');
  s2.clearAll(); assert.strictEqual(s2.state.members.length, 0); assert.strictEqual(s2.state.settings.upi_id, 'gym@okhdfc'); assert.strictEqual(s2.state.faqs.length, 1);
  s2.resetDemo(); assert.ok(s2.state.members.length > 0); assert.strictEqual(s2.state.faqs.length, 1);
});
// ---------- v3: owner gym QR + member pass ----------
let clock = Date.parse('2026-11-16T10:00:00Z');
const s4 = new C.Store(mem(), () => new Date(clock));
const MK = C.MemberKit;
const mstore = mem();
t('gym QR is stable inside 5 minutes and changes in the next window', () => {
  const a = s4.gymQR(); clock += 60 * 1000; const b = s4.gymQR();
  assert.strictEqual(a.code, b.code); assert.ok(/^[0-9A-F]{8}$/.test(a.code));
  clock += 5 * 60 * 1000; assert.notStrictEqual(s4.gymQR().code, a.code);
  assert.ok(s4.gymQR().seconds_left > 0 && s4.gymQR().seconds_left <= 300);
});
t('gym QR text parses on the member side and survives a QR round trip', () => {
  const g = s4.gymQR(), img = renderQR(g.text), res = jsQR(img.data, img.size, img.size);
  assert.ok(res && res.data === g.text);
  const p = MK.parseGymQR(res.data, clock);
  assert.strictEqual(p.code, g.code); assert.strictEqual(p.gym, 'Fitness Arena'); assert.strictEqual(p.fresh, true);
  assert.strictEqual(MK.parseGymQR(res.data, clock + 40 * 60 * 1000).fresh, false);
  assert.strictEqual(MK.parseGymQR('GF1|x|y', clock), null);
});
t('member pass checks the member in (phone must match a member)', () => {
  const m = s4.state.members[3], code = s4.gymQR().code;
  s4.state.attendance = s4.state.attendance.filter(a => !(a.member_id === m.id && a.visit_date === s4.today()));
  const pass = MK.buildPass(m.phone, code);
  const img = renderQR(pass), res = jsQR(img.data, img.size, img.size);
  assert.strictEqual(res.data, pass);
  const r = s4.scanCheckIn(res.data);
  assert.strictEqual(r.ok, true); assert.strictEqual(r.member.id, m.id);
  assert.strictEqual(s4.scanCheckIn(pass).code, 'already');
});
t('pass with a wrong or typed code: spaces/lowercase ok, wrong rejected', () => {
  const m = s4.state.members[1], code = s4.gymQR().code;
  s4.state.attendance = s4.state.attendance.filter(a => a.member_id !== m.id || a.visit_date !== s4.today());
  assert.strictEqual(s4.scanCheckIn(MK.buildPass(m.phone, '00000000')).code, 'bad_code');
  const typed = (code.slice(0, 4) + ' ' + code.slice(4)).toLowerCase();
  assert.strictEqual(MK.normalizeCode(typed), code);
  assert.strictEqual(s4.scanCheckIn(MK.buildPass(m.phone, typed)).ok, true);
});
t('pass is accepted for about 15 minutes, then refused', () => {
  const m = s4.state.members[2], code = s4.gymQR().code;
  s4.state.attendance = s4.state.attendance.filter(a => a.member_id !== m.id || a.visit_date !== s4.today());
  clock += 9 * 60 * 1000;   // still within the 3 accepted windows
  assert.strictEqual(s4.validGymCode(code), true);
  clock += 12 * 60 * 1000;  // now too old
  assert.strictEqual(s4.scanCheckIn(MK.buildPass(m.phone, code)).code, 'bad_code');
});
t('unknown phone and junk passes are rejected', () => {
  assert.strictEqual(s4.scanCheckIn(MK.buildPass('9000099999', s4.gymQR().code)).code, 'not_found');
  assert.strictEqual(s4.scanCheckIn('GFC1|only-two').code, 'invalid_qr');
});
t('gym secret survives settings changes, backups and resets', () => {
  const code = s4.gymQR().code;
  s4.setSettings({ upi_id: 'gym@okhdfc', payee_name: 'Fitness Arena' });
  assert.strictEqual(s4.gymQR().code, code);
  const s5 = new C.Store(mem(), () => new Date(clock)); s5.importJSON(s4.exportJSON());
  assert.strictEqual(s5.gymQR().code, code);
  s4.clearAll(); assert.strictEqual(s4.gymQR().code, code);
  assert.notStrictEqual(new C.Store(mem(), () => new Date(clock)).gymQR().code, code);   // other gyms get other codes
});
t('member profile: link phone, validate, keep history', () => {
  assert.strictEqual(MK.linkPhone(mstore, '12345').ok, false);
  assert.strictEqual(MK.linkPhone(mstore, '+91 98100 12345').phone, '9810012345');
  MK.addVisit(mstore, { date: '2026-11-16', time: '10:05', gym: 'Fitness Arena' });
  const p = MK.get(mstore); assert.strictEqual(p.phone, '9810012345'); assert.strictEqual(p.visits.length, 1);
  assert.deepStrictEqual(MK.get(mem()), { phone: '', visits: [] });
});
const SHOP = require('../www/products.js');
t('product catalog: 70+ items, unique ids, varied prices, all categories, art for each', () => {
  assert.ok(SHOP.PRODUCTS.length >= 70, 'count ' + SHOP.PRODUCTS.length);
  assert.strictEqual(new Set(SHOP.PRODUCTS.map(p => p.id)).size, SHOP.PRODUCTS.length);
  assert.strictEqual(new Set(SHOP.PRODUCTS.map(p => p.price)).size, SHOP.PRODUCTS.length);
  SHOP.CATS.forEach(c => assert.ok(SHOP.PRODUCTS.some(p => p.cat === c.id), c.id));
  SHOP.PRODUCTS.forEach(p => { assert.ok(C.validAmount(p.price), p.id); assert.ok(/^#[0-9a-f]{6}$/i.test(p.color)); assert.ok(SHOP.art(p.art, p.color).indexOf('<svg') === 0); });
});
t('product sale: totals, validation, recent list, summary, keeps fee payments separate', () => {
  const s6 = new C.Store(mem(), () => new Date(clock));
  const fees = s6.state.payments.length, m = s6.state.members[1];
  const items = [{ id: 'p01', name: 'Whey', price: 2899, qty: 2 }, { id: 'p14', name: 'Shaker', price: 249.5, qty: 1 }];
  const r = s6.recordSale({ items, member_id: m.id, method: 'upi', ref: 'R1' });
  assert.strictEqual(r.ok, true); assert.strictEqual(r.sale.total, 6047.5); assert.strictEqual(r.sale.customer, m.name);
  assert.strictEqual(s6.recordSale({ items: [], method: 'cash' }).ok, false);
  assert.strictEqual(s6.recordSale({ items, method: 'bitcoin' }).ok, false);
  assert.strictEqual(s6.recordSale({ items: [{ id: 'x', name: 'x', price: 10, qty: 0 }], method: 'cash' }).ok, false);
  assert.strictEqual(s6.recordSale({ items, member_id: 'nope', method: 'cash' }).ok, false);
  const w = s6.recordSale({ items: [{ id: 'p20', name: 'Rope', price: 279, qty: 3 }], customer: '  ', method: 'cash' });
  assert.strictEqual(w.sale.customer, 'Walk-in'); assert.strictEqual(w.sale.total, 837);
  assert.strictEqual(s6.recentSales(5).length, 2);
  const sum = s6.salesSummary(); assert.strictEqual(sum.count, 2); assert.strictEqual(sum.units, 6); assert.strictEqual(sum.total, 6884.5);
  assert.strictEqual(s6.state.payments.length, fees);
  const s7 = new C.Store(mem(), () => new Date(clock)); s7.importJSON(s6.exportJSON()); assert.strictEqual(s7.state.sales.length, 2);
  s6.clearAll(); assert.strictEqual(s6.state.sales.length, 0);
});
const GK = C.GoalKit;
t('goals: create with any number of days, validation, limits', () => {
  const st = mem();
  assert.strictEqual(GK.create(st, { title: 'x', days: 3 }, '2026-11-17').ok, false);
  assert.strictEqual(GK.create(st, { title: 'Daily walk', days: 0 }, '2026-11-17').ok, false);
  assert.strictEqual(GK.create(st, { title: 'Daily walk', days: 2.5 }, '2026-11-17').ok, false);
  assert.strictEqual(GK.create(st, { title: 'Daily walk', days: 366 }, '2026-11-17').ok, false);
  [1, 2, 3, 45, 365].forEach(d => assert.strictEqual(GK.create(st, { title: '  Goal   ' + d + ' ', days: d }, '2026-11-17').ok, true));
  assert.strictEqual(GK.list(st).length, 5);
  assert.strictEqual(GK.list(st)[4].title, 'Goal 1');
  for (let i = 0; i < 25; i++) GK.create(st, { title: 'Extra ' + i, days: 7 }, '2026-11-17');
  assert.strictEqual(GK.create(st, { title: 'One too many', days: 7 }, '2026-11-17').ok, false);
});
t('goals: tick days, streak, missed, percent, status over time', () => {
  const st = mem(), g = GK.create(st, { title: '3 day push', days: 3 }, '2026-11-10').goal;
  let s = GK.stats(GK.get(st, g.id), '2026-11-10');
  assert.strictEqual(s.status, 'active'); assert.strictEqual(s.day_no, 1); assert.strictEqual(s.days_left, 3); assert.strictEqual(s.percent, 0);
  assert.strictEqual(GK.setDay(st, g.id, '2026-11-11', true, '2026-11-10').ok, false);   // future
  assert.strictEqual(GK.setDay(st, g.id, '2026-11-09', true, '2026-11-10').ok, false);   // before start
  assert.strictEqual(GK.setDay(st, g.id, '2026-11-10', true, '2026-11-10').ok, true);
  s = GK.stats(GK.get(st, g.id), '2026-11-10'); assert.strictEqual(s.percent, 33); assert.strictEqual(s.streak, 1); assert.strictEqual(s.today_done, true);
  s = GK.stats(GK.get(st, g.id), '2026-11-11');                                       // day 2, today still open: streak counts yesterday
  assert.strictEqual(s.streak, 1); assert.strictEqual(s.missed, 0); assert.strictEqual(s.today_done, false);
  s = GK.stats(GK.get(st, g.id), '2026-11-12');                                       // skipped day 2
  assert.strictEqual(s.streak, 0); assert.strictEqual(s.missed, 1);
  GK.setDay(st, g.id, '2026-11-12', true, '2026-11-12');
  s = GK.stats(GK.get(st, g.id), '2026-11-12'); assert.strictEqual(s.done, 2); assert.strictEqual(s.streak, 1); assert.strictEqual(s.best, 1);
  GK.setDay(st, g.id, '2026-11-11', true, '2026-11-12');                              // catch-up on a past day
  s = GK.stats(GK.get(st, g.id), '2026-11-12'); assert.strictEqual(s.status, 'achieved'); assert.strictEqual(s.percent, 100); assert.strictEqual(s.streak, 3); assert.strictEqual(s.best, 3);
  GK.setDay(st, g.id, '2026-11-11', false, '2026-11-12');                             // untick
  s = GK.stats(GK.get(st, g.id), '2026-11-15'); assert.strictEqual(s.status, 'ended'); assert.strictEqual(s.days_left, 0); assert.strictEqual(s.missed, 1);
  assert.strictEqual(s.cells.length, 3); assert.deepStrictEqual(s.cells.map(c => c.state), ['done', 'missed', 'done']);
});
t('goals: restart, delete, survive broken storage', () => {
  const st = mem(), g = GK.create(st, { title: 'Abs month', days: 30, note: 'plank + crunches' }, '2026-11-01').goal;
  const r = GK.restart(st, g.id, '2026-12-01'); assert.strictEqual(r.ok, true); assert.strictEqual(r.goal.start, '2026-12-01'); assert.strictEqual(r.goal.days, 30);
  assert.strictEqual(GK.list(st).length, 2);
  GK.remove(st, g.id); assert.strictEqual(GK.list(st).length, 1);
  const bad = mem(); bad.setItem('gymflow.goals.v1', '{not json'); assert.deepStrictEqual(GK.list(bad), []);
});
const WELL = require('../www/wellness.js'), DK = C.DietKit;
t('trainers and diet plans: content is complete', () => {
  assert.ok(WELL.TRAINERS.length >= 6);
  WELL.TRAINERS.forEach(x => { assert.ok(x.name && x.focus.length && x.slots.every(i => WELL.SLOTS[i])); assert.ok(WELL.avatar(x.look).indexOf('<svg') === 0); WELL.packages(x).forEach(pk => assert.ok(C.validAmount(pk.price))); });
  assert.ok(WELL.packages(WELL.TRAINERS[0])[1].price > WELL.TRAINERS[0].session);
  const veg = WELL.PLANS.filter(p => p.type === 'veg'), non = WELL.PLANS.filter(p => p.type === 'nonveg');
  assert.ok(veg.length >= 7 && non.length >= 7);
  WELL.PLANS.forEach(p => { assert.deepStrictEqual(p.meals.map(m => m.slot), ['breakfast', 'lunch', 'snack', 'dinner']); p.meals.forEach(m => { assert.ok(m.items.length && m.kcal > 0 && m.protein > 0); assert.ok(WELL.food(m.art).indexOf('<svg') === 0); }); });
  non.forEach(p => assert.ok(WELL.planTotals(p).protein >= 80));
  assert.strictEqual(new Set(WELL.PLANS.map(p => p.id)).size, WELL.PLANS.length);
});
t('diet kit: start plan, edit times, tick meals, summary, next meal', () => {
  const st = mem();
  assert.strictEqual(DK.get(st).plan_id, ''); assert.deepStrictEqual(DK.get(st).times, DK.DEFAULT_TIMES);
  assert.strictEqual(DK.start(st, '', '2026-11-10').ok, false);
  assert.strictEqual(DK.start(st, 'dv1', '2026-11-10').ok, true);
  assert.strictEqual(DK.setTime(st, 'lunch', '25:00').ok, false);
  assert.strictEqual(DK.setTime(st, 'brunch', '10:00').ok, false);
  assert.strictEqual(DK.setTime(st, 'lunch', '1:5').ok, false);
  assert.strictEqual(DK.setTime(st, 'lunch', '12:45').diet.times.lunch, '12:45');
  assert.deepStrictEqual(DK.parseHM('07:05'), { hour: 7, minute: 5 }); assert.strictEqual(DK.parseHM('7pm'), null);
  DK.toggleMeal(st, '2026-11-12', 'breakfast'); DK.toggleMeal(st, '2026-11-12', 'lunch'); DK.toggleMeal(st, '2026-11-11', 'dinner');
  let sm = DK.summary(DK.get(st), '2026-11-12'); assert.strictEqual(sm.day_no, 3); assert.strictEqual(sm.today_done, 2); assert.strictEqual(sm.week_done, 3); assert.strictEqual(sm.week_possible, 12);
  DK.toggleMeal(st, '2026-11-12', 'lunch'); assert.strictEqual(DK.summary(DK.get(st), '2026-11-12').today_done, 1);
  assert.strictEqual(DK.nextMeal(DK.get(st), '09:00'), 'lunch'); assert.strictEqual(DK.nextMeal(DK.get(st), '21:00'), null);
  assert.strictEqual(DK.setRemind(st, false).remind, false);
  DK.stop(st); assert.strictEqual(DK.get(st).plan_id, ''); assert.strictEqual(DK.get(st).remind, false);   // reminder choice survives
  assert.strictEqual(DK.toggleMeal(st, '2026-11-12', 'lunch').ok, false);
  const bad = mem(); bad.setItem('gymflow.diet.v1', 'xx'); assert.strictEqual(DK.get(bad).plan_id, '');
});
t('trainer bookings: validation, statuses, cancel, contact number, backup', () => {
  const s8 = new C.Store(mem(), () => new Date(clock)), today = s8.today(), m = s8.state.members[1];
  const base = { trainer_id: 't1', trainer_name: 'Rohan Patil', package: '1 month', sessions: 12, amount: 5800, slot: 'Evening 5–8 pm', start_date: today, goal: 'Muscle gain', method: 'upi', ref: 'U1' };
  assert.strictEqual(s8.recordBooking(Object.assign({}, base, { customer: 'A', phone: '9876543210' })).ok, false);
  assert.strictEqual(s8.recordBooking(Object.assign({}, base, { customer: 'Asha Rao', phone: '12345' })).ok, false);
  assert.strictEqual(s8.recordBooking(Object.assign({}, base, { customer: 'Asha Rao', phone: '9876543210', start_date: C.addDays(today, -1) })).ok, false);
  assert.strictEqual(s8.recordBooking(Object.assign({}, base, { customer: 'Asha Rao', phone: '9876543210', method: 'crypto' })).ok, false);
  assert.strictEqual(s8.recordBooking(Object.assign({}, base, { customer: 'Asha Rao', phone: '9876543210', slot: '' })).ok, false);
  const a = s8.recordBooking(Object.assign({}, base, { customer: 'Asha Rao', phone: '+91 98765 43210' }));
  assert.strictEqual(a.ok, true); assert.strictEqual(a.booking.status, 'paid'); assert.strictEqual(a.booking.phone, '9876543210');
  const b = s8.recordBooking(Object.assign({}, base, { member_id: m.id, method: 'later' }));
  assert.strictEqual(b.booking.status, 'pay_later'); assert.strictEqual(b.booking.customer, m.name); assert.strictEqual(b.booking.phone, m.phone);
  assert.strictEqual(s8.recordBooking(Object.assign({}, base, { member_id: 'nope' })).ok, false);
  assert.strictEqual(s8.recentBookings().length, 2);
  assert.strictEqual(s8.cancelBooking(b.booking.id).booking.status, 'cancelled'); assert.strictEqual(s8.cancelBooking('zzz').ok, false);
  assert.throws(() => s8.setContact('123'));
  s8.setContact('+91 98123 45678'); assert.strictEqual(s8.state.settings.gym_phone, '9812345678'); assert.ok(s8.state.settings.gym_secret || true);
  s8.setSettings({ upi_id: 'gym@okhdfc', payee_name: 'Fitness Arena' }); assert.strictEqual(s8.state.settings.gym_phone, '9812345678');   // settings merge keeps it
  const s9 = new C.Store(mem(), () => new Date(clock)); s9.importJSON(s8.exportJSON()); assert.strictEqual(s9.state.bookings.length, 2);
  s8.clearAll(); assert.strictEqual(s8.state.bookings.length, 0);
});
const KX = require('../www/content.js'), AN = require('../www/anim.js'), CLB = require('../www/clubs.js');
t('exercises: 40+ with calorie, muscle and fat data, valid poses, new cardio category', () => {
  assert.ok(KX.EXERCISES.length >= 40);
  assert.strictEqual(new Set(KX.EXERCISES.map(e => e.id)).size, KX.EXERCISES.length);
  assert.ok(KX.CATEGORIES.some(c => c.id === 'cardio'));
  KX.CATEGORIES.forEach(c => assert.ok(KX.EXERCISES.some(e => e.cat === c.id), c.id));
  KX.EXERCISES.forEach(e => {
    assert.ok(KX.CATEGORIES.some(c => c.id === e.cat), e.id);
    assert.ok(e.met >= 2 && e.met <= 14, e.id + ' met');
    [e.muscle, e.fat].forEach(v => assert.ok(Number.isInteger(v) && v >= 1 && v <= 5, e.id + ' rating'));
    assert.ok(e.steps.length >= 3 && e.tips.length >= 1 && e.muscles.length >= 1, e.id);
    [0, 0.5, 1].forEach(u => assert.ok(AN.draw(e, u).indexOf('NaN') === -1, e.id + ' pose NaN at ' + u));
  });
  assert.ok(KX.EXERCISES.filter(e => e.cat === 'cardio').every(e => e.fat >= 4));
  const sq = KX.EXERCISES.find(e => e.id === 'squat'), cu = KX.EXERCISES.find(e => e.id === 'lateral-raise');
  assert.ok(sq.fat > cu.fat && sq.muscle >= cu.muscle);
});
t('exercise burn: MET x kg x hours, fat equivalent, bad input', () => {
  const sq = KX.EXERCISES.find(e => e.id === 'squat');             // MET 6
  assert.strictEqual(KX.burn(sq, 70, 60).kcal, 420); assert.strictEqual(KX.burn(sq, 70, 30).kcal, 210);
  assert.strictEqual(KX.burn(sq, 70, 10).kcal, 70);  assert.strictEqual(KX.burn(sq, 70, 60).fat_g, 54.5);
  assert.ok(KX.burn(sq, 90, 10).kcal > KX.burn(sq, 60, 10).kcal);
  assert.deepStrictEqual(KX.burn(sq, 0, 10), { kcal: 0, fat_g: 0 }); assert.deepStrictEqual(KX.burn(sq, 70, 0), { kcal: 0, fat_g: 0 });
  assert.deepStrictEqual(KX.burn(sq, 'abc', 10), { kcal: 0, fat_g: 0 }); assert.deepStrictEqual(KX.burn(sq, 70, 1000), { kcal: 0, fat_g: 0 });
});
t('clubs: content, join rules, points and reward levels, leave', () => {
  assert.ok(CLB.CLUBS.length >= 10 && new Set(CLB.CLUBS.map(c => c.id)).size === CLB.CLUBS.length);
  CLB.CLUBS.forEach(c => { assert.ok(c.perks.length >= 3 && c.tiers.length >= 3 && c.welcome > 0 && c.members > 0 && c.tiers[0].visits === 0); assert.ok(CLB.emblem(c).indexOf('<svg') === 0); assert.ok(c.tiers.every((x, i) => i === 0 || x.visits > c.tiers[i - 1].visits)); });
  const s10 = new C.Store(mem(), () => new Date(clock)), club = CLB.CLUBS[0], m = s10.state.members[1];
  const base = { club_id: club.id, club_name: club.name, welcome_points: club.welcome };
  assert.strictEqual(s10.joinClub(Object.assign({}, base, { customer: 'A', phone: '9876543210' })).ok, false);
  assert.strictEqual(s10.joinClub(Object.assign({}, base, { customer: 'Asha Rao', phone: '123' })).ok, false);
  assert.strictEqual(s10.joinClub({ customer: 'Asha Rao', phone: '9876543210' }).ok, false);
  assert.strictEqual(s10.joinClub(Object.assign({}, base, { member_id: 'nope' })).ok, false);
  const a = s10.joinClub(Object.assign({}, base, { customer: 'Asha Rao', phone: '+91 98765 43210' }));
  assert.strictEqual(a.ok, true); assert.strictEqual(a.join.member_id, null); assert.strictEqual(a.join.welcome_points, club.welcome);
  assert.strictEqual(s10.joinClub(Object.assign({}, base, { customer: 'Asha Again', phone: '9876543210' })).ok, false);          // same phone, same club
  assert.strictEqual(s10.joinClub(Object.assign({}, CLB.CLUBS[1] && { club_id: CLB.CLUBS[1].id, club_name: CLB.CLUBS[1].name, welcome_points: 100 }, { customer: 'Asha Rao', phone: '9876543210' })).ok, true);   // other club is fine
  const b = s10.joinClub(Object.assign({}, base, { member_id: m.id }));
  assert.strictEqual(b.ok, true); assert.strictEqual(b.join.phone, m.phone); assert.strictEqual(b.join.member_id, m.id);
  const c2 = s10.joinClub({ club_id: 'x', club_name: 'X', customer: 'Walk Up', phone: m.phone });                                   // typed phone of a registered member links to them
  assert.strictEqual(c2.join.member_id, m.id);
  assert.strictEqual(s10.clubCount(club.id), 2); assert.strictEqual(s10.clubJoins(m.phone).length, 2);
  let st = s10.clubStats(b.join, club.tiers); assert.strictEqual(st.visits, 0); assert.strictEqual(st.tier.name, 'Bronze'); assert.strictEqual(st.next.name, 'Silver'); assert.strictEqual(st.to_next, 12); assert.strictEqual(st.points, club.welcome);
  for (let i = 0; i < 12; i++) s10.state.attendance.push({ id: 'att_x' + i, member_id: m.id, gym_id: 'g', visit_date: s10.today(), check_in: '07:00' });
  s10.state.attendance.push({ id: 'att_old', member_id: m.id, gym_id: 'g', visit_date: C.addDays(s10.today(), -40), check_in: '07:00' });   // before joining: not counted
  st = s10.clubStats(b.join, club.tiers); assert.strictEqual(st.visits, 12); assert.strictEqual(st.tier.name, 'Silver'); assert.strictEqual(st.next.name, 'Gold'); assert.strictEqual(st.points, club.welcome + 12 * C.CLUB_VISIT_POINTS);
  st = s10.clubStats(a.join, club.tiers); assert.strictEqual(st.tracked, false); assert.strictEqual(st.visits, 0);
  assert.strictEqual(s10.leaveClub(a.join.id).ok, true); assert.strictEqual(s10.leaveClub(a.join.id).ok, false); assert.strictEqual(s10.clubCount(club.id), 1);
  const s11 = new C.Store(mem(), () => new Date(clock)); s11.importJSON(s10.exportJSON()); assert.ok(s11.state.club_joins.length >= 3);
  s10.clearAll(); assert.strictEqual(s10.state.club_joins.length, 0);
});

t('FitKit: logs, weigh-ins and weekly summary', () => {
  const st = mem(), today = '2026-11-18';
  assert.strictEqual(C.FitKit.logWorkout(st, { name: '', minutes: 10, kcal: 50 }, today).ok, false);
  assert.strictEqual(C.FitKit.logWorkout(st, { name: 'Squat', minutes: 0, kcal: 50 }, today).ok, false);
  C.FitKit.logWorkout(st, { name: 'Squat', minutes: 20, kcal: 150 }, today);
  C.FitKit.logWorkout(st, { name: 'Squat', minutes: 10, kcal: 70, date: '2026-11-16' }, today);
  C.FitKit.logWorkout(st, { name: 'Running', minutes: 30, kcal: 300, date: '2026-11-12' }, today);   // 6 days back: inside
  C.FitKit.logWorkout(st, { name: 'Old', minutes: 30, kcal: 999, date: '2026-11-11' }, today);       // 7 days back: outside
  assert.strictEqual(C.FitKit.logWeight(st, 5, '2026-11-12').ok, false);
  C.FitKit.logWeight(st, 80, '2026-11-10'); C.FitKit.logWeight(st, 79.4, '2026-11-18');
  const w = C.FitKit.week(st, today, ['2026-11-18', '2026-11-18', '2026-11-16', '2026-11-01']);
  assert.strictEqual(w.start, '2026-11-12'); assert.strictEqual(w.days.length, 7);
  assert.strictEqual(w.count, 3); assert.strictEqual(w.kcal, 520); assert.strictEqual(w.minutes, 60); assert.strictEqual(w.active_days, 3);
  assert.strictEqual(w.fat_g, Math.round(520 / 7700 * 1000)); assert.strictEqual(w.top[0].name, 'Running'); assert.strictEqual(w.gym_visits, 2);
  assert.strictEqual(w.days[6].kcal, 150); assert.strictEqual(w.days[0].kcal, 300);
  assert.strictEqual(w.weight.start, 80); assert.strictEqual(w.weight.end, 79.4); assert.strictEqual(w.weight.change, -0.6);
  const prev = C.FitKit.week(st, '2026-11-11', []); assert.strictEqual(prev.kcal, 999); assert.strictEqual(prev.weight.change, null);
  const empty = C.FitKit.week(mem(), today, []); assert.strictEqual(empty.count, 0); assert.strictEqual(empty.weight, null);
});
t('Invoice data, GST split, WhatsApp text and link', () => {
  const s = new C.Store(mem(), () => new Date('2026-11-18T10:00:00Z')); s.resetDemo();
  const m = s.state.members[0], plan = s.state.plans.filter(p => p.active)[0];
  const r = s.recordPayment({ member_id: m.id, amount: plan.price, method: 'upi', ref: 'UPI123', plan_id: plan.id, renew: true });
  assert.ok(r.ok);
  let v = s.invoiceData(r.payment.id);
  assert.strictEqual(v.total, plan.price); assert.strictEqual(v.tax, 0); assert.strictEqual(v.base, plan.price); assert.ok(/^FA-2026-\d{4}$/.test(v.no)); assert.strictEqual(v.member.phone, m.phone); assert.ok(v.period);
  assert.throws(() => s.setInvoiceSettings({ gst_pct: 40 })); assert.throws(() => s.setInvoiceSettings({ gstin: 'bad' }));
  s.setInvoiceSettings({ gym_address: 'MG Road, Pune', gstin: '27ABCDE1234F1Z5', gst_pct: 18, invoice_footer: 'Thanks!' });
  v = s.invoiceData(r.payment.id);
  assert.strictEqual(v.gst_pct, 18); assert.ok(Math.abs(v.base + v.tax - v.total) < 0.011); assert.strictEqual(v.gym.gstin, '27ABCDE1234F1Z5');
  const txt = C.invoiceText(v); assert.ok(txt.includes(m.name) && txt.includes('Total paid') && txt.includes('GST 18%') && txt.includes('UPI123') && txt.includes('MG Road, Pune'));
  const link = C.waLink(m.phone, txt); assert.ok(link.startsWith('https://wa.me/91' + m.phone + '?text=')); assert.ok(!link.includes('\n'));
  assert.strictEqual(C.waLink('123', 'x'), ''); assert.strictEqual(s.invoiceData('nope'), null);
  s.setSettings({ upi_id: 'gym@okbank', payee_name: 'X' }); assert.strictEqual(s.state.settings.gstin, '27ABCDE1234F1Z5');   // settings keep invoice fields
});
console.log('\n' + passed + ' passed');
