const assert = require('assert');
const C = require('../www/core.js');

function mem() { const d = {}; return { getItem: k => d[k] || null, setItem: (k, v) => { d[k] = v; } }; }
const fixed = () => new Date('2026-11-16T10:00:00Z');
let passed = 0;
function t(name, fn) { try { fn(); passed++; console.log('ok   ' + name); } catch (e) { console.log('FAIL ' + name + '\n     ' + e.message); process.exitCode = 1; } }

const store = new C.Store(mem(), fixed);
const bot = new C.Assistant(store);

t('India date helper', () => {
  assert.strictEqual(C.todayIST('2026-11-16T20:00:00Z'), '2026-11-17'); // 01:30 IST next day
  assert.strictEqual(store.today(), '2026-11-16');
});
t('phone cleaning', () => {
  assert.strictEqual(C.cleanPhone('+91 98765-43210'), '9876543210');
  assert.strictEqual(C.cleanPhone('09876543210'), '9876543210');
});
t('registration rejects bad input', () => {
  const r = store.register({ name: '', phone: '123', email: 'nope', plan_id: 'x' });
  assert.strictEqual(r.ok, false); assert.strictEqual(r.errors.length, 4);
});
t('registration rejects inactive plan', () => {
  store.state.plans[0].active = false;
  const r = store.register({ name: 'Test User', phone: '9000000001', email: 'a@b.co', plan_id: 'plan_monthly' });
  store.state.plans[0].active = true;
  assert.strictEqual(r.ok, false);
});
t('registration creates member + membership, no payment', () => {
  const before = store.state.payments.length;
  const r = store.register({ name: '  Asha   Rane ', phone: '+91 90000 00001', email: ' ASHA@Mail.COM ', plan_id: 'plan_quarterly' });
  assert.strictEqual(r.ok, true); assert.strictEqual(r.member.phone, '9000000001'); assert.strictEqual(r.member.email, 'asha@mail.com');
  assert.strictEqual(r.membership.start_date, '2026-11-16'); assert.strictEqual(r.membership.end_date, '2027-02-14');
  assert.strictEqual(store.state.payments.length, before);
});
t('duplicate active phone is blocked', () => {
  const r = store.register({ name: 'Asha Rane', phone: '9000000001', email: 'asha@mail.com', plan_id: 'plan_monthly' });
  assert.strictEqual(r.ok, false); assert.strictEqual(r.code, 'duplicate');
});
t('existing member without active membership gets a new membership, not a new member', () => {
  const expired = store.expiryReport(0, 'expired')[0];
  const count = store.state.members.length;
  const r = store.register({ name: expired.name, phone: expired.phone, email: 'x@y.com', plan_id: 'plan_monthly' });
  assert.strictEqual(r.ok, true); assert.strictEqual(r.code, 'renewed_existing');
  assert.strictEqual(store.state.members.length, count);
});
t('search returns at most 10, by name/phone/email', () => {
  assert.ok(store.searchMembers('patil').length >= 2);
  assert.strictEqual(store.searchMembers('rohan')[0].name, 'Rohan Patil');
  assert.ok(store.searchMembers('rohan.patil@example').length === 1);
  assert.ok(store.searchMembers('a').length <= 10);
});
t('payment lookup totals', () => {
  const m = store.searchMembers('rohan')[0], p = store.paymentLookup(m.id);
  assert.strictEqual(p.total_paid, p.payments.reduce((s, x) => s + x.amount, 0));
  assert.ok(p.last_payment);
});
t('revenue defaults to this month and splits correctly', () => {
  const r = store.revenueReport();
  assert.strictEqual(r.from, '2026-11-01');
  assert.strictEqual(r.total, r.by_method.reduce((s, x) => s + x.amount, 0));
  assert.strictEqual(r.total, r.by_day.reduce((s, x) => s + x.amount, 0));
});
t('expiry report windows', () => {
  store.state.memberships.forEach(() => {});
  store.expiryReport(7).forEach(r => assert.ok(r.days_left >= 0 && r.days_left <= 7));
  store.expiryReport(0, 'expired').forEach(r => assert.ok(r.days_left < 0));
});
t('attendance whole gym vs one member', () => {
  const all = store.attendanceReport('2026-10-01', '2026-11-16');
  const m = store.searchMembers('rohan')[0];
  const one = store.attendanceReport('2026-10-01', '2026-11-16', m.id);
  assert.ok(all.total_visits >= one.total_visits);
});
t('assistant refuses writes', () => {
  assert.ok(/read-only/i.test(bot.ask('Register a new member Ravi')));
  assert.ok(/read-only/i.test(bot.ask('delete Rohan Patil')));
});
t('assistant keeps health notes private', () => {
  assert.ok(/private/i.test(bot.ask("What are Rohan's health notes?")));
});
t('assistant answers revenue / expiry', () => {
  assert.ok(/Revenue for this month/.test(bot.ask('revenue this month')));
  assert.ok(/Expiring|No memberships expiring/.test(bot.ask('who expires in the next 10 days?')));
  assert.ok(/Expired memberships|No expired/.test(bot.ask('show already expired members')));
});
t('assistant asks which member when several match, then resolves', () => {
  const q = bot.ask('payments of patil');
  assert.ok(/Which one/.test(q), q);
  const a = bot.ask('1');
  assert.ok(/Payments for/.test(a), a);
});
t('assistant single-member lookup never leaks health notes', () => {
  const a = bot.ask('find Rohan Patil');
  assert.ok(/Rohan Patil/.test(a)); assert.ok(!/Private note/.test(a));
});
t('assistant keeps only last 10 messages', () => {
  for (let i = 0; i < 12; i++) bot.ask('revenue today');
  assert.strictEqual(bot.history.length, 10);
});
t('export/import roundtrip', () => {
  const s2 = new C.Store(mem(), fixed); s2.importJSON(store.exportJSON());
  assert.strictEqual(s2.state.members.length, store.state.members.length);
});
console.log('\n' + passed + ' passed');
