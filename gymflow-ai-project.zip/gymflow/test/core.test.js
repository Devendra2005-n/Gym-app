const assert = require('assert');
const C = require('../www/core.js');

function mem() { const d = {}; return { getItem: k => d[k] || null, setItem: (k, v) => { d[k] = v; } }; }
const fixed = () => new Date('2026-11-16T10:00:00Z');
let passed = 0;
function t(name, fn) { try { fn(); passed++; console.log('ok   ' + name); } catch (e) { console.log('FAIL ' + name + '\n     ' + e.message); process.exitCode = 1; } }

const store = new C.Store(mem(), fixed);
const bot = new C.Assistant(store);

t('India date helper', () => {
  assert.strictEqual(C.todayIST('2026-11-16T20:00:00Z'), '2026-11-17'); // 01:30 IST next day
  assert.strictEqual(store.today(), '2026-11-16');
});
t('phone cleaning', () => {
  assert.strictEqual(C.cleanPhone('+91 98765-43210'), '9876543210');
  assert.strictEqual(C.cleanPhone('09876543210'), '9876543210');
});
t('registration rejects bad input', () => {
  const r = store.register({ name: '', phone: '123', email: 'nope', plan_id: 'x' });
  assert.strictEqual(r.ok, false); assert.strictEqual(r.errors.length, 4);
});
t('registration rejects inactive plan', () => {
  store.state.plans[0].active = false;
  const r = store.register({ name: 'Test User', phone: '9000000001', email: 'a@b.co', plan_id: 'plan_monthly' });
  store.state.plans[0].active = true;
  assert.strictEqual(r.ok, false);
});
t('registration creates member + membership, no payment', () => {
  const before = store.state.payments.length;
  const r = store.register({ name: '  Asha   Rane ', phone: '+91 90000 00001', email: ' ASHA@Mail.COM ', plan_id: 'plan_quarterly' });
  assert.strictEqual(r.ok, true); assert.strictEqual(r.member.phone, '9000000001'); assert.strictEqual(r.member.email, 'asha@mail.com');
  assert.strictEqual(r.membership.start_date, '2026-11-16'); assert.strictEqual(r.membership.end_date, '2027-02-14');
  assert.strictEqual(store.state.payments.length, before);
});
t('duplicate active phone is blocked', () => {
  const r = store.register({ name: 'Asha Rane', phone: '9000000001', email: 'asha@mail.com', plan_id: 'plan_monthly' });
  assert.strictEqual(r.ok, false); assert.strictEqual(r.code, 'duplicate');
});
t('existing member without active membership gets a new membership, not a new member', () => {
  const expired = store.expiryReport(0, 'expired')[0];
  const count = store.state.members.length;
  const r = store.register({ name: expired.name, phone: expired.phone, email: 'x@y.com', plan_id: 'plan_monthly' });
  assert.strictEqual(r.ok, true); assert.strictEqual(r.code, 'renewed_existing');
  assert.strictEqual(store.state.members.length, count);
});
t('search returns at most 10, by name/phone/email', () => {
  assert.ok(store.searchMembers('patil').length >= 2);
  assert.strictEqual(store.searchMembers('rohan')[0].name, 'Rohan Patil');
  assert.ok(store.searchMembers('rohan.patil@example').length === 1);
  assert.ok(store.searchMembers('a').length <= 10);
});
t('payment lookup totals', () => {
  const m = store.searchMembers('rohan')[0], p = store.paymentLookup(m.id);
  assert.strictEqual(p.total_paid, p.payments.reduce((s, x) => s + x.amount, 0));
  assert.ok(p.last_payment);
});
t('revenue defaults to this month and splits correctly', () => {
  const r = store.revenueReport();
  assert.strictEqual(r.from, '2026-11-01');
  assert.strictEqual(r.total, r.by_method.reduce((s, x) => s + x.amount, 0));
  assert.strictEqual(r.total, r.by_day.reduce((s, x) => s + x.amount, 0));
});
t('expiry report windows', () => {
  store.state.memberships.forEach(() => {});
  store.expiryReport(7).forEach(r => assert.ok(r.days_left >= 0 && r.days_left <= 7));
  store.expiryReport(0, 'expired').forEach(r => assert.ok(r.days_left < 0));
});
t('attendance whole gym vs one member', () => {
  const all = store.attendanceReport('2026-10-01', '2026-11-16');
  const m = store.searchMembers('rohan')[0];
  const one = store.attendanceReport('2026-10-01', '2026-11-16', m.id);
  assert.ok(all.total_visits >= one.total_visits);
});
t('assistant refuses writes', () => {
  assert.ok(/read-only/i.test(bot.ask('Register a new member Ravi')));
  assert.ok(/read-only/i.test(bot.ask('delete Rohan Patil')));
});
t('assistant keeps health notes private', () => {
  assert.ok(/private/i.test(bot.ask("What are Rohan's health notes?")));
});
t('assistant answers revenue / expiry', () => {
  assert.ok(/Revenue for this month/.test(bot.ask('revenue this month')));
  assert.ok(/Expiring|No memberships expiring/.test(bot.ask('who expires in the next 10 days?')));
  assert.ok(/Expired memberships|No expired/.test(bot.ask('show already expired members')));
});
t('assistant asks which member when several match, then resolves', () => {
  const q = bot.ask('payments of patil');
  assert.ok(/Which one/.test(q), q);
  const a = bot.ask('1');
  assert.ok(/Payments for/.test(a), a);
});
t('assistant single-member lookup never leaks health notes', () => {
  const a = bot.ask('find Rohan Patil');
  assert.ok(/Rohan Patil/.test(a)); assert.ok(!/Private note/.test(a));
});
t('assistant keeps only last 10 messages', () => {
  for (let i = 0; i < 12; i++) bot.ask('revenue today');
  assert.strictEqual(bot.history.length, 10);
});
t('export/import roundtrip', () => {
  const s2 = new C.Store(mem(), fixed); s2.importJSON(store.exportJSON());
  assert.strictEqual(s2.state.members.length, store.state.members.length);
});
// ---------- v2 features: QR attendance, payments, UPI, FAQ ----------
const qrgen = require('../www/vendor/qrcode.js');
let jsQR = require('../www/vendor/jsQR.js'); jsQR = jsQR.default || jsQR;
function renderQR(text) {
  const q = qrgen(0, 'M'); q.addData(text); q.make();
  const n = q.getModuleCount(), scale = 6, quiet = 4, size = (n + quiet * 2) * scale;
  const data = new Uint8ClampedArray(size * size * 4).fill(255);
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) {
    for (let y = 0; y < scale; y++) for (let x = 0; x < scale; x++) {
      const i = (((r + quiet) * scale + y) * size + (c + quiet) * scale + x) * 4; data[i] = data[i + 1] = data[i + 2] = 0;
    }
  }
  return { data, size };
}
const s2 = new C.Store(mem(), fixed);
const rohan = s2.searchMembers('rohan')[0];
const expiredOne = s2.expiryReport(0, 'expired')[0];

t('member QR text survives generate -> scan round trip', () => {
  const txt = C.memberQRText(rohan), img = renderQR(txt);
  const res = jsQR(img.data, img.size, img.size);
  assert.ok(res, 'jsQR could not read the code'); assert.strictEqual(res.data, txt);
  assert.strictEqual(s2.parseQR(res.data).id, rohan.id);
});
t('QR with wrong phone or junk is rejected', () => {
  assert.strictEqual(s2.parseQR('GF1|' + rohan.id + '|9999999999'), null);
  assert.strictEqual(s2.parseQR('hello'), null);
  assert.strictEqual(s2.scanCheckIn('hello').code, 'invalid_qr');
});
t('check-in records IST time once per day', () => {
  const before = s2.state.attendance.length;
  s2.state.attendance = s2.state.attendance.filter(a => !(a.member_id === rohan.id && a.visit_date === '2026-11-16'));
  const r = s2.scanCheckIn(C.memberQRText(rohan));
  assert.strictEqual(r.ok, true); assert.strictEqual(r.time, '15:30');
  const again = s2.checkIn(rohan.id);
  assert.strictEqual(again.ok, false); assert.strictEqual(again.code, 'already'); assert.strictEqual(again.time, '15:30');
  assert.ok(s2.todayAttendance().list.some(x => x.member_id === rohan.id && x.time === '15:30'));
});
t('expired member is blocked unless forced', () => {
  s2.state.attendance = s2.state.attendance.filter(a => !(a.member_id === expiredOne.member_id && a.visit_date === '2026-11-16'));
  assert.strictEqual(s2.checkIn(expiredOne.member_id).code, 'expired');
  const f = s2.checkIn(expiredOne.member_id, { force: true });
  assert.strictEqual(f.ok, true); assert.strictEqual(f.expired, true);
});
t('attendance report has hourly distribution', () => {
  const r = s2.attendanceReport('2026-10-01', '2026-11-16');
  assert.strictEqual(r.by_hour.length, 24); assert.strictEqual(r.by_hour.reduce((a, b) => a + b, 0), r.total_visits);
});
t('UPI links are well formed', () => {
  const o = { pa: 'gym@okhdfc', pn: 'Fitness Arena', am: 1000, tn: 'Monthly Basic', tr: 'GFabc' };
  assert.strictEqual(C.upiLink(o), 'upi://pay?pa=gym@okhdfc&pn=Fitness%20Arena&am=1000.00&cu=INR&tn=Monthly%20Basic&tr=GFabc');
  assert.ok(C.gpayLink(o).indexOf('tez://upi/pay?pa=gym@okhdfc') === 0);
  assert.ok(C.validUpiId('gym@okhdfc') && C.validUpiId('98100.00000@ybl') && !C.validUpiId('gym') && !C.validUpiId('a b@c'));
  assert.ok(C.validAmount(1000) && C.validAmount(99.5) && !C.validAmount(0) && !C.validAmount(-5) && !C.validAmount(10.123) && !C.validAmount('x'));
});
t('settings validate UPI id', () => {
  assert.throws(() => s2.setSettings({ upi_id: 'bad', payee_name: 'Gym' }));
  s2.setSettings({ upi_id: 'gym@okhdfc', payee_name: 'Fitness Arena' });
  assert.strictEqual(s2.state.settings.upi_id, 'gym@okhdfc');
});
t('recordPayment validates and shows in revenue', () => {
  assert.strictEqual(s2.recordPayment({ member_id: 'nope', amount: 100, method: 'upi' }).ok, false);
  assert.strictEqual(s2.recordPayment({ member_id: rohan.id, amount: 0, method: 'upi' }).ok, false);
  assert.strictEqual(s2.recordPayment({ member_id: rohan.id, amount: 100, method: 'bitcoin' }).ok, false);
  const before = s2.revenueReport().total;
  const r = s2.recordPayment({ member_id: rohan.id, amount: 1500, method: 'upi', ref: 'UTR123' });
  assert.strictEqual(r.ok, true); assert.strictEqual(s2.revenueReport().total, before + 1500);
  assert.strictEqual(s2.recentPayments(1)[0].amount, 1500);
});
t('payment with renew extends from current end date', () => {
  const ms = s2.membershipLookup(rohan.id)[0];
  const r = s2.recordPayment({ member_id: rohan.id, amount: 1000, method: 'cash', plan_id: 'plan_monthly', renew: true });
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.membership.start_date, C.addDays(ms.end_date, 1));
  assert.strictEqual(r.membership.end_date, C.addDays(r.membership.start_date, 30));
});
t('renew for an expired member starts today', () => {
  const r = s2.recordPayment({ member_id: expiredOne.member_id, amount: 1000, method: 'card', plan_id: 'plan_monthly', renew: true });
  assert.strictEqual(r.membership.start_date, '2026-11-16');
});
t('FAQ add / remove', () => {
  assert.throws(() => s2.addFaq('hi', ''));
  const f = s2.addFaq('Is parking available?', 'Yes, free parking for members.');
  assert.strictEqual(s2.state.faqs.length, 1);
  s2.removeFaq(f.id); assert.strictEqual(s2.state.faqs.length, 0);
});
t('old v1 saved data gains settings/faqs and keeps its records', () => {
  const old = new C.Store(mem(), fixed); const snap = JSON.parse(old.exportJSON());
  delete snap.settings; delete snap.faqs;
  const storage = mem(); storage.setItem('gymflow.v1', JSON.stringify(snap));
  const s3 = new C.Store(storage, fixed);
  assert.strictEqual(s3.state.members.length, snap.members.length);
  assert.strictEqual(s3.state.settings.payee_name, 'Fitness Arena'); assert.deepStrictEqual(s3.state.faqs, []);
});
t('clear/reset keep payment settings and custom FAQs', () => {
  s2.addFaq('Keep me please?', 'Yes.');
  s2.clearAll(); assert.strictEqual(s2.state.members.length, 0); assert.strictEqual(s2.state.settings.upi_id, 'gym@okhdfc'); assert.strictEqual(s2.state.faqs.length, 1);
  s2.resetDemo(); assert.ok(s2.state.members.length > 0); assert.strictEqual(s2.state.faqs.length, 1);
});
// ---------- v3: owner gym QR + member pass ----------
let clock = Date.parse('2026-11-16T10:00:00Z');
const s4 = new C.Store(mem(), () => new Date(clock));
const MK = C.MemberKit;
const mstore = mem();
t('gym QR is stable inside 5 minutes and changes in the next window', () => {
  const a = s4.gymQR(); clock += 60 * 1000; const b = s4.gymQR();
  assert.strictEqual(a.code, b.code); assert.ok(/^[0-9A-F]{8}$/.test(a.code));
  clock += 5 * 60 * 1000; assert.notStrictEqual(s4.gymQR().code, a.code);
  assert.ok(s4.gymQR().seconds_left > 0 && s4.gymQR().seconds_left <= 300);
});
t('gym QR text parses on the member side and survives a QR round trip', () => {
  const g = s4.gymQR(), img = renderQR(g.text), res = jsQR(img.data, img.size, img.size);
  assert.ok(res && res.data === g.text);
  const p = MK.parseGymQR(res.data, clock);
  assert.strictEqual(p.code, g.code); assert.strictEqual(p.gym, 'Fitness Arena'); assert.strictEqual(p.fresh, true);
  assert.strictEqual(MK.parseGymQR(res.data, clock + 40 * 60 * 1000).fresh, false);
  assert.strictEqual(MK.parseGymQR('GF1|x|y', clock), null);
});
t('member pass checks the member in (phone must match a member)', () => {
  const m = s4.state.members[3], code = s4.gymQR().code;
  s4.state.attendance = s4.state.attendance.filter(a => !(a.member_id === m.id && a.visit_date === s4.today()));
  const pass = MK.buildPass(m.phone, code);
  const img = renderQR(pass), res = jsQR(img.data, img.size, img.size);
  assert.strictEqual(res.data, pass);
  const r = s4.scanCheckIn(res.data);
  assert.strictEqual(r.ok, true); assert.strictEqual(r.member.id, m.id);
  assert.strictEqual(s4.scanCheckIn(pass).code, 'already');
});
t('pass with a wrong or typed code: spaces/lowercase ok, wrong rejected', () => {
  const m = s4.state.members[1], code = s4.gymQR().code;
  s4.state.attendance = s4.state.attendance.filter(a => a.member_id !== m.id || a.visit_date !== s4.today());
  assert.strictEqual(s4.scanCheckIn(MK.buildPass(m.phone, '00000000')).code, 'bad_code');
  const typed = (code.slice(0, 4) + ' ' + code.slice(4)).toLowerCase();
  assert.strictEqual(MK.normalizeCode(typed), code);
  assert.strictEqual(s4.scanCheckIn(MK.buildPass(m.phone, typed)).ok, true);
});
t('pass is accepted for about 15 minutes, then refused', () => {
  const m = s4.state.members[2], code = s4.gymQR().code;
  s4.state.attendance = s4.state.attendance.filter(a => a.member_id !== m.id || a.visit_date !== s4.today());
  clock += 9 * 60 * 1000;   // still within the 3 accepted windows
  assert.strictEqual(s4.validGymCode(code), true);
  clock += 12 * 60 * 1000;  // now too old
  assert.strictEqual(s4.scanCheckIn(MK.buildPass(m.phone, code)).code, 'bad_code');
});
t('unknown phone and junk passes are rejected', () => {
  assert.strictEqual(s4.scanCheckIn(MK.buildPass('9000099999', s4.gymQR().code)).code, 'not_found');
  assert.strictEqual(s4.scanCheckIn('GFC1|only-two').code, 'invalid_qr');
});
t('gym secret survives settings changes, backups and resets', () => {
  const code = s4.gymQR().code;
  s4.setSettings({ upi_id: 'gym@okhdfc', payee_name: 'Fitness Arena' });
  assert.strictEqual(s4.gymQR().code, code);
  const s5 = new C.Store(mem(), () => new Date(clock)); s5.importJSON(s4.exportJSON());
  assert.strictEqual(s5.gymQR().code, code);
  s4.clearAll(); assert.strictEqual(s4.gymQR().code, code);
  assert.notStrictEqual(new C.Store(mem(), () => new Date(clock)).gymQR().code, code);   // other gyms get other codes
});
t('member profile: link phone, validate, keep history', () => {
  assert.strictEqual(MK.linkPhone(mstore, '12345').ok, false);
  assert.strictEqual(MK.linkPhone(mstore, '+91 98100 12345').phone, '9810012345');
  MK.addVisit(mstore, { date: '2026-11-16', time: '10:05', gym: 'Fitness Arena' });
  const p = MK.get(mstore); assert.strictEqual(p.phone, '9810012345'); assert.strictEqual(p.visits.length, 1);
  assert.deepStrictEqual(MK.get(mem()), { phone: '', visits: [] });
});
console.log('\n' + passed + ' passed');
