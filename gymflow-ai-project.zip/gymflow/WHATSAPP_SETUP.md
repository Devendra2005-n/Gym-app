# Automatic WhatsApp invoice (PDF) — setup

After every successful payment the server builds the invoice PDF and sends it to the member's WhatsApp by itself:
- online payment (Razorpay) → sent the moment the webhook confirms it
- cash / UPI recorded by owner or receptionist, or a member claim you confirm → sent right after you save
The old "Send on WhatsApp" button inside each invoice stays as a manual backup.

Each payment is sent **once** (log table `invoice_deliveries`). If it fails, open the invoice → "Send automatically now".

## Cost (be aware)
Meta's WhatsApp Cloud API is the official way. A business-started invoice message is a "utility template": about ₹0.115 + 18% GST (~₹0.14) per message in India (2026 rate; check Meta's pricing page). While testing with Meta's free test number, you can message only up to 5 phone numbers you verify.
WhatsApp does **not** allow an app to send a PDF from the owner's personal WhatsApp automatically; that is why a WhatsApp Business API number is needed.

## Steps
1. https://developers.facebook.com → Create app → type **Business** → add product **WhatsApp**.
2. WhatsApp → API Setup: note the **Phone number ID** (test number is given free). Add the member phone(s) you want to test with under "To" and verify them by OTP (max 5).
3. Create a **permanent token**: Business settings → Users → System users → add a system user → Generate token with permission `whatsapp_business_messaging` (+ `whatsapp_business_management`). The 24-hour token in API Setup works for a quick test only.
4. WhatsApp Manager → Message templates → Create template:
   - Category **Utility**, name `invoice_receipt`, language English
   - Header: **Document** (sample: any PDF)
   - Body (exactly 5 variables):
     `Hi {{1}}, we received your payment of {{2}} for {{3}} at {{4}}. Your invoice {{5}} is attached. Thank you!`
   - Submit; wait for "Approved" (usually minutes).
5. Supabase → Edge Functions → Secrets → add:
   - `WA_TOKEN` = the permanent token
   - `WA_PHONE_NUMBER_ID` = Phone number ID
   - (optional) `WA_TEMPLATE` if you used another template name, `WA_LANG` if not `en`
6. Pay a test amount (use a verified test member phone). The Payments screen shows "✅ Invoice PDF sent to the member on WhatsApp".

For real members (not only 5 test numbers) you must add your own business phone number and complete Meta business verification.

## Status messages in the app
- not set up yet → secrets missing (nothing breaks; use manual button)
- no valid phone → member phone is not a 10-digit Indian mobile
- failed (reason) → usually template not approved / token expired / number not verified
