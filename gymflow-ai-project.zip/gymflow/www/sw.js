// Minimal offline cache so the app also works when installed as a PWA from a browser.
const CACHE = 'gymflow-v9';
const FILES = ['./', './index.html', './style.css', './config.js', './core.js', './cloud.js', './vendor/supabase.js', './content.js', './anim.js', './products.js', './wellness.js', './clubs.js', './app.js', './report.js', './vendor/jspdf.umd.min.js', './vendor/qrcode.js', './vendor/jsQR.js', './manifest.webmanifest', './icon.svg'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES))); self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))));
});
self.addEventListener('fetch', e => {
  e.respondWith(fetch(e.request).catch(() => caches.match(e.request)));
});
