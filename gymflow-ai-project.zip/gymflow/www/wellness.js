/* The Forge - sample trainers and diet plans, with original drawn illustrations.
   Everything here is SAMPLE data (invented trainers, general diet guidance). The owner edits it to match the real gym.
   Images are drawn in code (no downloads, work offline). */
(function (root) {
  'use strict';
  var INK = '#1a1a1a', WHT = '#ffffff';
  function shade(hex, amt) {
    var n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    function f(v) { return Math.max(0, Math.min(255, Math.round(v + amt))); }
    return '#' + ((1 << 24) + (f(r) << 16) + (f(g) << 8) + f(b)).toString(16).slice(1);
  }
  function svg(inner, size) { return '<svg viewBox="0 0 120 120" ' + (size ? 'width="' + size + '" height="' + size + '" ' : 'width="100%" ') + 'role="img" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">' + inner + '</svg>'; }

  // ---------- trainers ----------
  // Slots are the times a trainer is available. Prices are sample prices in rupees.
  var SLOTS = ['Morning 6–9 am', 'Late morning 10–12', 'Evening 5–8 pm', 'Night 8–10 pm'];
  function T(id, name, focus, years, sessionFee, monthFee, quarterFee, langs, slots, bio, look) {
    return { id: id, name: name, focus: focus, years: years, session: sessionFee, month: monthFee, quarter: quarterFee, langs: langs, slots: slots, bio: bio, look: look };
  }
  var TRAINERS = [
    T('t1', 'Rohan Patil', ['Strength', 'Muscle gain'], 8, 600, 5800, 15500, ['Hindi', 'English', 'Marathi'], [0, 2, 3], 'Builds strength with simple progressive plans. Good for beginners who want to gain size safely.', { skin: '#c68a5e', hair: '#1c1c1c', style: 'short', shirt: '#1f3a5f', beard: true }),
    T('t2', 'Sneha Kulkarni', ['Weight loss', 'Yoga'], 6, 500, 4900, 13200, ['Hindi', 'English', 'Marathi'], [0, 1, 2], 'Combines cardio, strength and yoga for steady fat loss and better flexibility.', { skin: '#d9a47c', hair: '#2b1a12', style: 'bun', shirt: '#7b5ea7', beard: false }),
    T('t3', 'Vikram Shinde', ['CrossFit', 'Functional'], 9, 700, 6600, 17900, ['Hindi', 'English'], [0, 2, 3], 'High-energy functional training for stamina, mobility and all-round fitness.', { skin: '#b9794f', hair: '#222222', style: 'cap', shirt: '#c62828', beard: true }),
    T('t4', 'Pooja Jadhav', ['Women’s fitness', 'Toning'], 5, 550, 5200, 14100, ['Hindi', 'Marathi'], [1, 2], 'Toning and posture plans for women, with a friendly, no-pressure style.', { skin: '#e0b08a', hair: '#1c1c1c', style: 'long', shirt: '#e07a1f', beard: false }),
    T('t5', 'Aman Deshmukh', ['Bodybuilding', 'Competition prep'], 11, 900, 8500, 23000, ['Hindi', 'English', 'Marathi'], [2, 3], 'Experienced with physique goals, split routines and meal timing for lifters.', { skin: '#a96b44', hair: '#111111', style: 'bald', shirt: '#111111', beard: true }),
    T('t6', 'Neha Pawar', ['Pilates', 'Mobility'], 4, 500, 4700, 12800, ['Hindi', 'English'], [0, 1], 'Core, posture and mobility work for desk workers and anyone with stiff joints.', { skin: '#d8a27a', hair: '#4a2c1a', style: 'long', shirt: '#2a9d8f', beard: false }),
    T('t7', 'Sagar More', ['Beginners', 'Senior friendly'], 7, 450, 4300, 11600, ['Hindi', 'Marathi'], [0, 1, 2], 'Gentle, step-by-step coaching for first-timers, seniors and people returning after a break.', { skin: '#c98f63', hair: '#8a8a8a', style: 'short', shirt: '#3f7d4e', beard: false }),
    T('t8', 'Kabir Singh', ['Sports conditioning', 'Fat loss'], 10, 800, 7400, 20000, ['Hindi', 'English', 'Punjabi'], [0, 3], 'Speed, agility and conditioning for athletes, plus tough fat-loss circuits.', { skin: '#cf9468', hair: '#1c1c1c', style: 'cap', shirt: '#0d47a1', beard: true })
  ];
  function packages(t) {
    return [
      { id: 'trial', label: '1 trial session', sessions: 1, price: t.session },
      { id: 'm1', label: '1 month · 12 sessions', sessions: 12, price: t.month },
      { id: 'm3', label: '3 months · 36 sessions', sessions: 36, price: t.quarter }
    ];
  }
  // Friendly cartoon portrait. These are invented characters, not real people.
  function avatar(look, size) {
    var l = look, hairBack = '', hairTop = '', extra = '';
    if (l.style === 'long') hairBack = '<path d="M34 54q0-34 26-34t26 34v34H34z" fill="' + l.hair + '"/>';
    if (l.style === 'bun') extra = '<circle cx="60" cy="22" r="10" fill="' + l.hair + '"/>';
    if (l.style !== 'bald' && l.style !== 'cap') hairTop = '<path d="M37 50q-2-26 23-27t23 27q-6-14-23-14t-23 14z" fill="' + l.hair + '"/>';
    if (l.style === 'cap') hairTop = '<path d="M36 46q0-26 24-26t24 26z" fill="' + shade(l.shirt, 10) + '"/><path d="M36 46q24 6 52 0 4 4-4 6-24 6-48 0z" fill="' + shade(l.shirt, -40) + '"/>';
    var beard = l.beard ? '<path d="M40 56q2 28 20 28t20-28q-4 14-20 14T40 56z" fill="' + l.hair + '"/>' : '';
    return svg('<circle cx="60" cy="60" r="58" fill="#f0f0f0"/>' + hairBack +
      '<path d="M14 120q0-32 46-32t46 32z" fill="' + l.shirt + '"/><rect x="51" y="68" width="18" height="24" rx="6" fill="' + shade(l.skin, -18) + '"/>' +
      '<circle cx="60" cy="52" r="23" fill="' + l.skin + '"/>' + beard + hairTop + extra +
      '<circle cx="51" cy="52" r="2.6" fill="' + INK + '"/><circle cx="69" cy="52" r="2.6" fill="' + INK + '"/><path d="M52 63q8 6 16 0" fill="none" stroke="' + (l.beard ? WHT : INK) + '" stroke-width="2.4" stroke-linecap="round"/>' +
      '<path d="M44 120l16-26 16 26" fill="none" stroke="' + shade(l.shirt, -40) + '" stroke-width="3"/>', size);
  }

  // ---------- food art ----------
  var PL = '<circle cx="60" cy="64" r="46" fill="' + WHT + '" stroke="#d6d6d6" stroke-width="3"/><circle cx="60" cy="64" r="36" fill="none" stroke="#ececec" stroke-width="2"/>';
  function bowl(fill, top) { return '<path d="M12 56h96q0 40-48 44-48-4-48-44z" fill="' + fill + '"/><ellipse cx="60" cy="56" rx="48" ry="9" fill="' + top + '"/>'; }
  var FOOD = {
    oats: function () { return bowl('#c9a46a', '#efe3c8') + '<circle cx="46" cy="52" r="6" fill="#d94f5c"/><circle cx="62" cy="50" r="6" fill="#7b5ea7"/><path d="M72 54q10-8 18 0-6 8-18 0z" fill="#f2c94c"/><path d="M60 18q8 12 0 22" stroke="#cfcfcf" stroke-width="3" fill="none" opacity=".8"/>'; },
    eggs: function () { return PL + '<ellipse cx="46" cy="60" rx="18" ry="15" fill="' + WHT + '" stroke="#e2e2e2" stroke-width="2"/><circle cx="46" cy="60" r="8" fill="#f5b72e"/><ellipse cx="76" cy="70" rx="17" ry="14" fill="' + WHT + '" stroke="#e2e2e2" stroke-width="2"/><circle cx="76" cy="70" r="7.5" fill="#f5b72e"/>'; },
    boiled: function () { return PL + '<ellipse cx="46" cy="64" rx="15" ry="19" fill="' + WHT + '" stroke="#ddd" stroke-width="2"/><ellipse cx="76" cy="64" rx="15" ry="19" fill="' + WHT + '" stroke="#ddd" stroke-width="2"/><ellipse cx="76" cy="66" rx="8" ry="9" fill="#f5b72e"/><path d="M62 82q-3 6 4 8" stroke="#6aa84f" stroke-width="3" fill="none"/>'; },
    toast: function () { return PL + '<path d="M30 80V54q0-12 14-12h32q14 0 14 12v26z" fill="#d9a85c"/><path d="M36 76V56q0-8 10-8h28q10 0 10 8v20z" fill="#f2d49b"/>'; },
    chilla: function () { return PL + '<circle cx="52" cy="60" r="24" fill="#a6b94e"/><circle cx="68" cy="70" r="24" fill="#bccb62"/><circle cx="60" cy="66" r="3" fill="#7d8f33"/><circle cx="74" cy="64" r="3" fill="#7d8f33"/><circle cx="50" cy="72" r="3" fill="#7d8f33"/>'; },
    poha: function () { return PL + '<path d="M26 74q4-30 34-30t34 30q-34 14-68 0z" fill="#f2c94c"/><circle cx="46" cy="62" r="3.4" fill="#c97a2b"/><circle cx="62" cy="56" r="3.4" fill="#c97a2b"/><circle cx="76" cy="64" r="3.4" fill="#c97a2b"/><path d="M52 72l6 2M70 74l6 2" stroke="#6aa84f" stroke-width="3"/><path d="M82 48l10 8-10 6z" fill="#7ab648"/>'; },
    idli: function () { return PL + '<path d="M22 70q4-22 22-22t22 22z" fill="#f4efe6"/><path d="M52 76q4-22 22-22t22 22z" fill="#f4efe6"/><path d="M34 82q4-18 20-18t20 18z" fill="#fbf8f2"/><circle cx="88" cy="46" r="10" fill="#7ab648"/>'; },
    roti: function () { return PL + '<circle cx="48" cy="66" r="26" fill="#e3b46a"/><circle cx="72" cy="58" r="26" fill="#efc98a"/><circle cx="64" cy="52" r="3" fill="#c98f3d"/><circle cx="78" cy="62" r="3" fill="#c98f3d"/><circle cx="56" cy="70" r="3" fill="#c98f3d"/>'; },
    dal: function () { return bowl('#c98a2b', '#f2b84b') + '<circle cx="48" cy="55" r="2.6" fill="#c97a2b"/><circle cx="64" cy="57" r="2.6" fill="#8a5a1f"/><circle cx="80" cy="54" r="2.6" fill="#6aa84f"/><rect x="88" y="14" width="8" height="36" rx="4" fill="#9a9a9a" transform="rotate(20 92 32)"/>'; },
    rice: function () { return bowl('#e9e9e9', '#ffffff') + '<path d="M20 54q10-26 40-26t40 26z" fill="' + WHT + '" stroke="#e4e4e4" stroke-width="2"/><path d="M42 44l3 1M58 38l3 1M72 44l3 1M52 48l3 1" stroke="#dcdcdc" stroke-width="2"/>'; },
    curry: function () { return bowl('#b4452f', '#e0662f') + '<rect x="40" y="48" width="14" height="10" rx="3" fill="#f4e3b2"/><rect x="62" y="46" width="14" height="10" rx="3" fill="#f4e3b2"/><circle cx="86" cy="52" r="4" fill="#6aa84f"/>'; },
    chicken: function () { return PL + '<path d="M34 78q-8-26 12-38t34 8q6 22-10 32-14 6-18 0l-8 10q-6 2-8-6z" fill="#c9742e"/><path d="M44 52q8-8 20-4" stroke="#e8a45a" stroke-width="5" fill="none" stroke-linecap="round"/><circle cx="30" cy="86" r="6" fill="#f4efe6"/><circle cx="40" cy="92" r="6" fill="#f4efe6"/>'; },
    fish: function () { return PL + '<path d="M24 64q24-26 52-6l16-12v36L76 70q-28 20-52-6z" fill="#7aa6c2"/><circle cx="40" cy="60" r="3" fill="' + INK + '"/><path d="M52 52q6 10 0 20M62 54q6 8 0 16" stroke="#e8f2f8" stroke-width="2.5" fill="none"/>'; },
    salad: function () { return bowl('#f0f0f0', '#7ab648') + '<circle cx="42" cy="50" r="7" fill="#d94f5c"/><circle cx="62" cy="46" r="6" fill="#f2c94c"/><circle cx="80" cy="52" r="6" fill="#d94f5c"/><path d="M48 54q8-14 20-4" stroke="#4e8a2f" stroke-width="4" fill="none"/>'; },
    sprouts: function () { return bowl('#7a8f4e', '#a6c46a') + '<path d="M30 52q6-14 12-2M48 50q6-16 12-2M66 52q6-14 12-2M80 50q6-12 12-2" stroke="#f4efe6" stroke-width="4" fill="none" stroke-linecap="round"/><circle cx="60" cy="48" r="4" fill="#d94f5c"/>'; },
    fruits: function () { return '<circle cx="42" cy="70" r="26" fill="#d94f5c"/><path d="M42 44q-2-10 6-14" stroke="#6b4a2b" stroke-width="4" fill="none"/><path d="M48 36q10-6 14 2-8 6-14-2z" fill="#6aa84f"/><path d="M62 94q-4-34 26-48 6 4 0 14-14 12-12 30-6 8-14 4z" fill="#f2c94c"/>'; },
    milk: function () { return '<path d="M34 28h52l-6 70q-1 8-9 8H49q-8 0-9-8z" fill="#ffffff" stroke="#d6d6d6" stroke-width="3"/><path d="M37 48h46l-3 50q-1 6-8 6H48q-7 0-8-6z" fill="#f6f6f6"/><path d="M38 48h44" stroke="#d6d6d6" stroke-width="3"/>'; },
    smoothie: function () { return '<path d="M32 34h56l-6 64q-1 8-9 8H47q-8 0-9-8z" fill="#e9a3c2" stroke="#d4809f" stroke-width="3"/><path d="M36 54h48" stroke="#fff" stroke-width="3" opacity=".5"/><path d="M70 10l6 40" stroke="#2a9d8f" stroke-width="6" stroke-linecap="round"/><circle cx="44" cy="30" r="9" fill="#f2c94c"/>'; },
    nuts: function () { return bowl('#8a6a46', '#b88c5a') + '<ellipse cx="40" cy="50" rx="7" ry="4.5" fill="#d8b98a" transform="rotate(-20 40 50)"/><ellipse cx="58" cy="46" rx="7" ry="4.5" fill="#c9a06a" transform="rotate(15 58 46)"/><ellipse cx="76" cy="50" rx="7" ry="4.5" fill="#d8b98a" transform="rotate(-10 76 50)"/><ellipse cx="66" cy="54" rx="6" ry="4" fill="#e8d0a4"/>'; },
    paneer: function () { return PL + '<rect x="34" y="42" width="22" height="22" rx="4" fill="#fbf4dd" stroke="#e6d9a8" stroke-width="2"/><rect x="62" y="48" width="22" height="22" rx="4" fill="#fbf4dd" stroke="#e6d9a8" stroke-width="2"/><rect x="46" y="68" width="22" height="22" rx="4" fill="#fbf4dd" stroke="#e6d9a8" stroke-width="2"/><circle cx="82" cy="40" r="6" fill="#6aa84f"/><circle cx="36" cy="82" r="6" fill="#d94f5c"/>'; },
    curd: function () { return bowl('#e9e9e9', '#ffffff') + '<path d="M44 50q16-8 32 0" stroke="#d9d9d9" stroke-width="3" fill="none"/><circle cx="60" cy="48" r="3" fill="#6aa84f"/>'; },
    soup: function () { return bowl('#c26a2b', '#e8913a') + '<path d="M40 24q8 10 0 20M60 18q8 12 0 24M80 24q8 10 0 20" stroke="#cfcfcf" stroke-width="3.5" fill="none" stroke-linecap="round"/>'; },
    sandwich: function () { return PL + '<path d="M26 70l34-34 34 34z" fill="#e3b46a"/><path d="M30 72l30-28 30 28z" fill="#7ab648"/><path d="M34 76l26-22 26 22z" fill="#d94f5c"/><path d="M26 80l34-34 34 34z" fill="#e3b46a" opacity="0"/><rect x="26" y="74" width="68" height="12" rx="4" fill="#e3b46a"/>'; },
    khichdi: function () { return bowl('#d9a441', '#f2d27a') + '<circle cx="44" cy="53" r="3" fill="#c98a2b"/><circle cx="62" cy="55" r="3" fill="#6aa84f"/><circle cx="78" cy="52" r="3" fill="#d94f5c"/><path d="M58 18q8 12 0 22" stroke="#cfcfcf" stroke-width="3" fill="none"/>'; }
  };
  function food(key, size) { return svg((FOOD[key] || FOOD.salad)(), size); }

  // ---------- diet plans ----------
  // Four meals a day. kcal and protein are rough estimates for the listed portions.
  var SLOT_DEFAULT = { breakfast: '08:00', lunch: '13:00', snack: '17:00', dinner: '20:30' };
  var SLOT_LABEL = { breakfast: 'Breakfast', lunch: 'Lunch', snack: 'Evening snack', dinner: 'Dinner' };
  var SLOT_ORDER = ['breakfast', 'lunch', 'snack', 'dinner'];
  function M(slot, art, items, kcal, protein) { return { slot: slot, art: art, items: items, kcal: kcal, protein: protein }; }
  function D(id, type, name, goal, tag, desc, meals) { return { id: id, type: type, name: name, goal: goal, tag: tag, desc: desc, meals: meals }; }
  var PLANS = [
    D('dv1', 'veg', 'Veg Fat Loss', 'Lose fat', 'About 1,500 kcal', 'Lighter portions, high fibre and good protein from dal, sprouts and paneer.', [
      M('breakfast', 'chilla', ['2 moong dal chillas with mint chutney', 'Green tea or black coffee (no sugar)'], 330, 18),
      M('lunch', 'roti', ['2 multigrain rotis', '1 bowl dal', 'Mixed vegetable sabzi', 'Large cucumber-tomato salad'], 480, 22),
      M('snack', 'sprouts', ['1 bowl sprouts chaat with lemon', '1 apple'], 220, 12),
      M('dinner', 'paneer', ['100 g paneer bhurji', '1 roti', 'Cucumber salad or clear vegetable soup'], 430, 26)]),
    D('dv2', 'veg', 'Veg Muscle Gain', 'Build muscle', 'About 2,800 kcal', 'Calorie-rich vegetarian day with paneer, soya, milk and nuts to support heavy training.', [
      M('breakfast', 'oats', ['Oats porridge made with 300 ml milk', '1 banana and 10 almonds', '1 glass milk'], 700, 28),
      M('lunch', 'curry', ['4 rotis or 1.5 cups rice', '1.5 bowls thick dal', '150 g paneer curry', 'Curd and salad'], 900, 45),
      M('snack', 'sandwich', ['2 peanut butter brown bread slices', 'Banana-milk shake (300 ml milk)'], 520, 20),
      M('dinner', 'dal', ['50 g (dry) soya chunk curry', '3 rotis', 'Green vegetables', '1 bowl curd'], 720, 38)]),
    D('dv3', 'veg', 'Veg Balanced Health', 'Stay fit and healthy', 'About 2,000 kcal', 'A normal, well-rounded Indian vegetarian day for general fitness and energy.', [
      M('breakfast', 'poha', ['1 plate vegetable poha with peanuts', '1 fruit (seasonal)'], 400, 12),
      M('lunch', 'roti', ['3 rotis or 1 cup rice', '1 bowl dal', 'Seasonal sabzi', 'Salad and buttermilk'], 600, 22),
      M('snack', 'nuts', ['1 handful roasted chana and nuts', '1 cup tea with little sugar', '1 fruit'], 300, 11),
      M('dinner', 'khichdi', ['1.5 bowls vegetable khichdi', '1 bowl curd or raita', 'Salad'], 520, 20)]),
    D('dv4', 'veg', 'Veg Budget Desi', 'Eat well on a budget', 'About 1,800 kcal', 'Low-cost home foods: idli, dal-rice, chana and rajma. Easy to cook and easy on the pocket.', [
      M('breakfast', 'idli', ['3 idlis with sambar and chutney'], 380, 12),
      M('lunch', 'rice', ['1.5 cups rice', '1 bowl dal', 'Seasonal sabzi', '1 bowl curd'], 620, 20),
      M('snack', 'fruits', ['1 handful roasted chana', '1 banana'], 250, 9),
      M('dinner', 'curry', ['3 rotis', '1 bowl rajma or chole', 'Onion-tomato salad'], 560, 22)]),
    D('dn1', 'nonveg', 'Non-veg Fat Loss', 'Lose fat', 'About 1,600 kcal', 'Lean protein from eggs, chicken and fish with plenty of vegetables.', [
      M('breakfast', 'eggs', ['1 whole egg + 3 egg-white omelette', '1 multigrain toast', 'Green tea'], 330, 30),
      M('lunch', 'chicken', ['120 g grilled chicken', '2 rotis or 1 cup rice', 'Small bowl dal', 'Large salad'], 560, 45),
      M('snack', 'boiled', ['2 boiled eggs', 'Cucumber and carrot sticks'], 190, 14),
      M('dinner', 'fish', ['150 g grilled or curry fish', 'Sauteed vegetables', 'Clear soup'], 420, 36)]),
    D('dn2', 'nonveg', 'Non-veg Muscle Gain', 'Build muscle', 'About 3,000 kcal', 'High-protein day with eggs, chicken and fish for lifters who want to gain size.', [
      M('breakfast', 'eggs', ['4 whole eggs scrambled', '2 toasts with butter', '1 banana', '1 glass milk'], 780, 42),
      M('lunch', 'chicken', ['200 g chicken curry', '1.5 cups rice', '1 bowl dal', 'Salad'], 900, 62),
      M('snack', 'sandwich', ['Chicken or egg sandwich (2 slices)', 'Banana-milk shake'], 600, 34),
      M('dinner', 'fish', ['200 g grilled chicken or fish', '3 rotis', 'Vegetables', '1 bowl curd'], 760, 58)]),
    D('dn3', 'nonveg', 'Non-veg Balanced Health', 'Stay fit and healthy', 'About 2,100 kcal', 'Everyday balanced eating with eggs, fish or chicken, grains and vegetables.', [
      M('breakfast', 'eggs', ['Egg bhurji (2 eggs)', '2 rotis or 2 toasts', '1 fruit'], 480, 22),
      M('lunch', 'fish', ['Fish or chicken curry (120 g)', '1 cup rice or 2 rotis', 'Sabzi and salad'], 640, 38),
      M('snack', 'nuts', ['1 handful nuts', '1 fruit', 'Tea'], 280, 8),
      M('dinner', 'soup', ['Chicken soup', '2 rotis', 'Vegetable sabzi'], 520, 34)]),
    D('dn4', 'nonveg', 'Non-veg Budget Desi', 'Eat well on a budget', 'About 1,900 kcal', 'Affordable protein from eggs and home-style chicken with rice and roti.', [
      M('breakfast', 'boiled', ['2 boiled eggs', '1 plate poha or 2 rotis', '1 banana'], 480, 20),
      M('lunch', 'curry', ['Egg curry (2 eggs)', '1.5 cups rice', '1 bowl dal'], 640, 28),
      M('snack', 'fruits', ['Roasted chana', '1 banana or seasonal fruit'], 240, 9),
      M('dinner', 'chicken', ['100 g home-style chicken curry', '2-3 rotis', 'Onion-tomato salad'], 540, 36)])
    ,
    D('dv5', 'veg', 'Veg High-Protein Lean', 'Lean and strong without supplements', 'About 1,900 kcal', 'Protein-rich vegetarian day built from paneer, tofu, dal, soya and curd, with no powders needed.', [
      M('breakfast', 'paneer', ['Paneer bhurji (100 g)', '2 multigrain toasts', 'Green tea'], 420, 26),
      M('lunch', 'dal', ['2 rotis', '1.5 bowls moong or masoor dal', 'Soya chunk sabzi (30 g dry)', 'Curd and salad'], 650, 38),
      M('snack', 'curd', ['1 bowl thick hung curd with a few nuts', '1 handful roasted makhana'], 260, 18),
      M('dinner', 'curry', ['100 g tofu or paneer curry', '2 rotis', 'Sauteed vegetables'], 560, 30)]),
    D('dv6', 'veg', 'Veg Low-Carb', 'Cut carbs, keep protein', 'About 1,550 kcal', 'Fewer rotis and rice, more paneer, vegetables and nuts. Good for a fat-loss phase.', [
      M('breakfast', 'paneer', ['Paneer and spinach scramble', '8–10 almonds'], 380, 22),
      M('lunch', 'salad', ['Large salad with paneer cubes, nuts and olive oil', '1 small bowl dal', '1 roti'], 480, 26),
      M('snack', 'nuts', ['1 handful mixed nuts and seeds', '1 glass buttermilk'], 250, 9),
      M('dinner', 'soup', ['Palak paneer (100 g paneer, no cream)', 'Stir-fried vegetables', 'Clear vegetable soup'], 440, 26)]),
    D('dv7', 'veg', 'Vegan Plant-Based', 'Eat plant-based, no dairy', 'About 1,900 kcal', 'Completely plant-based day with soy, beans, grains, nuts and seeds. No milk, curd, paneer or honey.', [
      M('breakfast', 'oats', ['Oats cooked with soy or almond milk', '1 banana, chia seeds and walnuts'], 420, 14),
      M('lunch', 'rice', ['1 cup rice or 2 rotis', '1.5 bowls rajma or chana', 'Vegetable sabzi', 'Salad'], 650, 26),
      M('snack', 'sprouts', ['Sprouts salad with lemon', 'Small handful roasted peanuts', '1 fruit'], 300, 15),
      M('dinner', 'curry', ['Tofu or soya chunk curry', '2 rotis', 'Stir-fried vegetables'], 520, 30)]),
    D('dn5', 'nonveg', 'Non-veg High-Protein Lean', 'Stay lean and strong', 'About 1,650 kcal', 'Lean chicken, eggs and fish with plenty of vegetables for a high-protein, moderate-calorie day.', [
      M('breakfast', 'eggs', ['3 whole eggs + 2 egg whites scrambled', '1 multigrain toast', 'Black coffee or green tea'], 400, 34),
      M('lunch', 'chicken', ['150 g grilled chicken breast', '1 cup rice or 2 rotis', 'Sauteed vegetables', 'Curd'], 600, 50),
      M('snack', 'boiled', ['3 boiled eggs', 'Cucumber slices'], 240, 19),
      M('dinner', 'fish', ['150 g grilled fish or chicken', 'Large salad', 'Clear soup'], 380, 40)]),
    D('dn6', 'nonveg', 'Non-veg Low-Carb', 'Cut carbs, keep protein', 'About 1,600 kcal', 'Eggs, tandoori chicken and fish with salads and vegetables. Very few rotis or rice.', [
      M('breakfast', 'eggs', ['Vegetable omelette (3 eggs)', '1 handful nuts'], 430, 26),
      M('lunch', 'chicken', ['Chicken tikka (150 g)', 'Big salad with olive oil', '1 small bowl dal'], 480, 45),
      M('snack', 'boiled', ['2 boiled eggs', '8–10 almonds'], 290, 18),
      M('dinner', 'fish', ['Fish curry (150 g) with little oil', 'Stir-fried vegetables', 'Clear soup'], 400, 34)]),
    D('dn7', 'nonveg', 'Non-veg Athlete Fuel', 'Energy for runners and sports', 'About 2,650 kcal', 'Carb-rich day with chicken, eggs and fish to fuel long training sessions, matches and runs.', [
      M('breakfast', 'oats', ['Oats with milk and banana', '2 boiled eggs', '2 dates'], 620, 30),
      M('lunch', 'rice', ['150 g chicken curry', '2 cups rice', '1 bowl dal', 'Salad'], 880, 48),
      M('snack', 'sandwich', ['Egg or chicken sandwich', 'Coconut water or fruit juice'], 450, 24),
      M('dinner', 'roti', ['150 g fish or chicken', '3 rotis', 'Vegetables', '1 bowl curd'], 700, 46)])
  ];
  function planTotals(p) { var k = 0, g = 0; p.meals.forEach(function (m) { k += m.kcal; g += m.protein; }); return { kcal: k, protein: g }; }

  var api = {
    SLOTS: SLOTS, TRAINERS: TRAINERS, packages: packages, avatar: avatar, food: food,
    PLANS: PLANS, SLOT_DEFAULT: SLOT_DEFAULT, SLOT_LABEL: SLOT_LABEL, SLOT_ORDER: SLOT_ORDER, planTotals: planTotals,
    trainer: function (id) { return TRAINERS.filter(function (t) { return t.id === id; })[0]; },
    plan: function (id) { return PLANS.filter(function (p) { return p.id === id; })[0]; }
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.GymWell = api;
})(typeof window !== 'undefined' ? window : globalThis);
