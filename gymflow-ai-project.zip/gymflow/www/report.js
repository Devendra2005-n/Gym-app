/* GymReport: weekly report charts (SVG for screen), PDF builders (jsPDF) and file delivery. */
(function (root) {
  'use strict';
  var C = root.GymCore;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function dayLabel(d) { return ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'][new Date(d + 'T00:00:00Z').getUTCDay()]; }
  function rs(n) { return 'Rs. ' + Number(n || 0).toLocaleString('en-IN'); }
  function pdfDate(d) { return C.fmtDate(d); }

  // ---------- on-screen charts (inline SVG, theme colours through CSS variables) ----------
  function barChart(days, key, unit) {
    var W = 320, H = 150, pad = 22, max = 0, i;
    days.forEach(function (d) { if (d[key] > max) max = d[key]; });
    var top = max || 1, bw = (W - pad * 2) / days.length, o = '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Daily ' + esc(unit) + '">';
    o += '<line x1="' + pad + '" y1="' + (H - 24) + '" x2="' + (W - pad) + '" y2="' + (H - 24) + '" class="ax"/>';
    for (i = 0; i < days.length; i++) {
      var h = Math.round((days[i][key] / top) * (H - 56)), x = pad + i * bw + bw * 0.18, w = bw * 0.64;
      o += '<rect x="' + x.toFixed(1) + '" y="' + (H - 24 - h) + '" width="' + w.toFixed(1) + '" height="' + h + '" rx="3" class="bar' + (days[i][key] ? '' : ' zero') + '"/>';
      if (days[i][key]) o += '<text x="' + (x + w / 2).toFixed(1) + '" y="' + (H - 28 - h) + '" text-anchor="middle" class="val">' + days[i][key] + '</text>';
      o += '<text x="' + (x + w / 2).toFixed(1) + '" y="' + (H - 8) + '" text-anchor="middle" class="lab">' + dayLabel(days[i].date) + '</text>';
    }
    return o + '</svg>';
  }
  function hBars(items, unit) {
    if (!items.length) return '';
    var max = items[0].kcal || 1;
    return '<div class="hbars">' + items.slice(0, 5).map(function (t) {
      return '<div class="hb"><div class="hbt"><span>' + esc(t.name) + ' <span class="muted">×' + t.count + '</span></span><b>' + t.kcal + ' ' + esc(unit) + '</b></div><div class="hbtrack"><div class="hbfill" style="width:' + Math.max(4, Math.round(t.kcal / max * 100)) + '%"></div></div></div>';
    }).join('') + '</div>';
  }
  function weightChart(points) {
    if (points.length < 2) return '';
    var W = 320, H = 130, pad = 28, min = Infinity, max = -Infinity;
    points.forEach(function (p) { if (p.kg < min) min = p.kg; if (p.kg > max) max = p.kg; });
    if (max - min < 1) { max += 0.5; min -= 0.5; }
    var n = points.length, pts = points.map(function (p, i) { return [pad + i * (W - pad * 2) / (n - 1), 16 + (max - p.kg) / (max - min) * (H - 44)]; });
    var o = '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Weight trend"><polyline class="ln" fill="none" points="' + pts.map(function (p) { return p[0].toFixed(1) + ',' + p[1].toFixed(1); }).join(' ') + '"/>';
    pts.forEach(function (p, i) { o += '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="3.5" class="pt"/><text x="' + p[0].toFixed(1) + '" y="' + (p[1] - 8).toFixed(1) + '" text-anchor="middle" class="val">' + points[i].kg + '</text><text x="' + p[0].toFixed(1) + '" y="' + (H - 6) + '" text-anchor="middle" class="lab">' + esc(C.fmtDate(points[i].date).slice(0, 6)) + '</text>'; });
    return o + '</svg>';
  }

  // ---------- PDF helpers ----------
  function newDoc() {
    var lib = root.jspdf || root.jsPDF; var Ctor = lib && (lib.jsPDF || lib);
    if (!Ctor) throw new Error('PDF engine did not load.');
    return new Ctor({ unit: 'mm', format: 'a4' });
  }
  var GREEN = [101, 163, 13], INK = [24, 24, 27], MUTE = [113, 113, 122], LINE = [228, 228, 231];
  function header(doc, title, sub) {
    doc.setFillColor(24, 24, 27); doc.rect(0, 0, 210, 30, 'F');
    doc.setTextColor(212, 245, 90); doc.setFont('helvetica', 'bold'); doc.setFontSize(20); doc.text(C.GYM.name, 14, 14);
    doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'normal'); doc.setFontSize(11); doc.text(title, 14, 22); if (sub) doc.text(sub, 196, 22, { align: 'right' });
    doc.setTextColor(INK[0], INK[1], INK[2]);
  }
  function pdfBars(doc, x, y, w, h, days, key, label) {
    var max = 0; days.forEach(function (d) { if (d[key] > max) max = d[key]; }); max = max || 1;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.setTextColor(INK[0], INK[1], INK[2]); doc.text(label, x, y);
    var base = y + h, bw = w / days.length, ch = h - 12;
    doc.setDrawColor(LINE[0], LINE[1], LINE[2]); doc.line(x, base, x + w, base);
    days.forEach(function (d, i) {
      var bh = d[key] / max * ch, bx = x + i * bw + bw * 0.2;
      if (bh > 0) { doc.setFillColor(GREEN[0], GREEN[1], GREEN[2]); doc.rect(bx, base - bh, bw * 0.6, bh, 'F'); doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(INK[0], INK[1], INK[2]); doc.text(String(d[key]), bx + bw * 0.3, base - bh - 1.5, { align: 'center' }); }
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(MUTE[0], MUTE[1], MUTE[2]); doc.text(dayLabel(d.date), bx + bw * 0.3, base + 4.5, { align: 'center' });
    });
    doc.setTextColor(INK[0], INK[1], INK[2]);
  }
  function stat(doc, x, y, w, big, small) {
    doc.setDrawColor(LINE[0], LINE[1], LINE[2]); doc.roundedRect(x, y, w, 22, 2, 2, 'S');
    doc.setFont('helvetica', 'bold'); doc.setFontSize(16); doc.setTextColor(GREEN[0], GREEN[1], GREEN[2]); doc.text(String(big), x + w / 2, y + 10, { align: 'center' });
    doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(MUTE[0], MUTE[1], MUTE[2]); doc.text(small, x + w / 2, y + 17, { align: 'center' }); doc.setTextColor(INK[0], INK[1], INK[2]);
  }

  function weeklyPdf(wk, who, weights) {
    var doc = newDoc();
    header(doc, 'Weekly Fitness Report', pdfDate(wk.start) + ' - ' + pdfDate(wk.end));
    doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.text(who || 'Member', 14, 42);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(MUTE[0], MUTE[1], MUTE[2]); doc.text('Generated ' + pdfDate(wk.end) + ' from workouts logged in the The Forge app', 14, 47); doc.setTextColor(INK[0], INK[1], INK[2]);
    var fat = wk.fat_g >= 1000 ? (wk.fat_g / 1000).toFixed(2) + ' kg' : wk.fat_g + ' g';
    stat(doc, 14, 54, 41, String(wk.count), 'Exercises done'); stat(doc, 58, 54, 41, String(wk.kcal), 'Calories burned'); stat(doc, 102, 54, 41, fat, 'Fat (energy equiv.)'); stat(doc, 146, 54, 50, wk.active_days + ' / 7', 'Active days');
    pdfBars(doc, 14, 92, 182, 42, wk.days, 'kcal', 'Calories burned per day');
    pdfBars(doc, 14, 148, 182, 34, wk.days, 'minutes', 'Workout minutes per day');
    var y = 198; doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('Top exercises this week', 14, y); y += 6;
    doc.setFont('helvetica', 'normal'); doc.setFontSize(10);
    if (!wk.top.length) { doc.setTextColor(MUTE[0], MUTE[1], MUTE[2]); doc.text('No workouts were logged this week.', 14, y); y += 6; doc.setTextColor(INK[0], INK[1], INK[2]); }
    wk.top.slice(0, 6).forEach(function (t) { doc.text(t.name + '  x' + t.count, 14, y); doc.text(t.kcal + ' kcal  |  ' + t.minutes + ' min', 196, y, { align: 'right' }); doc.setDrawColor(LINE[0], LINE[1], LINE[2]); doc.line(14, y + 1.8, 196, y + 1.8); y += 6.5; });
    y += 4; doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('Body weight', 14, y); y += 6; doc.setFont('helvetica', 'normal'); doc.setFontSize(10);
    if (wk.weight && wk.weight.change != null) doc.text('Start ' + wk.weight.start + ' kg  ->  Now ' + wk.weight.end + ' kg  (' + (wk.weight.change > 0 ? '+' : '') + wk.weight.change + ' kg)', 14, y);
    else if (wk.weight) doc.text('Latest weigh-in: ' + wk.weight.end + ' kg (add another weigh-in to see the change).', 14, y);
    else doc.text('No weigh-in this week. Log your weight in the app to track real change.', 14, y);
    doc.setFontSize(8); doc.setTextColor(MUTE[0], MUTE[1], MUTE[2]);
    doc.text('Calories use MET values x body weight x time, and fat is calories / 7700 per kg. These are estimates, not medical measurements.', 14, 284);
    doc.setTextColor(INK[0], INK[1], INK[2]);
    return doc;
  }

  function invoicePdf(v) {
    var doc = newDoc();
    header(doc, 'INVOICE / PAYMENT RECEIPT', v.no);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.text(v.gym.name, 14, 42);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(10); doc.setTextColor(MUTE[0], MUTE[1], MUTE[2]);
    var y = 48; [v.gym.address, v.gym.phone ? 'Phone: ' + v.gym.phone : '', v.gym.gstin ? 'GSTIN: ' + v.gym.gstin : ''].forEach(function (t) { if (t) { doc.text(t, 14, y); y += 5; } });
    doc.setTextColor(INK[0], INK[1], INK[2]); doc.setFont('helvetica', 'bold'); doc.text('Invoice no', 140, 42); doc.text('Date', 140, 48); doc.setFont('helvetica', 'normal'); doc.text(v.no, 196, 42, { align: 'right' }); doc.text(pdfDate(v.date), 196, 48, { align: 'right' });
    y = Math.max(y, 62) + 4; doc.setDrawColor(LINE[0], LINE[1], LINE[2]); doc.line(14, y, 196, y); y += 8;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(9); doc.setTextColor(MUTE[0], MUTE[1], MUTE[2]); doc.text('BILLED TO', 14, y); y += 6; doc.setTextColor(INK[0], INK[1], INK[2]); doc.setFontSize(12); doc.text(v.member.name, 14, y); y += 5.5;
    doc.setFont('helvetica', 'normal'); doc.setFontSize(10); if (v.member.phone) { doc.text('Phone: ' + v.member.phone, 14, y); y += 5; } y += 6;
    doc.setFillColor(244, 244, 245); doc.rect(14, y, 182, 9, 'F'); doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.text('Description', 17, y + 6); doc.text('Amount', 193, y + 6, { align: 'right' }); y += 16;
    doc.setFont('helvetica', 'normal'); doc.text(v.item, 17, y); doc.text(rs(v.base), 193, y, { align: 'right' }); y += 5.5;
    if (v.period) { doc.setFontSize(9); doc.setTextColor(MUTE[0], MUTE[1], MUTE[2]); doc.text('Valid ' + pdfDate(v.period.from) + ' to ' + pdfDate(v.period.to), 17, y); doc.setTextColor(INK[0], INK[1], INK[2]); doc.setFontSize(10); y += 5; }
    y += 4; doc.line(14, y, 196, y); y += 7;
    if (v.gst_pct) { doc.text('GST ' + v.gst_pct + '% (included in total)', 17, y); doc.text(rs(v.tax), 193, y, { align: 'right' }); y += 7; }
    doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.text('Total paid', 17, y); doc.setTextColor(GREEN[0], GREEN[1], GREEN[2]); doc.text(rs(v.total), 193, y, { align: 'right' }); doc.setTextColor(INK[0], INK[1], INK[2]); y += 9;
    doc.setFont('helvetica', 'normal'); doc.setFontSize(10); doc.text('Payment mode: ' + String(v.method).toUpperCase() + (v.ref ? '   Ref: ' + v.ref : ''), 17, y); y += 7;
    doc.setFont('helvetica', 'bold'); doc.setTextColor(GREEN[0], GREEN[1], GREEN[2]); doc.text('PAID', 17, y); doc.setTextColor(INK[0], INK[1], INK[2]);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(10); doc.setTextColor(MUTE[0], MUTE[1], MUTE[2]); doc.text(v.footer || '', 105, 270, { align: 'center' }); doc.setFontSize(8); doc.text('This is a computer-generated invoice and needs no signature.', 105, 276, { align: 'center' });
    doc.setTextColor(INK[0], INK[1], INK[2]);
    return doc;
  }

  // ---------- delivery: Android share sheet, or browser download ----------
  function plugin(name) { var P = root.Capacitor && root.Capacitor.Plugins; return (P && P[name]) || (root.Capacitor && root.Capacitor.registerPlugin ? root.Capacitor.registerPlugin(name) : null); }
  function native() { return !!(root.Capacitor && root.Capacitor.isNativePlatform && root.Capacitor.isNativePlatform()); }
  function deliver(doc, filename, title) {
    var safe = String(filename).replace(/[^A-Za-z0-9._-]+/g, '_');
    if (native()) {
      var FS = plugin('Filesystem'), SH = plugin('Share'), b64 = doc.output('datauristring').split(',')[1];
      return FS.writeFile({ path: safe, data: b64, directory: 'CACHE' }).then(function (r) {
        return SH.share({ title: title || safe, text: title || safe, url: r.uri, dialogTitle: 'Send PDF' });
      });
    }
    var url = URL.createObjectURL(doc.output('blob')), a = document.createElement('a');
    a.href = url; a.download = safe; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
    return Promise.resolve();
  }

  root.GymReport = { barChart: barChart, hBars: hBars, weightChart: weightChart, weeklyPdf: weeklyPdf, invoicePdf: invoicePdf, deliver: deliver };
})(typeof window !== 'undefined' ? window : globalThis);
