/* GYM Flow - workout library, plans and default FAQ. */
(function (root) {
  'use strict';
  var F = 170;
  function foot(x, y) { return { type: 'foot', x: x, y: y == null ? F - 5 : y }; }
  function hip(x, y) { return { type: 'hip', x: x, y: y }; }
  function hand(x, y) { return { type: 'hand', x: x, y: y }; }
  function P(o, over) { var r = {}, k; for (k in o) r[k] = o[k]; for (k in over) r[k] = over[k]; return r; }

  var STAND = { t: -90, th: 90, sh: 90, ua: 90, fa: 90, anchor: foot(120) };
  var BENCH = [[48, 130, 150, 130, 8], [58, 134, 58, F, 4], [140, 134, 140, F, 4]];
  var LYING = { t: 180, th: 30, sh: 95, anchor: hip(110, 122) };   // lying on a flat bench

  var CATEGORIES = [
    { id: 'chest', name: 'Chest', icon: '🏋️' },
    { id: 'shoulders', name: 'Shoulders', icon: '🤸' },
    { id: 'biceps', name: 'Biceps', icon: '💪' },
    { id: 'triceps', name: 'Triceps', icon: '🦾' },
    { id: 'legs', name: 'Legs', icon: '🦵' },
    { id: 'back', name: 'Back', icon: '🧗' },
    { id: 'abs', name: 'Abs', icon: '🔥' },
    { id: 'cardio', name: 'Cardio & HIIT', icon: '⚡' }
  ];

  var EXERCISES = [
    // ---------------- CHEST ----------------
    { id: 'bench-press', name: 'Barbell Bench Press', cat: 'chest', muscles: ['Chest', 'Front shoulders', 'Triceps'], equip: 'Barbell, flat bench', level: 'Intermediate', sets: '4 × 6–10',
      hl: 'arm', equip_draw: 'bar', props: BENCH,
      poses: [P(LYING, { ua: -90, fa: -90 }), P(LYING, { ua: 40, fa: -95 })],
      steps: ['Lie on the bench with eyes under the bar, feet flat on the floor, shoulder blades pulled together.', 'Unrack the bar and lower it under control to the middle of your chest.', 'Press straight back up until your arms are straight, without bouncing the bar.'],
      tips: ['Keep your wrists straight and over your elbows.', 'Use a spotter when lifting heavy.'] },
    { id: 'push-up', name: 'Push-up', cat: 'chest', muscles: ['Chest', 'Front shoulders', 'Triceps', 'Core'], equip: 'Bodyweight', level: 'Beginner', sets: '3 × 8–15',
      hl: 'arm', equip_draw: 'none',
      poses: [{ t: -25, ua: 90, fa: 90, th: 154, sh: 154, ft: 120, anchor: hand(172, F - 3) }, { t: -12, ua: 150, fa: 70, th: 162, sh: 162, ft: 120, anchor: hand(172, F - 3) }],
      steps: ['Place your hands slightly wider than your shoulders with your body in a straight line from head to heels.', 'Bend your elbows and lower your chest until it is just above the floor.', 'Push the floor away until your arms are straight again.'],
      tips: ['Squeeze your glutes and abs so your hips do not sag.', 'Too hard? Do them with your knees on the floor.'] },
    { id: 'incline-press', name: 'Incline Dumbbell Press', cat: 'chest', muscles: ['Upper chest', 'Front shoulders', 'Triceps'], equip: 'Dumbbells, incline bench', level: 'Intermediate', sets: '3 × 8–12',
      hl: 'arm', equip_draw: 'db', props: [[104, 129, 66, 84, 7], [100, 134, 100, F, 4], [136, 134, 136, F, 4]],
      poses: [{ t: -128, th: 30, sh: 100, ua: -80, fa: -85, anchor: hip(110, 124) }, { t: -128, th: 30, sh: 100, ua: 60, fa: -95, anchor: hip(110, 124) }],
      steps: ['Set the bench to a low incline (about 30–45°) and sit back with a dumbbell on each thigh.', 'Kick the weights up to chest level, then press them overhead until your arms are straight.', 'Lower slowly until your elbows are a little below the bench.'],
      tips: ['Do not set the bench too steep – it turns into a shoulder exercise.', 'Keep your feet planted.'] },
    { id: 'pullover', name: 'Dumbbell Pullover', cat: 'chest', muscles: ['Chest', 'Lats', 'Triceps (long head)'], equip: 'One dumbbell, flat bench', level: 'Intermediate', sets: '3 × 10–12',
      hl: 'arm', equip_draw: 'db', props: BENCH,
      poses: [P(LYING, { ua: -90, fa: -90 }), P(LYING, { ua: -190, fa: -185 })],
      steps: ['Lie across or along the bench holding one dumbbell above your chest with both hands.', 'With a slight bend in your elbows, lower the weight in an arc behind your head until you feel a stretch.', 'Pull it back over your chest along the same arc.'],
      tips: ['Choose a light weight first; this is a stretch-and-control move.', 'Keep your ribs down and your lower back relaxed.'] },

    // ---------------- SHOULDERS ----------------
    { id: 'overhead-press', name: 'Overhead Press', cat: 'shoulders', muscles: ['Shoulders', 'Triceps', 'Upper chest'], equip: 'Barbell or dumbbells', level: 'Intermediate', sets: '4 × 6–10',
      hl: 'arm', equip_draw: 'bar',
      poses: [P(STAND, { ua: 75, fa: -80 }), P(STAND, { ua: -85, fa: -90 })],
      steps: ['Stand tall with feet shoulder-width apart and the weight resting at your shoulders.', 'Tighten your abs and glutes, then press the weight straight overhead.', 'Lower it back to your shoulders under control.'],
      tips: ['Do not lean back; keep your ribs down.', 'Move your head slightly back and forward as the bar passes your face.'] },
    { id: 'lateral-raise', name: 'Lateral Raise', cat: 'shoulders', muscles: ['Side shoulders'], equip: 'Dumbbells', level: 'Beginner', sets: '3 × 12–15',
      hl: 'arm', equip_draw: 'db',
      poses: [P(STAND, { ua: 90, fa: 90 }), P(STAND, { ua: 15, fa: 30 })],
      steps: ['Stand holding a light dumbbell in each hand at your sides, elbows slightly bent.', 'Raise your arms out to the sides until they reach shoulder height.', 'Lower slowly over about three seconds.'],
      tips: ['Lead with your elbows, not your hands.', 'Light weight and no swinging works best. (The picture is a side view, so the arms look like they move forward.)'] },
    { id: 'front-raise', name: 'Front Raise', cat: 'shoulders', muscles: ['Front shoulders', 'Upper chest'], equip: 'Dumbbells or plate', level: 'Beginner', sets: '3 × 10–12',
      hl: 'arm', equip_draw: 'db',
      poses: [P(STAND, { ua: 90, fa: 90 }), P(STAND, { ua: 0, fa: 0 })],
      steps: ['Stand holding dumbbells in front of your thighs.', 'Raise both arms straight in front of you to shoulder height.', 'Lower them slowly without swinging your body.'],
      tips: ['Keep a soft bend in your elbows.', 'Stop at shoulder height – going higher adds little.'] },

    // ---------------- BICEPS ----------------
    { id: 'barbell-curl', name: 'Barbell Curl', cat: 'biceps', muscles: ['Biceps', 'Forearms'], equip: 'Barbell or EZ-bar', level: 'Beginner', sets: '3 × 8–12',
      hl: 'arm', equip_draw: 'bar',
      poses: [P(STAND, { ua: 90, fa: 75 }), P(STAND, { ua: 88, fa: -70 })],
      steps: ['Stand tall holding the bar with palms facing forward, hands shoulder-width apart.', 'Keeping your elbows by your sides, curl the bar up towards your shoulders.', 'Squeeze at the top, then lower slowly until your arms are straight.'],
      tips: ['No swinging – if you need momentum, the weight is too heavy.', 'Keep your elbows pinned beside your ribs.'] },
    { id: 'hammer-curl', name: 'Hammer Curl', cat: 'biceps', muscles: ['Biceps', 'Brachialis', 'Forearms'], equip: 'Dumbbells', level: 'Beginner', sets: '3 × 10–12',
      hl: 'arm', equip_draw: 'db',
      poses: [P(STAND, { ua: 92, fa: 80 }), P(STAND, { ua: 95, fa: -75 })],
      steps: ['Stand with a dumbbell in each hand, palms facing your thighs (like holding a hammer).', 'Curl the weights up without turning your wrists.', 'Lower under control and repeat, or alternate arms.'],
      tips: ['Great for thicker-looking arms and stronger grip.', 'Keep your upper arms still.'] },
    { id: 'concentration-curl', name: 'Concentration Curl', cat: 'biceps', muscles: ['Biceps (peak)'], equip: 'One dumbbell, bench', level: 'Beginner', sets: '3 × 10–12 each arm',
      hl: 'arm', equip_draw: 'db', props: [[78, 142, 128, 142, 8], [88, 146, 88, F, 4], [120, 146, 120, F, 4]],
      poses: [{ t: -30, th: 5, sh: 95, ua: 104, fa: 85, anchor: hip(100, 134) }, { t: -30, th: 5, sh: 95, ua: 104, fa: -60, anchor: hip(100, 134) }],
      steps: ['Sit on a bench with your legs apart and rest the back of one upper arm against your inner thigh.', 'Curl the dumbbell up towards your shoulder.', 'Squeeze the biceps, then lower slowly and finish all reps before switching arms.'],
      tips: ['Do not let your elbow move off your thigh.', 'Use a lighter weight than normal curls.'] },

    // ---------------- TRICEPS ----------------
    { id: 'pushdown', name: 'Tricep Pushdown', cat: 'triceps', muscles: ['Triceps'], equip: 'Cable machine', level: 'Beginner', sets: '3 × 10–15',
      hl: 'arm', equip_draw: 'cable', cable: [160, 22], props: [[140, 20, 176, 20, 5], [170, 20, 170, F, 6]],
      poses: [P(STAND, { t: -85, ua: 90, fa: -35 }), P(STAND, { t: -85, ua: 90, fa: 88 })],
      steps: ['Stand facing the cable machine, hold the bar or rope, and pin your elbows to your sides.', 'Push the handle down until your arms are fully straight.', 'Let it rise slowly until your forearms are just above parallel.'],
      tips: ['Only your forearms should move.', 'Lean forward slightly and keep your shoulders down.'] },
    { id: 'overhead-extension', name: 'Overhead Tricep Extension', cat: 'triceps', muscles: ['Triceps (long head)'], equip: 'One dumbbell', level: 'Beginner', sets: '3 × 10–12',
      hl: 'arm', equip_draw: 'db',
      poses: [P(STAND, { ua: 270, fa: 150 }), P(STAND, { ua: 270, fa: 270 })],
      steps: ['Stand holding one dumbbell with both hands above your head.', 'Bend your elbows to lower the weight behind your head.', 'Straighten your arms to press it back up.'],
      tips: ['Keep your elbows pointing forward, close to your ears.', 'Do not arch your lower back.'] },
    { id: 'bench-dips', name: 'Bench Dips', cat: 'triceps', muscles: ['Triceps', 'Chest', 'Front shoulders'], equip: 'Bench, bodyweight', level: 'Beginner', sets: '3 × 8–12',
      hl: 'arm', equip_draw: 'none', props: [[50, 130, 102, 130, 8], [60, 134, 60, F, 4], [94, 134, 94, F, 4]],
      poses: [{ t: -100, ua: 90, fa: 90, th: 45, sh: 85, anchor: hand(97, 121) }, { t: -100, ua: 140, fa: 60, th: 28, sh: 68, anchor: hand(97, 121) }],
      steps: ['Sit on the edge of a bench, place your hands beside your hips, and slide your bottom off the front.', 'Bend your elbows to lower yourself until your upper arms are about parallel with the floor.', 'Press back up until your arms are straight.'],
      tips: ['Keep your back close to the bench.', 'Bend your knees to make it easier, straighten them to make it harder.'] },
    { id: 'skull-crusher', name: 'Skull Crusher', cat: 'triceps', muscles: ['Triceps'], equip: 'EZ-bar or dumbbells, bench', level: 'Intermediate', sets: '3 × 8–12',
      hl: 'arm', equip_draw: 'bar', props: BENCH,
      poses: [P(LYING, { ua: -90, fa: -90 }), P(LYING, { ua: -90, fa: -190 })],
      steps: ['Lie on a bench holding the bar above your chest with straight arms.', 'Bend only your elbows to lower the bar towards your forehead.', 'Extend your arms to return to the start.'],
      tips: ['Keep your upper arms still and elbows pointing at the ceiling.', 'Start light to protect your elbows.'] },

    // ---------------- LEGS ----------------
    { id: 'squat', name: 'Barbell Squat', cat: 'legs', muscles: ['Quads', 'Glutes', 'Hamstrings', 'Core'], equip: 'Barbell, squat rack', level: 'Intermediate', sets: '4 × 6–10',
      hl: 'leg', equip_draw: 'bar',
      poses: [P(STAND, { ua: 120, fa: -60 }), { t: -55, th: 8, sh: 112, ua: 120, fa: -60, anchor: foot(120) }],
      steps: ['Set the bar across your upper back, feet shoulder-width apart, toes slightly out.', 'Push your hips back and bend your knees, lowering until your thighs are about parallel to the floor.', 'Drive through your whole foot to stand back up.'],
      tips: ['Keep your chest up and knees in line with your toes.', 'Learn the movement with just the bar or bodyweight first.'] },
    { id: 'lunge', name: 'Reverse Lunge', cat: 'legs', muscles: ['Quads', 'Glutes', 'Hamstrings'], equip: 'Bodyweight or dumbbells', level: 'Beginner', sets: '3 × 10 each leg',
      hl: 'leg', equip_draw: 'db',
      poses: [P(STAND, {}), { t: -90, th: 5, sh: 95, th2: 110, sh2: 170, ua: 90, fa: 90, anchor: foot(135) }],
      steps: ['Stand tall, then step one foot back and lower straight down.', 'Stop when your back knee is just above the floor and your front thigh is about level.', 'Push through your front foot to return to standing, then switch legs.'],
      tips: ['Keep your torso upright.', 'Your front knee should stay over your ankle.'] },
    { id: 'leg-press', name: 'Leg Press', cat: 'legs', muscles: ['Quads', 'Glutes', 'Hamstrings'], equip: 'Leg press machine', level: 'Beginner', sets: '3 × 10–15',
      hl: 'leg', equip_draw: 'none', plate: true, props: [[34, 118, 80, 142, 8], [88, 152, 168, 76, 4]],
      poses: [{ t: -150, th: -40, sh: -40, ua: 0, fa: 0, ft: -40, anchor: hip(80, 132) }, { t: -150, th: -105, sh: -25, ua: 0, fa: 0, ft: -40, anchor: hip(80, 132) }],
      steps: ['Sit with your back and hips flat against the pad and place your feet shoulder-width apart on the plate.', 'Release the safety and lower the plate until your knees are bent to about 90°.', 'Press the plate away without locking your knees.'],
      tips: ['Do not let your lower back peel off the pad.', 'Never lock your knees hard at the top.'] },
    { id: 'rdl', name: 'Romanian Deadlift', cat: 'legs', muscles: ['Hamstrings', 'Glutes', 'Lower back'], equip: 'Barbell or dumbbells', level: 'Intermediate', sets: '3 × 8–12',
      hl: 'leg', equip_draw: 'bar',
      poses: [P(STAND, {}), { t: -20, th: 75, sh: 85, ua: 90, fa: 90, anchor: foot(120) }],
      steps: ['Stand holding the bar at your thighs with a soft bend in your knees.', 'Push your hips back and slide the bar down your legs, keeping your back flat, until you feel a hamstring stretch.', 'Drive your hips forward to stand tall.'],
      tips: ['It is a hip hinge, not a squat: knees stay almost still.', 'Keep the bar close to your legs.'] },
    { id: 'calf-raise', name: 'Standing Calf Raise', cat: 'legs', muscles: ['Calves'], equip: 'Bodyweight or dumbbells', level: 'Beginner', sets: '4 × 12–20',
      hl: 'leg', equip_draw: 'db',
      poses: [P(STAND, { ft: 15 }), P(STAND, { ft: 65, anchor: foot(120, F - 13) })],
      steps: ['Stand with your feet hip-width apart, holding light dumbbells if you like.', 'Rise up onto the balls of your feet as high as you can.', 'Pause for a second, then lower slowly.'],
      tips: ['Use a step to get a deeper stretch at the bottom.', 'Go slow – calves respond to control, not speed.'] },

    // ---------------- BACK ----------------
    { id: 'pull-up', name: 'Pull-up', cat: 'back', muscles: ['Lats', 'Upper back', 'Biceps'], equip: 'Pull-up bar', level: 'Intermediate', sets: '3 × 5–10',
      hl: 'torso', equip_draw: 'none', props: [[78, 30, 162, 30, 5], [78, 30, 78, F, 3], [162, 30, 162, F, 3]],
      poses: [{ t: -90, ua: 270, fa: 270, th: 100, sh: 145, anchor: hand(118, 30) }, { t: -90, ua: 110, fa: 290, th: 100, sh: 145, anchor: hand(118, 30) }],
      steps: ['Hang from the bar with your hands slightly wider than your shoulders and arms straight.', 'Pull your elbows down and back until your chin is above the bar.', 'Lower yourself slowly back to a full hang.'],
      tips: ['Cannot do one yet? Use an assisted machine or a resistance band.', 'Avoid kicking or swinging.'] },
    { id: 'bent-row', name: 'Bent-over Row', cat: 'back', muscles: ['Lats', 'Mid back', 'Biceps', 'Rear shoulders'], equip: 'Barbell or dumbbells', level: 'Intermediate', sets: '4 × 8–12',
      hl: 'torso', equip_draw: 'bar',
      poses: [{ t: -25, th: 75, sh: 85, ua: 90, fa: 90, anchor: foot(120) }, { t: -25, th: 75, sh: 85, ua: 165, fa: 95, anchor: foot(120) }],
      steps: ['Hold the bar, hinge forward at your hips with a flat back and soft knees.', 'Pull the bar towards your lower ribs, squeezing your shoulder blades together.', 'Lower it slowly until your arms are straight.'],
      tips: ['Keep your neck in line with your spine.', 'Do not jerk with your lower back.'] },

    // ---------------- ABS ----------------
    { id: 'crunch', name: 'Crunch', cat: 'abs', muscles: ['Upper abs'], equip: 'Bodyweight', level: 'Beginner', sets: '3 × 12–20',
      hl: 'torso', equip_draw: 'none',
      poses: [{ t: 180, th: -55, sh: 100, ua: -40, fa: -170, anchor: hip(130, F - 9) }, { t: 210, th: -55, sh: 100, ua: -10, fa: -140, anchor: hip(130, F - 9) }],
      steps: ['Lie on your back with your knees bent and feet flat, arms crossed over your chest.', 'Curl your shoulders off the floor by tightening your abs.', 'Pause, then lower slowly.'],
      tips: ['Do not pull on your neck.', 'Small, controlled movement beats big, fast ones.'] },
    { id: 'plank', name: 'Forearm Plank', cat: 'abs', muscles: ['Core', 'Shoulders', 'Glutes'], equip: 'Bodyweight', level: 'Beginner', sets: '3 × 20–60 sec hold',
      hl: 'torso', equip_draw: 'none',
      poses: [{ t: -8, ua: 90, fa: 0, th: 166, sh: 166, ft: 120, anchor: hand(150, F - 3) }, { t: -3, ua: 90, fa: 0, th: 162, sh: 162, ft: 120, anchor: hand(150, F - 3) }],
      steps: ['Rest on your forearms with elbows under your shoulders and your legs straight behind you.', 'Tighten your abs and glutes so your body forms one straight line.', 'Hold the position while breathing normally.'],
      tips: ['Do not let your hips sag or pike up.', 'Stop when your form breaks – shorter, clean holds are better.'] },
    { id: 'leg-raise', name: 'Lying Leg Raise', cat: 'abs', muscles: ['Lower abs', 'Hip flexors'], equip: 'Bodyweight', level: 'Intermediate', sets: '3 × 10–15',
      hl: 'leg', equip_draw: 'none',
      poses: [{ t: 180, th: 0, sh: 0, ua: 0, fa: 0, ft: -80, anchor: hip(130, F - 9) }, { t: 180, th: -90, sh: -90, ua: 0, fa: 0, ft: -80, anchor: hip(130, F - 9) }],
      steps: ['Lie on your back with your legs straight and hands under your hips or by your sides.', 'Keeping your legs straight, raise them until they point at the ceiling.', 'Lower slowly, stopping just before they touch the floor.'],
      tips: ['If your lower back lifts, bend your knees slightly.', 'Press your lower back gently into the floor.'] }    ,
    // ---------------- MORE CHEST ----------------
    { id: 'dumbbell-fly', name: 'Dumbbell Fly', cat: 'chest', muscles: ['Chest', 'Front shoulders'], equip: 'Dumbbells, flat bench', level: 'Intermediate', sets: '3 × 10–12',
      hl: 'arm', equip_draw: 'db', props: BENCH,
      poses: [P(LYING, { ua: -90, fa: -90 }), P(LYING, { ua: 100, fa: 95 })],
      steps: ['Lie on a flat bench with a dumbbell in each hand above your chest, palms facing each other.', 'With a slight bend in your elbows, open your arms wide and lower the weights until you feel a stretch across your chest.', 'Squeeze your chest to bring the weights back together above you in a hugging arc.'],
      tips: ['Keep the elbow bend the same all the way; it is not a press.', 'Use lighter weights than for pressing.'] },
    { id: 'incline-pushup', name: 'Incline Push-up', cat: 'chest', muscles: ['Lower chest', 'Front shoulders', 'Triceps'], equip: 'Bench or sturdy platform', level: 'Beginner', sets: '3 × 10–15',
      hl: 'arm', equip_draw: 'none', props: [[150, 118, 190, 118, 8], [158, 122, 158, F, 4], [184, 122, 184, F, 4]],
      poses: [{ t: -50, ua: 90, fa: 90, th: 130, sh: 130, ft: 100, anchor: hand(168, 112) }, { t: -42, ua: 150, fa: 70, th: 134, sh: 134, ft: 100, anchor: hand(168, 112) }],
      steps: ['Place your hands on a bench or sturdy surface, slightly wider than your shoulders, body in a straight line.', 'Bend your elbows and lower your chest towards the bench.', 'Push away until your arms are straight.'],
      tips: ['A higher surface makes it easier; use the floor when you are ready.', 'Keep your hips in line with your shoulders and heels.'] },

    // ---------------- MORE SHOULDERS ----------------
    { id: 'upright-row', name: 'Upright Row', cat: 'shoulders', muscles: ['Side shoulders', 'Traps', 'Biceps'], equip: 'Barbell or EZ-bar', level: 'Intermediate', sets: '3 × 10–12',
      hl: 'arm', equip_draw: 'bar',
      poses: [P(STAND, { ua: 90, fa: 90 }), P(STAND, { ua: -50, fa: 115 })],
      steps: ['Stand holding the bar with a shoulder-width grip, resting against your thighs.', 'Lift the bar up along your body, leading with your elbows, to about chest height.', 'Lower slowly back to your thighs.'],
      tips: ['Stop at chest height to protect your shoulders.', 'Keep the bar close to your body.'] },
    { id: 'rear-delt-fly', name: 'Bent-over Rear Delt Fly', cat: 'shoulders', muscles: ['Rear shoulders', 'Upper back'], equip: 'Light dumbbells', level: 'Beginner', sets: '3 × 12–15',
      hl: 'arm', equip_draw: 'db',
      poses: [{ t: -25, th: 75, sh: 85, ua: 90, fa: 90, anchor: foot(120) }, { t: -25, th: 75, sh: 85, ua: 160, fa: 160, anchor: foot(120) }],
      steps: ['Hinge forward at the hips with a flat back, holding light dumbbells below your chest.', 'With soft elbows, lift your arms out to the sides, squeezing your shoulder blades.', 'Lower slowly.'],
      tips: ['Use very light weights; this muscle is small.', 'Keep your neck long and your back flat.'] },

    // ---------------- MORE BICEPS / TRICEPS ----------------
    { id: 'cable-curl', name: 'Cable Curl', cat: 'biceps', muscles: ['Biceps', 'Forearms'], equip: 'Cable machine (low pulley)', level: 'Beginner', sets: '3 × 10–15',
      hl: 'arm', equip_draw: 'cable', cable: [200, 160], props: [[196, 158, 218, 158, 6], [208, 158, 208, F, 6]],
      poses: [P(STAND, { ua: 90, fa: 75 }), P(STAND, { ua: 88, fa: -70 })],
      steps: ['Stand facing the low pulley holding the bar or handle with palms up.', 'Keep your elbows by your sides and curl the handle up to your shoulders.', 'Lower slowly; the cable keeps tension on the biceps the whole time.'],
      tips: ['Step back so the weight stack is lifted at the start.', 'Do not lean back to cheat the weight up.'] },
    { id: 'triceps-kickback', name: 'Triceps Kickback', cat: 'triceps', muscles: ['Triceps'], equip: 'Light dumbbells', level: 'Beginner', sets: '3 × 12–15',
      hl: 'arm', equip_draw: 'db',
      poses: [{ t: -25, th: 75, sh: 85, ua: 155, fa: 90, anchor: foot(120) }, { t: -25, th: 75, sh: 85, ua: 155, fa: 175, anchor: foot(120) }],
      steps: ['Hinge forward with a flat back and bring your upper arm in line with your torso, elbow bent to 90°.', 'Straighten your arm backwards without moving your upper arm.', 'Squeeze the triceps, then bend the elbow back to 90°.'],
      tips: ['Keep your upper arm glued in place.', 'Go light – it is a finishing exercise.'] },

    // ---------------- MORE LEGS ----------------
    { id: 'deadlift', name: 'Conventional Deadlift', cat: 'legs', muscles: ['Hamstrings', 'Glutes', 'Lower back', 'Traps', 'Grip'], equip: 'Barbell and plates', level: 'Intermediate', sets: '3 × 5–8',
      hl: 'leg', equip_draw: 'bar', props: [[60, F - 6, 180, F - 6, 4]],
      poses: [{ t: -38, th: 40, sh: 108, ua: 90, fa: 90, anchor: foot(120) }, P(STAND, {})],
      steps: ['Stand with your feet hip-width apart and the bar over the middle of your feet. Hinge down and grip the bar just outside your legs.', 'Brace your abs, keep your back flat, and push the floor away to stand up with the bar close to your legs.', 'Stand tall, then lower the bar by pushing your hips back first.'],
      tips: ['Never round your lower back.', 'Learn with a light bar or a kettlebell first.'] },
    { id: 'glute-bridge', name: 'Glute Bridge', cat: 'legs', muscles: ['Glutes', 'Hamstrings', 'Core'], equip: 'Bodyweight', level: 'Beginner', sets: '3 × 12–20',
      hl: 'leg', equip_draw: 'none',
      poses: [{ t: 180, th: -50, sh: 70, ua: 15, fa: 10, anchor: foot(140) }, { t: 152, th: 12, sh: 82, ua: 15, fa: 10, anchor: foot(140) }],
      steps: ['Lie on your back with your knees bent and feet flat, hip-width apart.', 'Push through your heels and lift your hips until your body forms a straight line from knees to shoulders.', 'Squeeze your glutes for a second, then lower slowly.'],
      tips: ['Do not arch your lower back at the top.', 'Hold a dumbbell on your hips to make it harder.'] },
    { id: 'goblet-squat', name: 'Goblet Squat', cat: 'legs', muscles: ['Quads', 'Glutes', 'Core'], equip: 'One dumbbell or kettlebell', level: 'Beginner', sets: '3 × 10–15',
      hl: 'leg', equip_draw: 'db',
      poses: [P(STAND, { ua: 60, fa: -100 }), { t: -78, th: 20, sh: 105, ua: 70, fa: -100, anchor: foot(120) }],
      steps: ['Hold one dumbbell upright against your chest with both hands.', 'Sit your hips down and back between your knees, keeping your chest up.', 'Stand back up by pushing through your whole foot.'],
      tips: ['A great way to learn the squat pattern.', 'Keep your elbows inside your knees at the bottom.'] },
    { id: 'leg-extension', name: 'Leg Extension', cat: 'legs', muscles: ['Quads'], equip: 'Leg extension machine', level: 'Beginner', sets: '3 × 12–15',
      hl: 'leg', equip_draw: 'none', props: [[66, 138, 112, 138, 8], [74, 142, 74, F, 4], [106, 142, 106, F, 4], [64, 138, 64, 88, 6]],
      poses: [{ t: -85, th: 0, sh: 95, ua: 90, fa: 90, anchor: hip(94, 128) }, { t: -85, th: 0, sh: -8, ua: 90, fa: 90, anchor: hip(94, 128) }],
      steps: ['Sit with your back against the pad and the roller resting on your lower shins.', 'Straighten your legs until they are almost fully extended.', 'Pause, then lower under control.'],
      tips: ['Do not slam the weight stack.', 'Adjust the seat so your knees line up with the machine pivot.'] },

    // ---------------- MORE BACK ----------------
    { id: 'lat-pulldown', name: 'Lat Pulldown', cat: 'back', muscles: ['Lats', 'Upper back', 'Biceps'], equip: 'Cable machine, wide bar', level: 'Beginner', sets: '3 × 10–12',
      hl: 'torso', equip_draw: 'cable', cable: [122, 12], props: [[78, 138, 122, 138, 8], [86, 142, 86, F, 4], [114, 142, 114, F, 4]],
      poses: [{ t: -92, th: 0, sh: 90, ua: -78, fa: -80, anchor: hip(98, 130) }, { t: -98, th: 0, sh: 90, ua: 105, fa: -70, anchor: hip(98, 130) }],
      steps: ['Sit with your thighs under the pad and grab the wide bar with straight arms.', 'Lean back slightly and pull the bar down to your upper chest, squeezing your shoulder blades.', 'Let the bar rise slowly until your arms are straight.'],
      tips: ['Pull with your elbows, not your hands.', 'Do not swing your body back and forth.'] },
    { id: 'seated-row', name: 'Seated Cable Row', cat: 'back', muscles: ['Mid back', 'Lats', 'Biceps', 'Rear shoulders'], equip: 'Cable row machine', level: 'Beginner', sets: '3 × 10–12',
      hl: 'torso', equip_draw: 'cable', cable: [226, 138], props: [[216, 138, 232, 138, 6], [60, 166, 180, 166, 4]],
      poses: [{ t: -82, th: -5, sh: -5, ua: 5, fa: 5, anchor: hip(82, 158) }, { t: -92, th: -5, sh: -5, ua: 140, fa: 5, anchor: hip(82, 158) }],
      steps: ['Sit tall with your feet on the plate, knees slightly bent, and hold the handle with straight arms.', 'Pull the handle to your belly, keeping your chest up and squeezing your shoulder blades together.', 'Return slowly until your arms are straight again.'],
      tips: ['Do not rock your torso to move the weight.', 'Keep your shoulders down and away from your ears.'] },

    // ---------------- MORE ABS ----------------
    { id: 'hanging-leg-raise', name: 'Hanging Leg Raise', cat: 'abs', muscles: ['Lower abs', 'Hip flexors', 'Grip'], equip: 'Pull-up bar', level: 'Intermediate', sets: '3 × 8–12',
      hl: 'torso', equip_draw: 'none', props: [[78, 30, 162, 30, 5], [78, 30, 78, F, 3], [162, 30, 162, F, 3]],
      poses: [{ t: -90, ua: 270, fa: 270, th: 92, sh: 92, anchor: hand(118, 30) }, { t: -90, ua: 270, fa: 270, th: 5, sh: 10, anchor: hand(118, 30) }],
      steps: ['Hang from the bar with straight arms and legs together.', 'Raise your legs up in front of you, using your abs, until they are about level with your hips.', 'Lower them slowly without swinging.'],
      tips: ['Bend your knees to make it easier.', 'Tilt your pelvis up at the top to really use the abs.'] },
    { id: 'sit-up', name: 'Sit-up', cat: 'abs', muscles: ['Abs', 'Hip flexors'], equip: 'Bodyweight', level: 'Beginner', sets: '3 × 12–20',
      hl: 'torso', equip_draw: 'none',
      poses: [{ t: 180, th: -55, sh: 80, ua: -40, fa: -170, anchor: hip(130, F - 9) }, { t: -70, th: -55, sh: 80, ua: 10, fa: -10, anchor: hip(130, F - 9) }],
      steps: ['Lie on your back with your knees bent and feet flat, arms crossed or by your ears.', 'Curl your whole upper body up until you are sitting tall.', 'Lower yourself back down slowly.'],
      tips: ['Do not yank your neck.', 'Anchor your feet under something if they lift.'] },

    // ---------------- CARDIO & HIIT ----------------
    { id: 'high-knees', name: 'High Knees', cat: 'cardio', muscles: ['Hip flexors', 'Quads', 'Calves', 'Core'], equip: 'Bodyweight', level: 'Beginner', sets: '4 × 30 sec',
      hl: 'leg', equip_draw: 'none',
      poses: [{ t: -88, th: 88, sh: 92, th2: 5, sh2: 95, ua: 60, fa: -60, ua2: 120, fa2: -40, ft: 70, anchor: hip(120, 108) }, { t: -88, th: 5, sh: 95, th2: 88, sh2: 92, ua: 120, fa: -40, ua2: 60, fa2: -60, ft: 70, anchor: hip(120, 108) }],
      steps: ['Stand tall with your feet hip-width apart.', 'Run on the spot, driving each knee up towards hip height.', 'Pump your arms and stay light on the balls of your feet.'],
      tips: ['Keep your chest up and your core tight.', 'Start with 20 seconds on, 40 seconds rest.'] },
    { id: 'mountain-climber', name: 'Mountain Climbers', cat: 'cardio', muscles: ['Core', 'Shoulders', 'Hip flexors', 'Quads'], equip: 'Bodyweight', level: 'Intermediate', sets: '4 × 30 sec',
      hl: 'leg', equip_draw: 'none',
      poses: [{ t: -22, ua: 90, fa: 90, th: 154, sh: 154, th2: 62, sh2: 162, ft: 120, anchor: hand(172, F - 3) }, { t: -22, ua: 90, fa: 90, th: 62, sh: 162, th2: 154, sh2: 154, ft: 120, anchor: hand(172, F - 3) }],
      steps: ['Start in a straight-arm plank with your hands under your shoulders.', 'Drive one knee towards your chest, then quickly switch legs as if running on the floor.', 'Keep your hips low and your back flat.'],
      tips: ['Slow it down first to keep good form.', 'Do not let your hips pike up.'] },
    { id: 'jump-squat', name: 'Jump Squat', cat: 'cardio', muscles: ['Quads', 'Glutes', 'Calves', 'Core'], equip: 'Bodyweight', level: 'Intermediate', sets: '4 × 10–15',
      hl: 'leg', equip_draw: 'none',
      poses: [{ t: -55, th: 8, sh: 112, ua: 40, fa: 20, anchor: foot(120) }, { t: -90, th: 90, sh: 90, ua: -40, fa: -50, ft: 60, anchor: foot(120, F - 30) }],
      steps: ['Stand with your feet shoulder-width apart and squat down with your arms back.', 'Explode upwards, swinging your arms and jumping off the floor.', 'Land softly on bent knees and go straight into the next rep.'],
      tips: ['Land quietly, like a cat.', 'Skip this exercise if your knees hurt; use normal squats.'] },
    { id: 'kettlebell-swing', name: 'Kettlebell Swing', cat: 'cardio', muscles: ['Glutes', 'Hamstrings', 'Lower back', 'Shoulders', 'Core'], equip: 'Kettlebell', level: 'Intermediate', sets: '4 × 15',
      hl: 'leg', equip_draw: 'db',
      poses: [{ t: -28, th: 70, sh: 95, ua: 105, fa: 105, anchor: foot(120) }, P(STAND, { ua: 0, fa: 0 })],
      steps: ['Stand with your feet a little wider than your hips and the kettlebell on the floor in front of you. Hinge and grab it with both hands.', 'Hike the bell back between your legs, then snap your hips forward to swing it up to chest height.', 'Let the bell fall back and hinge again, keeping your back flat.'],
      tips: ['The power comes from your hips, not your arms.', 'Start with a light weight and learn the hinge first.'] },
    { id: 'jump-rope', name: 'Jump Rope', cat: 'cardio', muscles: ['Calves', 'Shoulders', 'Core', 'Heart and lungs'], equip: 'Skipping rope', level: 'Beginner', sets: '5 × 1 minute',
      hl: 'leg', equip_draw: 'none', props: [[100, F - 4, 140, F - 4, 3]],
      poses: [{ t: -90, th: 90, sh: 90, ua: 70, fa: 20, ft: 30, anchor: foot(120) }, { t: -90, th: 95, sh: 105, ua: 70, fa: 20, ft: 60, anchor: foot(120, F - 16) }],
      steps: ['Hold the rope handles at hip height with your elbows close to your sides.', 'Turn the rope with your wrists and hop over it on the balls of your feet.', 'Keep your jumps small and your rhythm steady.'],
      tips: ['A rope that reaches your armpits when you stand on it is the right length.', 'Land softly and keep your knees slightly bent.'] },
    { id: 'treadmill-run', name: 'Treadmill Run', cat: 'cardio', muscles: ['Quads', 'Hamstrings', 'Calves', 'Heart and lungs'], equip: 'Treadmill', level: 'Beginner', sets: '20–30 minutes',
      hl: 'leg', equip_draw: 'none', props: [[40, F - 5, 200, F - 5, 8], [190, F - 5, 196, 70, 5]],
      poses: [{ t: -80, th: 60, sh: 100, th2: -10, sh2: 95, ua: 40, fa: -80, ua2: 130, fa2: -20, ft: 45, anchor: hip(112, 112) }, { t: -80, th: -10, sh: 95, th2: 60, sh2: 100, ua: 130, fa: -20, ua2: 40, fa2: -80, ft: 45, anchor: hip(112, 112) }],
      steps: ['Start with a 3–5 minute walk to warm up.', 'Raise the speed to a comfortable jog you can keep for the whole session.', 'Finish with a slow walk for 3–5 minutes.'],
      tips: ['Do not hold the handrails while running.', 'Set a 1% incline to feel more like running outdoors.'] }

  ];
  EXERCISES.forEach(function (e) { e.equip_draw = e.equip_draw || 'none'; e.equip_label = e.equip; e.equip = e.equip_draw; });

  // Rough effect numbers per exercise: [MET, muscle-building 1-5, fat-burning 1-5].
  // MET values follow the common Compendium of Physical Activities (rounded). Calories = MET x body weight (kg) x hours.
  var EFFECT = {
    'bench-press': [5.0, 5, 2], 'push-up': [4.0, 3, 2], 'incline-press': [5.0, 4, 2], 'pullover': [3.5, 3, 1],
    'overhead-press': [5.0, 4, 2], 'lateral-raise': [3.0, 3, 1], 'front-raise': [3.0, 2, 1],
    'barbell-curl': [3.5, 3, 1], 'hammer-curl': [3.5, 3, 1], 'concentration-curl': [3.0, 3, 1],
    'pushdown': [3.5, 3, 1], 'overhead-extension': [3.5, 3, 1], 'bench-dips': [4.0, 3, 2], 'skull-crusher': [3.5, 3, 1],
    'squat': [6.0, 5, 4], 'lunge': [5.0, 4, 3], 'leg-press': [5.0, 4, 3], 'rdl': [5.5, 4, 3], 'calf-raise': [3.0, 2, 1],
    'pull-up': [6.0, 5, 3], 'bent-row': [5.0, 4, 2], 'crunch': [3.0, 2, 1], 'plank': [3.3, 2, 1], 'leg-raise': [3.5, 2, 1],
    'dumbbell-fly': [3.5, 3, 1], 'incline-pushup': [3.8, 2, 2], 'upright-row': [4.0, 3, 2], 'rear-delt-fly': [3.0, 3, 1],
    'cable-curl': [3.5, 3, 1], 'triceps-kickback': [3.0, 3, 1], 'deadlift': [6.0, 5, 4], 'glute-bridge': [3.5, 3, 2],
    'goblet-squat': [5.0, 4, 3], 'leg-extension': [3.5, 3, 1], 'lat-pulldown': [4.5, 4, 2], 'seated-row': [4.5, 4, 2],
    'hanging-leg-raise': [4.0, 3, 2], 'sit-up': [3.8, 2, 2], 'high-knees': [8.0, 2, 5], 'mountain-climber': [8.0, 3, 5],
    'jump-squat': [8.0, 3, 5], 'kettlebell-swing': [9.8, 4, 5], 'jump-rope': [11.0, 2, 5], 'treadmill-run': [9.0, 2, 5]
  };
  EXERCISES.forEach(function (e) { var f = EFFECT[e.id] || [4, 3, 2]; e.met = f[0]; e.muscle = f[1]; e.fat = f[2]; });
  // Estimated burn for a person of kg body weight doing the exercise for minutes. Fat is the energy equivalent
  // (about 7.7 kcal per gram of body fat), only true if the rest of the day is also in a calorie deficit.
  function burn(ex, kg, minutes) {
    kg = Number(kg); minutes = Number(minutes);
    if (!(kg >= 20 && kg <= 300) || !(minutes > 0 && minutes <= 300)) return { kcal: 0, fat_g: 0 };
    var kcal = ex.met * kg * minutes / 60;
    return { kcal: Math.round(kcal), fat_g: Math.round(kcal / 7.7 * 10) / 10 };
  }

  var PLANS = [
    { id: 'beginner', name: 'Beginner Full Body', blurb: '3 days a week (for example Mon / Wed / Fri). Rest a day between sessions.',
      days: [
        { name: 'Day 1 – Full Body A', items: [['squat', '3 × 10'], ['bench-press', '3 × 10'], ['bent-row', '3 × 10'], ['overhead-press', '2 × 10'], ['plank', '3 × 30 sec']] },
        { name: 'Day 2 – Full Body B', items: [['rdl', '3 × 10'], ['push-up', '3 × 8–12'], ['bent-row', '3 × 10'], ['barbell-curl', '2 × 12'], ['pushdown', '2 × 12'], ['crunch', '3 × 15']] },
        { name: 'Day 3 – Full Body C', items: [['lunge', '3 × 10 each'], ['incline-press', '3 × 10'], ['lateral-raise', '3 × 12'], ['hammer-curl', '2 × 12'], ['bench-dips', '2 × 10'], ['leg-raise', '3 × 10']] }
      ] },
    { id: 'split5', name: '5-Day Body-Part Split', blurb: 'Monday to Friday, one focus per day. Weekend rest.',
      days: [
        { name: 'Mon – Chest', items: [['bench-press', '4 × 8'], ['incline-press', '3 × 10'], ['pullover', '3 × 12'], ['push-up', '2 × max']] },
        { name: 'Tue – Back & Biceps', items: [['pull-up', '4 × max'], ['bent-row', '4 × 8'], ['barbell-curl', '3 × 10'], ['hammer-curl', '3 × 12']] },
        { name: 'Wed – Shoulders & Abs', items: [['overhead-press', '4 × 8'], ['lateral-raise', '3 × 12'], ['front-raise', '3 × 12'], ['crunch', '3 × 15'], ['leg-raise', '3 × 12']] },
        { name: 'Thu – Arms', items: [['barbell-curl', '3 × 10'], ['concentration-curl', '3 × 12'], ['pushdown', '3 × 12'], ['skull-crusher', '3 × 10'], ['overhead-extension', '3 × 12']] },
        { name: 'Fri – Legs', items: [['squat', '4 × 8'], ['leg-press', '3 × 12'], ['rdl', '3 × 10'], ['lunge', '3 × 10 each'], ['calf-raise', '4 × 15']] }
      ] },
    { id: 'ppl', name: 'Push / Pull / Legs', blurb: 'Three different sessions. Run them in a loop: Push, Pull, Legs, rest (or twice a week if you recover well).',
      days: [
        { name: 'Push', items: [['bench-press', '4 × 8'], ['overhead-press', '3 × 8'], ['incline-press', '3 × 10'], ['lateral-raise', '3 × 12'], ['pushdown', '3 × 12'], ['bench-dips', '2 × 10']] },
        { name: 'Pull', items: [['pull-up', '4 × max'], ['bent-row', '4 × 8'], ['barbell-curl', '3 × 10'], ['hammer-curl', '3 × 12'], ['concentration-curl', '2 × 12']] },
        { name: 'Legs', items: [['squat', '4 × 8'], ['rdl', '3 × 10'], ['leg-press', '3 × 12'], ['lunge', '3 × 10 each'], ['calf-raise', '4 × 15'], ['plank', '3 × 45 sec']] }
      ] }
  ];

  var FAQ = [
    { q: 'How does QR attendance work?', a: 'Open Check-in. The app asks whether you are the owner or a member. The owner picks “Owner” and shows the gym QR (it changes every 5 minutes). A member picks “Member”, scans that QR with the camera, and the phone shows a check-in pass. The owner then opens Owner → Scan and scans the member’s pass. The visit and exact time are saved, once per member per day.' },
    { q: 'Why does a member need to link a phone number?', a: 'The first time a member opens Check-in as a member, they enter the mobile number they gave the gym. It is saved only on their phone and goes inside their pass so the owner can find them. A wrong number shows “Member not found” at the desk.' },
    { q: 'The gym QR or pass says it is old. What now?', a: 'The gym QR changes every 5 minutes and a member pass works for about 15 minutes. Ask the owner to show the current QR (Owner → Show QR) and scan it again. You can also type the 8-character code shown under the QR.' },
    { q: 'A QR will not scan. What now?', a: 'Increase the phone brightness, hold the QR steady about 20–30 cm from the camera, and clean the lens. A member can type the code under the gym QR instead, and the owner can use Check-in → Owner → Manual and search by name or phone.' },
    { q: 'What if a member’s membership has expired?', a: 'The owner’s scan shows “Membership expired” and the visit is not saved. You can renew first (Payments → tick “Renew membership”) or choose “Check in anyway” if you want to allow the visit.' },
    { q: 'How do I take a UPI payment from a member?', a: 'Save the gym’s UPI ID once (More → Payments or Settings). Then open Payments, pick the member and amount, choose UPI QR and tap “Show payment QR for the member”. The member scans it with their own UPI app. When the money arrives, tap “Member has paid — record payment”. Members can also pay themselves from their own login under More → My Payments.' },
    { q: 'Does the app confirm that the UPI payment went through?', a: 'No. UPI apps do not send the result back to a web-style app, so you must check the success screen / your bank SMS yourself and then tap “Yes, record payment”. Add the UPI reference number so you can match it later.' },
    { q: 'How do I sell products like protein or gloves?', a: 'Open More → Products. Browse or search the 81 sample items, tap Add, then open the Cart tab. Choose the buyer (a member or walk-in), pick Google Pay / UPI, Cash or Card, and record the sale. Sales show in the Sales tab and are kept apart from membership fees.' },
    { q: 'Can I change product names and prices?', a: 'The 81 products are sample data stored in the app file products.js (name, price, size, colour and description). Edit that list and build the APK again to match what your gym really sells. A product screen to edit items inside the app can be added later.' },
    { q: 'How do Goals work?', a: 'Open More → Goals → New goal. Name it, choose how many days (1 to 365, any number), and start. Each day tap “Mark today as done”. The app shows percent complete, current and best streak, missed days and days left. You can tap a past day in the grid to fix it. Goals are saved on your own phone.' },
    { q: 'How do I hire a trainer?', a: 'Open More → Trainers, pick a trainer, tap Hire, then choose a package (trial, 1 month or 3 months), a time slot and start date. Pay now with Google Pay / UPI or choose “Pay at gym desk”. After booking, send the request to the gym by SMS or WhatsApp so the gym knows. Your bookings are listed under My bookings.' },
    { q: 'How do diet plans and meal reminders work?', a: 'Open More → Diet, choose Vegetarian or Non-veg, pick a plan with 4 meals a day and tap Start. The app sets a notification on your phone for each meal time, every day, even when the app is closed. You can change any meal time, tick meals as eaten, send a test reminder, or stop the plan.' },
    { q: 'Do reminders come as SMS?', a: 'No. They are phone notifications created by the app itself, so they work without internet and cost nothing. Real SMS needs a paid SMS service and a server. If reminders do not appear, allow Notifications for GYM Flow in phone settings and allow “Alarms & reminders”, and turn off battery saving for the app.' },
    { q: 'How many calories does an exercise burn?', a: 'Open Workouts and tap any exercise. The “What it does for your body” box shows calories burned for 10 to 60 minutes, the matching amount of body fat as energy, and star-like ratings for fat burning and muscle building. Enter your own weight in kg to personalise it. These are estimates, not exact numbers.' },
    { q: 'Can I lose fat from one body part, like my belly?', a: 'No. Exercise cannot burn fat from one spot. Fat comes off the whole body when you burn more energy than you eat over days and weeks. Exercises with a high fat-burning rating (cardio, squats, deadlifts) burn the most energy, and strength exercises build the muscle that keeps your body strong.' },
    { q: 'What are Clubs and how do I join?', a: 'Open More → Clubs, pick a club (Fat Burners, Iron Lifters, Yoga, Women’s Power, Transformation 90 and more), read the benefits and rewards, and tap Join. Joining is free. You get welcome points, then 10 points for every gym check-in, and you unlock rewards like a free shaker, product discounts or a free training session as your visits grow.' },
    { q: 'Why do my club visits show a dash?', a: 'Visits are counted only for members registered at the gym, matched by mobile number. Join with the same number you gave the desk, or ask the owner to register you, and your check-ins will start counting.' },
    { q: 'The member’s UPI app did not open. What should I do?', a: 'Make sure a UPI app (Google Pay, PhonePe, Paytm) is installed and set up, then tap “Pay with my UPI app” again, or show the QR and scan it from another phone.' },
    { q: 'How do I renew a membership?', a: 'Open Payments, choose the member and a plan, tick “Renew membership with this plan”, and record the payment. If the old membership is still running, the new one starts the day after it ends.' },
    { q: 'Where is my data stored? Can I lose it?', a: 'Everything is stored only on this phone. If you uninstall the app or clear its data, it is gone. Use Settings → Copy backup regularly and keep the text somewhere safe.' },
    { q: 'Can two phones share the same data?', a: 'Not yet. Each phone keeps its own records. Use one phone (for example the gym desk phone) as the main device. Syncing between phones needs an online database, which can be added later.' },
    { q: 'Which workout plan should a beginner start with?', a: 'The Beginner Full Body plan: three days a week, one rest day between sessions. Start with light weights, learn the movement, and add weight slowly.' },
    { q: 'How many sets and reps should I do?', a: 'As a rule of thumb: 6–10 reps for strength, 8–12 for muscle size, 12–20 for endurance. Stop a rep or two before you cannot keep good form.' },
    { q: 'Should I warm up and stretch?', a: 'Yes. Spend 5–10 minutes on light cardio and a few light sets of your first exercise. Stretch gently after training.' },
    { q: 'I feel sharp pain during an exercise.', a: 'Stop. Muscle burn is normal; sharp or joint pain is not. Rest, and ask a trainer or doctor before continuing. The workouts in this app are general guidance, not medical advice.' },
    { q: 'Why do I not see some sections?', a: 'The app shows each person only their own sections. Owners see Members, Payments, Reports, Register, Assistant and Settings. Members see Workouts, Diet, Goals, Clubs, Products, Trainers and their Weekly Report. Check-in and FAQ are for both.' },
    { q: 'How do I sign out or switch between owner and member?', a: 'Open More and tap Sign out. Then choose Owner or Member again on the first screen.' },
    { q: 'Who becomes the owner when I sign in with Google?', a: 'The first Google account that signs in as Owner becomes the gym owner account on that phone. Other Google accounts cannot open the owner screens there. Owners can also use an owner PIN.' },
    { q: 'Where did the Assistant go?', a: 'The app now opens on the Dashboard. The Assistant is in More, first item.' },
    { q: 'How do the Dashboard daily goals work?', a: 'They tick automatically: a workout logged today, your water goal, a gym check-in, and your calorie goal. Tap + on the Water card for each 250 ml. Tap the pencil on Daily goals to change the calorie and water goals.' },
    { q: 'How do I see my weekly report?', a: 'Open More, then Member Weekly Report. It shows exercises done, calories burned, fat loss estimate and graphs for the last 7 days. Tap Generate PDF to save or share it. Workouts appear there after you tap "I did this workout" on an exercise.' },
    { q: 'How is fat loss in the weekly report worked out?', a: 'It is the energy equivalent: calories burned divided by 7700 per kg of fat. It is an estimate. For real change, add your weight in the report each week and compare.' },
    { q: 'How does the owner send an invoice on WhatsApp?', a: 'After recording a payment, tap Send invoice on WhatsApp (or the Invoice button next to any recent payment). WhatsApp opens with the invoice written for that member and you tap Send. You can also share the invoice as a PDF. Add address and GST in Settings, Invoice details.' },
    { q: 'Why do the exercise figures look like stick figures?', a: 'They are simple animated illustrations drawn inside the app, so they work offline and never need downloads. Tap a figure to pause or play it. Ask your trainer to show the exact form in person.' }
  ];

  var api = { CATEGORIES: CATEGORIES, EXERCISES: EXERCISES, PLANS: PLANS, FAQ: FAQ, EFFECT: EFFECT, burn: burn };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.GymContent = api;
})(typeof window !== 'undefined' ? window : this);
