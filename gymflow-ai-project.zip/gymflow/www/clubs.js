/* The Forge - sample gym clubs, benefits and rewards, with original drawn emblems.
   Everything is SAMPLE data. The owner edits it to match what the gym really offers.
   "members" is a sample starting number; real joins on this phone are added to it. */
(function (root) {
  'use strict';
  var WHT = '#ffffff';
  var GLYPH = {
    dumbbell: '<rect x="18" y="48" width="10" height="24" rx="3" fill="#fff"/><rect x="28" y="40" width="10" height="40" rx="3" fill="#fff"/><rect x="38" y="56" width="44" height="8" rx="3" fill="#fff"/><rect x="82" y="40" width="10" height="40" rx="3" fill="#fff"/><rect x="92" y="48" width="10" height="24" rx="3" fill="#fff"/>',
    flame: '<path d="M60 18c6 16 26 24 26 46a26 26 0 0 1-52 0c0-14 8-20 14-30 2 10 6 12 9 10-5-12-3-18 3-26z" fill="#fff"/>',
    sun: '<circle cx="60" cy="60" r="16" fill="#fff"/><g stroke="#fff" stroke-width="6" stroke-linecap="round"><path d="M60 20v10M60 90v10M20 60h10M90 60h10M32 32l7 7M81 81l7 7M88 32l-7 7M39 81l-7 7"/></g>',
    lotus: '<path d="M60 30c14 12 14 36 0 52-14-16-14-40 0-52z" fill="#fff"/><path d="M36 44c16 2 26 18 24 38-16-4-26-20-24-38zM84 44c-16 2-26 18-24 38 16-4 26-20 24-38z" fill="#fff" opacity=".8"/><rect x="34" y="86" width="52" height="6" rx="3" fill="#fff"/>',
    trophy: '<path d="M38 26h44v22a22 22 0 0 1-44 0z" fill="#fff"/><path d="M38 32H24q0 20 16 22M82 32h14q0 20-16 22" fill="none" stroke="#fff" stroke-width="6"/><rect x="54" y="68" width="12" height="14" fill="#fff"/><rect x="40" y="82" width="40" height="9" rx="3" fill="#fff"/>',
    heart: '<path d="M60 90C24 66 28 34 48 34c8 0 12 5 12 9 0-4 4-9 12-9 20 0 24 32-12 56z" fill="#fff"/>',
    mountain: '<path d="M14 90l34-52 22 32 12-16 26 36z" fill="#fff"/><circle cx="84" cy="34" r="8" fill="#fff" opacity=".8"/>',
    kettlebell: '<path d="M44 48q-2-24 16-24t16 24" fill="none" stroke="#fff" stroke-width="9" stroke-linecap="round"/><circle cx="60" cy="68" r="26" fill="#fff"/>',
    crown: '<path d="M22 84l-4-44 24 20 18-30 18 30 24-20-4 44z" fill="#fff"/>',
    bolt: '<path d="M68 14L30 66h24l-8 40 44-56H66z" fill="#fff"/>',
    people: '<circle cx="60" cy="42" r="12" fill="#fff"/><path d="M36 92q0-28 24-28t24 28z" fill="#fff"/><circle cx="30" cy="52" r="9" fill="#fff" opacity=".75"/><path d="M12 92q0-20 18-20 6 0 10 3-8 6-10 17z" fill="#fff" opacity=".75"/><circle cx="90" cy="52" r="9" fill="#fff" opacity=".75"/><path d="M108 92q0-20-18-20-6 0-10 3 8 6 10 17z" fill="#fff" opacity=".75"/>',
    cap: '<path d="M60 26l48 24-48 24-48-24z" fill="#fff"/><path d="M34 62v16q26 16 52 0V62l-26 13z" fill="#fff" opacity=".85"/><rect x="100" y="52" width="5" height="26" fill="#fff"/>',
    star: '<path d="M60 16l13 29 31 3-23 21 7 31-28-17-28 17 7-31-23-21 31-3z" fill="#fff"/>',
    shoe: '<path d="M16 76q0-10 10-14l16-6 12-16 10 6q8 12 24 18l10 4q8 4 8 12v6H16z" fill="#fff"/><rect x="16" y="86" width="88" height="8" rx="3" fill="#fff" opacity=".75"/>'
  };
  function emblem(club, size) {
    var c = club.color;
    return '<svg viewBox="0 0 120 120" ' + (size ? 'width="' + size + '" height="' + size + '" ' : 'width="100%" ') + 'role="img" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">' +
      '<circle cx="60" cy="60" r="58" fill="' + c + '"/><circle cx="60" cy="60" r="52" fill="none" stroke="' + WHT + '" stroke-width="2" opacity=".5"/>' +
      '<g transform="translate(60 60) scale(.72) translate(-60 -60)">' + (GLYPH[club.glyph] || GLYPH.star) + '</g></svg>';
  }
  function T(name, visits, reward) { return { name: name, visits: visits, reward: reward }; }
  function C(id, name, tagline, glyph, color, members, level, schedule, about, perks, tiers, welcome, challenge) {
    return { id: id, name: name, tagline: tagline, glyph: glyph, color: color, members: members, level: level, schedule: schedule, about: about, perks: perks, tiers: tiers, welcome: welcome, challenge: challenge || null };
  }
  var CLUBS = [
    C('iron', 'Iron Lifters Club', 'Lift heavier, lift safer', 'dumbbell', '#1f2933', 112, 'All levels', 'Sat 7:00 am · Lifting workshop',
      'A club for people who love weights. Learn proper form, follow progressive plans and cheer each other on at the squat rack.',
      ['Free monthly form-check with a trainer', 'Saturday lifting workshops (squat, bench, deadlift)', 'Priority use of power racks at off-peak hours', 'Club leaderboard for personal records'],
      [T('Bronze', 0, 'Club badge and welcome pack'), T('Silver', 12, 'Free shaker bottle'), T('Gold', 36, '10% off protein products'), T('Platinum', 72, '1 free personal-training session')], 100,
      { title: 'Add weight to my main lifts', days: 30 }),
    C('burn', 'Fat Burners Club', 'Burn fat, keep it off', 'flame', '#c2410c', 164, 'Beginner friendly', 'Mon · Wed · Fri 6:30 pm · HIIT circuit',
      'Group HIIT, cardio challenges and healthy-eating support for members whose main goal is losing body fat.',
      ['Free monthly weigh-in and body check by the trainers', 'Weekly group HIIT circuit', 'Healthy-eating tips and diet plan help', 'Monthly “biggest improvement” shout-out'],
      [T('Starter', 0, 'Club badge'), T('Silver', 12, 'Free skipping rope'), T('Gold', 36, 'Free diet consultation'), T('Platinum', 72, 'Free month of group classes')], 100,
      { title: 'Burn fat for 30 days', days: 30 }),
    C('sunrise', 'Sunrise Runners Club', 'Start the day on the move', 'sun', '#d97706', 78, 'All levels', 'Daily 5:30 am · Group run / treadmill hour',
      'Early-bird runners and walkers who start the day together. Outdoor group runs on weekends, treadmill sessions on weekdays.',
      ['Group runs every Sunday morning', 'Pace partners for beginners', 'Free electrolyte drink after the Sunday run', 'Running tips from our trainers'],
      [T('Walker', 0, 'Club badge'), T('Jogger', 10, 'Free water bottle'), T('Runner', 30, 'Free headband and cap'), T('Racer', 60, '10% off running shoes')], 100,
      { title: 'Run or walk every morning', days: 21 }),
    C('yoga', 'Yoga & Mobility Circle', 'Stretch, breathe, recover', 'lotus', '#6d28d9', 96, 'All levels', 'Tue · Thu · Sat 7:00 am · Yoga session',
      'Calm group sessions for flexibility, posture and stress relief. Great along with heavy training.',
      ['Free yoga sessions twice a week', 'Mobility routine for tight hips and shoulders', 'Guided breathing and relaxation', 'Free yoga mat discount'],
      [T('Seeker', 0, 'Club badge'), T('Flow', 12, '10% off yoga products'), T('Balance', 36, 'Free yoga block set'), T('Zen', 72, '1 free private session')], 100,
      { title: 'Stretch and breathe daily', days: 21 }),
    C('cross', 'CrossFit Crew', 'Train hard together', 'bolt', '#b91c1c', 69, 'Intermediate', 'Mon · Wed · Fri 7:00 pm · WOD',
      'Workout-of-the-day style sessions with a coach, team challenges and friendly competition.',
      ['Coach-led workout of the day', 'Monthly team challenge', 'Benchmark workouts to track progress', 'Crew T-shirt after joining'],
      [T('Rookie', 0, 'Crew T-shirt'), T('Silver', 12, 'Free kettlebell session'), T('Gold', 36, '10% off clothing'), T('Platinum', 72, 'Free month of coached WODs')], 120),
    C('women', 'Women’s Power Club', 'Strong, confident, together', 'heart', '#be185d', 138, 'All levels', 'Tue · Thu 11:00 am and Sat 5:00 pm',
      'A friendly space for women to learn strength training, tone up and build confidence with a woman trainer.',
      ['Women-only group sessions with a woman trainer', 'Strength training basics workshop', 'Diet and lifestyle chat once a month', 'Free sports-bra or leggings discount'],
      [T('Starter', 0, 'Welcome pack'), T('Silver', 12, 'Free shaker bottle'), T('Gold', 36, '10% off women’s clothing'), T('Platinum', 72, '1 free personal-training session')], 100,
      { title: 'Strength training habit', days: 30 }),
    C('seniors', 'Seniors Active Club', 'Age 45+ and still going strong', 'star', '#0f766e', 54, 'Gentle', 'Mon · Wed · Fri 8:00 am · Easy training',
      'Low-impact training for balance, joint health and heart fitness, with extra help from patient trainers.',
      ['Easy-pace group sessions', 'Balance, mobility and posture work', 'Free blood-pressure check by the desk on Mondays', 'Tea and chat after Friday class'],
      [T('Member', 0, 'Club badge'), T('Silver', 12, 'Free health-tips booklet'), T('Gold', 36, 'Free 3-session trial with a trainer'), T('Platinum', 72, 'Free month of the club')], 100,
      { title: 'Move every day', days: 30 }),
    C('t90', 'Transformation 90 Club', 'Change your body in 90 days', 'mountain', '#1d4ed8', 187, 'All levels', 'Daily check-ins · Monthly progress day',
      'A 90-day challenge with a workout plan, diet plan, weekly check-ins and a big prize for the best transformation.',
      ['90-day workout and diet plan', 'Weekly check-in with a trainer', 'Before and after progress day each month', 'Prize for the best transformation'],
      [T('Challenger', 0, 'Challenge T-shirt'), T('30-day', 20, 'Free supplement sample pack'), T('60-day', 45, '10% off supplements'), T('90-day finisher', 70, 'Free protein tub (1 kg)')], 150,
      { title: 'Transformation 90', days: 90 }),
    C('body', 'Bodybuilding Elite Club', 'Build the physique', 'trophy', '#7c2d12', 58, 'Advanced', 'Mon–Sat 4:00 pm · Posing and split training',
      'For people serious about size, symmetry and competition. Split routines, posing practice and meal timing advice.',
      ['Coach-guided split routines', 'Posing practice evenings', 'Meal-timing and cutting advice', 'Entry help for local shows'],
      [T('Member', 0, 'Club tank top'), T('Silver', 15, '10% off protein'), T('Gold', 45, 'Free posing session'), T('Platinum', 90, 'Free month of club coaching')], 100),
    C('weekend', 'Weekend Warriors Club', 'Busy all week, strong at the weekend', 'kettlebell', '#4d7c0f', 121, 'All levels', 'Sat · Sun 8:00 am · Group workout',
      'For working people who can only train on weekends. Fun group workouts, games and a healthy brunch.',
      ['Fun group workouts every weekend', 'Short 45-minute full-body sessions', 'Family-friendly sessions once a month', 'Healthy brunch on the last Sunday'],
      [T('Warrior', 0, 'Club badge'), T('Silver', 8, 'Free water bottle'), T('Gold', 24, 'Free towel and wristbands'), T('Platinum', 48, '1 free personal-training session')], 100,
      { title: 'Never miss a weekend workout', days: 28 }),
    C('student', 'Student Fit Club', 'Fit on a student budget', 'cap', '#9333ea', 143, 'Beginner friendly', 'Mon–Fri 3:00 pm and 6:00 pm · Student batches',
      'Special batches for school and college students, with budget-friendly diet tips and exam-time stress relief.',
      ['Student-only batches at off-peak hours', 'Budget diet plans for hostel and home food', 'Exam-time stretching and relaxation tips', 'Student discount on membership renewal'],
      [T('Rookie', 0, 'Club badge'), T('Silver', 12, 'Free shaker bottle'), T('Gold', 36, '10% off accessories'), T('Platinum', 72, 'Free month on renewal')], 100,
      { title: 'Gym 4 days a week', days: 30 }),
    C('buddy', 'Buddy Club', 'Train with a friend, win together', 'people', '#0e7490', 99, 'All levels', 'Daily · Bring a friend any time',
      'Join with a friend, family member or colleague. Training together keeps you consistent and earns both of you rewards.',
      ['Bring a friend for a free trial day', 'Partner workouts and challenges', 'Both of you earn rewards when your buddy joins', 'Monthly “best buddies” prize'],
      [T('Buddy', 0, 'Club badge'), T('Silver', 10, 'Free buddy trial week'), T('Gold', 30, '10% off buddy membership'), T('Platinum', 60, 'Free month for one of you')], 100,
      { title: 'Train with my buddy', days: 21 })
  ];
  var api = { CLUBS: CLUBS, emblem: emblem, club: function (id) { return CLUBS.filter(function (c) { return c.id === id; })[0]; } };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.GymClubs = api;
})(typeof window !== 'undefined' ? window : globalThis);
