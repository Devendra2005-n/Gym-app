/* Paste your Google "Web application" OAuth client ID here (see GOOGLE_SIGNIN_SETUP.md).
   Supabase (online mode): the project URL and the PUBLISHABLE key are meant to be inside the app.
   Never put a secret / service_role key here. Security comes from Row Level Security on the server.
   To run fully offline on one phone (old behaviour), set supabaseUrl to ''. */
window.GYM_CONFIG = {
  googleWebClientId: '188637250350-jre1et56p9fjp30da070miljhvtllun7.apps.googleusercontent.com',
  supabaseUrl: 'https://qkedgztqvzoldgpawlyw.supabase.co',
  supabaseKey: 'sb_publishable_S4Pq2FI4T5Ej84Mv65bOlA_MmniUQC7'
};
