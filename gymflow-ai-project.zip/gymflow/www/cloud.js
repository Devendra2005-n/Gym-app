/* GYM Flow cloud layer (Supabase).
   Online mode is ON only when config.js has supabaseUrl + supabaseKey (publishable key, safe in the app).
   All money / attendance / membership changes go through server RPCs; the app never writes those tables directly.
   After every change we re-pull from the server, so the screens always show what the server really holds. */
(function () {
  'use strict';
  var cfg = window.GYM_CONFIG || {}, C = window.GymCore;
  var client = null, ctx = null, gym = null, pending = [];
  var OUTBOX = 'gymflow.outbox.v1';

  function on() { return !!(cfg.supabaseUrl && cfg.supabaseKey && window.supabase); }
  function sb() {
    if (!client) client = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseKey, { auth: { persistSession: true, autoRefreshToken: true, storage: window.localStorage } });
    return client;
  }
  function fail(e) {
    var m = String((e && (e.message || e.error_description)) || e || 'Something went wrong');
    if (/Failed to fetch|NetworkError|Load failed|network/i.test(m)) m = 'No internet. This action needs a connection.';
    var err = new Error(m); err.code = e && e.code; return err;
  }
  function rpc(name, args) {
    return sb().rpc(name, args || {}).then(function (r) { if (r.error) throw fail(r.error); return r.data; }, function (e) { throw fail(e); });
  }
  function sel(table, build) {
    var q = sb().from(table).select('*'); if (build) q = build(q);
    return q.then(function (r) { if (r.error) throw fail(r.error); return r.data || []; }, function (e) { throw fail(e); });
  }
  function hhmm(iso) {
    try { return new Date(iso).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'Asia/Kolkata' }); } catch (e) { return ''; }
  }

  // ---- mapping server rows -> the shapes the screens already use
  var map = {
    member: function (r) { return { id: r.id, gym_id: r.gym_id, name: r.full_name, phone: r.phone || '', email: r.email || '', health_notes: r.health_notes || '', created_at: r.created_at }; },
    plan: function (r) { return { id: r.id, gym_id: r.gym_id, name: r.name, duration_days: r.duration_days, price: Number(r.price), active: r.is_active !== false }; },
    ms: function (r) { return { id: r.id, member_id: r.member_id, gym_id: r.gym_id, plan_id: r.plan_id, start_date: r.start_date, end_date: r.end_date, status: r.status }; },
    pay: function (r) { return { id: r.id, member_id: r.member_id, membership_id: r.membership_id, gym_id: r.gym_id, amount: Number(r.amount), method: r.payment_method, paid_at: r.payment_date || String(r.created_at).slice(0, 10), ref: r.reference_no || '', note: r.notes || '', invoice_no: r.invoice_no || '' }; },
    att: function (r) { return { id: r.id, member_id: r.member_id, gym_id: r.gym_id, visit_date: r.attendance_date, check_in: hhmm(r.check_in_at), checked_out: !!r.check_out_at }; }
  };

  function pull(store) {
    var since = C.addDays(C.todayIST(), -120);
    return Promise.all([
      rpc('my_gym'),
      sel('members', function (q) { return q.order('full_name').limit(2000); }),
      sel('plans', function (q) { return q.limit(200); }),
      sel('memberships', function (q) { return q.limit(5000); }),
      sel('payments', function (q) { return q.order('created_at', { ascending: false }).limit(3000); }),
      sel('attendance', function (q) { return q.gte('attendance_date', since).order('check_in_at', { ascending: false }).limit(5000); })
    ]).then(function (a) {
      gym = a[0] || {};
      var st = store.state;
      st.members = a[1].map(map.member); st.plans = a[2].map(map.plan); st.memberships = a[3].map(map.ms);
      st.payments = a[4].map(map.pay).reverse(); st.attendance = a[5].map(map.att).reverse();
      st.settings = Object.assign({}, st.settings, { upi_id: gym.upi_id || '', payee_name: gym.payee_name || '', gym_phone: gym.phone || '', gym_address: gym.address || '', gstin: gym.gstin || '', gst_pct: gym.gst_pct == null ? 0 : Number(gym.gst_pct), invoice_footer: gym.invoice_footer == null ? '' : gym.invoice_footer });
      if (gym.name) { try { C.GYM.name = gym.name; } catch (e) { /* frozen */ } }
      store.save();
      return gym;
    });
  }

  // Link the signed-in Google account to the gym. Returns { role, member_id, status } or throws.
  function context() {
    return rpc('app_context').then(function (c) {
      if (c && c.role) { ctx = c; return c; }
      return rpc('claim_member_profile').then(function (r) {
        if (r.status === 'linked' || r.status === 'already_linked') return rpc('app_context').then(function (c2) { ctx = c2; return c2; });
        ctx = null; var e = new Error(claimText(r.status)); e.status = r.status; throw e;
      });
    });
  }
  function claimText(s) {
    return ({
      not_found: 'This Google e-mail is not registered at the gym. Ask the front desk to add you with this exact e-mail.',
      ambiguous: 'Two member records share this e-mail. Ask the owner to fix it.',
      email_not_verified: 'Your Google e-mail is not verified.',
      staff: 'This account is a staff account.'
    })[s] || 'Could not link your account (' + s + ').';
  }

  function signInWithGoogleToken(idToken, accessToken) {
    var a = { provider: 'google', token: idToken }; if (accessToken) a.access_token = accessToken;
    return sb().auth.signInWithIdToken(a).then(function (r) { if (r.error) throw fail(r.error); return r.data; }, function (e) { throw fail(e); });
  }
  function signOut() { ctx = null; gym = null; return client ? client.auth.signOut().catch(function () { /* offline */ }) : Promise.resolve(); }
  function restore() {
    if (!on()) return Promise.resolve(null);
    return sb().auth.getSession().then(function (r) { return r.data && r.data.session ? context().catch(function () { return null; }) : null; }, function () { return null; });
  }

  // ---- actions (each returns a promise; caller re-renders after the store was refreshed)
  function act(store, p) { return p.then(function (res) { return pull(store).then(function () { return res; }); }); }
  var A = {
    register: function (store, d) {
      return act(store, rpc('register_member', { p_name: d.name, p_phone: d.phone, p_email: d.email || null, p_plan_id: d.plan_id || null, p_collect: !!d.collect, p_method: d.method || 'cash', p_reference: d.ref || null }));
    },
    pay: function (store, d) {
      if (d.renew && d.plan) return act(store, rpc('renew_membership', { p_member_id: d.member_id, p_plan_id: d.plan, p_method: d.method, p_amount: d.amount, p_start: null, p_reference: d.ref || null, p_notes: d.note || null }));
      return act(store, rpc('record_payment', { p_member_id: d.member_id, p_amount: d.amount, p_method: d.method, p_membership_id: null, p_reference: d.ref || null, p_notes: d.note || null }));
    },
    checkIn: function (store, id, force) { return act(store, rpc('check_in', { p_member_id: id, p_force: !!force, p_source: 'manual' })); },
    gymCode: function () { return rpc('gym_checkin_code'); },
    selfCheckIn: function (store, code) { return act(store, rpc('self_check_in', { p_code: String(code || '').trim().toUpperCase() })); },
    checkOut: function (store, attId) { return act(store, rpc('check_out', { p_attendance_id: attId })); },
    saveGym: function (store, f) {
      var upd = {}; ['upi_id', 'payee_name', 'gstin', 'gst_pct', 'invoice_footer'].forEach(function (k) { if (f[k] !== undefined) upd[k] = f[k]; });
      if (f.gym_address !== undefined) upd.address = f.gym_address;
      if (f.gym_phone !== undefined) upd.phone = f.gym_phone;
      if (ctx && ctx.gym_id) return act(store, sb().from('gyms').update(upd).eq('id', ctx.gym_id).then(function (r) { if (r.error) throw fail(r.error); return true; }, function (e) { throw fail(e); }));
      return Promise.reject(new Error('Not signed in'));
    },
    payOnline: function (planId) {
      return sb().functions.invoke('rzp-create-order', { body: { plan_id: planId } }).then(function (r) {
        if (r.error) {
          var ctxr = r.error.context;
          if (ctxr && ctxr.json) return ctxr.json().then(function (j) { throw new Error((j && j.error) || 'Could not start the payment.'); }, function () { throw fail(r.error); });
          throw fail(r.error);
        }
        return r.data;
      }, function (e) { throw fail(e); });
    },
    orderStatus: function (id) { return sel('payment_orders', function (q) { return q.eq('id', id); }).then(function (rows) { return rows[0] || null; }); },
    registerSelf: function (name, phone) { return rpc('register_self', { p_name: name, p_phone: phone }); },
    claimPayment: function (store, planId, utr) { return act(store, rpc('submit_payment_claim', { p_plan_id: planId, p_utr: utr || null })); },
    claims: function () { return sel('payment_claims', function (q) { return q.eq('status', 'pending').order('created_at', { ascending: true }).limit(200); }); },
    resolveClaim: function (store, id, ok) { return act(store, rpc('resolve_payment_claim', { p_id: id, p_approve: !!ok })); },
    setMembershipStatus: function (store, id, status) { return act(store, rpc('set_membership_status', { p_id: id, p_status: status })); }
  };

  // ---- member tracking data (workouts / weight / goals) with an offline outbox
  function box() { try { return JSON.parse(window.localStorage.getItem(OUTBOX)) || []; } catch (e) { return []; } }
  function boxSave(b) { try { window.localStorage.setItem(OUTBOX, JSON.stringify(b.slice(-500))); } catch (e) { /* full */ } }
  function queue(item) { if (!on() || !ctx || !ctx.member_id) return; var b = box(); b.push(item); boxSave(b); flush(); }
  function sendOne(it) {
    var base = { member_id: ctx.member_id, gym_id: ctx.gym_id };
    if (it.t === 'workout') return sb().from('workout_logs').upsert(Object.assign({ client_id: it.id, exercise: it.name, minutes: it.minutes, kcal: it.kcal, logged_at: it.at }, base), { onConflict: 'member_id,client_id', ignoreDuplicates: true });
    if (it.t === 'weight') return sb().from('weight_logs').delete().eq('member_id', ctx.member_id).eq('logged_on', it.date).then(function (d) { if (d.error) return d; return sb().from('weight_logs').insert(Object.assign({ weight_kg: it.kg, logged_on: it.date }, base)); });
    if (it.t === 'water') return sb().from('water_logs').insert(Object.assign({ ml: it.ml, logged_at: it.at }, base));
    if (it.t === 'goals') return sb().from('member_goals').upsert(Object.assign({ calories_goal: it.kcal, water_ml: it.ml }, base), { onConflict: 'member_id' });
    return Promise.resolve({ error: null });
  }
  var flushing = false;
  // Sends queued items in order. Stops (keeps the rest) when offline; drops items the server rejects.
  function flush() {
    if (flushing || !on() || !ctx || !ctx.member_id) return Promise.resolve();
    flushing = true;
    var b = box(), keep = [], stop = false;
    function next(i) {
      if (i >= b.length) return Promise.resolve();
      if (stop) { keep.push(b[i]); return next(i + 1); }
      return Promise.resolve(sendOne(b[i])).then(function (r) {
        if (r && r.error && /fetch|network|JWT|expired/i.test(r.error.message || '')) { stop = true; keep.push(b[i]); }
        return next(i + 1);
      }, function () { stop = true; keep.push(b[i]); return next(i + 1); });
    }
    return next(0).then(function () { boxSave(keep); flushing = false; }, function () { flushing = false; });
  }
  var T = {
    workout: function (l) { queue({ t: 'workout', id: l.id, name: l.name, minutes: l.minutes, kcal: l.kcal, at: (l.date || C.todayIST()) + 'T12:00:00+05:30' }); },
    weight: function (w) { queue({ t: 'weight', kg: w.kg, date: w.date }); },
    water: function (ml) { queue({ t: 'water', ml: ml, at: new Date().toISOString() }); },
    goals: function (g) { queue({ t: 'goals', kcal: g.goal_kcal, ml: g.goal_ml }); }
  };

  function setCtx(c) { ctx = c || null; }
  window.GymCloud = {
    setCtx: setCtx,
    on: on, client: sb, rpc: rpc, pull: pull, context: context, restore: restore, signInWithGoogleToken: signInWithGoogleToken, signOut: signOut,
    A: A, T: T, flush: flush, claimText: claimText,
    ctx: function () { return ctx; }, gym: function () { return gym; },
    isStaff: function () { return !!(ctx && ctx.role && ctx.role !== 'member'); },
    _map: map, _hhmm: hhmm
  };
})();
