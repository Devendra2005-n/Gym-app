(function () {
  'use strict';
  var C = window.GymCore, K = window.GymContent, A = window.GymAnim;
  var store = new C.Store(window.localStorage);
  var bot = new C.Assistant(store);
  var view = document.getElementById('view');
  var tabsEl = document.getElementById('tabs');
  var sheet = document.getElementById('sheet');
  var sheetBg = document.getElementById('sheetBg');
  var jsQRfn = window.jsQR && (window.jsQR.default || window.jsQR);
  var current = 'dashboard';
  var activeAnim = null;
  var chatLog = [{ me: false, text: 'Hi! I’m your gym assistant for ' + C.GYM.name + '. Ask me about members, memberships, payments, revenue, expiries or attendance. I’m read-only.' }];
  var reportTab = 'revenue';
  var reportState = { from: '', to: '', days: 7, mode: 'soon', member: '' };
  var wk = { mode: 'ex', cat: 'all', q: '', plan: 'beginner' };
  var pay = { q: '', member: '', plan: '', amount: '', method: 'upi', renew: false, note: '', pending: null, showQr: false, lastId: '' };

  var rp = { off: 0 };
  var SUBPAGES = { assistant: 1, reports: 1, register: 1, payments: 1, products: 1, goals: 1, report: 1, trainers: 1, diet: 1, clubs: 1, faq: 1, settings: 1 };

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function badge(status, text) { return '<span class="badge ' + esc(status) + '">' + esc(text || status) + '</span>'; }
  function back() { return '<button class="back" data-go="more">‹ More</button>'; }
  function sortedMembers() { return store.state.members.slice().sort(function (a, b) { return a.name.localeCompare(b.name); }); }

  document.getElementById('gymName').textContent = C.GYM.name;
  document.getElementById('todayPill').textContent = C.fmtDate(store.today());

  // ---------- QR image (always black on white so any scanner can read it) ----------
  function qrSvg(text) {
    var q = window.qrcode(0, 'M'); q.addData(text); q.make();
    var n = q.getModuleCount(), m = 4, d = '';
    for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (q.isDark(r, c)) d += 'M' + (c + m) + ' ' + (r + m) + 'h1v1h-1z';
    var s = n + m * 2;
    return '<svg class="qr" viewBox="0 0 ' + s + ' ' + s + '" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><rect width="' + s + '" height="' + s + '" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>';
  }

  // ---------- navigation ----------
  tabsEl.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-tab]'); if (!b) return;
    go(b.getAttribute('data-tab'));
  });
  document.addEventListener('click', function (e) {
    var g = e.target.closest('[data-go]');
    if (g && !g.closest('.tabs')) go(g.getAttribute('data-go'));
  });
  var SCREENS = {
    dashboard: function () { renderDashboard(); }, assistant: function () { renderAssistant(); }, members: function () { renderMembers(); }, attendance: function () { renderAttendance(); },
    workouts: function () { renderWorkouts(); }, more: function () { renderMore(); }, reports: function () { renderReports(); },
    register: function () { renderRegister(); }, payments: function () { renderPayments(); }, products: function () { renderProducts(); }, goals: function () { renderGoals(); }, report: function () { renderReport(); }, trainers: function () { renderTrainers(); }, diet: function () { renderDiet(); }, clubs: function () { renderClubs(); }, faq: function () { renderFaq(); }, settings: function () { renderSettings(); }
  };
  function go(tab) {
    stopScan(); stopTimers(); stopAnim(); closeSheet();
    if (tab === 'attendance') attRole = null;   // always ask owner or member when Check-in is opened
    if (tab === 'goals') goalUi.mode = 'list';
    if (tab === 'report') rp.off = 0;
    if (tab === 'trainers') { tr.mode = 'list'; tr.pending = null; }
    if (tab === 'diet') dt.mode = 'home';
    if (tab === 'clubs') { ck.mode = 'list'; ck.welcome = false; }
    current = tab;
    var hi = SUBPAGES[tab] ? 'more' : tab;
    Array.prototype.forEach.call(tabsEl.querySelectorAll('button'), function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === hi); });
    document.body.classList.toggle('chat-open', tab === 'assistant');
    SCREENS[tab]();
    view.scrollTop = 0;
  }
  function stopAnim() { if (activeAnim) { activeAnim.stop(); activeAnim = null; } }

  // ---------- sheet ----------
  function openSheet(html) { sheet.innerHTML = html + '<button class="btn ghost" id="closeSheet">Close</button>'; sheet.hidden = false; sheetBg.hidden = false; sheet.scrollTop = 0; $('#closeSheet').onclick = closeSheet; }
  var exTimer = null;
  function closeSheet() { if (exTimer) { clearInterval(exTimer); exTimer = null; } stopAnim(); sheet.hidden = true; sheetBg.hidden = true; }
  sheetBg.addEventListener('click', closeSheet);

  // ---------- More ----------
  function renderMore() {
    var items = [['assistant', '💬', 'Assistant', 'Ask about members, payments and revenue'], ['reports', '📊', 'Reports', 'Revenue, expiry, attendance'], ['register', '➕', 'Register member', 'New member sign-up'], ['payments', '💳', 'Payments', 'Google Pay, UPI, cash, card'], ['products', '🛒', 'Products', 'Protein, accessories, clothes, shoes'], ['report', '📈', 'Member Weekly Report', 'Exercises, calories, fat loss, graphs and PDF'], ['goals', '🎯', 'Goals', 'Set a goal for any number of days and track it'], ['trainers', '🏋️', 'Trainers', 'Hire a professional trainer'], ['diet', '🥗', 'Diet', 'Veg and non-veg plans with meal reminders'], ['clubs', '🏅', 'Clubs', 'Join gym clubs and earn rewards'], ['faq', '❓', 'FAQ', 'Questions and answers'], ['settings', '⚙️', 'Settings', 'UPI ID, backup, data']];
    view.innerHTML = '<h2>More</h2><div class="list">' + items.map(function (i) {
      return '<div class="item" data-go="' + i[0] + '"><div class="row"><span><span class="mi">' + i[1] + '</span> <b>' + i[2] + '</b><div class="muted mi-s">' + i[3] + '</div></span><span class="muted">›</span></div></div>';
    }).join('') + '</div>';
  }

  // ---------- Assistant (chat) ----------
  var CHIPS = ['Revenue this month', 'Who expires in 7 days?', 'Show expired members', 'Attendance today', 'Find Patil'];
  function renderAssistant() {
    view.innerHTML = '<div class="chat">' + back() + '<div class="msgs" id="msgs"></div>' +
      '<div class="chips">' + CHIPS.map(function (c) { return '<button data-q="' + esc(c) + '">' + esc(c) + '</button>'; }).join('') + '</div>' +
      '<form class="composer" id="chatForm" autocomplete="off"><input id="chatIn" placeholder="Ask about your gym…" enterkeyhint="send"><button type="submit" aria-label="Send">&#10148;</button></form></div>';
    paintChat();
    $('#chatForm').onsubmit = function (e) { e.preventDefault(); var i = $('#chatIn'); send(i.value); i.value = ''; };
    view.querySelector('.chips').onclick = function (e) { var b = e.target.closest('button'); if (b) send(b.getAttribute('data-q')); };
  }
  function paintChat() {
    var box = $('#msgs'); if (!box) return;
    box.innerHTML = chatLog.map(function (m) { return '<div class="msg ' + (m.me ? 'me' : 'bot') + '">' + esc(m.text) + '</div>'; }).join('');
    box.scrollTop = box.scrollHeight;
  }
  function send(text) {
    text = String(text || '').trim(); if (!text) return;
    chatLog.push({ me: true, text: text });
    chatLog.push({ me: false, text: bot.ask(text) });
    paintChat();
  }

  // ---------- Members ----------
  function renderMembers() {
    view.innerHTML = '<div class="row"><h2>Members</h2><button class="btn small" data-go="register">+ New</button></div><input id="q" type="search" placeholder="Search name, phone or email" autocomplete="off">' +
      '<p class="muted" id="hint" style="margin:8px 2px"></p><div class="list" id="results"></div>';
    var q = $('#q');
    function run() {
      var term = q.value.trim();
      var rows = term ? store.searchMembers(term) : sortedMembers().slice(0, 10);
      $('#hint').textContent = term ? rows.length + ' result(s), up to 10 shown' : 'Showing the first 10 members. Type to search.';
      $('#results').innerHTML = rows.length ? rows.map(function (m) {
        var active = store.hasActive(m.id);
        return '<div class="item" data-id="' + esc(m.id) + '"><div class="row"><span class="name">' + esc(m.name) + '</span>' + badge(active ? 'active' : 'expired') + '</div><div class="muted">' + esc(m.phone) + ' · ' + esc(m.email) + '</div></div>';
      }).join('') : '<div class="empty">No members found.</div>';
    }
    q.oninput = run; run();
    $('#results').onclick = function (e) { var it = e.target.closest('.item'); if (it) showMember(it.getAttribute('data-id')); };
  }
  function showMember(id) {
    var m = store.member(id); if (!m) return;
    var ms = store.membershipLookup(id), p = store.paymentLookup(id);
    var html = '<h2>' + esc(m.name) + '</h2><div class="muted">' + esc(m.phone) + ' · ' + esc(m.email) + '</div>' +
      '<div class="row3"><button class="btn small" id="mQr">QR card</button><button class="btn small" id="mIn">Check in</button><button class="btn small" id="mPay">Payment</button></div><div id="mMsg"></div>';
    html += '<h3>Memberships</h3>' + (ms.length ? ms.map(function (x) {
      return '<div class="card"><div class="row"><b>' + esc(x.plan) + '</b>' + badge(x.status) + '</div><div class="muted">' + C.fmtDate(x.start_date) + ' → ' + C.fmtDate(x.end_date) + (x.status === 'active' ? ' · ' + x.days_left + ' days left' : '') + '</div></div>';
    }).join('') : '<div class="empty">No memberships.</div>');
    html += '<h3>Payments</h3>';
    if (p.payments.length) {
      html += '<div class="card"><div class="row"><span class="muted">Total paid</span><b>' + C.inr(p.total_paid) + '</b></div><div class="row"><span class="muted">Last payment</span><span>' + C.fmtDate(p.last_payment.paid_at) + ' · ' + C.inr(p.last_payment.amount) + '</span></div></div>';
      html += p.payments.map(function (x) { return '<div class="row card"><span>' + C.fmtDate(x.paid_at) + ' <span class="muted">' + esc(x.method) + (x.ref ? ' · ' + esc(x.ref) : '') + '</span></span><b>' + C.inr(x.amount) + '</b></div>'; }).join('');
    } else html += '<div class="empty">No payment records.</div>';
    openSheet(html);
    $('#mQr').onclick = function () { showQrCard(id); };
    $('#mPay').onclick = function () { pay.member = id; pay.q = ''; pay.pending = null; go('payments'); };
    $('#mIn').onclick = function () {
      var r = store.checkIn(id);
      if (r.code === 'expired') { $('#mMsg').innerHTML = resultCard(r) + '<button class="btn small" id="mForce">Check in anyway</button>'; $('#mForce').onclick = function () { $('#mMsg').innerHTML = resultCard(store.checkIn(id, { force: true })); }; }
      else $('#mMsg').innerHTML = resultCard(r);
    };
  }
  function showQrCard(id) {
    var m = store.member(id); if (!m) return;
    openSheet('<div class="qrcard"><h2>' + esc(m.name) + '</h2><div class="muted">' + esc(C.GYM.name) + ' member card</div>' + qrSvg(C.memberQRText(m)) +
      '<p class="muted">Show this QR at the gym desk to check in. Take a screenshot so the member can keep it on their phone.</p></div>');
  }

  // ---------- Check-in: owner shows the gym QR, members scan it ----------
  var attRole = null, ownerMode = 'show', memberMode = 'scan', timers = [];
  var scan = { stream: null, raf: 0, canvas: null, lastAt: 0, hold: 0, cb: null };
  function stopTimers() { timers.forEach(function (t) { clearInterval(t); }); timers = []; }
  function stopScan() {
    if (scan.raf) cancelAnimationFrame(scan.raf); scan.raf = 0; scan.cb = null;
    if (scan.stream) { scan.stream.getTracks().forEach(function (t) { t.stop(); }); scan.stream = null; }
  }
  function resultCard(r) {
    var n = r.member ? esc(r.member.name) : '';
    if (r.code === 'checked_in') return '<div class="res ok"><b>✓ ' + n + '</b><div>Checked in at ' + esc(r.time) + (r.expired ? ' (membership expired)' : '') + '</div></div>';
    if (r.code === 'already') return '<div class="res warn"><b>' + n + '</b><div>Already checked in today at ' + esc(r.time) + '</div></div>';
    if (r.code === 'expired') return '<div class="res bad"><b>' + n + '</b><div>Membership expired. Renew first, or check in anyway.</div></div>';
    if (r.code === 'bad_code') return '<div class="res bad"><b>' + n + '</b><div>This pass is old or the code is wrong. Ask the member to scan the gym QR again.</div></div>';
    if (r.code === 'invalid_qr') return '<div class="res bad"><b>Not a GYM Flow QR</b><div>Scan a member QR card or a member check-in pass.</div></div>';
    if (r.code === 'not_found' && r.phone) return '<div class="res bad"><b>Member not found</b><div>No member is registered with ' + esc(r.phone) + '.</div></div>';
    return '<div class="res bad"><b>Member not found</b></div>';
  }
  function renderAttendance() {
    stopScan(); stopTimers();
    if (attRole === 'owner') return ownerView();
    if (attRole === 'member') return memberView();
    view.innerHTML = '<h2>Check-in</h2><p class="muted">Who is using this phone?</p>' +
      '<button class="role" id="roleOwner"><b>I’m the owner</b><span>Show the gym QR code, scan member passes, see who came today</span></button>' +
      '<button class="role" id="roleMember"><b>I’m a member</b><span>Scan the gym QR code and check in</span></button>';
    $('#roleOwner').onclick = function () { attRole = 'owner'; ownerMode = 'show'; renderAttendance(); };
    $('#roleMember').onclick = function () { attRole = 'member'; memberMode = 'scan'; renderAttendance(); };
  }
  function roleBar() {
    return '<div class="row rolebar"><h2 style="margin:0">Check-in</h2><span><span class="tag">' + (attRole === 'owner' ? 'Owner' : 'Member') + '</span> <button class="back" id="switchRole">Switch</button></span></div>';
  }
  function bindSwitch() { $('#switchRole').onclick = function () { attRole = null; renderAttendance(); }; }

  // ----- owner -----
  function ownerView() {
    view.innerHTML = roleBar() + '<div class="seg" id="oseg">' + [['show', 'Show QR'], ['scan', 'Scan'], ['manual', 'Manual'], ['today', 'Today']].map(function (x) {
      return '<button data-m="' + x[0] + '" class="' + (ownerMode === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div><div id="abody"></div>';
    bindSwitch();
    $('#oseg').onclick = function (e) { var b = e.target.closest('button'); if (!b) return; ownerMode = b.getAttribute('data-m'); renderAttendance(); };
    var body = $('#abody');
    if (ownerMode === 'show') ownerShow(body); else if (ownerMode === 'scan') ownerScan(body); else if (ownerMode === 'manual') manualView(body); else todayView(body);
  }
  function ownerShow(body) {
    var shown = '';
    function paint() {
      var g = store.gymQR();
      if (g.code !== shown) {
        shown = g.code;
        body.innerHTML = '<div class="qrcard bigqr">' + qrSvg(g.text) + '<div class="codebig">' + g.code.slice(0, 4) + ' ' + g.code.slice(4) + '</div><div class="muted"><b id="cd"></b></div></div>' +
          '<div class="card"><b>How members check in</b><ol class="steps"><li>Member opens the app, taps <b>Check-in</b> then <b>I’m a member</b>.</li><li>They scan this QR (or type the code above).</li><li>Their phone shows a pass. Scan it from the <b>Scan</b> tab here.</li></ol><div class="muted">The code changes every 5 minutes, so a photo of this screen stops working soon.</div></div>';
      }
      var cd = $('#cd'), s = g.seconds_left;
      if (cd) cd.textContent = 'New code in ' + Math.floor(s / 60) + ':' + (s % 60 < 10 ? '0' : '') + (s % 60);
    }
    paint(); timers.push(setInterval(paint, 1000));
  }
  function ownerScan(body) {
    body.innerHTML = camMarkup('Point the camera at a member’s check-in pass or QR card. Each member can check in once a day.');
    $('#camStart').onclick = function () { startScan(onOwnerCode); };
  }
  function camMarkup(hint) {
    return '<div class="camwrap"><video id="cam" playsinline muted></video><div class="frame"></div></div>' +
      '<button class="btn" id="camStart">Start camera</button><p class="muted" id="scanMsg">' + esc(hint) + '</p><div id="scanResult"></div>';
  }
  function startScan(cb) {
    var video = $('#cam'), msg = $('#scanMsg');
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !jsQRfn) { msg.textContent = 'This device cannot open the camera here.'; return; }
    msg.textContent = 'Opening camera…';
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false }).then(function (stream) {
      scan.stream = stream; scan.cb = cb; video.srcObject = stream; return video.play();
    }).then(function () {
      $('#camStart').hidden = true; msg.textContent = 'Scanning… hold the QR inside the frame.'; scan.hold = 0; tick();
    }).catch(function () {
      stopScan(); msg.textContent = 'Could not open the camera. Allow the Camera permission for GYM Flow in your phone settings.';
    });
  }
  function tick() {
    var v = $('#cam'); if (!v || !scan.stream) return;
    var now = performance.now();
    if (v.readyState >= 2 && v.videoWidth && now - scan.lastAt > 140 && now > scan.hold) {
      scan.lastAt = now;
      var sc = Math.min(1, 520 / v.videoWidth), w = Math.round(v.videoWidth * sc), h = Math.round(v.videoHeight * sc);
      if (!scan.canvas) scan.canvas = document.createElement('canvas');
      scan.canvas.width = w; scan.canvas.height = h;
      var ctx = scan.canvas.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(v, 0, 0, w, h);
      var code = jsQRfn(ctx.getImageData(0, 0, w, h).data, w, h, { inversionAttempts: 'dontInvert' });
      if (code && code.data && scan.cb) scan.cb(code.data);
    }
    if (scan.stream) scan.raf = requestAnimationFrame(tick);
  }
  function onOwnerCode(text) {
    scan.hold = performance.now() + 2600;
    var r = store.scanCheckIn(text), box = $('#scanResult');
    try { if (navigator.vibrate) navigator.vibrate(r.ok ? 80 : [80, 60, 80]); } catch (e) { /* not supported */ }
    box.innerHTML = resultCard(r) + (r.code === 'expired' ? '<button class="btn small" id="force">Check in anyway</button>' : '');
    var f = $('#force'); if (f) f.onclick = function () { scan.hold = performance.now() + 2600; box.innerHTML = resultCard(store.checkIn(r.member.id, { force: true })); };
  }
  function manualView(body) {
    body.innerHTML = '<input id="mq" type="search" placeholder="Search name or phone" autocomplete="off"><div id="mres" style="margin-top:8px"></div><div class="list" id="mlist"></div>';
    var q = $('#mq');
    function run() {
      var term = q.value.trim(), rows = term ? store.searchMembers(term) : [];
      $('#mlist').innerHTML = term && !rows.length ? '<div class="empty">No members found.</div>' : rows.map(function (m) {
        return '<div class="item plain"><div class="row"><div><div class="name">' + esc(m.name) + '</div><div class="muted">' + esc(m.phone) + '</div></div><button class="btn small" data-in="' + esc(m.id) + '">Check in</button></div></div>';
      }).join('');
    }
    q.oninput = run; run();
    $('#mlist').onclick = function (e) {
      var b = e.target.closest('button[data-in]'); if (!b) return;
      var id = b.getAttribute('data-in'), r = store.checkIn(id), box = $('#mres');
      box.innerHTML = resultCard(r) + (r.code === 'expired' ? '<button class="btn small" id="mf">Check in anyway</button>' : '');
      var f = $('#mf'); if (f) f.onclick = function () { box.innerHTML = resultCard(store.checkIn(id, { force: true })); };
    };
  }
  function todayView(body) {
    var t = store.todayAttendance(), t0 = store.today();
    var rep = store.attendanceReport(C.addDays(t0, -30), t0), hours = rep.by_hour, max = Math.max.apply(null, hours.concat([1]));
    var cols = '';
    for (var h = 5; h <= 22; h++) cols += '<div class="col"><div class="colbar" style="height:' + Math.round(hours[h] / max * 70) + 'px"></div><span>' + (h % 3 === 0 ? h : '') + '</span></div>';
    body.innerHTML = '<div class="card"><div class="muted">Checked in today</div><div class="big">' + t.count + '</div></div>' +
      '<h3>Busiest hours (last 30 days)</h3><div class="card"><div class="cols">' + cols + '</div><div class="muted" style="text-align:center">hour of day (24h)</div></div>' +
      '<h3>Today’s check-ins</h3><div class="list">' + (t.list.length ? t.list.map(function (x) {
        return '<div class="item plain"><div class="row"><span class="name">' + esc(x.name) + '</span><b>' + esc(x.time) + '</b></div></div>'; }).join('') : '<div class="empty">No check-ins yet today.</div>') + '</div>';
  }

  // ----- member -----
  function memberView() {
    var MK = C.MemberKit, prof = MK.get(window.localStorage);
    if (!prof.phone) {
      view.innerHTML = roleBar() + '<div class="card"><b>Link your phone number</b><div class="muted">Use the number you gave the gym when you joined. This is saved only on your phone.</div>' +
        '<label>Mobile number</label><input id="mph" inputmode="tel" autocomplete="tel" placeholder="10-digit number"><button class="btn" id="mLink">Save and continue</button><div id="mErr" class="errtxt"></div></div>';
      bindSwitch();
      $('#mLink').onclick = function () {
        var r = MK.linkPhone(window.localStorage, $('#mph').value);
        if (!r.ok) { $('#mErr').textContent = r.error; return; }
        renderAttendance();
      };
      return;
    }
    view.innerHTML = roleBar() + '<div class="card row"><div><div class="muted">Your number</div><b>' + esc(prof.phone) + '</b></div><button class="btn small ghost" id="mChange">Change</button></div>' +
      '<div class="seg" id="mseg">' + [['scan', 'Scan QR'], ['history', 'History']].map(function (x) { return '<button data-m="' + x[0] + '" class="' + (memberMode === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div><div id="mbody"></div>';
    bindSwitch();
    $('#mChange').onclick = function () { var p = MK.get(window.localStorage); p.phone = ''; MK.save(window.localStorage, p); renderAttendance(); };
    $('#mseg').onclick = function (e) { var b = e.target.closest('button'); if (!b) return; memberMode = b.getAttribute('data-m'); renderAttendance(); };
    var body = $('#mbody');
    if (memberMode === 'history') memberHistory(body, prof); else memberScan(body, prof);
  }
  function memberScan(body, prof) {
    body.innerHTML = camMarkup('Scan the QR code shown on the gym owner’s phone.') +
      '<h3>Camera not working?</h3><div class="card"><label style="margin-top:0">Type the 8-character code under the QR</label><input id="mcode" placeholder="XXXX XXXX" autocapitalize="characters" autocomplete="off"><button class="btn ghost" id="mUse">Use this code</button></div>';
    $('#camStart').onclick = function () { startScan(function (text) { onGymQr(body, prof, text); }); };
    $('#mUse').onclick = function () {
      var code = C.MemberKit.normalizeCode($('#mcode').value);
      if (!code) { $('#scanResult').innerHTML = '<div class="res bad">Enter the 8 letters/numbers shown under the QR code.</div>'; return; }
      showPass(body, prof, code, C.GYM.name);
    };
  }
  function onGymQr(body, prof, text) {
    var g = C.MemberKit.parseGymQR(text, Date.now()), box = $('#scanResult');
    scan.hold = performance.now() + 1500;
    if (!g) { box.innerHTML = '<div class="res bad"><b>Not the gym QR</b><div>Scan the QR shown on the owner’s phone (Check-in → Show QR).</div></div>'; return; }
    if (!g.fresh) { box.innerHTML = '<div class="res warn"><b>This QR is old</b><div>Ask the owner to show the current QR, then scan again.</div></div>'; return; }
    try { if (navigator.vibrate) navigator.vibrate(80); } catch (e) { /* not supported */ }
    showPass(body, prof, g.code, g.gym);
  }
  function showPass(body, prof, code, gym) {
    stopScan();
    C.MemberKit.addVisit(window.localStorage, { date: C.todayIST(), time: C.timeIST(), gym: gym });
    body.innerHTML = '<div class="res ok"><b>✓ Gym QR accepted</b><div>Show this pass to the desk to finish checking in.</div></div>' +
      '<div class="qrcard bigqr">' + qrSvg(C.MemberKit.buildPass(prof.phone, code)) + '<p class="muted">The owner scans this pass from the <b>Scan</b> tab. It works for about 15 minutes. Turn the screen brightness up.</p></div>' +
      '<button class="btn ghost" id="scanAgain">Scan again</button>';
    $('#scanAgain').onclick = function () { renderAttendance(); };
  }
  function memberHistory(body, prof) {
    body.innerHTML = '<p class="muted">Check-in passes created on this phone. The gym’s own record is on the owner’s phone.</p><div class="list">' + (prof.visits.length ? prof.visits.map(function (v) {
      return '<div class="item plain"><div class="row"><span class="name">' + esc(C.fmtDate(v.date)) + '</span><b>' + esc(v.time) + '</b></div><div class="muted">' + esc(v.gym || '') + '</div></div>'; }).join('') : '<div class="empty">No check-ins yet.</div>') + '</div>';
  }

  // ---------- Workouts ----------
  function exById(id) { return K.EXERCISES.filter(function (e) { return e.id === id; })[0]; }
  function catName(id) { var c = K.CATEGORIES.filter(function (x) { return x.id === id; })[0]; return c ? c.name : id; }
  function renderWorkouts() {
    view.innerHTML = '<h2>Workouts</h2><div class="seg" id="wseg"><button data-m="ex" class="' + (wk.mode === 'ex' ? 'on' : '') + '">Exercises</button><button data-m="plans" class="' + (wk.mode === 'plans' ? 'on' : '') + '">Workout plans</button></div><div id="wbody"></div>';
    $('#wseg').onclick = function (e) { var b = e.target.closest('button'); if (b) { wk.mode = b.getAttribute('data-m'); renderWorkouts(); } };
    if (wk.mode === 'ex') exercisesView($('#wbody')); else plansView($('#wbody'));
  }
  function exercisesView(body) {
    body.innerHTML = '<div class="chips" id="cats"><button data-c="all" class="' + (wk.cat === 'all' ? 'on' : '') + '">All</button>' + K.CATEGORIES.map(function (c) {
      return '<button data-c="' + c.id + '" class="' + (wk.cat === c.id ? 'on' : '') + '">' + c.icon + ' ' + esc(c.name) + '</button>'; }).join('') + '</div>' +
      '<input id="wq" type="search" placeholder="Search exercises" value="' + esc(wk.q) + '" autocomplete="off"><p class="muted" id="wcount" style="margin:8px 2px"></p><div class="grid2" id="wgrid"></div>';
    $('#cats').onclick = function (e) { var b = e.target.closest('button'); if (b) { wk.cat = b.getAttribute('data-c'); exercisesView(body); } };
    function run() {
      var q = wk.q.toLowerCase();
      var list = K.EXERCISES.filter(function (x) {
        return (wk.cat === 'all' || x.cat === wk.cat) && (!q || (x.name + ' ' + x.muscles.join(' ') + ' ' + catName(x.cat)).toLowerCase().indexOf(q) !== -1);
      });
      $('#wcount').textContent = list.length + ' exercise(s)';
      $('#wgrid').innerHTML = list.length ? list.map(function (x) {
        return '<div class="ex" data-ex="' + x.id + '"><div class="exfig">' + A.still(x) + '</div><div class="exname">' + esc(x.name) + '</div><div class="muted">' + esc(catName(x.cat)) + ' · ' + esc(x.level) + '</div><div class="kchip">🔥 ~' + K.burn(x, bodyKg(), 10).kcal + ' kcal / 10 min</div></div>';
      }).join('') : '<div class="empty" style="grid-column:1/-1">No exercises found.</div>';
    }
    $('#wq').oninput = function (e) { wk.q = e.target.value; run(); };
    run();
    $('#wgrid').onclick = function (e) { var c = e.target.closest('.ex'); if (c) showExercise(c.getAttribute('data-ex')); };
  }
  var BODY_KEY = 'gymflow.body.v1', EFFECT_WORDS = ['Very low', 'Low', 'Medium', 'High', 'Very high'];
  function bodyKg() { var v = 70; try { var o = JSON.parse(window.localStorage.getItem(BODY_KEY)); if (o && o.kg >= 20 && o.kg <= 300) v = o.kg; } catch (e) { /* default */ } return v; }
  function setBodyKg(kg) { try { window.localStorage.setItem(BODY_KEY, JSON.stringify({ kg: kg })); } catch (e) { /* storage blocked */ } }
  function dots(n) { var o = ''; for (var i = 1; i <= 5; i++) o += '<span class="dot' + (i <= n ? ' on' : '') + '"></span>'; return '<span class="dots" aria-label="' + n + ' out of 5">' + o + '</span>'; }
  function effectPanel(x) {
    return '<h3>What it does for your body</h3><div class="card effect">' +
      '<div class="row"><label style="margin:0" for="exKg">Your weight (kg)</label><input id="exKg" type="number" inputmode="decimal" min="20" max="300" step="0.5" value="' + bodyKg() + '" style="width:90px"></div>' +
      '<div class="chips wrap" id="exMin">' + [10, 20, 30, 45, 60].map(function (m) { return '<button data-m="' + m + '" class="' + (m === 10 ? 'on' : '') + '">' + m + ' min</button>'; }).join('') + '</div>' +
      '<div class="effgrid"><div><div class="muted">Calories burned</div><div class="big" id="exKcal">–</div></div><div><div class="muted">Body fat (energy equivalent)</div><div class="big" id="exFat">–</div></div></div>' +
      '<button class="btn" id="exLog">✅ I did this workout – add to my weekly report</button><div id="exLogMsg" class="muted" style="margin:6px 0"></div>' +
      '<div class="row effrow"><span>🔥 Fat-burning effect</span><span>' + dots(x.fat) + ' <b>' + EFFECT_WORDS[x.fat - 1] + '</b></span></div>' +
      '<div class="row effrow"><span>💪 Muscle-building effect</span><span>' + dots(x.muscle) + ' <b>' + EFFECT_WORDS[x.muscle - 1] + '</b></span></div>' +
      '<p class="muted" style="margin:8px 0 0">Estimates only. Real numbers change with effort, fitness and rest. Muscle grows when you train it with enough weight, protein and sleep. Fat comes off the whole body, never from one spot, and only when your daily food is below what you burn.</p></div>';
  }
  function bindEffect(x) {
    var mins = 10;
    function upd() {
      var kg = Number($('#exKg').value), r = K.burn(x, kg, mins);
      $('#exKcal').textContent = r.kcal ? '≈ ' + r.kcal + ' kcal' : 'Enter weight'; $('#exFat').textContent = r.kcal ? '≈ ' + r.fat_g + ' g' : '–';
    }
    $('#exKg').oninput = function () { var kg = Number(this.value); if (kg >= 20 && kg <= 300) setBodyKg(kg); upd(); };
    $('#exMin').onclick = function (e) { var b = e.target.closest('button'); if (!b) return; mins = Number(b.getAttribute('data-m')); Array.prototype.forEach.call(this.children, function (c) { c.classList.toggle('on', c === b); }); upd(); };
    upd();
    $('#exLog').onclick = function () {
      var kg = Number($('#exKg').value), r = K.burn(x, kg, mins);
      if (!r.kcal) { $('#exLogMsg').textContent = 'Enter your weight first.'; return; }
      var res = C.FitKit.logWorkout(window.localStorage, { ex_id: x.id, name: x.name, minutes: mins, kcal: r.kcal }, C.todayIST());
      $('#exLogMsg').textContent = res.ok ? 'Added: ' + x.name + ', ' + mins + ' min, about ' + r.kcal + ' kcal. See it in More → Member Weekly Report.' : res.error;
    };
  }
  function fmtClock(sec) { var m = Math.floor(sec / 60), r = sec % 60; return (m < 10 ? '0' : '') + m + ':' + (r < 10 ? '0' : '') + r; }
  function bindStart(x) {
    var box = $('#exStartBox');
    $('#exStart').onclick = function () {
      var startAt = Date.now(), pausedAt = 0, pausedTotal = 0;
      box.innerHTML = '<div class="timer" id="exClock" aria-live="off">00:00</div><div class="muted" style="text-align:center">' + esc(x.name) + '</div>' +
        '<button class="btn ghost" id="exPause">Pause</button><button class="btn" id="exDone">✔ Done</button><button class="btn ghost" id="exCancel">Cancel</button><div id="exDoneMsg" class="muted" style="margin-top:6px;text-align:center"></div>';
      box.scrollIntoView({ block: 'center' });
      function elapsed() { return Math.max(0, Math.floor(((pausedAt || Date.now()) - startAt - pausedTotal) / 1000)); }
      function tick() { var c = $('#exClock'); if (c) c.textContent = fmtClock(elapsed()); }
      exTimer = setInterval(tick, 250);
      function stop() { clearInterval(exTimer); exTimer = null; }
      $('#exPause').onclick = function () {
        if (pausedAt) { pausedTotal += Date.now() - pausedAt; pausedAt = 0; this.textContent = 'Pause'; }
        else { pausedAt = Date.now(); this.textContent = 'Resume'; }
      };
      $('#exCancel').onclick = function () { stop(); box.innerHTML = '<button class="btn" id="exStart">▶ Start</button>'; bindStart(x); };
      $('#exDone').onclick = function () {
        var sec = elapsed(); stop(); tick();
        if (sec < 5) { box.innerHTML = '<div class="muted" style="text-align:center">Timer was too short to save (under 5 seconds).</div><button class="btn" id="exStart">▶ Start again</button>'; bindStart(x); return; }
        var kg = bodyKg(), min = sec / 60, r = K.burn(x, kg, min), mins = Math.max(1, Math.round(min));
        var res = C.FitKit.logWorkout(window.localStorage, { ex_id: x.id, name: x.name, minutes: mins, kcal: r.kcal }, C.todayIST());
        box.innerHTML = '<div class="timer done">' + fmtClock(sec) + '</div><div class="res ok" style="text-align:center">' + (res.ok ? '✅ Exercise complete! ' + esc(x.name) + ': ' + fmtClock(sec) + ', about ' + r.kcal + ' kcal burned (at ' + kg + ' kg). Added to your Weekly Report.' : esc(res.error)) + '</div>' +
          '<button class="btn" data-go="report">View Weekly Report</button><button class="btn ghost" id="exStart">▶ Start again</button>';
        bindStart(x);
      };
    };
  }
  function showExercise(id) {
    var x = exById(id); if (!x) return;
    openSheet('<div class="exfig big" id="exAnim"></div><p class="muted tap">Tap the figure to pause or play</p><h2 style="margin-top:6px">' + esc(x.name) + '</h2>' +
      '<div class="chipline"><span class="tag">' + esc(catName(x.cat)) + '</span><span class="tag">' + esc(x.level) + '</span><span class="tag">' + esc(x.sets) + '</span></div>' +
      effectPanel(x) +
      '<h3>Muscles worked</h3><div class="chipline">' + x.muscles.map(function (m) { return '<span class="tag hot">' + esc(m) + '</span>'; }).join('') + '</div>' +
      '<h3>Equipment</h3><p style="margin:0">' + esc(x.equip_label) + '</p>' +
      '<h3>How to do it</h3><ol class="steps">' + x.steps.map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('') + '</ol>' +
      '<h3>Tips</h3><ul class="steps">' + x.tips.map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('') + '</ul>' +
      '<p class="muted">General guidance, not medical advice. Start light and ask a trainer to check your form.</p>' +
      '<div class="card startbox" id="exStartBox"><button class="btn" id="exStart">▶ Start</button><div class="muted" style="text-align:center;margin-top:6px">Starts a timer. Tap Done when you finish and it is added to your Weekly Report.</div></div>');
    activeAnim = A.play($('#exAnim'), x);
    bindEffect(x);
    bindStart(x);
  }
  function plansView(body) {
    var plan = K.PLANS.filter(function (p) { return p.id === wk.plan; })[0] || K.PLANS[0];
    body.innerHTML = '<div class="seg" id="pseg">' + K.PLANS.map(function (p) { return '<button data-p="' + p.id + '" class="' + (plan.id === p.id ? 'on' : '') + '">' + esc(p.name.replace('Beginner Full Body', 'Beginner').replace('5-Day Body-Part Split', '5-Day Split').replace('Push / Pull / Legs', 'PPL')) + '</button>'; }).join('') + '</div>' +
      '<div class="card"><b>' + esc(plan.name) + '</b><div class="muted">' + esc(plan.blurb) + '</div></div>' +
      plan.days.map(function (d) {
        return '<h3>' + esc(d.name) + '</h3><div class="list">' + d.items.map(function (it) {
          var x = exById(it[0]); if (!x) return '';
          return '<div class="item" data-ex="' + x.id + '"><div class="row"><span class="planrow"><span class="thumb">' + A.still(x) + '</span><span><b>' + esc(x.name) + '</b><div class="muted">' + esc(catName(x.cat)) + '</div></span></span><b class="nowrap">' + esc(it[1]) + '</b></div></div>';
        }).join('') + '</div>';
      }).join('') + '<p class="muted">Tap an exercise to see the animation and how to do it. Rest 60–90 seconds between sets.</p>';
    $('#pseg').onclick = function (e) { var b = e.target.closest('button'); if (b) { wk.plan = b.getAttribute('data-p'); plansView(body); } };
    body.onclick = function (e) { var c = e.target.closest('.item[data-ex]'); if (c) showExercise(c.getAttribute('data-ex')); };
  }

  // ---------- Reports ----------
  function renderReports() {
    var t = store.today();
    if (!reportState.from) { reportState.from = C.monthStart(t); reportState.to = t; }
    view.innerHTML = back() + '<h2>Reports</h2><div class="seg" id="seg">' +
      [['revenue', 'Revenue'], ['expiry', 'Expiry'], ['attendance', 'Attendance']].map(function (x) { return '<button data-r="' + x[0] + '" class="' + (reportTab === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') +
      '</div><div id="rbody"></div>';
    $('#seg').onclick = function (e) { var b = e.target.closest('button'); if (!b) return; reportTab = b.getAttribute('data-r'); renderReports(); };
    var body = $('#rbody');
    if (reportTab === 'revenue') revenueView(body); else if (reportTab === 'expiry') expiryView(body); else attendanceView(body);
  }
  function rangeControls(withMember) {
    var h = '<div class="row"><div style="flex:1"><label>From</label><input type="date" id="rf" value="' + reportState.from + '"></div><div style="flex:1"><label>To</label><input type="date" id="rt" value="' + reportState.to + '"></div></div>';
    if (withMember) {
      h += '<label>Member</label><select id="rm"><option value="">Whole gym</option>' + sortedMembers().map(function (m) {
        return '<option value="' + esc(m.id) + '"' + (reportState.member === m.id ? ' selected' : '') + '>' + esc(m.name) + '</option>';
      }).join('') + '</select>';
    }
    return h;
  }
  function bindRange(body) {
    var f = $('#rf', body), t = $('#rt', body), m = $('#rm', body);
    function chg() { reportState.from = f.value; reportState.to = t.value; if (m) reportState.member = m.value; renderReports(); }
    f.onchange = chg; t.onchange = chg; if (m) m.onchange = chg;
  }
  function bars(items, valueKey, labelFn, fmt) {
    var max = Math.max.apply(null, items.map(function (i) { return i[valueKey]; }).concat([1]));
    return '<div class="bars">' + items.map(function (i) {
      return '<div class="b"><span class="l">' + esc(labelFn(i)) + '</span><div class="bar" style="width:' + Math.max(3, Math.round(i[valueKey] / max * 55)) + '%"></div><span class="v">' + fmt(i[valueKey]) + '</span></div>';
    }).join('') + '</div>';
  }
  function revenueView(body) {
    var r = store.revenueReport(reportState.from, reportState.to);
    body.innerHTML = rangeControls(false) +
      '<div class="card" style="margin-top:12px"><div class="muted">Total income</div><div class="big">' + C.inr(r.total) + '</div><div class="muted">' + r.count + ' payment(s)</div></div>' +
      '<h3>By payment method</h3>' + (r.by_method.length ? '<div class="card">' + bars(r.by_method, 'amount', function (i) { return i.method; }, C.inr) + '</div>' : '<div class="empty">No payments in this range.</div>') +
      '<h3>By day</h3>' + (r.by_day.length ? '<div class="card">' + bars(r.by_day, 'amount', function (i) { return C.fmtDate(i.date).slice(0, 6); }, C.inr) + '</div>' : '<div class="empty">Nothing to show.</div>');
    bindRange(body);
  }
  function expiryView(body) {
    var rows = store.expiryReport(reportState.days, reportState.mode);
    body.innerHTML = '<div class="seg" id="emode"><button data-m="soon" class="' + (reportState.mode === 'soon' ? 'on' : '') + '">Expiring soon</button><button data-m="expired" class="' + (reportState.mode === 'expired' ? 'on' : '') + '">Already expired</button></div>' +
      (reportState.mode === 'soon' ? '<label>Within next (days)</label><input type="number" id="ed" min="0" max="365" inputmode="numeric" value="' + reportState.days + '">' : '') +
      '<h3>' + rows.length + ' member(s)</h3><div class="list">' + (rows.length ? rows.map(function (r) {
        var tag = reportState.mode === 'expired' ? '<span class="badge expired">' + Math.abs(r.days_left) + 'd ago</span>' : '<span class="badge soon">' + (r.days_left === 0 ? 'today' : r.days_left + 'd left') + '</span>';
        return '<div class="item" data-id="' + esc(r.member_id) + '"><div class="row"><span class="name">' + esc(r.name) + '</span>' + tag + '</div><div class="muted">' + esc(r.plan) + ' · ends ' + C.fmtDate(r.end_date) + ' · ' + esc(r.phone) + '</div></div>';
      }).join('') : '<div class="empty">Nothing here.</div>') + '</div>';
    $('#emode', body).onclick = function (e) { var b = e.target.closest('button'); if (b) { reportState.mode = b.getAttribute('data-m'); renderReports(); } };
    var d = $('#ed', body); if (d) d.onchange = function () { reportState.days = Math.max(0, parseInt(d.value, 10) || 0); renderReports(); };
    $('.list', body).onclick = function (e) { var it = e.target.closest('.item[data-id]'); if (it) showMember(it.getAttribute('data-id')); };
  }
  function attendanceView(body) {
    var r = store.attendanceReport(reportState.from, reportState.to, reportState.member || null);
    body.innerHTML = rangeControls(true) +
      '<div class="card" style="margin-top:12px"><div class="muted">Total visits</div><div class="big">' + r.total_visits + '</div></div>' +
      (reportState.member ? '' : '<h3>By member</h3>' + (r.by_member.length ? '<div class="card">' + bars(r.by_member.slice(0, 10), 'visits', function (i) { return i.name.split(' ')[0]; }, String) + '</div>' : '<div class="empty">No visits.</div>')) +
      '<h3>By day</h3>' + (r.by_day.length ? '<div class="card">' + bars(r.by_day.slice(-14), 'visits', function (i) { return C.fmtDate(i.date).slice(0, 6); }, String) + '</div>' : '<div class="empty">No visits in this range.</div>');
    bindRange(body);
  }

  // ---------- Register ----------
  function renderRegister(result, draft) {
    draft = draft || {};
    if (result && result.ok) {
      var m = result.member, ms = result.membership;
      view.innerHTML = back() + '<div class="card result ok"><div class="icon">&#10003;</div><h2>Registration successful</h2><p class="muted">' + (result.code === 'renewed_existing' ? 'Existing member — new membership added.' : 'New member created.') + ' No payment was recorded.</p>' +
        '<div class="kv"><div><span class="muted">Name</span><b>' + esc(m.name) + '</b></div><div><span class="muted">Phone</span><b>' + esc(m.phone) + '</b></div><div><span class="muted">Plan</span><b>' + esc(result.plan.name) + '</b></div><div><span class="muted">Starts</span><b>' + C.fmtDate(ms.start_date) + '</b></div><div><span class="muted">Ends</span><b>' + C.fmtDate(ms.end_date) + '</b></div></div>' +
        '<button class="btn" id="qrBtn">Show member QR card</button><button class="btn ghost" id="payBtn">Record payment</button><button class="btn ghost" id="again">Register another member</button></div>';
      $('#again').onclick = function () { renderRegister(); };
      $('#qrBtn').onclick = function () { showQrCard(m.id); };
      $('#payBtn').onclick = function () { pay.member = m.id; pay.plan = result.plan.id; pay.amount = String(result.plan.price); pay.renew = false; pay.pending = null; go('payments'); };
      return;
    }
    var plans = store.state.plans.filter(function (p) { return p.active; });
    var err = '';
    if (result && !result.ok) {
      err = '<div class="card result bad" style="padding:14px"><b>' + (result.code === 'duplicate' ? 'Already registered' : 'Please fix the following') + '</b><ul class="errs">' + result.errors.map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></div>';
    }
    view.innerHTML = back() + '<h2>New member registration</h2>' + err +
      '<form id="regForm" novalidate><label>Full name</label><input name="name" autocomplete="name" value="' + esc(draft.name) + '">' +
      '<label>Phone (10 digits)</label><input name="phone" inputmode="tel" autocomplete="tel" value="' + esc(draft.phone) + '">' +
      '<label>Email</label><input name="email" type="email" inputmode="email" autocomplete="email" value="' + esc(draft.email) + '">' +
      '<label>Plan</label><select name="plan_id">' + plans.map(function (p) { return '<option value="' + esc(p.id) + '"' + (draft.plan_id === p.id ? ' selected' : '') + '>' + esc(p.name) + ' — ' + C.inr(p.price) + ' / ' + p.duration_days + ' days</option>'; }).join('') + '</select>' +
      '<p class="muted">Membership starts today and runs for the plan’s number of days. Gym: ' + esc(C.GYM.name) + '.</p><button class="btn" type="submit">Register member</button></form>';
    $('#regForm').onsubmit = function (e) {
      e.preventDefault();
      var f = e.target, d = { name: f.name.value, phone: f.phone.value, email: f.email.value, plan_id: f.plan_id.value };
      renderRegister(store.register(d), d);
    };
  }

  // ---------- Goals (personal multi-day goals, tracked on this phone) ----------
  var GK = C.GoalKit, goalUi = { mode: 'list', id: '' }, ng = { title: '', days: '7', note: '' };
  var GOAL_PRESETS = [1, 2, 3, 5, 7, 10, 14, 21, 30, 60, 90];
  var GOAL_IDEAS = ['Go to the gym', 'Workout 45 minutes', 'Drink 3 litres of water', 'Protein target', '10,000 steps', 'Sleep 8 hours'];
  var GOAL_BADGE = { active: ['soon', 'In progress'], achieved: ['active', 'Achieved'], ended: ['expired', 'Ended'], upcoming: ['upcoming', 'Not started'] };
  function pbar(pct) { return '<div class="pbar"><div style="width:' + pct + '%"></div></div>'; }
  function goalMsg(s, g) {
    if (s.status === 'achieved') return '🏆 Goal achieved! All ' + g.days + ' days done. Great discipline.';
    if (s.status === 'ended') return 'This goal has ended with ' + s.done + ' of ' + g.days + ' days done (' + s.percent + '%). Restart it and beat that score.';
    if (s.today_done) return '✅ Today is done. ' + (s.days_left > 1 ? (s.days_left - 1) + ' more day' + (s.days_left - 1 === 1 ? '' : 's') + ' to go.' : 'That was the last day!');
    return 'Today is day ' + s.day_no + ' of ' + g.days + '. Mark it done when you finish.';
  }
  function renderGoals(msg) {
    if (goalUi.mode === 'new') return goalNew();
    if (goalUi.mode === 'detail' && GK.get(window.localStorage, goalUi.id)) return goalDetail(msg);
    goalUi.mode = 'list';
    var today = store.today(), list = GK.list(window.localStorage).map(function (g) { return { g: g, s: GK.stats(g, today) }; });
    var open = list.filter(function (x) { return x.s.status === 'active'; }), rest = list.filter(function (x) { return x.s.status !== 'active'; });
    function card(x) {
      var b = GOAL_BADGE[x.s.status];
      return '<div class="item" data-goal="' + esc(x.g.id) + '"><div class="row"><b>' + esc(x.g.title) + '</b><span class="badge ' + b[0] + '">' + b[1] + '</span></div>' +
        '<div class="muted">' + x.g.days + '-day goal · ' + (x.s.status === 'active' ? 'Day ' + x.s.day_no + ' · ' + x.s.days_left + ' left' : fmtShort(x.g.start) + ' to ' + fmtShort(x.s.end)) + '</div>' +
        pbar(x.s.percent) + '<div class="row"><span class="muted">' + x.s.done + ' of ' + x.g.days + ' days · ' + x.s.percent + '%' + (x.s.streak ? ' · 🔥 ' + x.s.streak : '') + '</span>' +
        (x.s.status === 'active' && !x.s.today_done ? '<button class="btn small" data-tick="' + esc(x.g.id) + '">Done today</button>' : '') + '</div></div>';
    }
    view.innerHTML = back() + '<div class="row"><h2>Goals</h2><button class="btn small" id="gNew">+ New goal</button></div>' + (msg ? '<div class="res ok">' + esc(msg) + '</div>' : '') +
      (list.length ? '' : '<div class="card"><b>Set your first goal</b><div class="muted">Choose how many days you want (1 day, 3 days, 30 days… any number up to 365), then tick each day when you complete it. The app shows your progress, streak and missed days.</div></div>') +
      (open.length ? '<h3>Active</h3><div class="list">' + open.map(card).join('') + '</div>' : '') +
      (rest.length ? '<h3>Finished</h3><div class="list">' + rest.map(card).join('') + '</div>' : '');
    $('#gNew').onclick = function () { goalUi.mode = 'new'; renderGoals(); };
    var lst = view.querySelectorAll('.list');
    Array.prototype.forEach.call(lst, function (el) {
      el.onclick = function (e) {
        var t = e.target.closest('[data-tick]');
        if (t) { var r = GK.setDay(window.localStorage, t.getAttribute('data-tick'), today, true, today); renderGoals(r.ok ? 'Nice! Today is marked done.' : r.error); return; }
        var c = e.target.closest('[data-goal]'); if (c) { goalUi.mode = 'detail'; goalUi.id = c.getAttribute('data-goal'); renderGoals(); }
      };
    });
  }
  function fmtShort(d) { return C.fmtDate(d).slice(0, 6); }
  function goalNew() {
    view.innerHTML = '<button class="back" id="gBack">‹ Goals</button><h2>New goal</h2>' +
      '<label>What is your goal?</label><input id="gTitle" maxlength="60" placeholder="e.g. Go to the gym every day" value="' + esc(ng.title) + '" autocomplete="off">' +
      '<div class="chips" id="gIdeas">' + GOAL_IDEAS.map(function (i) { return '<button data-i="' + esc(i) + '">' + esc(i) + '</button>'; }).join('') + '</div>' +
      '<label>For how many days?</label><div class="chips" id="gPre">' + GOAL_PRESETS.map(function (d) { return '<button data-d="' + d + '" class="' + (String(ng.days) === String(d) ? 'on' : '') + '">' + d + (d === 1 ? ' day' : ' days') + '</button>'; }).join('') + '</div>' +
      '<label>Or type any number of days (1 to 365)</label><input id="gDays" type="number" inputmode="numeric" min="1" max="365" value="' + esc(ng.days) + '">' +
      '<label>Daily target (optional)</label><input id="gNote" maxlength="120" placeholder="e.g. 45 minutes workout + 3 L water" value="' + esc(ng.note) + '">' +
      '<button class="btn" id="gSave">Start goal today</button><div id="gErr" class="errtxt"></div>';
    $('#gBack').onclick = function () { goalUi.mode = 'list'; renderGoals(); };
    $('#gTitle').oninput = function () { ng.title = this.value; };
    $('#gNote').oninput = function () { ng.note = this.value; };
    $('#gDays').oninput = function () { ng.days = this.value; Array.prototype.forEach.call(document.querySelectorAll('#gPre button'), function (b) { b.classList.toggle('on', b.getAttribute('data-d') === String(ng.days)); }); };
    $('#gIdeas').onclick = function (e) { var b = e.target.closest('button'); if (b) { ng.title = b.getAttribute('data-i'); $('#gTitle').value = ng.title; } };
    $('#gPre').onclick = function (e) { var b = e.target.closest('button'); if (b) { ng.days = b.getAttribute('data-d'); $('#gDays').value = ng.days; Array.prototype.forEach.call(document.querySelectorAll('#gPre button'), function (x) { x.classList.toggle('on', x === b); }); } };
    $('#gSave').onclick = function () {
      var r = GK.create(window.localStorage, { title: ng.title, days: ng.days, note: ng.note }, store.today());
      if (!r.ok) { $('#gErr').textContent = r.error; return; }
      ng = { title: '', days: '7', note: '' }; goalUi.mode = 'detail'; goalUi.id = r.goal.id; renderGoals('Goal started. Day 1 is today!');
    };
  }
  function goalDetail(msg) {
    var g = GK.get(window.localStorage, goalUi.id), today = store.today(), s = GK.stats(g, today), b = GOAL_BADGE[s.status];
    var tile = function (label, val) { return '<div class="card"><div class="muted">' + label + '</div><div class="big">' + val + '</div></div>'; };
    view.innerHTML = '<button class="back" id="gBack">‹ Goals</button><div class="row"><h2 style="margin-bottom:4px">' + esc(g.title) + '</h2><span class="badge ' + b[0] + '">' + b[1] + '</span></div>' +
      '<div class="muted">' + g.days + ' days · ' + C.fmtDate(g.start) + ' to ' + C.fmtDate(s.end) + (g.note ? ' · ' + esc(g.note) : '') + '</div>' + (msg ? '<div class="res ok" style="margin-top:10px">' + esc(msg) + '</div>' : '') +
      '<div class="card" style="margin-top:12px"><div class="row"><b>Progress</b><b>' + s.percent + '%</b></div>' + pbar(s.percent) + '<div class="muted">' + s.done + ' of ' + g.days + ' days completed</div></div>' +
      '<div class="res ' + (s.status === 'ended' ? 'warn' : 'ok') + '">' + esc(goalMsg(s, g)) + '</div>' +
      (s.status === 'active' ? '<button class="btn ' + (s.today_done ? 'ghost' : '') + '" id="gToday">' + (s.today_done ? 'Undo today' : '✓ Mark today as done') + '</button>' : '') +
      '<div class="stats" style="margin-top:12px">' + tile('Current streak', '🔥 ' + s.streak) + tile('Best streak', s.best) + tile('Missed days', s.missed) + tile(s.status === 'active' ? 'Days left' : 'Days done', s.status === 'active' ? s.days_left : s.done) + '</div>' +
      '<h3>Day by day</h3><div class="daygrid" id="gGrid">' + s.cells.map(function (c) {
        var tappable = c.date <= today;
        return '<button class="day ' + c.state + (c.today ? ' now' : '') + '"' + (tappable ? ' data-date="' + c.date + '"' : ' disabled') + ' title="' + C.fmtDate(c.date) + '">' + c.n + '</button>'; }).join('') + '</div>' +
      '<div class="muted legend"><span class="day done">&nbsp;</span> done <span class="day missed">&nbsp;</span> missed <span class="day today">&nbsp;</span> today <span class="day future">&nbsp;</span> coming. Tap a past day to fix it.</div>' +
      '<button class="btn ghost" id="gRestart">Restart this goal from today</button><button class="btn danger" id="gDel">Delete goal</button>';
    $('#gBack').onclick = function () { goalUi.mode = 'list'; renderGoals(); };
    var t = $('#gToday'); if (t) t.onclick = function () { GK.setDay(window.localStorage, g.id, today, !s.today_done, today); var n = GK.stats(GK.get(window.localStorage, g.id), today); renderGoals(n.status === 'achieved' ? 'Goal achieved! 🏆' : ''); };
    $('#gGrid').onclick = function (e) { var d = e.target.closest('[data-date]'); if (!d) return; var date = d.getAttribute('data-date'); GK.setDay(window.localStorage, g.id, date, !g.done[date], today); renderGoals(); };
    $('#gRestart').onclick = function () { var r = GK.restart(window.localStorage, g.id, today); if (r.ok) { goalUi.id = r.goal.id; renderGoals('Restarted. Day 1 is today!'); } else renderGoals(r.error); };
    $('#gDel').onclick = function () { if (confirm('Delete this goal and its progress?')) { GK.remove(window.localStorage, g.id); goalUi.mode = 'list'; renderGoals('Goal deleted.'); } };
  }

  // ---------- Trainer (hire a professional trainer) ----------
  var W = window.GymWell;
  var tr = { mode: 'list', tab: 'trainers', focus: 'all', id: '', pkg: 'm1', slot: '', date: '', goal: 'Fitness', notes: '', buyer: '', customer: '', phone: '', method: 'upi', pending: null, showQr: false, last: null };
  var GOALS = ['Weight loss', 'Muscle gain', 'General fitness', 'Strength', 'Rehab / pain', 'Sports'];
  function trainerFocusTags() { var seen = {}, out = []; W.TRAINERS.forEach(function (t) { t.focus.forEach(function (f) { if (!seen[f]) { seen[f] = 1; out.push(f); } }); }); return out; }
  function pkgOf(t) { return W.packages(t).filter(function (p) { return p.id === tr.pkg; })[0] || W.packages(t)[1]; }
  function renderTrainers(msg) {
    if (tr.mode === 'detail') return trainerDetail();
    if (tr.mode === 'book') return trainerBook();
    if (tr.mode === 'done') return trainerDone();
    var h = back() + '<h2>Trainers</h2>' + (msg ? '<div class="res ok">' + esc(msg) + '</div>' : '') +
      '<div class="seg" id="tseg">' + [['trainers', 'Find a trainer'], ['bookings', 'My bookings']].map(function (x) { return '<button data-m="' + x[0] + '" class="' + (tr.tab === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div>';
    if (tr.tab === 'trainers') {
      var list = W.TRAINERS.filter(function (t) { return tr.focus === 'all' || t.focus.indexOf(tr.focus) !== -1; });
      h += '<div class="chips" id="tfocus">' + ['all'].concat(trainerFocusTags()).map(function (f) { return '<button data-f="' + esc(f) + '" class="' + (tr.focus === f ? 'on' : '') + '">' + (f === 'all' ? 'All' : esc(f)) + '</button>'; }).join('') + '</div>' +
        '<div class="list" id="tlist" style="margin-top:8px">' + list.map(function (t) {
          return '<div class="item" data-t="' + t.id + '"><div class="planrow"><div class="avatar">' + W.avatar(t.look) + '</div><div style="flex:1"><div class="name">' + esc(t.name) + '</div>' +
            '<div class="chipline">' + t.focus.map(function (f) { return '<span class="tag">' + esc(f) + '</span>'; }).join('') + '</div><div class="muted">' + t.years + ' years · ' + esc(t.langs.join(', ')) + '</div>' +
            '<div><b>From ' + C.inr(t.session) + '</b> <span class="muted">per session</span></div></div><span class="muted">›</span></div></div>'; }).join('') + '</div>' +
        '<p class="muted">Sample trainers and prices. The owner can edit them in wellness.js.</p>';
    } else {
      var bs = store.recentBookings(30);
      h += '<div class="list">' + (bs.length ? bs.map(function (b) {
        var st = b.status === 'cancelled' ? ['expired', 'Cancelled'] : b.status === 'paid' ? ['active', 'Paid'] : ['soon', 'Pay at desk'];
        return '<div class="item plain"><div class="row"><b>' + esc(b.trainer_name) + '</b><span class="badge ' + st[0] + '">' + st[1] + '</span></div><div class="muted">' + esc(b.package) + ' · ' + C.inr(b.amount) + '</div>' +
          '<div class="muted">' + esc(b.customer) + ' · ' + esc(b.phone) + '</div><div class="muted">Starts ' + C.fmtDate(b.start_date) + ' · ' + esc(b.slot) + '</div>' +
          (b.status === 'cancelled' ? '' : '<div class="row" style="margin-top:6px"><button class="back" data-sms="' + esc(b.id) + '">Send to gym</button><button class="back" data-cancel="' + esc(b.id) + '">Cancel booking</button></div>') + '</div>'; }).join('') : '<div class="empty">No bookings yet. Pick a trainer in the first tab.</div>') + '</div>';
    }
    view.innerHTML = h;
    $('#tseg').onclick = function (e) { var b = e.target.closest('button'); if (b) { tr.tab = b.getAttribute('data-m'); renderTrainers(); } };
    if ($('#tfocus')) $('#tfocus').onclick = function (e) { var b = e.target.closest('button'); if (b) { tr.focus = b.getAttribute('data-f'); renderTrainers(); } };
    if ($('#tlist')) $('#tlist').onclick = function (e) { var c = e.target.closest('[data-t]'); if (c) { tr.id = c.getAttribute('data-t'); tr.mode = 'detail'; renderTrainers(); } };
    if (tr.tab === 'bookings') view.querySelector('.list').onclick = function (e) {
      var c = e.target.closest('[data-cancel]'), s = e.target.closest('[data-sms]');
      if (c && confirm('Cancel this booking?')) { store.cancelBooking(c.getAttribute('data-cancel')); renderTrainers('Booking cancelled.'); }
      if (s) { var b = store.state.bookings.filter(function (x) { return x.id === s.getAttribute('data-sms'); })[0]; if (b) sendToGym('sms', b); }
    };
  }
  function bookingText(b) {
    return 'Hello ' + C.GYM.name + ', I want to book trainer ' + b.trainer_name + ' (' + b.package + ', ' + C.inr(b.amount) + '). Start: ' + C.fmtDate(b.start_date) + ', slot: ' + b.slot +
      '. Goal: ' + (b.goal || '-') + '. Name: ' + b.customer + ', phone: ' + b.phone + '. ' + (b.status === 'paid' ? 'Paid by UPI' + (b.ref ? ' (ref ' + b.ref + ')' : '') + '.' : 'I will pay at the gym desk.');
  }
  function sendToGym(kind, b) {
    var gp = store.state.settings.gym_phone;
    if (!gp) { alert('The owner has not saved the gym phone number yet. Set it in More → Settings.'); return; }
    var text = bookingText(b);
    window.location.href = kind === 'sms' ? 'sms:+91' + gp + '?body=' + encodeURIComponent(text) : 'https://wa.me/91' + gp + '?text=' + encodeURIComponent(text);
  }
  function trainerDetail() {
    var t = W.trainer(tr.id);
    view.innerHTML = '<button class="back" id="tBack">‹ Trainers</button><div class="row" style="justify-content:flex-start;gap:14px;margin-top:6px"><div class="avatar big">' + W.avatar(t.look) + '</div><div><h2 style="margin:0">' + esc(t.name) + '</h2>' +
      '<div class="muted">' + t.years + ' years experience</div><div class="muted">' + esc(t.langs.join(', ')) + '</div></div></div>' +
      '<div class="chipline" style="margin-top:10px">' + t.focus.map(function (f) { return '<span class="tag hot">' + esc(f) + '</span>'; }).join('') + '</div><p>' + esc(t.bio) + '</p>' +
      '<h3>Available</h3><div class="chipline">' + t.slots.map(function (i) { return '<span class="tag">' + esc(W.SLOTS[i]) + '</span>'; }).join('') + '</div>' +
      '<h3>Packages</h3>' + W.packages(t).map(function (p) { return '<div class="card row"><div><b>' + esc(p.label) + '</b><div class="muted">' + C.inr(Math.round(p.price / p.sessions)) + ' per session</div></div><b>' + C.inr(p.price) + '</b></div>'; }).join('') +
      '<button class="btn" id="tHire">Hire ' + esc(t.name.split(' ')[0]) + '</button>';
    $('#tBack').onclick = function () { tr.mode = 'list'; renderTrainers(); };
    $('#tHire').onclick = function () { tr.mode = 'book'; tr.slot = W.SLOTS[t.slots[0]]; tr.date = store.today(); tr.pkg = 'm1'; tr.pending = null; tr.showQr = false; renderTrainers(); };
  }
  function bookingParams() {
    var t = W.trainer(tr.id), pk = pkgOf(t), st = store.state.settings;
    if (!st.upi_id) return { err: 'The gym UPI ID is not saved yet. Choose “Pay at gym desk”, or ask the owner to save it in More → Payments.' };
    return { o: { pa: st.upi_id, pn: st.payee_name, am: pk.price, tn: ('Trainer ' + t.name + ' ' + pk.label).slice(0, 50), tr: 'GT' + Date.now().toString(36).toUpperCase() } };
  }
  function trainerBook(err) {
    var t = W.trainer(tr.id), pk = pkgOf(t), members = sortedMembers();
    view.innerHTML = '<button class="back" id="tBack">‹ ' + esc(t.name) + '</button><h2>Book ' + esc(t.name) + '</h2>' +
      '<label>Package</label><div class="seg col3" id="bPkg">' + W.packages(t).map(function (p) { return '<button data-p="' + p.id + '" class="' + (pk.id === p.id ? 'on' : '') + '">' + esc(p.label.split(' · ')[0]) + '<br><small>' + C.inr(p.price) + '</small></button>'; }).join('') + '</div>' +
      '<label>Time slot</label><div class="chips wrap" id="bSlot">' + t.slots.map(function (i) { return '<button data-s="' + esc(W.SLOTS[i]) + '" class="' + (tr.slot === W.SLOTS[i] ? 'on' : '') + '">' + esc(W.SLOTS[i]) + '</button>'; }).join('') + '</div>' +
      '<label>Start date</label><input id="bDate" type="date" min="' + store.today() + '" value="' + esc(tr.date) + '">' +
      '<label>Your goal</label><select id="bGoal">' + GOALS.map(function (g) { return '<option' + (tr.goal === g ? ' selected' : '') + '>' + esc(g) + '</option>'; }).join('') + '</select>' +
      '<label>Who is booking?</label><select id="bWho"><option value="">New person (type details)</option>' + members.map(function (m) { return '<option value="' + esc(m.id) + '"' + (tr.buyer === m.id ? ' selected' : '') + '>' + esc(m.name) + ' — ' + esc(m.phone) + '</option>'; }).join('') + '</select>' +
      (tr.buyer ? '' : '<label>Name</label><input id="bName" value="' + esc(tr.customer) + '" autocomplete="name"><label>Mobile number</label><input id="bPhone" inputmode="tel" value="' + esc(tr.phone) + '" placeholder="10-digit number" autocomplete="tel">') +
      '<label>Notes for the trainer (optional)</label><input id="bNotes" maxlength="160" value="' + esc(tr.notes) + '" placeholder="Injury, diet, timing…">' +
      '<div class="card row"><b>Total</b><span class="big">' + C.inr(pk.price) + '</span></div>' +
      '<label>Payment</label><div class="seg" id="bMeth">' + [['upi', 'Pay now (Google Pay / UPI)'], ['later', 'Pay at gym desk']].map(function (x) { return '<button data-m="' + x[0] + '" class="' + (tr.method === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div>';
    var h;
    if (tr.method === 'upi') {
      h = '<button class="btn gpay" id="bGpay">Pay ' + C.inr(pk.price) + ' with Google Pay</button><button class="btn ghost" id="bUpi">Other UPI apps</button><button class="btn ghost" id="bQr">' + (tr.showQr ? 'Hide' : 'Show') + ' UPI QR</button>';
      if (tr.showQr) { var up = bookingParams(); h += up.o ? '<div class="qrcard">' + qrSvg(C.upiLink(up.o)) + '<p class="muted">Scan with Google Pay, PhonePe, Paytm or any UPI app.</p></div>' : '<p class="muted">' + esc(up.err) + '</p>'; }
    } else h = '<button class="btn" id="bConfirm">Confirm booking</button>';
    view.insertAdjacentHTML('beforeend', h + '<div id="bErr" class="errtxt">' + esc(err || '') + '</div>');
    if (tr.pending) view.insertAdjacentHTML('beforeend', '<div class="card pend"><b>Did the payment go through?</b><div class="muted">' + C.inr(tr.pending.am) + ' for ' + esc(t.name) + '. Check the Google Pay success screen or your bank SMS, then confirm.</div><label>UPI reference (optional)</label><input id="bRef" placeholder="12-digit UPI ref"><button class="btn" id="bYes">Yes, confirm booking</button><button class="btn ghost" id="bNo">No / cancel</button></div>');
    bindBook(t);
  }
  function readBook() {
    if ($('#bDate')) tr.date = $('#bDate').value; if ($('#bGoal')) tr.goal = $('#bGoal').value; if ($('#bNotes')) tr.notes = $('#bNotes').value;
    if ($('#bName')) tr.customer = $('#bName').value; if ($('#bPhone')) tr.phone = $('#bPhone').value;
  }
  function submitBooking(method, ref) {
    var t = W.trainer(tr.id), pk = pkgOf(t);
    var r = store.recordBooking({ trainer_id: t.id, trainer_name: t.name, package: pk.label, sessions: pk.sessions, amount: pk.price, slot: tr.slot, start_date: tr.date, goal: tr.goal, notes: tr.notes, member_id: tr.buyer, customer: tr.customer, phone: tr.phone, method: method, ref: ref });
    if (!r.ok) { tr.pending = null; trainerBook(r.error); return; }
    tr.last = r.booking; tr.mode = 'done'; tr.pending = null; tr.notes = ''; tr.customer = ''; tr.phone = ''; tr.showQr = false; renderTrainers();
  }
  function bindBook(t) {
    var on = function (id, fn) { var el = $(id); if (el) el.onclick = fn; };
    on('#tBack', function () { readBook(); tr.mode = 'detail'; tr.pending = null; renderTrainers(); });
    $('#bPkg').onclick = function (e) { var b = e.target.closest('button'); if (b) { readBook(); tr.pkg = b.getAttribute('data-p'); tr.pending = null; trainerBook(); } };
    $('#bSlot').onclick = function (e) { var b = e.target.closest('button'); if (b) { readBook(); tr.slot = b.getAttribute('data-s'); trainerBook(); } };
    $('#bWho').onchange = function () { readBook(); tr.buyer = this.value; trainerBook(); };
    $('#bMeth').onclick = function (e) { var b = e.target.closest('button'); if (b) { readBook(); tr.method = b.getAttribute('data-m'); tr.pending = null; trainerBook(); } };
    function launch(kind) {
      readBook(); var up = bookingParams(); if (up.err) { $('#bErr').textContent = up.err; return; }
      tr.pending = { am: up.o.am }; trainerBook();
      if (kind === 'upi') { window.location.href = C.upiLink(up.o); return; }
      var left = false; function gone() { left = true; }
      document.addEventListener('visibilitychange', gone, { once: true }); window.addEventListener('blur', gone, { once: true });
      window.location.href = C.gpayLink(up.o);
      setTimeout(function () { if (!left) window.location.href = C.upiLink(up.o); }, 1500);
    }
    on('#bGpay', function () { launch('gpay'); }); on('#bUpi', function () { launch('upi'); });
    on('#bQr', function () { readBook(); tr.showQr = !tr.showQr; trainerBook(); });
    on('#bConfirm', function () { readBook(); submitBooking('later', ''); });
    on('#bYes', function () { readBook(); submitBooking('upi', $('#bRef').value); });
    on('#bNo', function () { tr.pending = null; trainerBook(); });
  }
  function trainerDone() {
    var b = tr.last, gp = store.state.settings.gym_phone;
    view.innerHTML = '<div class="card result ok"><div class="icon">&#10003;</div><h2>Booking saved</h2><p class="muted">' + esc(b.trainer_name) + ' · ' + esc(b.package) + '<br>Starts ' + C.fmtDate(b.start_date) + ' · ' + esc(b.slot) + '<br>' + (b.status === 'paid' ? 'Payment recorded (' + C.inr(b.amount) + ').' : 'Pay ' + C.inr(b.amount) + ' at the gym desk.') + '</p></div>' +
      '<div class="card"><b>Tell the gym</b><div class="muted">This app has no server, so your request stays on this phone until you send it. Tap a button to send the booking to the gym.</div>' +
      (gp ? '<button class="btn" id="dSms">Send by SMS</button><button class="btn ghost" id="dWa">Send by WhatsApp</button>' : '<div class="res warn" style="margin-top:10px">The gym phone number is not saved yet. The owner can add it in More → Settings.</div>') + '</div>' +
      '<button class="btn ghost" id="dBookings">See my bookings</button><button class="btn ghost" id="dMore">Back to trainers</button>';
    if (gp) { $('#dSms').onclick = function () { sendToGym('sms', b); }; $('#dWa').onclick = function () { sendToGym('wa', b); }; }
    $('#dBookings').onclick = function () { tr.mode = 'list'; tr.tab = 'bookings'; renderTrainers(); };
    $('#dMore').onclick = function () { tr.mode = 'list'; tr.tab = 'trainers'; renderTrainers(); };
  }

  // ---------- Diet (plans, meal times, reminders) ----------
  var DK = C.DietKit, dt = { mode: 'home', type: 'veg', id: '', remind: true, note: '' };
  var Notify = {
    ids: { breakfast: 7101, lunch: 7102, snack: 7103, dinner: 7104 },
    plugin: function () { var c = window.Capacitor; return (c && c.Plugins && c.Plugins.LocalNotifications) || null; },
    body: function (m) { return m.items.slice(0, 3).join(' · ') + ' (about ' + m.kcal + ' kcal)'; },
    // Cancels old reminders and schedules one repeating daily notification per meal.
    sync: function (diet, plan) {
      var P = Notify.plugin(), noop = function () {};
      if (!P) return Promise.resolve({ ok: false, msg: 'Reminders work in the installed GYM Flow app (not in a browser).' });
      var cancelAll = P.cancel({ notifications: DK.SLOTS.map(function (k) { return { id: Notify.ids[k] }; }) });
      return Promise.resolve(cancelAll).catch(noop).then(function () {
        if (!plan || !diet.remind) return { ok: true, msg: 'Reminders are off.' };
        return P.requestPermissions().then(function (r) {
          if (!r || r.display !== 'granted') return { ok: false, msg: 'Notifications are blocked. Allow notifications for GYM Flow in your phone settings, then switch reminders on again.' };
          var ch = P.createChannel ? P.createChannel({ id: 'meals', name: 'Meal reminders', description: 'Daily diet reminders', importance: 4, visibility: 1, vibration: true }) : null;
          return Promise.resolve(ch).catch(noop).then(function () {
            var list = plan.meals.map(function (m) {
              var t = DK.parseHM(diet.times[m.slot]);
              return { id: Notify.ids[m.slot], title: '🍽 ' + W.SLOT_LABEL[m.slot] + ' time', body: Notify.body(m), channelId: 'meals', schedule: { on: { hour: t.hour, minute: t.minute }, allowWhileIdle: true } };
            });
            return P.schedule({ notifications: list }).then(function () {
              var exact = P.checkExactNotificationSetting ? P.checkExactNotificationSetting().catch(function () { return null; }) : Promise.resolve(null);
              return exact.then(function (ex) { return { ok: true, msg: 'Reminders set for ' + DK.SLOTS.map(function (k) { return diet.times[k]; }).join(', ') + ' every day.', exactDenied: !!(ex && ex.exact_alarm === 'denied') }; });
            });
          });
        });
      }).catch(function (e) { return { ok: false, msg: 'Could not set reminders: ' + ((e && e.message) || e) }; });
    },
    test: function () {
      var P = Notify.plugin();
      if (!P) return Promise.resolve({ ok: false, msg: 'Test reminders work in the installed app.' });
      return P.requestPermissions().then(function (r) {
        if (!r || r.display !== 'granted') return { ok: false, msg: 'Notifications are blocked for GYM Flow. Allow them in phone settings.' };
        return P.schedule({ notifications: [{ id: 7199, title: '🍽 GYM Flow test reminder', body: 'Your meal reminders are working.', schedule: { at: new Date(Date.now() + 5000), allowWhileIdle: true } }] }).then(function () { return { ok: true, msg: 'Test reminder will appear in about 5 seconds. Lock the screen or leave the app to see it.' }; });
      }).catch(function (e) { return { ok: false, msg: 'Test failed: ' + ((e && e.message) || e) }; });
    }
  };
  function renderDiet(msg) {
    var d = DK.get(window.localStorage), plan = d.plan_id ? W.plan(d.plan_id) : null;
    if (dt.mode === 'plan') return dietPlan();
    if (plan && dt.mode !== 'choose') return dietActive(d, plan, msg);
    dietChoose(msg);
  }
  function dietChoose(msg) {
    var plans = W.PLANS.filter(function (p) { return p.type === dt.type; });
    view.innerHTML = back() + '<h2>Diet plans</h2>' + (msg ? '<div class="res ok">' + esc(msg) + '</div>' : '') +
      '<p class="muted">Pick a plan with 4 meals a day. Start it and the app reminds you at each meal time.</p>' +
      '<div class="seg" id="dType">' + [['veg', '🥦 Vegetarian'], ['nonveg', '🍗 Non-veg']].map(function (x) { return '<button data-t="' + x[0] + '" class="' + (dt.type === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div>' +
      '<div class="list" id="dList">' + plans.map(function (p) { var tt = W.planTotals(p);
        return '<div class="item" data-p="' + p.id + '"><div class="planrow"><div class="thumb foodthumb">' + W.food(p.meals[1].art) + '</div><div style="flex:1"><div class="name">' + esc(p.name) + '</div><div class="muted">' + esc(p.goal) + '</div>' +
          '<div class="chipline"><span class="tag">' + tt.kcal + ' kcal</span><span class="tag">' + tt.protein + ' g protein</span></div></div><span class="muted">›</span></div></div>'; }).join('') + '</div>' +
      (DK.get(window.localStorage).plan_id ? '<button class="btn ghost" id="dBackActive">Back to my current plan</button>' : '') +
      '<p class="muted">General healthy-eating guidance with approximate calories. Not medical advice. If you have a health condition, check with a doctor or dietitian first.</p>';
    $('#dType').onclick = function (e) { var b = e.target.closest('button'); if (b) { dt.type = b.getAttribute('data-t'); dietChoose(); } };
    $('#dList').onclick = function (e) { var c = e.target.closest('[data-p]'); if (c) { dt.id = c.getAttribute('data-p'); dt.mode = 'plan'; renderDiet(); } };
    if ($('#dBackActive')) $('#dBackActive').onclick = function () { dt.mode = 'home'; renderDiet(); };
  }
  function mealRow(m, times, extra) {
    return '<div class="item plain meal"><div class="planrow"><div class="thumb foodthumb">' + W.food(m.art) + '</div><div style="flex:1"><div class="row"><b>' + W.SLOT_LABEL[m.slot] + '</b>' + (times || '') + '</div>' +
      '<div class="muted">' + m.items.map(esc).join(' · ') + '</div><div class="chipline"><span class="tag">' + m.kcal + ' kcal</span><span class="tag">' + m.protein + ' g protein</span></div>' + (extra || '') + '</div></div></div>';
  }
  function dietPlan() {
    var p = W.plan(dt.id), tt = W.planTotals(p), d = DK.get(window.localStorage);
    view.innerHTML = '<button class="back" id="dBack">‹ Diet plans</button><h2>' + esc(p.name) + '</h2><div class="chipline"><span class="tag hot">' + (p.type === 'veg' ? 'Vegetarian' : 'Non-veg') + '</span><span class="tag">' + esc(p.goal) + '</span><span class="tag">' + tt.kcal + ' kcal</span><span class="tag">' + tt.protein + ' g protein</span></div>' +
      '<p>' + esc(p.desc) + '</p><div class="list">' + p.meals.map(function (m) { return mealRow(m, '<span class="muted">' + d.times[m.slot] + '</span>'); }).join('') + '</div>' +
      '<label class="chk"><input type="checkbox" id="dRem"' + (dt.remind ? ' checked' : '') + '> Remind me at each meal time (phone notification)</label>' +
      '<button class="btn" id="dStart">Start this plan today</button><div id="dErr" class="errtxt"></div>' +
      '<p class="muted">You can change the meal times after starting. Portions are a general guide, not medical advice.</p>';
    $('#dBack').onclick = function () { dt.mode = 'choose'; renderDiet(); };
    $('#dRem').onchange = function () { dt.remind = this.checked; };
    $('#dStart').onclick = function () {
      DK.start(window.localStorage, p.id, store.today()); var d2 = DK.setRemind(window.localStorage, dt.remind);
      Notify.sync(d2, p).then(function (r) { dt.mode = 'home'; dt.note = r; renderDiet('Plan started: ' + p.name + '. ' + r.msg); });
    };
  }
  function nowHM() { var t = C.timeIST(); return t; }
  function dietActive(d, plan, msg) {
    var today = store.today(), sm = DK.summary(d, today), next = DK.nextMeal(d, nowHM()), tt = W.planTotals(plan), exact = dt.note && dt.note.exactDenied;
    view.innerHTML = back() + '<div class="row"><h2>My diet</h2><button class="btn small ghost" id="dChange">Change plan</button></div>' + (msg ? '<div class="res ok">' + esc(msg) + '</div>' : '') +
      '<div class="card"><div class="row"><div><b>' + esc(plan.name) + '</b><div class="muted">Day ' + sm.day_no + ' · ' + tt.kcal + ' kcal · ' + tt.protein + ' g protein</div></div><span class="tag hot">' + (plan.type === 'veg' ? 'Veg' : 'Non-veg') + '</span></div>' +
      pbar(Math.round(sm.today_done / 4 * 100)) + '<div class="row muted"><span>Today: ' + sm.today_done + ' of 4 meals</span><span>This week: ' + sm.week_percent + '%</span></div></div>' +
      '<h3>Today’s meals</h3><div class="list" id="dMeals">' + plan.meals.map(function (m) {
        var done = !!(d.done[today] && d.done[today][m.slot]);
        return mealRow(m, '<input type="time" class="timein" data-slot="' + m.slot + '" value="' + d.times[m.slot] + '">',
          '<div class="row" style="margin-top:8px"><span class="muted">' + (m.slot === next && !done ? '⏰ Next meal' : '') + '</span><button class="btn small ' + (done ? '' : 'ghost') + '" data-eat="' + m.slot + '">' + (done ? '✓ Eaten' : 'Mark eaten') + '</button></div>'); }).join('') + '</div>' +
      '<h3>Reminders</h3><div class="card"><label class="chk" style="margin-top:0"><input type="checkbox" id="dRemOn"' + (d.remind ? ' checked' : '') + '> Remind me at meal times</label>' +
      '<div class="muted">A notification arrives on this phone every day at the times above, even when the app is closed. Change a time above and reminders update.</div>' +
      (exact ? '<div class="res warn" style="margin-top:10px">For on-time reminders, allow “Alarms &amp; reminders” for GYM Flow.</div><button class="btn small" id="dExact">Open setting</button>' : '') +
      '<button class="btn ghost" id="dTest">Send a test reminder (5 seconds)</button><div id="dMsg" class="muted" style="margin-top:8px"></div></div>' +
      '<button class="btn danger" id="dStop">Stop this plan</button>';
    $('#dChange').onclick = function () { dt.mode = 'choose'; dt.type = plan.type; renderDiet(); };
    $('#dMeals').onclick = function (e) { var b = e.target.closest('[data-eat]'); if (b) { DK.toggleMeal(window.localStorage, today, b.getAttribute('data-eat')); renderDiet(); } };
    Array.prototype.forEach.call(view.querySelectorAll('.timein'), function (inp) {
      inp.onchange = function () {
        var r = DK.setTime(window.localStorage, inp.getAttribute('data-slot'), inp.value);
        if (!r.ok) { $('#dMsg').textContent = r.error; return; }
        Notify.sync(r.diet, plan).then(function (n) { dt.note = n; renderDiet('Time saved. ' + n.msg); });
      };
    });
    $('#dRemOn').onchange = function () { var d2 = DK.setRemind(window.localStorage, this.checked); Notify.sync(d2, plan).then(function (n) { dt.note = n; renderDiet(n.msg); }); };
    $('#dTest').onclick = function () { $('#dMsg').textContent = 'Please wait…'; Notify.test().then(function (r) { $('#dMsg').textContent = r.msg; }); };
    if ($('#dExact')) $('#dExact').onclick = function () { var P = Notify.plugin(); if (P && P.changeExactNotificationSetting) P.changeExactNotificationSetting(); };
    $('#dStop').onclick = function () { if (confirm('Stop this plan and turn off its reminders?')) { DK.stop(window.localStorage); Notify.sync(DK.get(window.localStorage), null).then(function () { dt.mode = 'choose'; renderDiet('Plan stopped. Reminders are off.'); }); } };
  }

  // ---------- Clubs (join gym clubs, benefits and rewards) ----------
  var CL = window.GymClubs;
  var ck = { mode: 'list', tab: 'all', id: '', buyer: '', customer: '', phone: '', welcome: false, note: '' };
  function myPhone() { try { return (C.MemberKit.get(window.localStorage).phone) || ''; } catch (e) { return ''; } }
  function sendGymText(kind, text) {
    var gp = store.state.settings.gym_phone;
    if (!gp) { alert('The owner has not saved the gym phone number yet. Set it in More → Settings.'); return; }
    window.location.href = kind === 'sms' ? 'sms:+91' + gp + '?body=' + encodeURIComponent(text) : 'https://wa.me/91' + gp + '?text=' + encodeURIComponent(text);
  }
  function clubCountOf(c) { return c.members + store.clubCount(c.id); }
  function renderClubs(msg) {
    if (ck.mode === 'detail' && CL.club(ck.id)) return clubDetail(msg);
    ck.mode = 'list';
    var phone = myPhone(), mine = store.clubJoins(phone || ''), joinedIds = {};
    mine.forEach(function (j) { joinedIds[j.club_id] = j; });
    var h = back() + '<h2>Clubs</h2>' + (msg ? '<div class="res ok">' + esc(msg) + '</div>' : '') +
      '<p class="muted">Join a club to meet people with the same goal and earn rewards. Joining is free.</p>' +
      '<div class="seg" id="cseg">' + [['all', 'All clubs (' + CL.CLUBS.length + ')'], ['mine', 'My clubs (' + mine.length + ')']].map(function (x) { return '<button data-m="' + x[0] + '" class="' + (ck.tab === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div>';
    var list = ck.tab === 'mine' ? CL.CLUBS.filter(function (c) { return joinedIds[c.id]; }) : CL.CLUBS;
    h += '<div class="list" id="clist" style="margin-top:8px">' + (list.length ? list.map(function (c) {
      var top = c.tiers[c.tiers.length - 1];
      return '<div class="item" data-c="' + c.id + '"><div class="planrow"><div class="avatar emblem">' + CL.emblem(c) + '</div><div style="flex:1"><div class="row"><b>' + esc(c.name) + '</b>' + (joinedIds[c.id] ? '<span class="badge active">Joined</span>' : '') + '</div>' +
        '<div class="muted">' + esc(c.tagline) + '</div><div class="chipline"><span class="tag">👥 ' + clubCountOf(c) + ' members</span><span class="tag">' + esc(c.level) + '</span></div>' +
        '<div class="muted">🎁 Top reward: ' + esc(top.reward) + '</div></div><span class="muted">›</span></div></div>';
    }).join('') : '<div class="empty">You have not joined any club yet. Open the first tab and pick one.</div>') + '</div>' +
      '<p class="muted">Sample clubs, benefits and member numbers. The owner can edit them in clubs.js.</p>';
    view.innerHTML = h;
    $('#cseg').onclick = function (e) { var b = e.target.closest('button'); if (b) { ck.tab = b.getAttribute('data-m'); renderClubs(); } };
    $('#clist').onclick = function (e) { var c = e.target.closest('[data-c]'); if (c) { ck.id = c.getAttribute('data-c'); ck.mode = 'detail'; ck.welcome = false; ck.note = ''; renderClubs(); } };
  }
  function clubJoinOf(club) {
    var phone = myPhone(), all = store.clubJoins(phone || '');
    return all.filter(function (j) { return j.club_id === club.id; })[0] || null;
  }
  function clubDetail(msg) {
    var c = CL.club(ck.id), j = clubJoinOf(c), members = sortedMembers();
    var h = '<button class="back" id="cBack">‹ Clubs</button><div class="row" style="justify-content:flex-start;gap:14px;margin-top:6px"><div class="avatar big emblem">' + CL.emblem(c) + '</div><div><h2 style="margin:0">' + esc(c.name) + '</h2><div class="muted">' + esc(c.tagline) + '</div><div class="chipline" style="margin-top:6px"><span class="tag">👥 ' + clubCountOf(c) + ' members</span><span class="tag">' + esc(c.level) + '</span></div></div></div>';
    if (msg) h += '<div class="res ok" style="margin-top:10px">' + esc(msg) + '</div>';
    if (j && ck.welcome) {
      h += '<div class="card welcome"><h3 style="margin-top:0">🎉 Welcome to ' + esc(c.name) + '!</h3><p style="margin:4px 0">You are in, ' + esc(j.customer.split(' ')[0]) + '. Here is what you get:</p><ul class="steps">' + c.perks.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('') + '</ul>' +
        '<p style="margin:4px 0"><b>🎁 ' + j.welcome_points + ' welcome points</b> added. Earn ' + C.CLUB_VISIT_POINTS + ' more points every time you check in at the gym, and unlock the rewards below.</p></div>';
    }
    h += '<p>' + esc(c.about) + '</p><div class="card"><div class="muted">When</div><b>' + esc(c.schedule) + '</b></div>' +
      '<h3>Benefits of joining</h3><ul class="checks">' + c.perks.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('') + '</ul>' +
      '<h3>Rewards you can unlock</h3><div class="list">';
    var st = j ? store.clubStats(j, c.tiers) : null;
    c.tiers.forEach(function (t) {
      var got = st && st.visits >= t.visits;
      h += '<div class="item plain"><div class="row"><span><b>' + (got ? '✅ ' : '🎁 ') + esc(t.name) + '</b><div class="muted">' + (t.visits ? 'After ' + t.visits + ' gym visits' : 'When you join') + '</div></span><span style="text-align:right;max-width:55%">' + esc(t.reward) + '</span></div></div>';
    });
    h += '</div>';
    if (j) {
      h += '<h3>Your progress</h3><div class="card"><div class="effgrid"><div><div class="muted">Points</div><div class="big">' + st.points + '</div></div><div><div class="muted">Visits since joining</div><div class="big">' + (st.tracked ? st.visits : '–') + '</div></div></div>' +
        (st.tracked ? '<div class="muted">Current level: <b>' + (st.tier ? esc(st.tier.name) : 'New member') + '</b></div>' + (st.next ? pbar(Math.round(st.visits / st.next.visits * 100)) + '<div class="muted">' + st.to_next + ' more visit' + (st.to_next === 1 ? '' : 's') + ' to unlock <b>' + esc(st.next.name) + '</b>: ' + esc(st.next.reward) + '</div>' : '<div class="res ok" style="margin-top:8px">You unlocked every reward. Amazing!</div>')
          : '<div class="muted">Visits are counted for members registered at the gym with this phone number (' + esc(j.phone) + '). Ask the desk to register you to start earning.</div>') + '</div>' +
        '<button class="btn" id="cInvite">Invite a friend on WhatsApp</button>' +
        (c.challenge ? '<button class="btn ghost" id="cChal">Start the club challenge: ' + esc(c.challenge.title) + ' (' + c.challenge.days + ' days)</button>' : '') +
        '<button class="btn ghost" id="cTell">Tell the gym I joined (SMS)</button><button class="btn danger" id="cLeave">Leave this club</button>';
    } else {
      h += '<h3>Join this club</h3><div class="card"><label style="margin-top:0">Who is joining?</label><select id="jWho"><option value="">New person (type details)</option>' + members.map(function (m) { return '<option value="' + esc(m.id) + '"' + (ck.buyer === m.id ? ' selected' : '') + '>' + esc(m.name) + ' — ' + esc(m.phone) + '</option>'; }).join('') + '</select>' +
        (ck.buyer ? '' : '<label>Name</label><input id="jName" value="' + esc(ck.customer) + '" autocomplete="name"><label>Mobile number</label><input id="jPhone" inputmode="tel" value="' + esc(ck.phone || myPhone()) + '" placeholder="10-digit number" autocomplete="tel">') +
        '<button class="btn" id="jGo">Join for free &amp; get ' + c.welcome + ' points</button><div id="jErr" class="errtxt"></div></div>';
    }
    view.innerHTML = h + '<p class="muted" style="margin-top:14px">Sample benefits and rewards. The gym can change them.</p>';
    $('#cBack').onclick = function () { ck.mode = 'list'; renderClubs(); };
    if (!j) {
      $('#jWho').onchange = function () { readJoin(); ck.buyer = this.value; clubDetail(); };
      $('#jGo').onclick = function () {
        readJoin();
        var r = store.joinClub({ club_id: c.id, club_name: c.name, welcome_points: c.welcome, member_id: ck.buyer, customer: ck.customer, phone: ck.phone });
        if (!r.ok) { $('#jErr').textContent = r.error; return; }
        ck.welcome = true; ck.customer = ''; ck.buyer = ''; clubDetail();
        window.scrollTo(0, 0); var v = document.getElementById('view'); if (v && v.scrollTo) v.scrollTo(0, 0);
      };
    } else {
      var inviteText = 'Join the ' + c.name + ' at ' + C.GYM.name + '! ' + c.tagline + '. Benefits: ' + c.perks.slice(0, 2).join('; ') + '. Free to join. Ask at the desk or open GYM Flow → More → Clubs.';
      $('#cInvite').onclick = function () { window.location.href = 'https://wa.me/?text=' + encodeURIComponent(inviteText); };
      $('#cTell').onclick = function () { sendGymText('sms', 'Hello ' + C.GYM.name + ', I joined the ' + c.name + '. Name: ' + j.customer + ', phone: ' + j.phone + '.'); };
      if (c.challenge) $('#cChal').onclick = function () {
        var g = C.GoalKit.create(window.localStorage, { title: c.challenge.title, days: c.challenge.days, note: c.name }, store.today());
        clubDetail(g.ok ? 'Challenge started! Open More → Goals to tick off each day.' : g.error);
      };
      $('#cLeave').onclick = function () { if (confirm('Leave this club? Your points and progress here will be removed.')) { store.leaveClub(j.id); ck.welcome = false; ck.mode = 'list'; renderClubs('You left ' + c.name + '.'); } };
    }
  }
  function readJoin() { if ($('#jName')) ck.customer = $('#jName').value; if ($('#jPhone')) ck.phone = $('#jPhone').value; }

  // ---------- Products (shop) ----------
  var S = window.GymShop;
  var shop = { tab: 'shop', cat: 'all', q: '', cart: {}, buyer: '', customer: '', method: 'upi', note: '', pending: null, showQr: false };
  function cartLines() {
    return Object.keys(shop.cart).map(function (id) { var p = S.byId(id); return p ? { p: p, qty: shop.cart[id] } : null; }).filter(Boolean);
  }
  function cartCount() { return cartLines().reduce(function (n, l) { return n + l.qty; }, 0); }
  function cartTotal() { return Math.round(cartLines().reduce(function (t, l) { return t + Math.round(l.p.price * 100) * l.qty; }, 0)) / 100; }
  function addToCart(id, n) { shop.cart[id] = Math.min(99, (shop.cart[id] || 0) + (n || 1)); }
  function setQty(id, q) { if (q <= 0) delete shop.cart[id]; else shop.cart[id] = Math.min(99, q); }
  function renderProducts(msg) {
    var n = cartCount();
    var h = back() + '<h2>Products</h2>' + (msg ? '<div class="res ok">' + esc(msg) + '</div>' : '') +
      '<div class="seg" id="pseg">' + [['shop', 'Shop'], ['cart', 'Cart' + (n ? ' (' + n + ')' : '')], ['sales', 'Sales']].map(function (x) { return '<button data-m="' + x[0] + '" class="' + (shop.tab === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div>';
    if (shop.tab === 'shop') h += shopGrid();
    else if (shop.tab === 'cart') h += cartView();
    else h += salesView();
    view.innerHTML = h;
    $('#pseg').onclick = function (e) { var b = e.target.closest('button'); if (b) { shop.tab = b.getAttribute('data-m'); shop.pending = null; renderProducts(); } };
    if (shop.tab === 'shop') bindShop(); else if (shop.tab === 'cart') bindCart();
  }
  function shopGrid() {
    var term = shop.q.trim().toLowerCase();
    var list = S.PRODUCTS.filter(function (p) { return (shop.cat === 'all' || p.cat === shop.cat) && (!term || (p.name + ' ' + p.variant + ' ' + p.cat).toLowerCase().indexOf(term) !== -1); });
    return '<input id="sq" type="search" placeholder="Search products" value="' + esc(shop.q) + '" autocomplete="off">' +
      '<div class="chips" id="scats">' + [{ id: 'all', name: 'All' }].concat(S.CATS).map(function (c) { return '<button data-c="' + c.id + '" class="' + (shop.cat === c.id ? 'on' : '') + '">' + esc(c.name) + '</button>'; }).join('') + '</div>' +
      '<div class="muted" style="margin:6px 2px">' + list.length + ' of ' + S.PRODUCTS.length + ' products</div>' +
      '<div class="grid2" id="sgrid">' + list.map(function (p) {
        return '<div class="ex prod" data-p="' + p.id + '"><div class="exfig">' + S.art(p.art, p.color) + '</div><div class="exname">' + esc(p.name) + '</div><div class="muted">' + esc(p.variant) + '</div>' +
          '<div class="row" style="margin-top:6px"><b>' + C.inr(p.price) + '</b><button class="btn small" data-add="' + p.id + '">Add</button></div></div>';
      }).join('') + '</div>' + (list.length ? '' : '<div class="empty">No products match.</div>');
  }
  function bindShop() {
    $('#sq').oninput = function () { shop.q = this.value; var pos = this.selectionStart; renderProducts(); var q = $('#sq'); q.focus(); try { q.setSelectionRange(pos, pos); } catch (e) { /* not supported */ } };
    $('#scats').onclick = function (e) { var b = e.target.closest('button'); if (b) { shop.cat = b.getAttribute('data-c'); renderProducts(); } };
    $('#sgrid').onclick = function (e) {
      var a = e.target.closest('[data-add]');
      if (a) { addToCart(a.getAttribute('data-add')); a.textContent = 'Added ✓'; var t = document.querySelector('#pseg button[data-m=cart]'); if (t) t.textContent = 'Cart (' + cartCount() + ')'; return; }
      var c = e.target.closest('[data-p]'); if (c) showProduct(c.getAttribute('data-p'));
    };
  }
  function showProduct(id) {
    var p = S.byId(id); if (!p) return;
    var catName = S.CATS.filter(function (c) { return c.id === p.cat; })[0].name;
    openSheet('<div class="exfig big">' + S.art(p.art, p.color) + '</div><h2 style="margin-top:12px">' + esc(p.name) + '</h2>' +
      '<div class="chipline"><span class="tag">' + esc(catName) + '</span>' + (p.variant ? '<span class="tag">' + esc(p.variant) + '</span>' : '') + '</div>' +
      '<div class="big">' + C.inr(p.price) + '</div><p>' + esc(p.desc) + '</p><p class="muted">Sample product and price. The owner can edit the list in products.js.</p>' +
      '<button class="btn" id="pdAdd">Add to cart</button>');
    $('#pdAdd').onclick = function () { addToCart(p.id); closeSheet(); renderProducts(); };
  }
  function cartView() {
    var lines = cartLines();
    if (!lines.length) return '<div class="empty">Your cart is empty. Open the Shop tab and add products.</div>';
    var st = store.state.settings, members = sortedMembers();
    var h = '<div class="list">' + lines.map(function (l) {
      return '<div class="item plain"><div class="planrow"><div class="thumb">' + S.art(l.p.art, l.p.color) + '</div><div style="flex:1"><div class="name">' + esc(l.p.name) + '</div><div class="muted">' + C.inr(l.p.price) + ' each</div></div>' +
        '<div class="qty"><button data-dec="' + l.p.id + '">−</button><b>' + l.qty + '</b><button data-inc="' + l.p.id + '">+</button></div></div>' +
        '<div class="row" style="margin-top:6px"><button class="back" data-rm="' + l.p.id + '">Remove</button><b>' + C.inr(l.p.price * l.qty) + '</b></div></div>';
    }).join('') + '</div>' +
      '<div class="card row"><b>Total</b><span class="big">' + C.inr(cartTotal()) + '</span></div>' +
      '<label>Buyer</label><select id="sb"><option value="">Walk-in customer</option>' + members.map(function (m) { return '<option value="' + esc(m.id) + '"' + (shop.buyer === m.id ? ' selected' : '') + '>' + esc(m.name) + ' — ' + esc(m.phone) + '</option>'; }).join('') + '</select>' +
      (shop.buyer ? '' : '<label>Customer name (optional)</label><input id="sc" value="' + esc(shop.customer) + '" placeholder="Walk-in name">');
    if (!st.upi_id) {
      h += '<div class="card"><b>Set the gym’s UPI ID</b><div class="muted">Needed for Google Pay / UPI. Money goes to this UPI ID.</div>' +
        '<label>UPI ID</label><input id="sUpi" placeholder="yourname@bank" autocapitalize="none" autocomplete="off"><label>Name shown when paying</label><input id="sName" value="' + esc(st.payee_name) + '">' +
        '<button class="btn" id="sSave">Save UPI ID</button><div id="sErr" class="errtxt"></div></div>';
    }
    h += '<label>Pay with</label><div class="seg" id="smeth">' + [['upi', 'Google Pay / UPI'], ['cash', 'Cash'], ['card', 'Card']].map(function (x) { return '<button data-m="' + x[0] + '" class="' + (shop.method === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div>' +
      '<label>Note / UPI reference (optional)</label><input id="sn" value="' + esc(shop.note) + '" placeholder="e.g. UPI ref no.">';
    if (shop.method === 'upi') {
      h += '<button class="btn gpay" id="goGpay">Pay ' + C.inr(cartTotal()) + ' with Google Pay</button><button class="btn ghost" id="goUpi">Other UPI apps</button><button class="btn ghost" id="goQr">' + (shop.showQr ? 'Hide' : 'Show') + ' UPI QR</button>';
      if (shop.showQr) { var up = shopUpi(); h += up.o ? '<div class="qrcard">' + qrSvg(C.upiLink(up.o)) + '<p class="muted">Scan with Google Pay, PhonePe, Paytm or any UPI app.</p></div>' : '<p class="muted">' + esc(up.err) + '</p>'; }
    } else {
      h += '<button class="btn" id="goRec">Record ' + (shop.method === 'cash' ? 'cash' : 'card') + ' sale</button>';
    }
    h += '<div id="pErr" class="errtxt"></div>';
    if (shop.pending) {
      h += '<div class="card pend"><b>Did the payment go through?</b><div class="muted">' + C.inr(shop.pending.amount) + ' to ' + esc(st.payee_name) + '. Check the Google Pay success screen or your bank SMS, then confirm.</div>' +
        '<label>UPI reference (optional)</label><input id="pref" placeholder="12-digit UPI ref" value="' + esc(shop.pending.ref || '') + '"><button class="btn" id="pYes">Yes, record sale</button><button class="btn ghost" id="pNo">No / cancel</button></div>';
    }
    return h;
  }
  function shopUpi() {
    var st = store.state.settings, total = cartTotal();
    if (!st.upi_id) return { err: 'Save the gym’s UPI ID first.' };
    if (!total || !C.validAmount(total)) return { err: 'Add products to the cart.' };
    var l = cartLines(), note = 'Shop ' + l[0].p.name + (l.length > 1 ? ' +' + (l.length - 1) : '');
    return { o: { pa: st.upi_id, pn: st.payee_name, am: total, tn: note.slice(0, 50), tr: 'GS' + Date.now().toString(36).toUpperCase() } };
  }
  function shopSale(method, ref) {
    var buyer = shop.buyer ? store.member(shop.buyer) : null;
    var r = store.recordSale({ items: cartLines().map(function (l) { return { id: l.p.id, name: l.p.name, price: l.p.price, qty: l.qty }; }), member_id: buyer ? buyer.id : '', customer: shop.customer, method: method, ref: ref || shop.note });
    if (!r.ok) { if ($('#pErr')) $('#pErr').textContent = r.error; return; }
    shop.cart = {}; shop.pending = null; shop.note = ''; shop.customer = ''; shop.buyer = ''; shop.showQr = false; shop.tab = 'sales';
    renderProducts('Sale recorded: ' + C.inr(r.sale.total) + ' (' + method + ') for ' + r.sale.customer + '.');
  }
  function bindCart() {
    var on = function (id, fn) { var el = $(id); if (el) el.onclick = fn; };
    var list = document.querySelector('.list');
    if (list) list.onclick = function (e) {
      var b = e.target.closest('button'); if (!b) return;
      var inc = b.getAttribute('data-inc'), dec = b.getAttribute('data-dec'), rm = b.getAttribute('data-rm');
      if (inc) setQty(inc, shop.cart[inc] + 1); else if (dec) setQty(dec, shop.cart[dec] - 1); else if (rm) setQty(rm, 0); else return;
      shop.pending = null; renderProducts();
    };
    $('#sb') && ($('#sb').onchange = function () { shop.buyer = this.value; renderProducts(); });
    $('#sc') && ($('#sc').oninput = function () { shop.customer = this.value; });
    $('#sn') && ($('#sn').oninput = function () { shop.note = this.value; });
    $('#smeth') && ($('#smeth').onclick = function (e) { var b = e.target.closest('button'); if (b) { shop.method = b.getAttribute('data-m'); shop.pending = null; renderProducts(); } });
    on('#sSave', function () {
      try { store.setSettings({ upi_id: $('#sUpi').value, payee_name: $('#sName').value }); if (!store.state.settings.upi_id) throw new Error('Enter the UPI ID.'); renderProducts('UPI ID saved.'); }
      catch (e) { $('#sErr').textContent = e.message; }
    });
    function launch(kind) {
      var r = shopUpi(); if (r.err) { $('#pErr').textContent = r.err; return; }
      var o = r.o; shop.pending = { amount: o.am, ref: '' }; renderProducts();
      if (kind === 'upi') { window.location.href = C.upiLink(o); return; }
      var left = false; function gone() { left = true; }
      document.addEventListener('visibilitychange', gone, { once: true }); window.addEventListener('blur', gone, { once: true });
      window.location.href = C.gpayLink(o);
      setTimeout(function () { if (!left) window.location.href = C.upiLink(o); }, 1500);
    }
    on('#goGpay', function () { launch('gpay'); });
    on('#goUpi', function () { launch('upi'); });
    on('#goQr', function () { shop.showQr = !shop.showQr; renderProducts(); });
    on('#goRec', function () { shopSale(shop.method); });
    on('#pYes', function () { shopSale('upi', $('#pref').value); });
    on('#pNo', function () { shop.pending = null; renderProducts(); });
  }
  function salesView() {
    var t = store.today(), all = store.salesSummary(), mon = store.salesSummary(C.monthStart(t), t), recent = store.recentSales(15);
    return '<div class="stats"><div class="card"><div class="muted">This month</div><div class="big">' + C.inr(mon.total) + '</div><div class="muted">' + mon.units + ' items</div></div>' +
      '<div class="card"><div class="muted">All time</div><div class="big">' + C.inr(all.total) + '</div><div class="muted">' + all.count + ' sales</div></div></div>' +
      '<h3>Recent sales</h3><div class="list">' + (recent.length ? recent.map(function (s) {
        return '<div class="item plain"><div class="row"><span><b>' + esc(s.customer) + '</b><div class="muted">' + C.fmtDate(s.paid_at) + ' · ' + esc(s.method) + (s.ref ? ' · ' + esc(s.ref) : '') + '</div><div class="muted">' +
          s.items.map(function (i) { return esc(i.name) + ' ×' + i.qty; }).join(', ') + '</div></span><b>' + C.inr(s.total) + '</b></div></div>'; }).join('') : '<div class="empty">No product sales yet.</div>') + '</div>';
  }

  // ---------- Payments ----------
  function payTarget() { return store.member(pay.member); }
  function renderPayments(msg) {
    var st = store.state.settings, plans = store.state.plans.filter(function (p) { return p.active; });
    var members = pay.q ? store.searchMembers(pay.q) : sortedMembers().slice(0, 10);
    if (pay.member && !members.some(function (m) { return m.id === pay.member; }) && store.member(pay.member)) members.unshift(store.member(pay.member));
    var h = back() + '<h2>Payments</h2>' + (msg ? '<div class="res ok">' + esc(msg) + '</div>' : '');
    if (!st.upi_id) {
      h += '<div class="card"><b>Set the gym’s UPI ID</b><div class="muted">Needed to take Google Pay / UPI payments. Money goes to this UPI ID.</div>' +
        '<label>UPI ID</label><input id="sUpi" placeholder="yourname@bank" autocapitalize="none" autocomplete="off"><label>Name shown when paying</label><input id="sName" value="' + esc(st.payee_name) + '">' +
        '<button class="btn" id="sSave">Save UPI ID</button><div id="sErr" class="errtxt"></div></div>';
    } else {
      h += '<div class="card row"><div><div class="muted">Receiving UPI ID</div><b>' + esc(st.upi_id) + '</b></div><button class="btn small ghost" data-go="settings">Change</button></div>';
    }
    h += '<label>Member</label><input id="pq" type="search" placeholder="Search name or phone" value="' + esc(pay.q) + '" autocomplete="off">' +
      '<select id="pm" style="margin-top:8px"><option value="">Choose a member…</option>' + members.map(function (m) { return '<option value="' + esc(m.id) + '"' + (pay.member === m.id ? ' selected' : '') + '>' + esc(m.name) + ' — ' + esc(m.phone) + '</option>'; }).join('') + '</select>' +
      '<label>Plan</label><select id="pp"><option value="">Custom amount</option>' + plans.map(function (p) { return '<option value="' + esc(p.id) + '"' + (pay.plan === p.id ? ' selected' : '') + '>' + esc(p.name) + ' — ' + C.inr(p.price) + '</option>'; }).join('') + '</select>' +
      '<label>Amount (₹)</label><input id="pa" type="number" inputmode="decimal" min="1" step="0.01" value="' + esc(pay.amount) + '">' +
      '<label class="chk"><input type="checkbox" id="pr"' + (pay.renew ? ' checked' : '') + (pay.plan ? '' : ' disabled') + '> Renew membership with this plan when recorded</label>' +
      '<label>Pay with</label><div class="seg" id="pmeth">' + [['upi', 'Google Pay / UPI'], ['cash', 'Cash'], ['card', 'Card']].map(function (x) { return '<button data-m="' + x[0] + '" class="' + (pay.method === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div>' +
      '<label>Note / UPI reference (optional)</label><input id="pn" value="' + esc(pay.note) + '" placeholder="e.g. UPI ref no.">';
    if (pay.method === 'upi') {
      h += '<button class="btn gpay" id="goGpay">Pay with Google Pay</button><button class="btn ghost" id="goUpi">Other UPI apps</button><button class="btn ghost" id="goQr">' + (pay.showQr ? 'Hide' : 'Show') + ' UPI QR</button>';
      if (pay.showQr) {
        var up = upiParams();
        h += up.o ? '<div class="qrcard">' + qrSvg(C.upiLink(up.o)) + '<p class="muted">Scan with Google Pay, PhonePe, Paytm or any UPI app.</p></div>' : '<p class="muted">' + esc(up.err) + ' Then the QR appears here.</p>';
      }
    } else {
      h += '<button class="btn" id="goRec">Record ' + (pay.method === 'cash' ? 'cash' : 'card') + ' payment</button>';
    }
    h += '<div id="pErr" class="errtxt"></div>';
    if (pay.pending) {
      h += '<div class="card pend"><b>Did the payment go through?</b><div class="muted">' + C.inr(pay.pending.amount) + ' to ' + esc(store.state.settings.payee_name) + ' for ' + esc(payTargetName(pay.pending.member)) + '. Check the Google Pay success screen or your bank SMS, then confirm.</div>' +
        '<label>UPI reference (optional)</label><input id="pref" placeholder="12-digit UPI ref" value="' + esc(pay.pending.ref || '') + '"><button class="btn" id="pYes">Yes, record payment</button><button class="btn ghost" id="pNo">No / cancel</button></div>';
    }
    var lastInv = pay.lastId && store.invoiceData(pay.lastId);
    if (lastInv) h += '<div class="card pend"><b>🧾 Send invoice to ' + esc(lastInv.member.name) + '</b><div class="muted">Invoice ' + esc(lastInv.no) + ' · ' + C.inr(lastInv.total) + '. Opens WhatsApp with the invoice ready for ' + esc(lastInv.member.phone || 'the member') + '.</div><button class="btn" data-inv="' + esc(pay.lastId) + '">Send invoice on WhatsApp</button></div>';
    var recent = store.recentPayments(8);
    h += '<h3>Recent payments</h3><div class="list">' + (recent.length ? recent.map(function (p) {
      return '<div class="item plain"><div class="row"><span><b>' + esc(p.name) + '</b><div class="muted">' + C.fmtDate(p.paid_at) + ' · ' + esc(p.method) + (p.ref ? ' · ' + esc(p.ref) : '') + '</div></span><span style="text-align:right"><b>' + C.inr(p.amount) + '</b><div><button class="btn ghost small" data-inv="' + esc(p.id) + '">🧾 Invoice</button></div></span></div></div>'; }).join('') : '<div class="empty">No payments yet.</div>') + '</div>';
    view.innerHTML = h;
    Array.prototype.forEach.call(view.querySelectorAll('[data-inv]'), function (b) { b.onclick = function () { invoiceSheet(b.getAttribute('data-inv')); }; });
    bindPayments();
  }
  function payTargetName(id) { var m = store.member(id); return m ? m.name : 'member'; }
  function readForm() {
    var q = $('#pq'); if (!q) return;
    pay.q = q.value; pay.member = $('#pm').value; pay.plan = $('#pp').value; pay.amount = $('#pa').value; pay.renew = $('#pr').checked && !!pay.plan; pay.note = $('#pn').value;
  }
  function planById(id) { return store.state.plans.filter(function (p) { return p.id === id; })[0]; }
  // UPI parameters built from the saved form state only (never touches the DOM).
  function upiParams() {
    var st = store.state.settings, err = '';
    if (!st.upi_id) err = 'Save the gym’s UPI ID first.';
    else if (!payTarget()) err = 'Choose a member.';
    else if (!C.validAmount(pay.amount)) err = 'Enter a valid amount.';
    if (err) return { err: err };
    var plan = planById(pay.plan);
    return { o: { pa: st.upi_id, pn: st.payee_name, am: Number(pay.amount), tn: ((plan ? plan.name : 'Gym fee') + ' ' + payTarget().name).slice(0, 50), tr: 'GF' + Date.now().toString(36).toUpperCase() } };
  }
  // Reads the on-screen form, then validates; shows the problem under the buttons.
  function upiInputs() {
    readForm();
    var r = upiParams();
    if (r.err) { if ($('#pErr')) $('#pErr').textContent = r.err; return null; }
    return r.o;
  }
  function launchUpi(kind) {
    var o = upiInputs(); if (!o) return;
    pay.pending = { member: pay.member, plan: pay.plan, renew: pay.renew, amount: o.am, ref: '' };
    renderPayments();
    if (kind === 'upi') { window.location.href = C.upiLink(o); return; }
    // Google Pay first; if nothing took over the screen, fall back to the normal UPI app chooser.
    var left = false;
    function gone() { left = true; }
    document.addEventListener('visibilitychange', gone, { once: true });
    window.addEventListener('blur', gone, { once: true });
    window.location.href = C.gpayLink(o);
    setTimeout(function () { if (!left) window.location.href = C.upiLink(o); }, 1500);
  }
  function finishPayment(method, ref) {
    var data = pay.pending || { member: pay.member, plan: pay.plan, renew: pay.renew, amount: pay.amount };
    var r = store.recordPayment({ member_id: data.member, amount: data.amount, method: method, ref: ref || pay.note, plan_id: data.plan, renew: data.renew && !!data.plan, note: '' });
    if (!r.ok) { if ($('#pErr')) $('#pErr').textContent = r.error; return; }
    var who = payTargetName(data.member), extra = r.membership ? ' Membership runs ' + C.fmtDate(r.membership.start_date) + ' to ' + C.fmtDate(r.membership.end_date) + '.' : '';
    pay.pending = null; pay.amount = ''; pay.plan = ''; pay.renew = false; pay.note = ''; pay.showQr = false; pay.lastId = r.payment.id;
    renderPayments('Recorded ' + C.inr(r.payment.amount) + ' (' + method + ') for ' + who + '.' + extra);
  }
  function bindPayments() {
    var on = function (id, fn) { var el = $(id); if (el) el.onclick = fn; };
    on('#sSave', function () {
      try { store.setSettings({ upi_id: $('#sUpi').value, payee_name: $('#sName').value }); if (!store.state.settings.upi_id) throw new Error('Enter the UPI ID.'); renderPayments('UPI ID saved.'); }
      catch (e) { $('#sErr').textContent = e.message; }
    });
    $('#pq').oninput = function () {
      pay.q = this.value; var list = pay.q ? store.searchMembers(pay.q) : sortedMembers().slice(0, 10), sel = $('#pm');
      sel.innerHTML = '<option value="">Choose a member…</option>' + list.map(function (m) { return '<option value="' + esc(m.id) + '">' + esc(m.name) + ' — ' + esc(m.phone) + '</option>'; }).join('');
      if (list.length === 1) { sel.value = list[0].id; pay.member = list[0].id; } else pay.member = '';
    };
    $('#pm').onchange = function () { pay.member = this.value; };
    $('#pp').onchange = function () { readForm(); var p = planById(pay.plan); if (p) pay.amount = String(p.price); pay.renew = !!p && pay.renew; renderPayments(); };
    $('#pa').oninput = function () { pay.amount = this.value; };
    $('#pn').oninput = function () { pay.note = this.value; };
    $('#pr').onchange = function () { pay.renew = this.checked; };
    $('#pmeth').onclick = function (e) { var b = e.target.closest('button'); if (b) { readForm(); pay.method = b.getAttribute('data-m'); pay.pending = null; renderPayments(); } };
    on('#goGpay', function () { launchUpi('gpay'); });
    on('#goUpi', function () { launchUpi('upi'); });
    on('#goQr', function () { readForm(); pay.showQr = !pay.showQr; renderPayments(); });
    on('#goRec', function () {
      readForm();
      if (!payTarget()) { $('#pErr').textContent = 'Choose a member.'; return; }
      pay.pending = null; finishPayment(pay.method, pay.note);
    });
    on('#pYes', function () { finishPayment('upi', $('#pref').value); });
    on('#pNo', function () { pay.pending = null; renderPayments(); });
  }

  // ---------- FAQ ----------
  function renderFaq(q) {
    q = (q || '').toLowerCase();
    var all = K.FAQ.map(function (f) { return { q: f.q, a: f.a, custom: false }; }).concat(store.state.faqs.map(function (f) { return { id: f.id, q: f.q, a: f.a, custom: true }; }));
    var list = all.filter(function (f) { return !q || (f.q + ' ' + f.a).toLowerCase().indexOf(q) !== -1; });
    view.innerHTML = back() + '<h2>FAQ</h2><input id="fq" type="search" placeholder="Search questions" value="' + esc(q) + '" autocomplete="off"><p class="muted" style="margin:8px 2px">' + list.length + ' question(s)</p>' +
      '<div id="faqList">' + (list.length ? list.map(function (f) {
        return '<details class="faq"><summary>' + esc(f.q) + (f.custom ? ' <span class="tag">yours</span>' : '') + '</summary><p>' + esc(f.a) + '</p>' + (f.custom ? '<button class="btn small danger" data-del="' + esc(f.id) + '">Delete</button>' : '') + '</details>';
      }).join('') : '<div class="empty">No matching questions.</div>') + '</div>' +
      '<h3>Add your own question</h3><div class="card"><label>Question</label><input id="nq" placeholder="e.g. What are the gym timings?"><label>Answer</label><textarea id="na" rows="3" placeholder="Write the answer members should see"></textarea><button class="btn" id="addFaq">Add question</button><div id="fErr" class="errtxt"></div></div>';
    $('#fq').oninput = function () { var pos = this.selectionStart; renderFaq(this.value); var i = $('#fq'); i.focus(); try { i.setSelectionRange(pos, pos); } catch (e) { /* ignore */ } };
    $('#addFaq').onclick = function () {
      try { store.addFaq($('#nq').value, $('#na').value); renderFaq(''); }
      catch (e) { $('#fErr').textContent = e.message; }
    };
    $('#faqList').onclick = function (e) {
      var b = e.target.closest('button[data-del]'); if (!b) return;
      if (confirm('Delete this question?')) { store.removeFaq(b.getAttribute('data-del')); renderFaq($('#fq').value); }
    };
  }



  // ---------- Dashboard (home screen) ----------
  var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'], WDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  function ordinal(n) { var r = n % 100; return n + ((r >= 11 && r <= 13) ? 'th' : ({ 1: 'st', 2: 'nd', 3: 'rd' }[n % 10] || 'th')); }
  function litres(ml) { return (Math.round(ml / 100) / 10).toString().replace(/\.0$/, '') + 'L'; }
  function hoursText(min) { var h = Math.floor(min / 60), m = min % 60; return h ? h + 'h' + (m ? ' ' + m + 'm' : '') : m + 'm'; }
  function dashFirstName() { var n = myName(); return n === 'Member' ? 'Champ' : n.split(' ')[0]; }
  function renderDashboard() {
    var today = C.todayIST(), DKit = C.DashKit, goals = DKit.get(window.localStorage), visits = C.MemberKit.get(window.localStorage).visits.map(function (v) { return v.date; });
    var wk = C.FitKit.week(window.localStorage, today, visits), td = wk.days[6], ml = DKit.waterToday(window.localStorage, today);
    var diet = DK.get(window.localStorage), plan = diet.plan_id ? W.plan(diet.plan_id) : null, dsum = plan ? DK.summary(diet, today) : null;
    var dt0 = new Date(today + 'T00:00:00Z');
    // workouts card: seven bars, today highlighted
    var maxMin = Math.max(60, Math.max.apply(null, wk.days.map(function (d) { return d.minutes; })));
    var bars = wk.days.map(function (d, i) {
      var pct = d.minutes ? Math.max(10, Math.round(d.minutes / maxMin * 100)) : 0, isT = i === 6;
      return '<div class="dbcol"><div class="dbtrack' + (isT ? ' now' : '') + '"><div class="dbfill' + (isT ? ' now' : '') + '" style="height:' + pct + '%"></div></div><span class="dblab' + (isT ? ' now' : '') + '">' + WDAYS[new Date(d.date + 'T00:00:00Z').getUTCDay()].slice(0, 2) + '</span></div>';
    }).join('');
    // calorie ring
    var R = 58, CIR = 2 * Math.PI * R, frac = Math.min(1, td.kcal / goals.goal_kcal);
    var ring = '<svg class="ring" viewBox="0 0 140 140" role="img" aria-label="Calories today"><circle cx="70" cy="70" r="' + R + '" class="rtrack"/><circle cx="70" cy="70" r="' + R + '" class="rfill" stroke-dasharray="' + (CIR * frac).toFixed(1) + ' ' + CIR.toFixed(1) + '" transform="rotate(-90 70 70)"/></svg>';
    // goals list
    var items = [['🏋️', 'Complete a workout', td.count > 0], ['💧', 'Drink ' + litres(goals.goal_ml) + ' of water', ml >= goals.goal_ml], ['📷', 'Gym check-in today', visits.indexOf(today) !== -1], ['🔥', 'Burn ' + goals.goal_kcal + ' calories', td.kcal >= goals.goal_kcal]];
    if (plan) items.push(['🥗', 'Eat all 4 meals', dsum.today_done >= 4]);
    var doneN = items.filter(function (i) { return i[2]; }).length, pctDone = Math.round(doneN / items.length * 100);
    // schedule: trainer bookings starting today + diet meals
    var sched = store.state.bookings.filter(function (b) { return b.start_date === today && b.status !== 'cancelled'; }).map(function (b) { return { time: b.slot, title: 'Personal training', sub: b.trainer_name + ' · ' + b.package, cls: 'a' }; });
    if (plan) plan.meals.map(function (m) { return { t: diet.times[m.slot], m: m }; }).sort(function (a, b) { return a.t < b.t ? -1 : 1; }).forEach(function (x) {
      sched.push({ time: x.t, title: W.SLOT_LABEL[x.m.slot], sub: x.m.items.slice(0, 2).join(' · '), cls: 'b' });
    });
    var quick = [['attendance', '📷', 'Check-in'], ['payments', '💳', 'Payments'], ['products', '🛒', 'Products'], ['report', '📈', 'Report']];
    view.innerHTML = '<div class="dash"><div class="hello">Hello, <span>' + esc(dashFirstName()) + '</span></div>' +
      '<div class="dgrid"><div class="card dcard"><div class="row dhead"><b>Workouts</b><button class="circ" data-go="workouts" aria-label="Open workouts">↗</button></div><div class="dbars">' + bars + '</div><div class="row dfoot"><span class="muted">Total</span><span class="dval">' + hoursText(wk.minutes) + '</span></div></div>' +
      '<div class="card dcard"><div class="row dhead"><b>Calories</b><button class="circ" data-go="report" aria-label="Open weekly report">↗</button></div><div class="ringwrap">' + ring + '<div class="ringtxt"><b>' + td.kcal + '</b><span>kcal</span></div></div><div class="row dfoot"><span class="muted">Goal</span><span class="dval">' + goals.goal_kcal + '</span></div></div></div>' +
      '<div class="limecard">' + quick.map(function (q) { return '<button class="qk" data-go="' + q[0] + '"><span class="qkc">' + q[1] + '</span><span>' + q[2] + '</span></button>'; }).join('') + '</div>' +
      '<div class="card watercard"><div class="waterfill" style="height:' + Math.min(100, Math.round(ml / goals.goal_ml * 100)) + '%"><svg class="wave" viewBox="0 0 200 20" preserveAspectRatio="none"><path d="M0 10 Q25 0 50 10 T100 10 T150 10 T200 10 V20 H0Z"/></svg></div>' +
      '<div class="wtxt"><b>Water</b><div class="row"><span class="wbig">' + litres(ml) + '</span><span class="wbtns"><button class="circ w" id="wMinus" aria-label="Remove 250 ml">−</button><button class="circ w" id="wPlus" aria-label="Add 250 ml">+</button></span></div><div class="wsub">Goal ' + litres(goals.goal_ml) + ' · each tap is 250 ml</div></div></div>' +
      '<div class="card goalscard"><div class="row dhead"><b>Daily goals</b><button class="circ" id="dGoalEdit" aria-label="Edit goals">✎</button></div>' +
      items.map(function (i) { return '<div class="grow' + (i[2] ? ' done' : '') + '"><span class="gico">' + i[0] + '</span><span class="gtxt">' + esc(i[1]) + '</span><span class="gchk">' + (i[2] ? '✓' : '') + '</span></div>'; }).join('') +
      '<div class="gbar"><div style="width:' + pctDone + '%"></div></div><div class="row dfoot"><span class="muted">Completed</span><span class="dval">' + pctDone + '%</span></div></div>' +
      '<div class="card schedcard"><div class="row"><span class="dpill">' + WDAYS[dt0.getUTCDay()] + ', ' + ordinal(dt0.getUTCDate()) + '</span><span class="dpill wide">' + MONTHS[dt0.getUTCMonth()] + ' ' + dt0.getUTCFullYear() + ' 📅</span></div>' +
      (sched.length ? '<div class="tl">' + sched.map(function (x) { return '<div class="tli"><span class="tlt">' + esc(x.time) + '</span><div class="tlc ' + x.cls + '"><b>' + esc(x.title) + '</b><div class="muted">' + esc(x.sub) + '</div></div></div>'; }).join('') + '</div>' : '<div class="muted" style="margin:18px 2px 4px">Nothing planned today. Start a diet plan or book a trainer and it shows up here.</div><div class="row3"><button class="btn ghost small" data-go="diet">Diet</button><button class="btn ghost small" data-go="trainers">Trainers</button></div>') +
      '<button class="fab" data-go="workouts" aria-label="Start a workout">+</button></div></div>';
    $('#wPlus').onclick = function () { DKit.addWater(window.localStorage, 250, today); renderDashboard(); };
    $('#wMinus').onclick = function () { DKit.addWater(window.localStorage, -250, today); renderDashboard(); };
    $('#dGoalEdit').onclick = function () {
      openSheet('<h2>Daily goals</h2><label>Calories to burn each day</label><input id="gKcal" type="number" inputmode="numeric" value="' + goals.goal_kcal + '"><label>Water each day (ml)</label><input id="gMl" type="number" inputmode="numeric" step="250" value="' + goals.goal_ml + '"><button class="btn" id="gSave">Save</button><div id="gErr" class="errtxt"></div>');
      $('#gSave').onclick = function () { var r = DKit.setGoals(window.localStorage, $('#gKcal').value, $('#gMl').value); if (!r.ok) { $('#gErr').textContent = r.error; return; } closeSheet(); renderDashboard(); };
    };
  }

  // ---------- Member Weekly Report ----------
  function myName() {
    var ph = myPhone(), m = ph ? store.state.members.filter(function (x) { return x.phone === ph; })[0] : null;
    return m ? m.name : 'Member';
  }
  function weekData() {
    var end = C.addDays(C.todayIST(), -7 * rp.off), visits = C.MemberKit.get(window.localStorage).visits.map(function (v) { return v.date; });
    return C.FitKit.week(window.localStorage, end, visits);
  }
  function fatText(g) { return g >= 1000 ? (g / 1000).toFixed(2) + ' kg' : g + ' g'; }
  function renderReport(msg) {
    var wk = weekData(), R = window.GymReport, fit = C.FitKit.load(window.localStorage);
    var h = back() + '<h2>Member Weekly Report</h2>' +
      '<div class="row weeknav"><button class="btn ghost small" id="rpPrev">‹ Prev</button><b>' + C.fmtDate(wk.start) + ' – ' + C.fmtDate(wk.end) + '</b><button class="btn ghost small" id="rpNext"' + (rp.off === 0 ? ' disabled' : '') + '>Next ›</button></div>' +
      (msg ? '<div class="card" style="background:var(--brand-soft)">' + esc(msg) + '</div>' : '');
    h += '<div class="stats4"><div class="card stat"><div class="big">' + wk.count + '</div><div class="muted">Exercises done</div></div><div class="card stat"><div class="big">' + wk.kcal + '</div><div class="muted">Calories burned</div></div>' +
      '<div class="card stat"><div class="big">' + fatText(wk.fat_g) + '</div><div class="muted">Fat loss (energy equiv.)</div></div><div class="card stat"><div class="big">' + wk.active_days + '/7</div><div class="muted">Active days</div></div></div>';
    if (!wk.count) h += '<div class="card"><b>No workouts logged for this week.</b><div class="muted">Open any exercise in Workouts and tap “I did this workout”. It then shows up here with graphs.</div><button class="btn" data-go="workouts">Go to Workouts</button></div>';
    h += '<h3>Calories burned per day</h3><div class="card">' + R.barChart(wk.days, 'kcal', 'calories') + '</div>' +
      '<h3>Workout minutes per day</h3><div class="card">' + R.barChart(wk.days, 'minutes', 'minutes') + '</div>';
    if (wk.top.length) h += '<h3>Top exercises</h3><div class="card">' + R.hBars(wk.top, 'kcal') + '</div>';
    h += '<h3>Body weight</h3><div class="card">';
    if (wk.weight && wk.weight.change != null) h += '<div class="row"><span class="muted">Start → now</span><b>' + wk.weight.start + ' → ' + wk.weight.end + ' kg (' + (wk.weight.change > 0 ? '+' : '') + wk.weight.change + ' kg)</b></div>';
    else if (wk.weight) h += '<div class="row"><span class="muted">Latest weigh-in</span><b>' + wk.weight.end + ' kg</b></div><div class="muted">Add another weigh-in to see the real change.</div>';
    else h += '<div class="muted">No weigh-in in this week. Add one to track real body change.</div>';
    h += R.weightChart(fit.weights.slice(-8)) + '<div class="row" style="margin-top:8px"><input id="rpKg" type="number" inputmode="decimal" step="0.1" min="20" max="300" placeholder="Today’s weight (kg)" style="flex:1"><button class="btn small" id="rpKgSave">Save</button></div><div id="rpErr" class="errtxt"></div></div>';
    h += '<h3>Gym visits</h3><div class="card"><div class="row"><span class="muted">Check-ins this week</span><b>' + wk.gym_visits + '</b></div></div>';
    if (wk.logs.length) h += '<h3>Workouts this week</h3><div class="list">' + wk.logs.slice().reverse().map(function (l) {
      return '<div class="item plain"><div class="row"><span><b>' + esc(l.name) + '</b><div class="muted">' + C.fmtDate(l.date) + ' · ' + l.minutes + ' min · ' + l.kcal + ' kcal</div></span><button class="btn ghost small" data-rm="' + esc(l.id) + '" aria-label="Remove">✕</button></div></div>'; }).join('') + '</div>';
    h += '<button class="btn" id="rpPdf" style="margin-top:14px">📄 Generate PDF report</button><div id="rpPdfMsg" class="muted" style="margin-top:6px"></div>' +
      '<p class="muted">Calories = MET × body weight × time. Fat loss shows the energy equivalent (calories ÷ 7700 per kg). It is an estimate. Real fat change shows in your weigh-ins and depends on food, sleep and rest.</p>';
    view.innerHTML = h;
    $('#rpPrev').onclick = function () { rp.off++; renderReport(); };
    $('#rpNext').onclick = function () { if (rp.off > 0) { rp.off--; renderReport(); } };
    $('#rpKgSave').onclick = function () {
      var r = C.FitKit.logWeight(window.localStorage, $('#rpKg').value, C.todayIST());
      if (!r.ok) { $('#rpErr').textContent = r.error; return; }
      setBodyKg(r.kg); rp.off = 0; renderReport('Weight saved: ' + r.kg + ' kg.');
    };
    Array.prototype.forEach.call(view.querySelectorAll('[data-rm]'), function (b) { b.onclick = function () { C.FitKit.removeLog(window.localStorage, b.getAttribute('data-rm')); renderReport('Workout removed.'); }; });
    $('#rpPdf').onclick = function () {
      var m = $('#rpPdfMsg'); m.textContent = 'Preparing PDF…';
      try {
        var doc = R.weeklyPdf(wk, myName(), fit.weights);
        R.deliver(doc, 'Weekly-Report-' + wk.end + '.pdf', C.GYM.name + ' weekly report').then(function () { m.textContent = 'PDF ready. On Android choose where to save or send it.'; }, function (e) { m.textContent = 'Could not open the share sheet: ' + (e && e.message ? e.message : e); });
      } catch (e) { m.textContent = 'Could not make the PDF: ' + e.message; }
    };
  }

  // ---------- Invoice (owner sends to the member on WhatsApp) ----------
  function invoiceSheet(payId) {
    var v = store.invoiceData(payId); if (!v) return;
    var link = C.waLink(v.member.phone, C.invoiceText(v));
    openSheet('<h2>Invoice ' + esc(v.no) + '</h2><div class="card invoice"><b>' + esc(v.gym.name) + '</b>' + (v.gym.address ? '<div class="muted">' + esc(v.gym.address) + '</div>' : '') + (v.gym.gstin ? '<div class="muted">GSTIN ' + esc(v.gym.gstin) + '</div>' : '') +
      '<hr><div class="row"><span class="muted">Billed to</span><b>' + esc(v.member.name) + '</b></div><div class="row"><span class="muted">WhatsApp</span><b>' + esc(v.member.phone || '–') + '</b></div><div class="row"><span class="muted">Date</span><b>' + C.fmtDate(v.date) + '</b></div>' +
      '<div class="row"><span class="muted">Item</span><b>' + esc(v.item) + '</b></div>' + (v.period ? '<div class="row"><span class="muted">Valid</span><b>' + C.fmtDate(v.period.from) + ' – ' + C.fmtDate(v.period.to) + '</b></div>' : '') +
      (v.gst_pct ? '<div class="row"><span class="muted">GST ' + v.gst_pct + '%</span><b>' + C.inr(v.tax) + '</b></div>' : '') + '<div class="row"><span class="muted">Mode</span><b>' + esc(String(v.method).toUpperCase()) + (v.ref ? ' · ' + esc(v.ref) : '') + '</b></div>' +
      '<div class="row" style="font-size:18px"><span>Total paid</span><b>' + C.inr(v.total) + '</b></div></div>' +
      (link ? '<a class="btn" id="invWa" href="' + esc(link) + '" target="_blank" rel="noopener">💬 Send on WhatsApp</a>' : '<div class="errtxt">This member has no valid 10-digit phone number, so WhatsApp cannot open.</div>') +
      '<button class="btn ghost" id="invPdf">📄 Share invoice as PDF</button><button class="btn ghost" id="invCopy">Copy invoice text</button><div id="invMsg" class="muted" style="margin-top:6px"></div>' +
      '<p class="muted">WhatsApp opens with the message ready for ' + esc(v.member.name) + '. You only tap Send. For the PDF, choose WhatsApp in the share sheet and pick the member.</p>');
    $('#invPdf').onclick = function () {
      try { window.GymReport.deliver(window.GymReport.invoicePdf(v), 'Invoice-' + v.no + '.pdf', v.gym.name + ' invoice ' + v.no).then(function () { $('#invMsg').textContent = 'PDF ready.'; }, function (e) { $('#invMsg').textContent = 'Could not share: ' + (e && e.message ? e.message : e); }); }
      catch (e) { $('#invMsg').textContent = 'Could not make the PDF: ' + e.message; }
    };
    $('#invCopy').onclick = function () {
      var t = C.invoiceText(v);
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(function () { $('#invMsg').textContent = 'Copied.'; }, function () { $('#invMsg').textContent = 'Copy blocked on this device.'; });
      else $('#invMsg').textContent = 'Copy is not available here.';
    };
  }

  // ---------- Settings ----------
  function renderSettings(msg) {
    var st = store.state.settings;
    view.innerHTML = back() + '<h2>Settings</h2>' + (msg ? '<div class="card" style="background:var(--brand-soft)">' + esc(msg) + '</div>' : '') +
      '<div class="card"><b>' + esc(C.GYM.name) + '</b><div class="muted">' + store.state.members.length + ' members · ' + store.state.memberships.length + ' memberships · ' + store.state.payments.length + ' payments · ' + store.state.attendance.length + ' visits</div></div>' +
      '<h3>Payments (Google Pay / UPI)</h3><div class="card"><label style="margin-top:0">Gym UPI ID</label><input id="sUpi" value="' + esc(st.upi_id) + '" placeholder="yourname@bank" autocapitalize="none" autocomplete="off"><label>Name shown when paying</label><input id="sName" value="' + esc(st.payee_name) + '"><button class="btn" id="sSave">Save</button><div id="sErr" class="errtxt"></div></div>' +
      '<h3>Invoice details</h3><div class="card"><label style="margin-top:0">Gym address (printed on invoice)</label><input id="sAddr" value="' + esc(st.gym_address || '') + '" placeholder="Shop no, area, city"><label>GSTIN (optional)</label><input id="sGstin" value="' + esc(st.gstin || '') + '" placeholder="15-character GSTIN" autocapitalize="characters"><label>GST % included in fee (0 if none)</label><input id="sGst" type="number" inputmode="decimal" min="0" max="28" step="0.5" value="' + esc(st.gst_pct || 0) + '"><label>Message at the bottom</label><input id="sFoot" value="' + esc(st.invoice_footer == null ? 'Thank you for training with us!' : st.invoice_footer) + '"><button class="btn" id="sInvSave">Save invoice details</button><div id="sInvErr" class="errtxt"></div></div>' +
      '<h3>Trainer requests</h3><div class="card"><label style="margin-top:0">Gym phone number</label><input id="sPhone" inputmode="tel" value="' + esc(st.gym_phone || '') + '" placeholder="10-digit number"><div class="muted">Members send trainer booking requests to this number by SMS or WhatsApp.</div><button class="btn" id="sPhoneSave">Save number</button><div id="sPhoneErr" class="errtxt"></div></div>' +
      '<h3>Plans</h3>' + store.state.plans.map(function (p) { return '<div class="card row"><div><b>' + esc(p.name) + '</b><div class="muted">' + p.duration_days + ' days</div></div><b>' + C.inr(p.price) + '</b></div>'; }).join('') +
      '<h3>Data (stored on this phone)</h3>' +
      '<button class="btn ghost" id="copyBackup">Copy backup to clipboard</button>' +
      '<label>Restore from backup (paste JSON)</label><textarea id="importBox" rows="3" placeholder="Paste backup JSON here"></textarea>' +
      '<button class="btn ghost" id="importBtn">Restore backup</button>' +
      '<button class="btn ghost" id="demoBtn">Reset to demo data</button>' +
      '<button class="btn danger" id="clearBtn">Clear all members &amp; records</button>' +
      '<p class="muted" style="margin-top:16px">All data lives only on this device. There is no server or sync.</p>';
    $('#sSave').onclick = function () {
      try { store.setSettings({ upi_id: $('#sUpi').value, payee_name: $('#sName').value }); renderSettings('Payment settings saved.'); }
      catch (e) { $('#sErr').textContent = e.message; }
    };
    $('#sInvSave').onclick = function () { try { store.setInvoiceSettings({ gym_address: $('#sAddr').value, gstin: $('#sGstin').value, gst_pct: $('#sGst').value, invoice_footer: $('#sFoot').value }); renderSettings('Invoice details saved.'); } catch (e) { $('#sInvErr').textContent = e.message; } };
    $('#sPhoneSave').onclick = function () { try { store.setContact($('#sPhone').value); renderSettings('Gym phone number saved.'); } catch (e) { $('#sPhoneErr').textContent = e.message; } };
    $('#copyBackup').onclick = function () {
      var text = store.exportJSON();
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function () { renderSettings('Backup copied. Paste it somewhere safe.'); }, function () { fallbackCopy(text); });
      else fallbackCopy(text);
    };
    function fallbackCopy(text) { var ta = $('#importBox'); ta.value = text; ta.select(); try { document.execCommand('copy'); renderSettings('Backup copied.'); } catch (e) { /* user can copy by hand */ } }
    $('#importBtn').onclick = function () {
      try { store.importJSON($('#importBox').value); bot = new C.Assistant(store); renderSettings('Backup restored.'); }
      catch (e) { renderSettings('Could not restore: ' + e.message); }
    };
    $('#demoBtn').onclick = function () { if (confirm('Replace all data with demo data?')) { store.resetDemo(); bot = new C.Assistant(store); renderSettings('Demo data loaded.'); } };
    $('#clearBtn').onclick = function () { if (confirm('Delete ALL members, memberships, payments and visits? This cannot be undone.')) { store.clearAll(); bot = new C.Assistant(store); renderSettings('All records cleared.'); } };
  }

  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && location.hostname !== 'localhost') {
    navigator.serviceWorker.register('sw.js').catch(function () { /* offline cache is optional */ });
  }
  go('dashboard');
})();
