# Razorpay (online payments) – setup

Flow: member taps **Pay online** → Edge Function `rzp-create-order` makes a Razorpay Payment Link (amount = plan price on the server)
→ member pays on Razorpay's page → Razorpay calls `rzp-webhook` → signature is verified → `apply_gateway_payment`
starts the membership, records the payment and creates the invoice number → the app notices and shows "Payment received".

Both functions are already deployed on project gymflow-ai. They stay inactive until you add the secrets below.

## 1. Secrets (Supabase → Edge Functions → Secrets)
| Name | Value |
|---|---|
| `RAZORPAY_KEY_ID` | `rzp_test_...` (Test mode Key ID) |
| `RAZORPAY_KEY_SECRET` | Test mode Key Secret (never share in chat) |
| `RAZORPAY_WEBHOOK_SECRET` | any long random string you invent; the SAME string goes into Razorpay in step 2 |

## 2. Webhook (Razorpay dashboard, Test Mode ON → Account & Settings → Webhooks → Add New Webhook)
- URL: `https://qkedgztqvzoldgpawlyw.supabase.co/functions/v1/rzp-webhook`
- Secret: the same value as `RAZORPAY_WEBHOOK_SECRET`
- Active events: **Payment Link → payment_link.paid**

## 3. Test
Member login → More → My Payments → choose a plan → **Pay online**. On Razorpay's test page use UPI id `success@razorpay`
(or the "Success" test option). A real rupee never moves in Test mode. Within seconds the app shows "Payment received".

## 4. Going live later
Complete Razorpay KYC, switch to Live mode, create Live keys, replace the three secrets, create the webhook again in Live mode.
Fee is charged by Razorpay on live payments only.
