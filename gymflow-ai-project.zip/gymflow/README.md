# GYM Flow (mobile app for Fitness Arena)

Offline Android app that reproduces your n8n GymFlow AI workflows and adds QR attendance, payments, workouts and FAQ. All data is stored on the phone (no server, no internet needed).

## Screens

| Tab | What it does |
|---|---|
| **Assistant** | Plain-English owner chat (read-only, built-in rules, asks which member when several match, never shows health notes, remembers last 10 messages) |
| **Members** | Search by name / phone / email. Tap a member for memberships, payments, **QR card**, check-in, payment |
| **Check-in** | Asks **Owner or Member** every time. Owner: **Show QR**, **Scan**, **Manual**, **Today**. Member: link phone once, **Scan QR**, type code, **History** |
| **Workouts** | 24 exercises in 7 categories (Chest, Shoulders, Biceps, Triceps, Legs, Back, Abs) with animated figures, muscles, steps and tips, plus 3 workout plans |
| **More > Reports** | Revenue, Expiry, Attendance |
| **More > Register member** | Same rules as the n8n form |
| **More > Products** | 46 sample gym products (protein, supplements, accessories, equipment, clothing, shoes) with drawn images, search and category filter. Cart, buyer (member or walk-in), pay with Google Pay / UPI, cash or card, sales summary |
| **More > Goals** | Personal goal for any number of days (1 to 365). Tick each day, see percent, streak, best streak, missed and days left, day-by-day grid, restart or delete. Saved on the phone |
| **More > Trainers** | 8 sample trainers with drawn portraits, filter by focus, packages (trial / 1 month / 3 months), slot and start date, pay with Google Pay / UPI or at the desk, bookings list, send the request to the gym by SMS or WhatsApp |
| **More > Diet** | 8 plans (4 veg, 4 non-veg), 4 meals a day with food pictures and approximate calories and protein. Start a plan, edit meal times, tick meals, daily phone notification at each meal time |
| **More > Payments** | Google Pay / UPI, cash, card. Opens Google Pay on the phone |
| **More > FAQ** | 20 ready questions + add your own |
| **More > Settings** | Gym UPI ID, backup / restore, reset demo data |

## How QR attendance works
Each time **Check-in** is opened the app asks: owner or member.
1. **Owner > Show QR**: the gym QR appears (with an 8-character code). It changes every 5 minutes, so a photo of it stops working.
2. **Member > Scan QR**: the member links their registered phone number once, scans the gym QR (or types the code) and the phone shows a check-in **pass** QR, valid about 15 minutes.
3. **Owner > Scan**: the owner scans the member's pass. Name and exact time (India time) are saved, once per member per day. Expired memberships are blocked unless you choose "Check in anyway".
4. The old member QR cards (Members > QR card) and **Manual** check-in still work.

Honest limit: data lives on each phone with no server, so a member's phone cannot write into the owner's phone by itself. That is why the pass is shown and scanned (two steps). One-scan check-in needs an online database (see Next steps). Also, the same APK on a member's phone contains the full admin screens with local demo data.

## How payments work
1. Save the gym's UPI ID once (Payments or Settings).
2. Pick member, plan or amount, tap **Pay with Google Pay**. The app tries Google Pay first and falls back to the normal UPI app chooser.
3. After paying, come back and tap **Yes, record payment**. The app cannot see the result of a UPI payment, so check the success screen or SMS first.
4. **Show UPI QR** displays a QR any UPI app can scan.

## Products (shop)
The catalog lives in `www/products.js` (name, price, size, colour, description per item; images are drawn in code). Product sales use the same Google Pay / UPI flow as fees: the app opens Google Pay, then you confirm "Yes, record sale". Sales are saved separately from membership payments, so the Revenue report still shows fees only.

## Trainers and Diet
Data lives in `www/wellness.js` (sample trainers, prices and diet plans; edit to match your gym). Meal reminders use the Capacitor Local Notifications plugin, so they are **notifications on the member's phone, not SMS** (real SMS needs a paid gateway and a server). Permissions added: notifications and exact alarms. Trainer booking requests stay on the phone that made them; the member sends them to the gym with the SMS / WhatsApp buttons. The owner saves the gym phone number in More > Settings.

## Get the APK
Your repo already has the workflow `.github/workflows/build-apk.yml` that unzips `gymflow-ai-project.zip` and builds the APK. To get this new version:
1. In your GitHub repo choose **Add file > Upload files**, upload the new `gymflow-ai-project.zip` (same name replaces the old one) and commit.
2. Open **Actions**, wait for **Build GYM Flow APK** to finish (about 5 minutes).
3. Download the **GymFlow-AI-debug-apk** artifact, unzip it and install `app-debug.apk`. Allow "install unknown apps" if asked.
4. The first time you scan, allow the **Camera** permission. Theme: white and black (follows phone dark mode).

Other ways: Android Studio (`npm install`, `npx cap sync android`, `npx cap open android`, Build > Build APK) or `npm run apk` with the Android SDK and JDK 21.

## Tests
`npm test` runs 48 checks (registration rules, reports, assistant, QR round trip, check-in rules, rotating gym code, member pass, UPI links, payments, FAQ, old-data upgrade).

## Updating
The debug APK is signed with a new key on every build, so Android may say "package conflicts". Copy a backup (Settings), uninstall the old app, then install the new one.

## Notes
- Demo data is loaded first. Settings > Clear all members & records starts you fresh.
- Exercise pictures are original animated illustrations drawn in the app (no downloads, work offline). Photos can be added later.
- QR libraries in `www/vendor`: jsQR (Apache-2.0) and qrcode-generator (MIT).
- Not built: syncing between phones, payment auto-confirmation, push notifications.
