# GymFlow AI (mobile app for Fitness Arena)

Offline Android app that reproduces your n8n GymFlow AI workflows. All data is stored on the phone (no server, no internet needed).

## What is inside

| n8n workflow | App screen |
|---|---|
| 1. New Member Registration | **Register** tab (same validation, duplicate block, renewal-without-new-member, India dates, never creates a payment) |
| 2. Operations Agent | **Assistant** tab (plain-English chat, read-only, asks which member when several match, never shows health notes, remembers last 10 messages) |
| 3. Member Search | **Members** tab (name / phone / email, up to 10 results) |
| 4. Membership Lookup | Tap a member (current and past memberships) |
| 5. Payment Lookup | Tap a member (payments, total paid, last payment) |
| 6. Revenue Report | **Reports > Revenue** (default this month, by method and by day) |
| 7. Expiry Report | **Reports > Expiry** (next X days, or already expired) |
| 8. Attendance Report | **Reports > Attendance** (whole gym or one member) |

Difference from n8n: the Assistant here uses built-in rules instead of an OpenAI model, so it understands common phrasings but not every sentence.

The app starts with **demo data**. Use **Settings > Clear all members & records** to start fresh.

## Get the APK (pick one)

### A. GitHub (no installs, ~5 minutes)
1. Create a new GitHub repository and upload everything in this folder (keep `.github/workflows`).
2. Open the **Actions** tab, run **Build GymFlow APK** (it also runs on every push).
3. When it finishes, download the **GymFlow-AI-debug-apk** artifact, unzip it, and install `app-debug.apk` on your phone (allow "install unknown apps").

### B. Android Studio
1. Install Android Studio, then run `npm install` in this folder.
2. `npx cap sync android` and `npx cap open android`.
3. Build > Build APK(s). The file is at `android/app/build/outputs/apk/debug/app-debug.apk`.

### C. Command line (Android SDK + JDK 21 installed)
```
npm install
npm run apk
```

## After editing the app
Edit files in `www/`, then run `npx cap sync android` and rebuild.

## Tests
`npm test` runs 19 checks on registration rules, reports and the assistant.

## Not built yet (same as the n8n version)
Recording payments, renewing through the assistant, and attendance check-in. Real member data can be moved in with Settings > Restore backup (JSON).
