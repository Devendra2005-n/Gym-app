# GymFlow AI (mobile app for Fitness Arena)

Offline Android app that reproduces your n8n GymFlow AI workflows and adds QR attendance, payments, workouts and FAQ. All data is stored on the phone (no server, no internet needed).

## Screens

| Tab | What it does |
|---|---|
| **Assistant** | Plain-English owner chat (read-only, built-in rules, asks which member when several match, never shows health notes, remembers last 10 messages) |
| **Members** | Search by name / phone / email. Tap a member for memberships, payments, **QR card**, check-in, payment |
| **Check-in** | **Scan QR** (camera), **Manual** check-in, **Today** (who came and when, busiest hours) |
| **Workouts** | 24 exercises in 7 categories (Chest, Shoulders, Biceps, Triceps, Legs, Back, Abs) with animated figures, muscles, steps and tips, plus 3 workout plans |
| **More > Reports** | Revenue, Expiry, Attendance |
| **More > Register member** | Same rules as the n8n form |
| **More > Payments** | Google Pay / UPI, cash, card. Opens Google Pay on the phone |
| **More > FAQ** | 14 ready questions + add your own |
| **More > Settings** | Gym UPI ID, backup / restore, reset demo data |

## How QR attendance works
1. Open a member (Members tab) and tap **QR card**. The member keeps a screenshot, or you print it.
2. At the gym desk phone open **Check-in > Scan QR** and point the camera at the member's QR.
3. The visit and the exact time (India time) are saved. One check-in per member per day. Expired memberships are blocked unless you choose "Check in anyway".

Because data lives on one phone, the **desk phone must be the one that scans**. Members cannot check themselves in from their own phones unless the data is moved online (see "Next steps").

## How payments work
1. Save the gym's UPI ID once (Payments or Settings).
2. Pick member, plan or amount, tap **Pay with Google Pay**. The app tries Google Pay first and falls back to the normal UPI app chooser.
3. After paying, come back and tap **Yes, record payment**. The app cannot see the result of a UPI payment, so check the success screen or SMS first.
4. **Show UPI QR** displays a QR any UPI app can scan.

## Get the APK
Your repo already has the workflow `.github/workflows/build-apk.yml` that unzips `gymflow-ai-project.zip` and builds the APK. To get this new version:
1. In your GitHub repo choose **Add file > Upload files**, upload the new `gymflow-ai-project.zip` (same name replaces the old one) and commit.
2. Open **Actions**, wait for **Build GymFlow APK** to finish (about 5 minutes).
3. Download the **GymFlow-AI-debug-apk** artifact, unzip it and install `app-debug.apk`. Allow "install unknown apps" if asked.
4. The first time you scan, allow the **Camera** permission.

Other ways: Android Studio (`npm install`, `npx cap sync android`, `npx cap open android`, Build > Build APK) or `npm run apk` with the Android SDK and JDK 21.

## Tests
`npm test` runs 32 checks (registration rules, reports, assistant, QR round trip, check-in rules, UPI links, payments, FAQ, old-data upgrade).

## Notes
- Demo data is loaded first. Settings > Clear all members & records starts you fresh.
- Exercise pictures are original animated illustrations drawn in the app (no downloads, work offline). Photos can be added later.
- QR libraries in `www/vendor`: jsQR (Apache-2.0) and qrcode-generator (MIT).
- Not built: syncing between phones, payment auto-confirmation, push notifications.
