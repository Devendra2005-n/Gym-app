package com.gymflow.ai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
