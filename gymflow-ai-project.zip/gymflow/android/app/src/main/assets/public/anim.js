/* GymFlow AI - animated exercise figures.
   A side-view stick figure is described by joint ANGLES (so limb lengths never change)
   plus an anchor (foot / hip / hand fixed to the floor, bench or bar).
   Each exercise has two poses; the figure eases between them. All drawings are original. */
(function (root) {
  'use strict';
  var F = 170;                       // floor y inside the 240 x 180 drawing
  var L = { torso: 40, ua: 23, fa: 21, th: 29, sh: 28, neck: 14 };
  var NUM = ['t', 'ua', 'fa', 'th', 'sh', 'ua2', 'fa2', 'th2', 'sh2', 'ft'];

  function d(a) { var r = a * Math.PI / 180; return [Math.cos(r), Math.sin(r)]; }
  function add(p, v, len) { return [p[0] + v[0] * len, p[1] + v[1] * len]; }
  function norm(p) {
    var o = {}; for (var k in p) o[k] = p[k];
    if (o.ua2 == null) o.ua2 = o.ua; if (o.fa2 == null) o.fa2 = o.fa;
    if (o.th2 == null) o.th2 = o.th; if (o.sh2 == null) o.sh2 = o.sh;
    if (o.ft == null) o.ft = 20;
    return o;
  }
  function mix(a, b, u) {
    var o = { anchor: { type: a.anchor.type, x: a.anchor.x + (b.anchor.x - a.anchor.x) * u, y: a.anchor.y + (b.anchor.y - a.anchor.y) * u } };
    NUM.forEach(function (k) { o[k] = a[k] + (b[k] - a[k]) * u; });
    return o;
  }

  // Joint positions for one pose.
  function solve(p) {
    var hip = [0, 0], sho = add(hip, d(p.t), L.torso);
    var elb = add(sho, d(p.ua), L.ua), wri = add(elb, d(p.fa), L.fa);
    var kne = add(hip, d(p.th), L.th), ank = add(kne, d(p.sh), L.sh);
    var a = p.anchor, off;
    if (a.type === 'hip') off = [a.x, a.y];
    else if (a.type === 'foot') off = [a.x - ank[0], a.y - ank[1]];
    else off = [a.x - wri[0], a.y - wri[1]];
    function sh(q) { return [q[0] + off[0], q[1] + off[1]]; }
    var J = { hip: sh(hip), sho: sh(sho), elb: sh(elb), wri: sh(wri), kne: sh(kne), ank: sh(ank) };
    var sho2 = J.sho, hip2 = J.hip;
    J.elb2 = add(sho2, d(p.ua2), L.ua); J.wri2 = add(J.elb2, d(p.fa2), L.fa);
    J.kne2 = add(hip2, d(p.th2), L.th); J.ank2 = add(J.kne2, d(p.sh2), L.sh);
    J.head = add(J.sho, d(p.t), L.neck);
    J.toe = add(J.ank, d(p.ft), 11); J.heel = add(J.ank, d(p.ft), -4);
    J.toe2 = add(J.ank2, d(p.ft), 11); J.heel2 = add(J.ank2, d(p.ft), -4);
    return J;
  }
  function f(n) { return Math.round(n * 10) / 10; }
  function line(a, b, cls, w) { return '<line class="' + cls + '" x1="' + f(a[0]) + '" y1="' + f(a[1]) + '" x2="' + f(b[0]) + '" y2="' + f(b[1]) + '"' + (w ? ' stroke-width="' + w + '"' : '') + '/>'; }
  function poly(pts, cls, w) {
    return '<polyline class="' + cls + '" fill="none" points="' + pts.map(function (q) { return f(q[0]) + ',' + f(q[1]); }).join(' ') + '"' + (w ? ' stroke-width="' + w + '"' : '') + '/>';
  }

  // Draw the figure for progress u (0 = first pose, 1 = second pose). Returns SVG markup.
  function draw(ex, u) {
    var A = ex._A || (ex._A = norm(ex.poses[0])), B = ex._B || (ex._B = norm(ex.poses[1]));
    var p = mix(A, B, u), J = solve(p), hl = ex.hl || 'arm';
    var s = '<line class="floor" x1="12" y1="' + F + '" x2="228" y2="' + F + '"/>';
    (ex.props || []).forEach(function (q) { s += '<line class="prop" x1="' + q[0] + '" y1="' + q[1] + '" x2="' + q[2] + '" y2="' + q[3] + '" stroke-width="' + (q[4] || 4) + '"/>'; });
    if (ex.cable) s += '<line class="cable" x1="' + ex.cable[0] + '" y1="' + ex.cable[1] + '" x2="' + f(J.wri[0]) + '" y2="' + f(J.wri[1]) + '"/>';
    var armC = hl === 'arm' ? 'hl' : 'body', legC = hl === 'leg' ? 'hl' : 'body', torC = (hl === 'torso') ? 'hl' : 'body';
    // far-side limbs first (lighter), then torso, near-side limbs
    s += '<g opacity=".45">' + poly([J.sho, J.elb2, J.wri2], armC, 6) + poly([J.hip, J.kne2, J.ank2], legC, 7) + poly([J.heel2, J.toe2], legC, 5) + '</g>';
    s += line(J.hip, J.sho, torC, 11);
    s += '<circle class="head" cx="' + f(J.head[0]) + '" cy="' + f(J.head[1]) + '" r="8"/>';
    s += poly([J.hip, J.kne, J.ank], legC, 7) + poly([J.heel, J.toe], legC, 5);
    s += poly([J.sho, J.elb, J.wri], armC, 6);
    if (ex.equip === 'bar') s += '<circle class="gear" cx="' + f(J.wri[0]) + '" cy="' + f(J.wri[1]) + '" r="10" fill="none" stroke-width="3"/><circle class="gearfill" cx="' + f(J.wri[0]) + '" cy="' + f(J.wri[1]) + '" r="2.6"/>';
    else if (ex.equip === 'db') s += '<circle class="gearfill" cx="' + f(J.wri[0]) + '" cy="' + f(J.wri[1]) + '" r="5.5"/>';
    else if (ex.equip === 'cable') s += '<circle class="gearfill" cx="' + f(J.wri[0]) + '" cy="' + f(J.wri[1]) + '" r="3.5"/>';
    if (ex.plate) { // leg-press foot plate, perpendicular to the shin
      var dv = d(p.sh + 90); s += line(add(J.ank, dv, 16), add(J.ank, dv, -16), 'gear', 5);
    }
    return s;
  }

  function svgWrap(inner, label) {
    return '<svg class="fig" viewBox="0 0 240 180" role="img" aria-label="' + (label || 'exercise') + '" xmlns="http://www.w3.org/2000/svg">' + inner + '</svg>';
  }
  // Static picture (used in lists): the second pose, which shows the working position.
  function still(ex) { return svgWrap(draw(ex, 1), ex.name); }

  // Looping animation inside a container element. Tap the figure to pause/play.
  function play(el, ex) {
    el.innerHTML = svgWrap('', ex.name);
    var g = el.querySelector('svg'), raf = 0, paused = false, t0 = null, offset = 0, PERIOD = 2600;
    var reduce = root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches;
    function frame(ts) {
      if (t0 === null) t0 = ts;
      var ph = ((ts - t0 + offset) % PERIOD) / PERIOD;       // 0..1
      var u = 0.5 - 0.5 * Math.cos(ph * 2 * Math.PI);          // ease 0 -> 1 -> 0
      g.innerHTML = draw(ex, u);
      raf = root.requestAnimationFrame(frame);
    }
    function start() { if (raf) return; t0 = null; raf = root.requestAnimationFrame(frame); paused = false; }
    function stop() { if (raf) root.cancelAnimationFrame(raf); raf = 0; paused = true; }
    g.innerHTML = draw(ex, 0);
    if (!reduce) start();
    el.addEventListener('click', function () { if (paused) { offset = 0; start(); } else stop(); });
    return { stop: stop, start: start };
  }

  var api = { draw: draw, still: still, play: play, solve: solve, norm: norm, mix: mix, F: F };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.GymAnim = api;
})(typeof window !== 'undefined' ? window : this);
