/* GYM Flow - workout library, plans and default FAQ. */
(function (root) {
  'use strict';
  var F = 170;
  function foot(x, y) { return { type: 'foot', x: x, y: y == null ? F - 5 : y }; }
  function hip(x, y) { return { type: 'hip', x: x, y: y }; }
  function hand(x, y) { return { type: 'hand', x: x, y: y }; }
  function P(o, over) { var r = {}, k; for (k in o) r[k] = o[k]; for (k in over) r[k] = over[k]; return r; }

  var STAND = { t: -90, th: 90, sh: 90, ua: 90, fa: 90, anchor: foot(120) };
  var BENCH = [[48, 130, 150, 130, 8], [58, 134, 58, F, 4], [140, 134, 140, F, 4]];
  var LYING = { t: 180, th: 30, sh: 95, anchor: hip(110, 122) };   // lying on a flat bench

  var CATEGORIES = [
    { id: 'chest', name: 'Chest', icon: '🏋️' },
    { id: 'shoulders', name: 'Shoulders', icon: '🤸' },
    { id: 'biceps', name: 'Biceps', icon: '💪' },
    { id: 'triceps', name: 'Triceps', icon: '🦾' },
    { id: 'legs', name: 'Legs', icon: '🦵' },
    { id: 'back', name: 'Back', icon: '🧗' },
    { id: 'abs', name: 'Abs', icon: '🔥' }
  ];

  var EXERCISES = [
    // ---------------- CHEST ----------------
    { id: 'bench-press', name: 'Barbell Bench Press', cat: 'chest', muscles: ['Chest', 'Front shoulders', 'Triceps'], equip: 'Barbell, flat bench', level: 'Intermediate', sets: '4 × 6–10',
      hl: 'arm', equip_draw: 'bar', props: BENCH,
      poses: [P(LYING, { ua: -90, fa: -90 }), P(LYING, { ua: 40, fa: -95 })],
      steps: ['Lie on the bench with eyes under the bar, feet flat on the floor, shoulder blades pulled together.', 'Unrack the bar and lower it under control to the middle of your chest.', 'Press straight back up until your arms are straight, without bouncing the bar.'],
      tips: ['Keep your wrists straight and over your elbows.', 'Use a spotter when lifting heavy.'] },
    { id: 'push-up', name: 'Push-up', cat: 'chest', muscles: ['Chest', 'Front shoulders', 'Triceps', 'Core'], equip: 'Bodyweight', level: 'Beginner', sets: '3 × 8–15',
      hl: 'arm', equip_draw: 'none',
      poses: [{ t: -25, ua: 90, fa: 90, th: 154, sh: 154, ft: 120, anchor: hand(172, F - 3) }, { t: -12, ua: 150, fa: 70, th: 162, sh: 162, ft: 120, anchor: hand(172, F - 3) }],
      steps: ['Place your hands slightly wider than your shoulders with your body in a straight line from head to heels.', 'Bend your elbows and lower your chest until it is just above the floor.', 'Push the floor away until your arms are straight again.'],
      tips: ['Squeeze your glutes and abs so your hips do not sag.', 'Too hard? Do them with your knees on the floor.'] },
    { id: 'incline-press', name: 'Incline Dumbbell Press', cat: 'chest', muscles: ['Upper chest', 'Front shoulders', 'Triceps'], equip: 'Dumbbells, incline bench', level: 'Intermediate', sets: '3 × 8–12',
      hl: 'arm', equip_draw: 'db', props: [[104, 129, 66, 84, 7], [100, 134, 100, F, 4], [136, 134, 136, F, 4]],
      poses: [{ t: -128, th: 30, sh: 100, ua: -80, fa: -85, anchor: hip(110, 124) }, { t: -128, th: 30, sh: 100, ua: 60, fa: -95, anchor: hip(110, 124) }],
      steps: ['Set the bench to a low incline (about 30–45°) and sit back with a dumbbell on each thigh.', 'Kick the weights up to chest level, then press them overhead until your arms are straight.', 'Lower slowly until your elbows are a little below the bench.'],
      tips: ['Do not set the bench too steep – it turns into a shoulder exercise.', 'Keep your feet planted.'] },
    { id: 'pullover', name: 'Dumbbell Pullover', cat: 'chest', muscles: ['Chest', 'Lats', 'Triceps (long head)'], equip: 'One dumbbell, flat bench', level: 'Intermediate', sets: '3 × 10–12',
      hl: 'arm', equip_draw: 'db', props: BENCH,
      poses: [P(LYING, { ua: -90, fa: -90 }), P(LYING, { ua: -190, fa: -185 })],
      steps: ['Lie across or along the bench holding one dumbbell above your chest with both hands.', 'With a slight bend in your elbows, lower the weight in an arc behind your head until you feel a stretch.', 'Pull it back over your chest along the same arc.'],
      tips: ['Choose a light weight first; this is a stretch-and-control move.', 'Keep your ribs down and your lower back relaxed.'] },

    // ---------------- SHOULDERS ----------------
    { id: 'overhead-press', name: 'Overhead Press', cat: 'shoulders', muscles: ['Shoulders', 'Triceps', 'Upper chest'], equip: 'Barbell or dumbbells', level: 'Intermediate', sets: '4 × 6–10',
      hl: 'arm', equip_draw: 'bar',
      poses: [P(STAND, { ua: 75, fa: -80 }), P(STAND, { ua: -85, fa: -90 })],
      steps: ['Stand tall with feet shoulder-width apart and the weight resting at your shoulders.', 'Tighten your abs and glutes, then press the weight straight overhead.', 'Lower it back to your shoulders under control.'],
      tips: ['Do not lean back; keep your ribs down.', 'Move your head slightly back and forward as the bar passes your face.'] },
    { id: 'lateral-raise', name: 'Lateral Raise', cat: 'shoulders', muscles: ['Side shoulders'], equip: 'Dumbbells', level: 'Beginner', sets: '3 × 12–15',
      hl: 'arm', equip_draw: 'db',
      poses: [P(STAND, { ua: 90, fa: 90 }), P(STAND, { ua: 15, fa: 30 })],
      steps: ['Stand holding a light dumbbell in each hand at your sides, elbows slightly bent.', 'Raise your arms out to the sides until they reach shoulder height.', 'Lower slowly over about three seconds.'],
      tips: ['Lead with your elbows, not your hands.', 'Light weight and no swinging works best. (The picture is a side view, so the arms look like they move forward.)'] },
    { id: 'front-raise', name: 'Front Raise', cat: 'shoulders', muscles: ['Front shoulders', 'Upper chest'], equip: 'Dumbbells or plate', level: 'Beginner', sets: '3 × 10–12',
      hl: 'arm', equip_draw: 'db',
      poses: [P(STAND, { ua: 90, fa: 90 }), P(STAND, { ua: 0, fa: 0 })],
      steps: ['Stand holding dumbbells in front of your thighs.', 'Raise both arms straight in front of you to shoulder height.', 'Lower them slowly without swinging your body.'],
      tips: ['Keep a soft bend in your elbows.', 'Stop at shoulder height – going higher adds little.'] },

    // ---------------- BICEPS ----------------
    { id: 'barbell-curl', name: 'Barbell Curl', cat: 'biceps', muscles: ['Biceps', 'Forearms'], equip: 'Barbell or EZ-bar', level: 'Beginner', sets: '3 × 8–12',
      hl: 'arm', equip_draw: 'bar',
      poses: [P(STAND, { ua: 90, fa: 75 }), P(STAND, { ua: 88, fa: -70 })],
      steps: ['Stand tall holding the bar with palms facing forward, hands shoulder-width apart.', 'Keeping your elbows by your sides, curl the bar up towards your shoulders.', 'Squeeze at the top, then lower slowly until your arms are straight.'],
      tips: ['No swinging – if you need momentum, the weight is too heavy.', 'Keep your elbows pinned beside your ribs.'] },
    { id: 'hammer-curl', name: 'Hammer Curl', cat: 'biceps', muscles: ['Biceps', 'Brachialis', 'Forearms'], equip: 'Dumbbells', level: 'Beginner', sets: '3 × 10–12',
      hl: 'arm', equip_draw: 'db',
      poses: [P(STAND, { ua: 92, fa: 80 }), P(STAND, { ua: 95, fa: -75 })],
      steps: ['Stand with a dumbbell in each hand, palms facing your thighs (like holding a hammer).', 'Curl the weights up without turning your wrists.', 'Lower under control and repeat, or alternate arms.'],
      tips: ['Great for thicker-looking arms and stronger grip.', 'Keep your upper arms still.'] },
    { id: 'concentration-curl', name: 'Concentration Curl', cat: 'biceps', muscles: ['Biceps (peak)'], equip: 'One dumbbell, bench', level: 'Beginner', sets: '3 × 10–12 each arm',
      hl: 'arm', equip_draw: 'db', props: [[78, 142, 128, 142, 8], [88, 146, 88, F, 4], [120, 146, 120, F, 4]],
      poses: [{ t: -30, th: 5, sh: 95, ua: 104, fa: 85, anchor: hip(100, 134) }, { t: -30, th: 5, sh: 95, ua: 104, fa: -60, anchor: hip(100, 134) }],
      steps: ['Sit on a bench with your legs apart and rest the back of one upper arm against your inner thigh.', 'Curl the dumbbell up towards your shoulder.', 'Squeeze the biceps, then lower slowly and finish all reps before switching arms.'],
      tips: ['Do not let your elbow move off your thigh.', 'Use a lighter weight than normal curls.'] },

    // ---------------- TRICEPS ----------------
    { id: 'pushdown', name: 'Tricep Pushdown', cat: 'triceps', muscles: ['Triceps'], equip: 'Cable machine', level: 'Beginner', sets: '3 × 10–15',
      hl: 'arm', equip_draw: 'cable', cable: [160, 22], props: [[140, 20, 176, 20, 5], [170, 20, 170, F, 6]],
      poses: [P(STAND, { t: -85, ua: 90, fa: -35 }), P(STAND, { t: -85, ua: 90, fa: 88 })],
      steps: ['Stand facing the cable machine, hold the bar or rope, and pin your elbows to your sides.', 'Push the handle down until your arms are fully straight.', 'Let it rise slowly until your forearms are just above parallel.'],
      tips: ['Only your forearms should move.', 'Lean forward slightly and keep your shoulders down.'] },
    { id: 'overhead-extension', name: 'Overhead Tricep Extension', cat: 'triceps', muscles: ['Triceps (long head)'], equip: 'One dumbbell', level: 'Beginner', sets: '3 × 10–12',
      hl: 'arm', equip_draw: 'db',
      poses: [P(STAND, { ua: 270, fa: 150 }), P(STAND, { ua: 270, fa: 270 })],
      steps: ['Stand holding one dumbbell with both hands above your head.', 'Bend your elbows to lower the weight behind your head.', 'Straighten your arms to press it back up.'],
      tips: ['Keep your elbows pointing forward, close to your ears.', 'Do not arch your lower back.'] },
    { id: 'bench-dips', name: 'Bench Dips', cat: 'triceps', muscles: ['Triceps', 'Chest', 'Front shoulders'], equip: 'Bench, bodyweight', level: 'Beginner', sets: '3 × 8–12',
      hl: 'arm', equip_draw: 'none', props: [[50, 130, 102, 130, 8], [60, 134, 60, F, 4], [94, 134, 94, F, 4]],
      poses: [{ t: -100, ua: 90, fa: 90, th: 45, sh: 85, anchor: hand(97, 121) }, { t: -100, ua: 140, fa: 60, th: 28, sh: 68, anchor: hand(97, 121) }],
      steps: ['Sit on the edge of a bench, place your hands beside your hips, and slide your bottom off the front.', 'Bend your elbows to lower yourself until your upper arms are about parallel with the floor.', 'Press back up until your arms are straight.'],
      tips: ['Keep your back close to the bench.', 'Bend your knees to make it easier, straighten them to make it harder.'] },
    { id: 'skull-crusher', name: 'Skull Crusher', cat: 'triceps', muscles: ['Triceps'], equip: 'EZ-bar or dumbbells, bench', level: 'Intermediate', sets: '3 × 8–12',
      hl: 'arm', equip_draw: 'bar', props: BENCH,
      poses: [P(LYING, { ua: -90, fa: -90 }), P(LYING, { ua: -90, fa: -190 })],
      steps: ['Lie on a bench holding the bar above your chest with straight arms.', 'Bend only your elbows to lower the bar towards your forehead.', 'Extend your arms to return to the start.'],
      tips: ['Keep your upper arms still and elbows pointing at the ceiling.', 'Start light to protect your elbows.'] },

    // ---------------- LEGS ----------------
    { id: 'squat', name: 'Barbell Squat', cat: 'legs', muscles: ['Quads', 'Glutes', 'Hamstrings', 'Core'], equip: 'Barbell, squat rack', level: 'Intermediate', sets: '4 × 6–10',
      hl: 'leg', equip_draw: 'bar',
      poses: [P(STAND, { ua: 120, fa: -60 }), { t: -55, th: 8, sh: 112, ua: 120, fa: -60, anchor: foot(120) }],
      steps: ['Set the bar across your upper back, feet shoulder-width apart, toes slightly out.', 'Push your hips back and bend your knees, lowering until your thighs are about parallel to the floor.', 'Drive through your whole foot to stand back up.'],
      tips: ['Keep your chest up and knees in line with your toes.', 'Learn the movement with just the bar or bodyweight first.'] },
    { id: 'lunge', name: 'Reverse Lunge', cat: 'legs', muscles: ['Quads', 'Glutes', 'Hamstrings'], equip: 'Bodyweight or dumbbells', level: 'Beginner', sets: '3 × 10 each leg',
      hl: 'leg', equip_draw: 'db',
      poses: [P(STAND, {}), { t: -90, th: 5, sh: 95, th2: 110, sh2: 170, ua: 90, fa: 90, anchor: foot(135) }],
      steps: ['Stand tall, then step one foot back and lower straight down.', 'Stop when your back knee is just above the floor and your front thigh is about level.', 'Push through your front foot to return to standing, then switch legs.'],
      tips: ['Keep your torso upright.', 'Your front knee should stay over your ankle.'] },
    { id: 'leg-press', name: 'Leg Press', cat: 'legs', muscles: ['Quads', 'Glutes', 'Hamstrings'], equip: 'Leg press machine', level: 'Beginner', sets: '3 × 10–15',
      hl: 'leg', equip_draw: 'none', plate: true, props: [[34, 118, 80, 142, 8], [88, 152, 168, 76, 4]],
      poses: [{ t: -150, th: -40, sh: -40, ua: 0, fa: 0, ft: -40, anchor: hip(80, 132) }, { t: -150, th: -105, sh: -25, ua: 0, fa: 0, ft: -40, anchor: hip(80, 132) }],
      steps: ['Sit with your back and hips flat against the pad and place your feet shoulder-width apart on the plate.', 'Release the safety and lower the plate until your knees are bent to about 90°.', 'Press the plate away without locking your knees.'],
      tips: ['Do not let your lower back peel off the pad.', 'Never lock your knees hard at the top.'] },
    { id: 'rdl', name: 'Romanian Deadlift', cat: 'legs', muscles: ['Hamstrings', 'Glutes', 'Lower back'], equip: 'Barbell or dumbbells', level: 'Intermediate', sets: '3 × 8–12',
      hl: 'leg', equip_draw: 'bar',
      poses: [P(STAND, {}), { t: -20, th: 75, sh: 85, ua: 90, fa: 90, anchor: foot(120) }],
      steps: ['Stand holding the bar at your thighs with a soft bend in your knees.', 'Push your hips back and slide the bar down your legs, keeping your back flat, until you feel a hamstring stretch.', 'Drive your hips forward to stand tall.'],
      tips: ['It is a hip hinge, not a squat: knees stay almost still.', 'Keep the bar close to your legs.'] },
    { id: 'calf-raise', name: 'Standing Calf Raise', cat: 'legs', muscles: ['Calves'], equip: 'Bodyweight or dumbbells', level: 'Beginner', sets: '4 × 12–20',
      hl: 'leg', equip_draw: 'db',
      poses: [P(STAND, { ft: 15 }), P(STAND, { ft: 65, anchor: foot(120, F - 13) })],
      steps: ['Stand with your feet hip-width apart, holding light dumbbells if you like.', 'Rise up onto the balls of your feet as high as you can.', 'Pause for a second, then lower slowly.'],
      tips: ['Use a step to get a deeper stretch at the bottom.', 'Go slow – calves respond to control, not speed.'] },

    // ---------------- BACK ----------------
    { id: 'pull-up', name: 'Pull-up', cat: 'back', muscles: ['Lats', 'Upper back', 'Biceps'], equip: 'Pull-up bar', level: 'Intermediate', sets: '3 × 5–10',
      hl: 'torso', equip_draw: 'none', props: [[78, 30, 162, 30, 5], [78, 30, 78, F, 3], [162, 30, 162, F, 3]],
      poses: [{ t: -90, ua: 270, fa: 270, th: 100, sh: 145, anchor: hand(118, 30) }, { t: -90, ua: 110, fa: 290, th: 100, sh: 145, anchor: hand(118, 30) }],
      steps: ['Hang from the bar with your hands slightly wider than your shoulders and arms straight.', 'Pull your elbows down and back until your chin is above the bar.', 'Lower yourself slowly back to a full hang.'],
      tips: ['Cannot do one yet? Use an assisted machine or a resistance band.', 'Avoid kicking or swinging.'] },
    { id: 'bent-row', name: 'Bent-over Row', cat: 'back', muscles: ['Lats', 'Mid back', 'Biceps', 'Rear shoulders'], equip: 'Barbell or dumbbells', level: 'Intermediate', sets: '4 × 8–12',
      hl: 'torso', equip_draw: 'bar',
      poses: [{ t: -25, th: 75, sh: 85, ua: 90, fa: 90, anchor: foot(120) }, { t: -25, th: 75, sh: 85, ua: 165, fa: 95, anchor: foot(120) }],
      steps: ['Hold the bar, hinge forward at your hips with a flat back and soft knees.', 'Pull the bar towards your lower ribs, squeezing your shoulder blades together.', 'Lower it slowly until your arms are straight.'],
      tips: ['Keep your neck in line with your spine.', 'Do not jerk with your lower back.'] },

    // ---------------- ABS ----------------
    { id: 'crunch', name: 'Crunch', cat: 'abs', muscles: ['Upper abs'], equip: 'Bodyweight', level: 'Beginner', sets: '3 × 12–20',
      hl: 'torso', equip_draw: 'none',
      poses: [{ t: 180, th: -55, sh: 100, ua: -40, fa: -170, anchor: hip(130, F - 9) }, { t: 210, th: -55, sh: 100, ua: -10, fa: -140, anchor: hip(130, F - 9) }],
      steps: ['Lie on your back with your knees bent and feet flat, arms crossed over your chest.', 'Curl your shoulders off the floor by tightening your abs.', 'Pause, then lower slowly.'],
      tips: ['Do not pull on your neck.', 'Small, controlled movement beats big, fast ones.'] },
    { id: 'plank', name: 'Forearm Plank', cat: 'abs', muscles: ['Core', 'Shoulders', 'Glutes'], equip: 'Bodyweight', level: 'Beginner', sets: '3 × 20–60 sec hold',
      hl: 'torso', equip_draw: 'none',
      poses: [{ t: -8, ua: 90, fa: 0, th: 166, sh: 166, ft: 120, anchor: hand(150, F - 3) }, { t: -3, ua: 90, fa: 0, th: 162, sh: 162, ft: 120, anchor: hand(150, F - 3) }],
      steps: ['Rest on your forearms with elbows under your shoulders and your legs straight behind you.', 'Tighten your abs and glutes so your body forms one straight line.', 'Hold the position while breathing normally.'],
      tips: ['Do not let your hips sag or pike up.', 'Stop when your form breaks – shorter, clean holds are better.'] },
    { id: 'leg-raise', name: 'Lying Leg Raise', cat: 'abs', muscles: ['Lower abs', 'Hip flexors'], equip: 'Bodyweight', level: 'Intermediate', sets: '3 × 10–15',
      hl: 'leg', equip_draw: 'none',
      poses: [{ t: 180, th: 0, sh: 0, ua: 0, fa: 0, ft: -80, anchor: hip(130, F - 9) }, { t: 180, th: -90, sh: -90, ua: 0, fa: 0, ft: -80, anchor: hip(130, F - 9) }],
      steps: ['Lie on your back with your legs straight and hands under your hips or by your sides.', 'Keeping your legs straight, raise them until they point at the ceiling.', 'Lower slowly, stopping just before they touch the floor.'],
      tips: ['If your lower back lifts, bend your knees slightly.', 'Press your lower back gently into the floor.'] }
  ];
  EXERCISES.forEach(function (e) { e.equip_draw = e.equip_draw || 'none'; e.equip_label = e.equip; e.equip = e.equip_draw; });

  var PLANS = [
    { id: 'beginner', name: 'Beginner Full Body', blurb: '3 days a week (for example Mon / Wed / Fri). Rest a day between sessions.',
      days: [
        { name: 'Day 1 – Full Body A', items: [['squat', '3 × 10'], ['bench-press', '3 × 10'], ['bent-row', '3 × 10'], ['overhead-press', '2 × 10'], ['plank', '3 × 30 sec']] },
        { name: 'Day 2 – Full Body B', items: [['rdl', '3 × 10'], ['push-up', '3 × 8–12'], ['bent-row', '3 × 10'], ['barbell-curl', '2 × 12'], ['pushdown', '2 × 12'], ['crunch', '3 × 15']] },
        { name: 'Day 3 – Full Body C', items: [['lunge', '3 × 10 each'], ['incline-press', '3 × 10'], ['lateral-raise', '3 × 12'], ['hammer-curl', '2 × 12'], ['bench-dips', '2 × 10'], ['leg-raise', '3 × 10']] }
      ] },
    { id: 'split5', name: '5-Day Body-Part Split', blurb: 'Monday to Friday, one focus per day. Weekend rest.',
      days: [
        { name: 'Mon – Chest', items: [['bench-press', '4 × 8'], ['incline-press', '3 × 10'], ['pullover', '3 × 12'], ['push-up', '2 × max']] },
        { name: 'Tue – Back & Biceps', items: [['pull-up', '4 × max'], ['bent-row', '4 × 8'], ['barbell-curl', '3 × 10'], ['hammer-curl', '3 × 12']] },
        { name: 'Wed – Shoulders & Abs', items: [['overhead-press', '4 × 8'], ['lateral-raise', '3 × 12'], ['front-raise', '3 × 12'], ['crunch', '3 × 15'], ['leg-raise', '3 × 12']] },
        { name: 'Thu – Arms', items: [['barbell-curl', '3 × 10'], ['concentration-curl', '3 × 12'], ['pushdown', '3 × 12'], ['skull-crusher', '3 × 10'], ['overhead-extension', '3 × 12']] },
        { name: 'Fri – Legs', items: [['squat', '4 × 8'], ['leg-press', '3 × 12'], ['rdl', '3 × 10'], ['lunge', '3 × 10 each'], ['calf-raise', '4 × 15']] }
      ] },
    { id: 'ppl', name: 'Push / Pull / Legs', blurb: 'Three different sessions. Run them in a loop: Push, Pull, Legs, rest (or twice a week if you recover well).',
      days: [
        { name: 'Push', items: [['bench-press', '4 × 8'], ['overhead-press', '3 × 8'], ['incline-press', '3 × 10'], ['lateral-raise', '3 × 12'], ['pushdown', '3 × 12'], ['bench-dips', '2 × 10']] },
        { name: 'Pull', items: [['pull-up', '4 × max'], ['bent-row', '4 × 8'], ['barbell-curl', '3 × 10'], ['hammer-curl', '3 × 12'], ['concentration-curl', '2 × 12']] },
        { name: 'Legs', items: [['squat', '4 × 8'], ['rdl', '3 × 10'], ['leg-press', '3 × 12'], ['lunge', '3 × 10 each'], ['calf-raise', '4 × 15'], ['plank', '3 × 45 sec']] }
      ] }
  ];

  var FAQ = [
    { q: 'How does QR attendance work?', a: 'Open Check-in. The app asks whether you are the owner or a member. The owner picks “Owner” and shows the gym QR (it changes every 5 minutes). A member picks “Member”, scans that QR with the camera, and the phone shows a check-in pass. The owner then opens Owner → Scan and scans the member’s pass. The visit and exact time are saved, once per member per day.' },
    { q: 'Why does a member need to link a phone number?', a: 'The first time a member opens Check-in as a member, they enter the mobile number they gave the gym. It is saved only on their phone and goes inside their pass so the owner can find them. A wrong number shows “Member not found” at the desk.' },
    { q: 'The gym QR or pass says it is old. What now?', a: 'The gym QR changes every 5 minutes and a member pass works for about 15 minutes. Ask the owner to show the current QR (Owner → Show QR) and scan it again. You can also type the 8-character code shown under the QR.' },
    { q: 'A QR will not scan. What now?', a: 'Increase the phone brightness, hold the QR steady about 20–30 cm from the camera, and clean the lens. A member can type the code under the gym QR instead, and the owner can use Check-in → Owner → Manual and search by name or phone.' },
    { q: 'What if a member’s membership has expired?', a: 'The owner’s scan shows “Membership expired” and the visit is not saved. You can renew first (Payments → tick “Renew membership”) or choose “Check in anyway” if you want to allow the visit.' },
    { q: 'How do I take a payment with Google Pay?', a: 'Save the gym’s UPI ID once (More → Payments or Settings). Then open Payments, pick the member and amount, and tap “Pay with Google Pay”. Google Pay opens on the phone. After paying, come back and tap “Yes, record payment”.' },
    { q: 'Does the app confirm that the Google Pay payment went through?', a: 'No. UPI apps do not send the result back to a web-style app, so you must check the success screen / your bank SMS yourself and then tap “Yes, record payment”. Add the UPI reference number so you can match it later.' },
    { q: 'Google Pay did not open. What should I do?', a: 'Make sure Google Pay is installed and set up. The app falls back to the normal UPI app chooser; pick any UPI app there. You can also tap “Show UPI QR” and let the member scan it from their own phone.' },
    { q: 'How do I renew a membership?', a: 'Open Payments, choose the member and a plan, tick “Renew membership with this plan”, and record the payment. If the old membership is still running, the new one starts the day after it ends.' },
    { q: 'Where is my data stored? Can I lose it?', a: 'Everything is stored only on this phone. If you uninstall the app or clear its data, it is gone. Use Settings → Copy backup regularly and keep the text somewhere safe.' },
    { q: 'Can two phones share the same data?', a: 'Not yet. Each phone keeps its own records. Use one phone (for example the gym desk phone) as the main device. Syncing between phones needs an online database, which can be added later.' },
    { q: 'Which workout plan should a beginner start with?', a: 'The Beginner Full Body plan: three days a week, one rest day between sessions. Start with light weights, learn the movement, and add weight slowly.' },
    { q: 'How many sets and reps should I do?', a: 'As a rule of thumb: 6–10 reps for strength, 8–12 for muscle size, 12–20 for endurance. Stop a rep or two before you cannot keep good form.' },
    { q: 'Should I warm up and stretch?', a: 'Yes. Spend 5–10 minutes on light cardio and a few light sets of your first exercise. Stretch gently after training.' },
    { q: 'I feel sharp pain during an exercise.', a: 'Stop. Muscle burn is normal; sharp or joint pain is not. Rest, and ask a trainer or doctor before continuing. The workouts in this app are general guidance, not medical advice.' },
    { q: 'Why do the exercise figures look like stick figures?', a: 'They are simple animated illustrations drawn inside the app, so they work offline and never need downloads. Tap a figure to pause or play it. Ask your trainer to show the exact form in person.' }
  ];

  var api = { CATEGORIES: CATEGORIES, EXERCISES: EXERCISES, PLANS: PLANS, FAQ: FAQ };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.GymContent = api;
})(typeof window !== 'undefined' ? window : this);
