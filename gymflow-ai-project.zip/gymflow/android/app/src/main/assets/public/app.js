(function () {
  'use strict';
  var C = window.GymCore;
  var store = new C.Store(window.localStorage);
  var bot = new C.Assistant(store);
  var view = document.getElementById('view');
  var tabsEl = document.getElementById('tabs');
  var sheet = document.getElementById('sheet');
  var sheetBg = document.getElementById('sheetBg');
  var current = 'assistant';
  var chatLog = [{ me: false, text: 'Hi! I’m your gym assistant for ' + C.GYM.name + '. Ask me about members, memberships, payments, revenue, expiries or attendance. I’m read-only.' }];
  var reportTab = 'revenue';
  var reportState = { from: '', to: '', days: 7, mode: 'soon', member: '' };

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function badge(status) { return '<span class="badge ' + esc(status) + '">' + esc(status) + '</span>'; }

  document.getElementById('gymName').textContent = C.GYM.name;
  document.getElementById('todayPill').textContent = C.fmtDate(store.today());

  // ---------- navigation ----------
  tabsEl.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-tab]'); if (!b) return;
    go(b.getAttribute('data-tab'));
  });
  function go(tab) {
    current = tab;
    Array.prototype.forEach.call(tabsEl.querySelectorAll('button'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-tab') === tab);
    });
    document.body.classList.toggle('chat-open', tab === 'assistant');
    ({ assistant: renderAssistant, members: renderMembers, reports: renderReports, register: renderRegister, settings: renderSettings })[tab]();
    view.scrollTop = 0;
  }

  // ---------- sheet ----------
  function openSheet(html) { sheet.innerHTML = html + '<button class="btn ghost" id="closeSheet">Close</button>'; sheet.hidden = false; sheetBg.hidden = false; $('#closeSheet').onclick = closeSheet; }
  function closeSheet() { sheet.hidden = true; sheetBg.hidden = true; }
  sheetBg.addEventListener('click', closeSheet);

  // ---------- Assistant (chat) ----------
  var CHIPS = ['Revenue this month', 'Who expires in 7 days?', 'Show expired members', 'Attendance this week', 'Find Patil'];
  function renderAssistant() {
    view.innerHTML = '<div class="chat"><div class="msgs" id="msgs"></div>' +
      '<div class="chips">' + CHIPS.map(function (c) { return '<button data-q="' + esc(c) + '">' + esc(c) + '</button>'; }).join('') + '</div>' +
      '<form class="composer" id="chatForm" autocomplete="off"><input id="chatIn" placeholder="Ask about your gym…" enterkeyhint="send"><button type="submit" aria-label="Send">&#10148;</button></form></div>';
    paintChat();
    $('#chatForm').onsubmit = function (e) { e.preventDefault(); var i = $('#chatIn'); send(i.value); i.value = ''; };
    view.querySelector('.chips').onclick = function (e) { var b = e.target.closest('button'); if (b) send(b.getAttribute('data-q')); };
  }
  function paintChat() {
    var box = $('#msgs'); if (!box) return;
    box.innerHTML = chatLog.map(function (m) { return '<div class="msg ' + (m.me ? 'me' : 'bot') + '">' + esc(m.text) + '</div>'; }).join('');
    box.scrollTop = box.scrollHeight;
  }
  function send(text) {
    text = String(text || '').trim(); if (!text) return;
    chatLog.push({ me: true, text: text });
    chatLog.push({ me: false, text: bot.ask(text) });
    paintChat();
  }

  // ---------- Members ----------
  function renderMembers() {
    view.innerHTML = '<h2>Members</h2><input id="q" type="search" placeholder="Search name, phone or email" autocomplete="off">' +
      '<p class="muted" id="hint" style="margin:8px 2px"></p><div class="list" id="results"></div>';
    var q = $('#q');
    function run() {
      var term = q.value.trim();
      var rows = term ? store.searchMembers(term) : store.state.members.slice().sort(function (a, b) { return a.name.localeCompare(b.name); }).slice(0, 10);
      $('#hint').textContent = term ? rows.length + ' result(s), up to 10 shown' : 'Showing the first 10 members. Type to search.';
      $('#results').innerHTML = rows.length ? rows.map(function (m) {
        var active = store.hasActive(m.id);
        return '<div class="item" data-id="' + esc(m.id) + '"><div class="row"><span class="name">' + esc(m.name) + '</span>' + badge(active ? 'active' : 'expired') + '</div><div class="muted">' + esc(m.phone) + ' · ' + esc(m.email) + '</div></div>';
      }).join('') : '<div class="empty">No members found.</div>';
    }
    q.oninput = run; run();
    $('#results').onclick = function (e) { var it = e.target.closest('.item'); if (it) showMember(it.getAttribute('data-id')); };
  }
  function showMember(id) {
    var m = store.member(id); if (!m) return;
    var ms = store.membershipLookup(id), pay = store.paymentLookup(id);
    var html = '<h2>' + esc(m.name) + '</h2><div class="muted">' + esc(m.phone) + ' · ' + esc(m.email) + '</div>';
    html += '<h3>Memberships</h3>' + (ms.length ? ms.map(function (x) {
      return '<div class="card"><div class="row"><b>' + esc(x.plan) + '</b>' + badge(x.status) + '</div><div class="muted">' + C.fmtDate(x.start_date) + ' → ' + C.fmtDate(x.end_date) + (x.status === 'active' ? ' · ' + x.days_left + ' days left' : '') + '</div></div>';
    }).join('') : '<div class="empty">No memberships.</div>');
    html += '<h3>Payments</h3>';
    if (pay.payments.length) {
      html += '<div class="card"><div class="row"><span class="muted">Total paid</span><b>' + C.inr(pay.total_paid) + '</b></div><div class="row"><span class="muted">Last payment</span><span>' + C.fmtDate(pay.last_payment.paid_at) + ' · ' + C.inr(pay.last_payment.amount) + '</span></div></div>';
      html += pay.payments.map(function (p) { return '<div class="row card"><span>' + C.fmtDate(p.paid_at) + ' <span class="muted">' + esc(p.method) + '</span></span><b>' + C.inr(p.amount) + '</b></div>'; }).join('');
    } else html += '<div class="empty">No payment records.</div>';
    openSheet(html);
  }

  // ---------- Reports ----------
  function renderReports() {
    var t = store.today();
    if (!reportState.from) { reportState.from = C.monthStart(t); reportState.to = t; }
    view.innerHTML = '<h2>Reports</h2><div class="seg" id="seg">' +
      [['revenue', 'Revenue'], ['expiry', 'Expiry'], ['attendance', 'Attendance']].map(function (x) { return '<button data-r="' + x[0] + '" class="' + (reportTab === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') +
      '</div><div id="rbody"></div>';
    $('#seg').onclick = function (e) { var b = e.target.closest('button'); if (!b) return; reportTab = b.getAttribute('data-r'); renderReports(); };
    var body = $('#rbody');
    if (reportTab === 'revenue') revenueView(body); else if (reportTab === 'expiry') expiryView(body); else attendanceView(body);
  }
  function rangeControls(withMember) {
    var h = '<div class="row"><div style="flex:1"><label>From</label><input type="date" id="rf" value="' + reportState.from + '"></div><div style="flex:1"><label>To</label><input type="date" id="rt" value="' + reportState.to + '"></div></div>';
    if (withMember) {
      h += '<label>Member</label><select id="rm"><option value="">Whole gym</option>' + store.state.members.slice().sort(function (a, b) { return a.name.localeCompare(b.name); }).map(function (m) {
        return '<option value="' + esc(m.id) + '"' + (reportState.member === m.id ? ' selected' : '') + '>' + esc(m.name) + '</option>';
      }).join('') + '</select>';
    }
    return h;
  }
  function bindRange(body) {
    var f = $('#rf', body), t = $('#rt', body), m = $('#rm', body);
    function chg() { reportState.from = f.value; reportState.to = t.value; if (m) reportState.member = m.value; renderReports(); }
    f.onchange = chg; t.onchange = chg; if (m) m.onchange = chg;
  }
  function bars(items, valueKey, labelFn, fmt) {
    var max = Math.max.apply(null, items.map(function (i) { return i[valueKey]; }).concat([1]));
    return '<div class="bars">' + items.map(function (i) {
      return '<div class="b"><span class="l">' + esc(labelFn(i)) + '</span><div class="bar" style="width:' + Math.max(3, Math.round(i[valueKey] / max * 55)) + '%"></div><span class="v">' + fmt(i[valueKey]) + '</span></div>';
    }).join('') + '</div>';
  }
  function revenueView(body) {
    var r = store.revenueReport(reportState.from, reportState.to);
    body.innerHTML = rangeControls(false) +
      '<div class="card" style="margin-top:12px"><div class="muted">Total income</div><div class="big">' + C.inr(r.total) + '</div><div class="muted">' + r.count + ' payment(s)</div></div>' +
      '<h3>By payment method</h3>' + (r.by_method.length ? '<div class="card">' + bars(r.by_method, 'amount', function (i) { return i.method; }, C.inr) + '</div>' : '<div class="empty">No payments in this range.</div>') +
      '<h3>By day</h3>' + (r.by_day.length ? '<div class="card">' + bars(r.by_day, 'amount', function (i) { return C.fmtDate(i.date).slice(0, 6); }, C.inr) + '</div>' : '<div class="empty">Nothing to show.</div>');
    bindRange(body);
  }
  function expiryView(body) {
    var rows = store.expiryReport(reportState.days, reportState.mode);
    body.innerHTML = '<div class="seg" id="emode"><button data-m="soon" class="' + (reportState.mode === 'soon' ? 'on' : '') + '">Expiring soon</button><button data-m="expired" class="' + (reportState.mode === 'expired' ? 'on' : '') + '">Already expired</button></div>' +
      (reportState.mode === 'soon' ? '<label>Within next (days)</label><input type="number" id="ed" min="0" max="365" inputmode="numeric" value="' + reportState.days + '">' : '') +
      '<h3>' + rows.length + ' member(s)</h3><div class="list">' + (rows.length ? rows.map(function (r) {
        var tag = reportState.mode === 'expired' ? '<span class="badge expired">' + Math.abs(r.days_left) + 'd ago</span>' : '<span class="badge soon">' + (r.days_left === 0 ? 'today' : r.days_left + 'd left') + '</span>';
        return '<div class="item" data-id="' + esc(r.member_id) + '"><div class="row"><span class="name">' + esc(r.name) + '</span>' + tag + '</div><div class="muted">' + esc(r.plan) + ' · ends ' + C.fmtDate(r.end_date) + ' · ' + esc(r.phone) + '</div></div>';
      }).join('') : '<div class="empty">Nothing here.</div>') + '</div>';
    $('#emode', body).onclick = function (e) { var b = e.target.closest('button'); if (b) { reportState.mode = b.getAttribute('data-m'); renderReports(); } };
    var d = $('#ed', body); if (d) d.onchange = function () { reportState.days = Math.max(0, parseInt(d.value, 10) || 0); renderReports(); };
    $('.list', body).onclick = function (e) { var it = e.target.closest('.item[data-id]'); if (it) showMember(it.getAttribute('data-id')); };
  }
  function attendanceView(body) {
    var r = store.attendanceReport(reportState.from, reportState.to, reportState.member || null);
    body.innerHTML = rangeControls(true) +
      '<div class="card" style="margin-top:12px"><div class="muted">Total visits</div><div class="big">' + r.total_visits + '</div></div>' +
      (reportState.member ? '' : '<h3>By member</h3>' + (r.by_member.length ? '<div class="card">' + bars(r.by_member.slice(0, 10), 'visits', function (i) { return i.name.split(' ')[0]; }, String) + '</div>' : '<div class="empty">No visits.</div>')) +
      '<h3>By day</h3>' + (r.by_day.length ? '<div class="card">' + bars(r.by_day.slice(-14), 'visits', function (i) { return C.fmtDate(i.date).slice(0, 6); }, String) + '</div>' : '<div class="empty">No visits in this range.</div>');
    bindRange(body);
  }

  // ---------- Register ----------
  function renderRegister(result, draft) {
    draft = draft || {};
    if (result && result.ok) {
      var m = result.member, ms = result.membership;
      view.innerHTML = '<div class="card result ok"><div class="icon">&#10003;</div><h2>Registration successful</h2><p class="muted">' + (result.code === 'renewed_existing' ? 'Existing member — new membership added.' : 'New member created.') + ' No payment was recorded.</p>' +
        '<div class="kv"><div><span class="muted">Name</span><b>' + esc(m.name) + '</b></div><div><span class="muted">Phone</span><b>' + esc(m.phone) + '</b></div><div><span class="muted">Plan</span><b>' + esc(result.plan.name) + '</b></div><div><span class="muted">Starts</span><b>' + C.fmtDate(ms.start_date) + '</b></div><div><span class="muted">Ends</span><b>' + C.fmtDate(ms.end_date) + '</b></div></div>' +
        '<button class="btn" id="again">Register another member</button></div>';
      $('#again').onclick = function () { renderRegister(); };
      return;
    }
    var plans = store.state.plans.filter(function (p) { return p.active; });
    var err = '';
    if (result && !result.ok) {
      err = '<div class="card result bad" style="padding:14px"><b>' + (result.code === 'duplicate' ? 'Already registered' : 'Please fix the following') + '</b><ul class="errs">' + result.errors.map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></div>';
    }
    view.innerHTML = '<h2>New member registration</h2>' + err +
      '<form id="regForm" novalidate><label>Full name</label><input name="name" autocomplete="name" value="' + esc(draft.name) + '">' +
      '<label>Phone (10 digits)</label><input name="phone" inputmode="tel" autocomplete="tel" value="' + esc(draft.phone) + '">' +
      '<label>Email</label><input name="email" type="email" inputmode="email" autocomplete="email" value="' + esc(draft.email) + '">' +
      '<label>Plan</label><select name="plan_id">' + plans.map(function (p) { return '<option value="' + esc(p.id) + '"' + (draft.plan_id === p.id ? ' selected' : '') + '>' + esc(p.name) + ' — ' + C.inr(p.price) + ' / ' + p.duration_days + ' days</option>'; }).join('') + '</select>' +
      '<p class="muted">Membership starts today and runs for the plan’s number of days. Gym: ' + esc(C.GYM.name) + '.</p><button class="btn" type="submit">Register member</button></form>';
    $('#regForm').onsubmit = function (e) {
      e.preventDefault();
      var f = e.target, d = { name: f.name.value, phone: f.phone.value, email: f.email.value, plan_id: f.plan_id.value };
      renderRegister(store.register(d), d);
    };
  }

  // ---------- Settings ----------
  function renderSettings(msg) {
    view.innerHTML = '<h2>Settings</h2>' + (msg ? '<div class="card" style="background:var(--brand-soft)">' + esc(msg) + '</div>' : '') +
      '<div class="card"><b>' + esc(C.GYM.name) + '</b><div class="muted">' + store.state.members.length + ' members · ' + store.state.memberships.length + ' memberships · ' + store.state.payments.length + ' payments · ' + store.state.attendance.length + ' visits</div></div>' +
      '<h3>Plans</h3>' + store.state.plans.map(function (p) { return '<div class="card row"><div><b>' + esc(p.name) + '</b><div class="muted">' + p.duration_days + ' days</div></div><b>' + C.inr(p.price) + '</b></div>'; }).join('') +
      '<h3>Data (stored on this phone)</h3>' +
      '<button class="btn ghost" id="copyBackup">Copy backup to clipboard</button>' +
      '<label>Restore from backup (paste JSON)</label><textarea id="importBox" rows="3" placeholder="Paste backup JSON here"></textarea>' +
      '<button class="btn ghost" id="importBtn">Restore backup</button>' +
      '<button class="btn ghost" id="demoBtn">Reset to demo data</button>' +
      '<button class="btn danger" id="clearBtn">Clear all members &amp; records</button>' +
      '<p class="muted" style="margin-top:16px">All data lives only on this device. There is no server or sync.</p>';
    $('#copyBackup').onclick = function () {
      var text = store.exportJSON();
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function () { renderSettings('Backup copied. Paste it somewhere safe.'); }, function () { fallbackCopy(text); });
      else fallbackCopy(text);
    };
    function fallbackCopy(text) { var ta = $('#importBox'); ta.value = text; ta.select(); try { document.execCommand('copy'); renderSettings('Backup copied.'); } catch (e) { /* user can copy by hand */ } }
    $('#importBtn').onclick = function () {
      try { store.importJSON($('#importBox').value); bot = new C.Assistant(store); renderSettings('Backup restored.'); }
      catch (e) { renderSettings('Could not restore: ' + e.message); }
    };
    $('#demoBtn').onclick = function () { if (confirm('Replace all data with demo data?')) { store.resetDemo(); bot = new C.Assistant(store); renderSettings('Demo data loaded.'); } };
    $('#clearBtn').onclick = function () { if (confirm('Delete ALL members, memberships, payments and visits? This cannot be undone.')) { store.clearAll(); bot = new C.Assistant(store); renderSettings('All records cleared.'); } };
  }

  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && location.hostname !== 'localhost') {
    navigator.serviceWorker.register('sw.js').catch(function () { /* offline cache is optional */ });
  }
  go('assistant');
})();
