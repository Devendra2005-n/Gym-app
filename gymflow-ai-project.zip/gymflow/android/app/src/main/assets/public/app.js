(function () {
  'use strict';
  var C = window.GymCore, K = window.GymContent, A = window.GymAnim;
  var store = new C.Store(window.localStorage);
  var bot = new C.Assistant(store);
  var view = document.getElementById('view');
  var tabsEl = document.getElementById('tabs');
  var sheet = document.getElementById('sheet');
  var sheetBg = document.getElementById('sheetBg');
  var jsQRfn = window.jsQR && (window.jsQR.default || window.jsQR);
  var current = 'assistant';
  var activeAnim = null;
  var chatLog = [{ me: false, text: 'Hi! I’m your gym assistant for ' + C.GYM.name + '. Ask me about members, memberships, payments, revenue, expiries or attendance. I’m read-only.' }];
  var reportTab = 'revenue';
  var reportState = { from: '', to: '', days: 7, mode: 'soon', member: '' };
  var wk = { mode: 'ex', cat: 'all', q: '', plan: 'beginner' };
  var pay = { q: '', member: '', plan: '', amount: '', method: 'upi', renew: false, note: '', pending: null, showQr: false };

  var SUBPAGES = { reports: 1, register: 1, payments: 1, faq: 1, settings: 1 };

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function badge(status, text) { return '<span class="badge ' + esc(status) + '">' + esc(text || status) + '</span>'; }
  function back() { return '<button class="back" data-go="more">‹ More</button>'; }
  function sortedMembers() { return store.state.members.slice().sort(function (a, b) { return a.name.localeCompare(b.name); }); }

  document.getElementById('gymName').textContent = C.GYM.name;
  document.getElementById('todayPill').textContent = C.fmtDate(store.today());

  // ---------- QR image (always black on white so any scanner can read it) ----------
  function qrSvg(text) {
    var q = window.qrcode(0, 'M'); q.addData(text); q.make();
    var n = q.getModuleCount(), m = 4, d = '';
    for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) if (q.isDark(r, c)) d += 'M' + (c + m) + ' ' + (r + m) + 'h1v1h-1z';
    var s = n + m * 2;
    return '<svg class="qr" viewBox="0 0 ' + s + ' ' + s + '" shape-rendering="crispEdges" xmlns="http://www.w3.org/2000/svg"><rect width="' + s + '" height="' + s + '" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>';
  }

  // ---------- navigation ----------
  tabsEl.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-tab]'); if (!b) return;
    go(b.getAttribute('data-tab'));
  });
  document.addEventListener('click', function (e) {
    var g = e.target.closest('[data-go]');
    if (g && !g.closest('.tabs')) go(g.getAttribute('data-go'));
  });
  var SCREENS = {
    assistant: function () { renderAssistant(); }, members: function () { renderMembers(); }, attendance: function () { renderAttendance(); },
    workouts: function () { renderWorkouts(); }, more: function () { renderMore(); }, reports: function () { renderReports(); },
    register: function () { renderRegister(); }, payments: function () { renderPayments(); }, faq: function () { renderFaq(); }, settings: function () { renderSettings(); }
  };
  function go(tab) {
    stopScan(); stopTimers(); stopAnim(); closeSheet();
    if (tab === 'attendance') attRole = null;   // always ask owner or member when Check-in is opened
    current = tab;
    var hi = SUBPAGES[tab] ? 'more' : tab;
    Array.prototype.forEach.call(tabsEl.querySelectorAll('button'), function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === hi); });
    document.body.classList.toggle('chat-open', tab === 'assistant');
    SCREENS[tab]();
    view.scrollTop = 0;
  }
  function stopAnim() { if (activeAnim) { activeAnim.stop(); activeAnim = null; } }

  // ---------- sheet ----------
  function openSheet(html) { sheet.innerHTML = html + '<button class="btn ghost" id="closeSheet">Close</button>'; sheet.hidden = false; sheetBg.hidden = false; sheet.scrollTop = 0; $('#closeSheet').onclick = closeSheet; }
  function closeSheet() { stopAnim(); sheet.hidden = true; sheetBg.hidden = true; }
  sheetBg.addEventListener('click', closeSheet);

  // ---------- More ----------
  function renderMore() {
    var items = [['reports', '📊', 'Reports', 'Revenue, expiry, attendance'], ['register', '➕', 'Register member', 'New member sign-up'], ['payments', '💳', 'Payments', 'Google Pay, UPI, cash, card'], ['faq', '❓', 'FAQ', 'Questions and answers'], ['settings', '⚙️', 'Settings', 'UPI ID, backup, data']];
    view.innerHTML = '<h2>More</h2><div class="list">' + items.map(function (i) {
      return '<div class="item" data-go="' + i[0] + '"><div class="row"><span><span class="mi">' + i[1] + '</span> <b>' + i[2] + '</b><div class="muted mi-s">' + i[3] + '</div></span><span class="muted">›</span></div></div>';
    }).join('') + '</div>';
  }

  // ---------- Assistant (chat) ----------
  var CHIPS = ['Revenue this month', 'Who expires in 7 days?', 'Show expired members', 'Attendance today', 'Find Patil'];
  function renderAssistant() {
    view.innerHTML = '<div class="chat"><div class="msgs" id="msgs"></div>' +
      '<div class="chips">' + CHIPS.map(function (c) { return '<button data-q="' + esc(c) + '">' + esc(c) + '</button>'; }).join('') + '</div>' +
      '<form class="composer" id="chatForm" autocomplete="off"><input id="chatIn" placeholder="Ask about your gym…" enterkeyhint="send"><button type="submit" aria-label="Send">&#10148;</button></form></div>';
    paintChat();
    $('#chatForm').onsubmit = function (e) { e.preventDefault(); var i = $('#chatIn'); send(i.value); i.value = ''; };
    view.querySelector('.chips').onclick = function (e) { var b = e.target.closest('button'); if (b) send(b.getAttribute('data-q')); };
  }
  function paintChat() {
    var box = $('#msgs'); if (!box) return;
    box.innerHTML = chatLog.map(function (m) { return '<div class="msg ' + (m.me ? 'me' : 'bot') + '">' + esc(m.text) + '</div>'; }).join('');
    box.scrollTop = box.scrollHeight;
  }
  function send(text) {
    text = String(text || '').trim(); if (!text) return;
    chatLog.push({ me: true, text: text });
    chatLog.push({ me: false, text: bot.ask(text) });
    paintChat();
  }

  // ---------- Members ----------
  function renderMembers() {
    view.innerHTML = '<div class="row"><h2>Members</h2><button class="btn small" data-go="register">+ New</button></div><input id="q" type="search" placeholder="Search name, phone or email" autocomplete="off">' +
      '<p class="muted" id="hint" style="margin:8px 2px"></p><div class="list" id="results"></div>';
    var q = $('#q');
    function run() {
      var term = q.value.trim();
      var rows = term ? store.searchMembers(term) : sortedMembers().slice(0, 10);
      $('#hint').textContent = term ? rows.length + ' result(s), up to 10 shown' : 'Showing the first 10 members. Type to search.';
      $('#results').innerHTML = rows.length ? rows.map(function (m) {
        var active = store.hasActive(m.id);
        return '<div class="item" data-id="' + esc(m.id) + '"><div class="row"><span class="name">' + esc(m.name) + '</span>' + badge(active ? 'active' : 'expired') + '</div><div class="muted">' + esc(m.phone) + ' · ' + esc(m.email) + '</div></div>';
      }).join('') : '<div class="empty">No members found.</div>';
    }
    q.oninput = run; run();
    $('#results').onclick = function (e) { var it = e.target.closest('.item'); if (it) showMember(it.getAttribute('data-id')); };
  }
  function showMember(id) {
    var m = store.member(id); if (!m) return;
    var ms = store.membershipLookup(id), p = store.paymentLookup(id);
    var html = '<h2>' + esc(m.name) + '</h2><div class="muted">' + esc(m.phone) + ' · ' + esc(m.email) + '</div>' +
      '<div class="row3"><button class="btn small" id="mQr">QR card</button><button class="btn small" id="mIn">Check in</button><button class="btn small" id="mPay">Payment</button></div><div id="mMsg"></div>';
    html += '<h3>Memberships</h3>' + (ms.length ? ms.map(function (x) {
      return '<div class="card"><div class="row"><b>' + esc(x.plan) + '</b>' + badge(x.status) + '</div><div class="muted">' + C.fmtDate(x.start_date) + ' → ' + C.fmtDate(x.end_date) + (x.status === 'active' ? ' · ' + x.days_left + ' days left' : '') + '</div></div>';
    }).join('') : '<div class="empty">No memberships.</div>');
    html += '<h3>Payments</h3>';
    if (p.payments.length) {
      html += '<div class="card"><div class="row"><span class="muted">Total paid</span><b>' + C.inr(p.total_paid) + '</b></div><div class="row"><span class="muted">Last payment</span><span>' + C.fmtDate(p.last_payment.paid_at) + ' · ' + C.inr(p.last_payment.amount) + '</span></div></div>';
      html += p.payments.map(function (x) { return '<div class="row card"><span>' + C.fmtDate(x.paid_at) + ' <span class="muted">' + esc(x.method) + (x.ref ? ' · ' + esc(x.ref) : '') + '</span></span><b>' + C.inr(x.amount) + '</b></div>'; }).join('');
    } else html += '<div class="empty">No payment records.</div>';
    openSheet(html);
    $('#mQr').onclick = function () { showQrCard(id); };
    $('#mPay').onclick = function () { pay.member = id; pay.q = ''; pay.pending = null; go('payments'); };
    $('#mIn').onclick = function () {
      var r = store.checkIn(id);
      if (r.code === 'expired') { $('#mMsg').innerHTML = resultCard(r) + '<button class="btn small" id="mForce">Check in anyway</button>'; $('#mForce').onclick = function () { $('#mMsg').innerHTML = resultCard(store.checkIn(id, { force: true })); }; }
      else $('#mMsg').innerHTML = resultCard(r);
    };
  }
  function showQrCard(id) {
    var m = store.member(id); if (!m) return;
    openSheet('<div class="qrcard"><h2>' + esc(m.name) + '</h2><div class="muted">' + esc(C.GYM.name) + ' member card</div>' + qrSvg(C.memberQRText(m)) +
      '<p class="muted">Show this QR at the gym desk to check in. Take a screenshot so the member can keep it on their phone.</p></div>');
  }

  // ---------- Check-in: owner shows the gym QR, members scan it ----------
  var attRole = null, ownerMode = 'show', memberMode = 'scan', timers = [];
  var scan = { stream: null, raf: 0, canvas: null, lastAt: 0, hold: 0, cb: null };
  function stopTimers() { timers.forEach(function (t) { clearInterval(t); }); timers = []; }
  function stopScan() {
    if (scan.raf) cancelAnimationFrame(scan.raf); scan.raf = 0; scan.cb = null;
    if (scan.stream) { scan.stream.getTracks().forEach(function (t) { t.stop(); }); scan.stream = null; }
  }
  function resultCard(r) {
    var n = r.member ? esc(r.member.name) : '';
    if (r.code === 'checked_in') return '<div class="res ok"><b>✓ ' + n + '</b><div>Checked in at ' + esc(r.time) + (r.expired ? ' (membership expired)' : '') + '</div></div>';
    if (r.code === 'already') return '<div class="res warn"><b>' + n + '</b><div>Already checked in today at ' + esc(r.time) + '</div></div>';
    if (r.code === 'expired') return '<div class="res bad"><b>' + n + '</b><div>Membership expired. Renew first, or check in anyway.</div></div>';
    if (r.code === 'bad_code') return '<div class="res bad"><b>' + n + '</b><div>This pass is old or the code is wrong. Ask the member to scan the gym QR again.</div></div>';
    if (r.code === 'invalid_qr') return '<div class="res bad"><b>Not a GYM Flow QR</b><div>Scan a member QR card or a member check-in pass.</div></div>';
    if (r.code === 'not_found' && r.phone) return '<div class="res bad"><b>Member not found</b><div>No member is registered with ' + esc(r.phone) + '.</div></div>';
    return '<div class="res bad"><b>Member not found</b></div>';
  }
  function renderAttendance() {
    stopScan(); stopTimers();
    if (attRole === 'owner') return ownerView();
    if (attRole === 'member') return memberView();
    view.innerHTML = '<h2>Check-in</h2><p class="muted">Who is using this phone?</p>' +
      '<button class="role" id="roleOwner"><b>I’m the owner</b><span>Show the gym QR code, scan member passes, see who came today</span></button>' +
      '<button class="role" id="roleMember"><b>I’m a member</b><span>Scan the gym QR code and check in</span></button>';
    $('#roleOwner').onclick = function () { attRole = 'owner'; ownerMode = 'show'; renderAttendance(); };
    $('#roleMember').onclick = function () { attRole = 'member'; memberMode = 'scan'; renderAttendance(); };
  }
  function roleBar() {
    return '<div class="row rolebar"><h2 style="margin:0">Check-in</h2><span><span class="tag">' + (attRole === 'owner' ? 'Owner' : 'Member') + '</span> <button class="back" id="switchRole">Switch</button></span></div>';
  }
  function bindSwitch() { $('#switchRole').onclick = function () { attRole = null; renderAttendance(); }; }

  // ----- owner -----
  function ownerView() {
    view.innerHTML = roleBar() + '<div class="seg" id="oseg">' + [['show', 'Show QR'], ['scan', 'Scan'], ['manual', 'Manual'], ['today', 'Today']].map(function (x) {
      return '<button data-m="' + x[0] + '" class="' + (ownerMode === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div><div id="abody"></div>';
    bindSwitch();
    $('#oseg').onclick = function (e) { var b = e.target.closest('button'); if (!b) return; ownerMode = b.getAttribute('data-m'); renderAttendance(); };
    var body = $('#abody');
    if (ownerMode === 'show') ownerShow(body); else if (ownerMode === 'scan') ownerScan(body); else if (ownerMode === 'manual') manualView(body); else todayView(body);
  }
  function ownerShow(body) {
    var shown = '';
    function paint() {
      var g = store.gymQR();
      if (g.code !== shown) {
        shown = g.code;
        body.innerHTML = '<div class="qrcard bigqr">' + qrSvg(g.text) + '<div class="codebig">' + g.code.slice(0, 4) + ' ' + g.code.slice(4) + '</div><div class="muted"><b id="cd"></b></div></div>' +
          '<div class="card"><b>How members check in</b><ol class="steps"><li>Member opens the app, taps <b>Check-in</b> then <b>I’m a member</b>.</li><li>They scan this QR (or type the code above).</li><li>Their phone shows a pass. Scan it from the <b>Scan</b> tab here.</li></ol><div class="muted">The code changes every 5 minutes, so a photo of this screen stops working soon.</div></div>';
      }
      var cd = $('#cd'), s = g.seconds_left;
      if (cd) cd.textContent = 'New code in ' + Math.floor(s / 60) + ':' + (s % 60 < 10 ? '0' : '') + (s % 60);
    }
    paint(); timers.push(setInterval(paint, 1000));
  }
  function ownerScan(body) {
    body.innerHTML = camMarkup('Point the camera at a member’s check-in pass or QR card. Each member can check in once a day.');
    $('#camStart').onclick = function () { startScan(onOwnerCode); };
  }
  function camMarkup(hint) {
    return '<div class="camwrap"><video id="cam" playsinline muted></video><div class="frame"></div></div>' +
      '<button class="btn" id="camStart">Start camera</button><p class="muted" id="scanMsg">' + esc(hint) + '</p><div id="scanResult"></div>';
  }
  function startScan(cb) {
    var video = $('#cam'), msg = $('#scanMsg');
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !jsQRfn) { msg.textContent = 'This device cannot open the camera here.'; return; }
    msg.textContent = 'Opening camera…';
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false }).then(function (stream) {
      scan.stream = stream; scan.cb = cb; video.srcObject = stream; return video.play();
    }).then(function () {
      $('#camStart').hidden = true; msg.textContent = 'Scanning… hold the QR inside the frame.'; scan.hold = 0; tick();
    }).catch(function () {
      stopScan(); msg.textContent = 'Could not open the camera. Allow the Camera permission for GYM Flow in your phone settings.';
    });
  }
  function tick() {
    var v = $('#cam'); if (!v || !scan.stream) return;
    var now = performance.now();
    if (v.readyState >= 2 && v.videoWidth && now - scan.lastAt > 140 && now > scan.hold) {
      scan.lastAt = now;
      var sc = Math.min(1, 520 / v.videoWidth), w = Math.round(v.videoWidth * sc), h = Math.round(v.videoHeight * sc);
      if (!scan.canvas) scan.canvas = document.createElement('canvas');
      scan.canvas.width = w; scan.canvas.height = h;
      var ctx = scan.canvas.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(v, 0, 0, w, h);
      var code = jsQRfn(ctx.getImageData(0, 0, w, h).data, w, h, { inversionAttempts: 'dontInvert' });
      if (code && code.data && scan.cb) scan.cb(code.data);
    }
    if (scan.stream) scan.raf = requestAnimationFrame(tick);
  }
  function onOwnerCode(text) {
    scan.hold = performance.now() + 2600;
    var r = store.scanCheckIn(text), box = $('#scanResult');
    try { if (navigator.vibrate) navigator.vibrate(r.ok ? 80 : [80, 60, 80]); } catch (e) { /* not supported */ }
    box.innerHTML = resultCard(r) + (r.code === 'expired' ? '<button class="btn small" id="force">Check in anyway</button>' : '');
    var f = $('#force'); if (f) f.onclick = function () { scan.hold = performance.now() + 2600; box.innerHTML = resultCard(store.checkIn(r.member.id, { force: true })); };
  }
  function manualView(body) {
    body.innerHTML = '<input id="mq" type="search" placeholder="Search name or phone" autocomplete="off"><div id="mres" style="margin-top:8px"></div><div class="list" id="mlist"></div>';
    var q = $('#mq');
    function run() {
      var term = q.value.trim(), rows = term ? store.searchMembers(term) : [];
      $('#mlist').innerHTML = term && !rows.length ? '<div class="empty">No members found.</div>' : rows.map(function (m) {
        return '<div class="item plain"><div class="row"><div><div class="name">' + esc(m.name) + '</div><div class="muted">' + esc(m.phone) + '</div></div><button class="btn small" data-in="' + esc(m.id) + '">Check in</button></div></div>';
      }).join('');
    }
    q.oninput = run; run();
    $('#mlist').onclick = function (e) {
      var b = e.target.closest('button[data-in]'); if (!b) return;
      var id = b.getAttribute('data-in'), r = store.checkIn(id), box = $('#mres');
      box.innerHTML = resultCard(r) + (r.code === 'expired' ? '<button class="btn small" id="mf">Check in anyway</button>' : '');
      var f = $('#mf'); if (f) f.onclick = function () { box.innerHTML = resultCard(store.checkIn(id, { force: true })); };
    };
  }
  function todayView(body) {
    var t = store.todayAttendance(), t0 = store.today();
    var rep = store.attendanceReport(C.addDays(t0, -30), t0), hours = rep.by_hour, max = Math.max.apply(null, hours.concat([1]));
    var cols = '';
    for (var h = 5; h <= 22; h++) cols += '<div class="col"><div class="colbar" style="height:' + Math.round(hours[h] / max * 70) + 'px"></div><span>' + (h % 3 === 0 ? h : '') + '</span></div>';
    body.innerHTML = '<div class="card"><div class="muted">Checked in today</div><div class="big">' + t.count + '</div></div>' +
      '<h3>Busiest hours (last 30 days)</h3><div class="card"><div class="cols">' + cols + '</div><div class="muted" style="text-align:center">hour of day (24h)</div></div>' +
      '<h3>Today’s check-ins</h3><div class="list">' + (t.list.length ? t.list.map(function (x) {
        return '<div class="item plain"><div class="row"><span class="name">' + esc(x.name) + '</span><b>' + esc(x.time) + '</b></div></div>'; }).join('') : '<div class="empty">No check-ins yet today.</div>') + '</div>';
  }

  // ----- member -----
  function memberView() {
    var MK = C.MemberKit, prof = MK.get(window.localStorage);
    if (!prof.phone) {
      view.innerHTML = roleBar() + '<div class="card"><b>Link your phone number</b><div class="muted">Use the number you gave the gym when you joined. This is saved only on your phone.</div>' +
        '<label>Mobile number</label><input id="mph" inputmode="tel" autocomplete="tel" placeholder="10-digit number"><button class="btn" id="mLink">Save and continue</button><div id="mErr" class="errtxt"></div></div>';
      bindSwitch();
      $('#mLink').onclick = function () {
        var r = MK.linkPhone(window.localStorage, $('#mph').value);
        if (!r.ok) { $('#mErr').textContent = r.error; return; }
        renderAttendance();
      };
      return;
    }
    view.innerHTML = roleBar() + '<div class="card row"><div><div class="muted">Your number</div><b>' + esc(prof.phone) + '</b></div><button class="btn small ghost" id="mChange">Change</button></div>' +
      '<div class="seg" id="mseg">' + [['scan', 'Scan QR'], ['history', 'History']].map(function (x) { return '<button data-m="' + x[0] + '" class="' + (memberMode === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div><div id="mbody"></div>';
    bindSwitch();
    $('#mChange').onclick = function () { var p = MK.get(window.localStorage); p.phone = ''; MK.save(window.localStorage, p); renderAttendance(); };
    $('#mseg').onclick = function (e) { var b = e.target.closest('button'); if (!b) return; memberMode = b.getAttribute('data-m'); renderAttendance(); };
    var body = $('#mbody');
    if (memberMode === 'history') memberHistory(body, prof); else memberScan(body, prof);
  }
  function memberScan(body, prof) {
    body.innerHTML = camMarkup('Scan the QR code shown on the gym owner’s phone.') +
      '<h3>Camera not working?</h3><div class="card"><label style="margin-top:0">Type the 8-character code under the QR</label><input id="mcode" placeholder="XXXX XXXX" autocapitalize="characters" autocomplete="off"><button class="btn ghost" id="mUse">Use this code</button></div>';
    $('#camStart').onclick = function () { startScan(function (text) { onGymQr(body, prof, text); }); };
    $('#mUse').onclick = function () {
      var code = C.MemberKit.normalizeCode($('#mcode').value);
      if (!code) { $('#scanResult').innerHTML = '<div class="res bad">Enter the 8 letters/numbers shown under the QR code.</div>'; return; }
      showPass(body, prof, code, C.GYM.name);
    };
  }
  function onGymQr(body, prof, text) {
    var g = C.MemberKit.parseGymQR(text, Date.now()), box = $('#scanResult');
    scan.hold = performance.now() + 1500;
    if (!g) { box.innerHTML = '<div class="res bad"><b>Not the gym QR</b><div>Scan the QR shown on the owner’s phone (Check-in → Show QR).</div></div>'; return; }
    if (!g.fresh) { box.innerHTML = '<div class="res warn"><b>This QR is old</b><div>Ask the owner to show the current QR, then scan again.</div></div>'; return; }
    try { if (navigator.vibrate) navigator.vibrate(80); } catch (e) { /* not supported */ }
    showPass(body, prof, g.code, g.gym);
  }
  function showPass(body, prof, code, gym) {
    stopScan();
    C.MemberKit.addVisit(window.localStorage, { date: C.todayIST(), time: C.timeIST(), gym: gym });
    body.innerHTML = '<div class="res ok"><b>✓ Gym QR accepted</b><div>Show this pass to the desk to finish checking in.</div></div>' +
      '<div class="qrcard bigqr">' + qrSvg(C.MemberKit.buildPass(prof.phone, code)) + '<p class="muted">The owner scans this pass from the <b>Scan</b> tab. It works for about 15 minutes. Turn the screen brightness up.</p></div>' +
      '<button class="btn ghost" id="scanAgain">Scan again</button>';
    $('#scanAgain').onclick = function () { renderAttendance(); };
  }
  function memberHistory(body, prof) {
    body.innerHTML = '<p class="muted">Check-in passes created on this phone. The gym’s own record is on the owner’s phone.</p><div class="list">' + (prof.visits.length ? prof.visits.map(function (v) {
      return '<div class="item plain"><div class="row"><span class="name">' + esc(C.fmtDate(v.date)) + '</span><b>' + esc(v.time) + '</b></div><div class="muted">' + esc(v.gym || '') + '</div></div>'; }).join('') : '<div class="empty">No check-ins yet.</div>') + '</div>';
  }

  // ---------- Workouts ----------
  function exById(id) { return K.EXERCISES.filter(function (e) { return e.id === id; })[0]; }
  function catName(id) { var c = K.CATEGORIES.filter(function (x) { return x.id === id; })[0]; return c ? c.name : id; }
  function renderWorkouts() {
    view.innerHTML = '<h2>Workouts</h2><div class="seg" id="wseg"><button data-m="ex" class="' + (wk.mode === 'ex' ? 'on' : '') + '">Exercises</button><button data-m="plans" class="' + (wk.mode === 'plans' ? 'on' : '') + '">Workout plans</button></div><div id="wbody"></div>';
    $('#wseg').onclick = function (e) { var b = e.target.closest('button'); if (b) { wk.mode = b.getAttribute('data-m'); renderWorkouts(); } };
    if (wk.mode === 'ex') exercisesView($('#wbody')); else plansView($('#wbody'));
  }
  function exercisesView(body) {
    body.innerHTML = '<div class="chips" id="cats"><button data-c="all" class="' + (wk.cat === 'all' ? 'on' : '') + '">All</button>' + K.CATEGORIES.map(function (c) {
      return '<button data-c="' + c.id + '" class="' + (wk.cat === c.id ? 'on' : '') + '">' + c.icon + ' ' + esc(c.name) + '</button>'; }).join('') + '</div>' +
      '<input id="wq" type="search" placeholder="Search exercises" value="' + esc(wk.q) + '" autocomplete="off"><p class="muted" id="wcount" style="margin:8px 2px"></p><div class="grid2" id="wgrid"></div>';
    $('#cats').onclick = function (e) { var b = e.target.closest('button'); if (b) { wk.cat = b.getAttribute('data-c'); exercisesView(body); } };
    function run() {
      var q = wk.q.toLowerCase();
      var list = K.EXERCISES.filter(function (x) {
        return (wk.cat === 'all' || x.cat === wk.cat) && (!q || (x.name + ' ' + x.muscles.join(' ') + ' ' + catName(x.cat)).toLowerCase().indexOf(q) !== -1);
      });
      $('#wcount').textContent = list.length + ' exercise(s)';
      $('#wgrid').innerHTML = list.length ? list.map(function (x) {
        return '<div class="ex" data-ex="' + x.id + '"><div class="exfig">' + A.still(x) + '</div><div class="exname">' + esc(x.name) + '</div><div class="muted">' + esc(catName(x.cat)) + ' · ' + esc(x.level) + '</div></div>';
      }).join('') : '<div class="empty" style="grid-column:1/-1">No exercises found.</div>';
    }
    $('#wq').oninput = function (e) { wk.q = e.target.value; run(); };
    run();
    $('#wgrid').onclick = function (e) { var c = e.target.closest('.ex'); if (c) showExercise(c.getAttribute('data-ex')); };
  }
  function showExercise(id) {
    var x = exById(id); if (!x) return;
    openSheet('<div class="exfig big" id="exAnim"></div><p class="muted tap">Tap the figure to pause or play</p><h2 style="margin-top:6px">' + esc(x.name) + '</h2>' +
      '<div class="chipline"><span class="tag">' + esc(catName(x.cat)) + '</span><span class="tag">' + esc(x.level) + '</span><span class="tag">' + esc(x.sets) + '</span></div>' +
      '<h3>Muscles worked</h3><div class="chipline">' + x.muscles.map(function (m) { return '<span class="tag hot">' + esc(m) + '</span>'; }).join('') + '</div>' +
      '<h3>Equipment</h3><p style="margin:0">' + esc(x.equip_label) + '</p>' +
      '<h3>How to do it</h3><ol class="steps">' + x.steps.map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('') + '</ol>' +
      '<h3>Tips</h3><ul class="steps">' + x.tips.map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('') + '</ul>' +
      '<p class="muted">General guidance, not medical advice. Start light and ask a trainer to check your form.</p>');
    activeAnim = A.play($('#exAnim'), x);
  }
  function plansView(body) {
    var plan = K.PLANS.filter(function (p) { return p.id === wk.plan; })[0] || K.PLANS[0];
    body.innerHTML = '<div class="seg" id="pseg">' + K.PLANS.map(function (p) { return '<button data-p="' + p.id + '" class="' + (plan.id === p.id ? 'on' : '') + '">' + esc(p.name.replace('Beginner Full Body', 'Beginner').replace('5-Day Body-Part Split', '5-Day Split').replace('Push / Pull / Legs', 'PPL')) + '</button>'; }).join('') + '</div>' +
      '<div class="card"><b>' + esc(plan.name) + '</b><div class="muted">' + esc(plan.blurb) + '</div></div>' +
      plan.days.map(function (d) {
        return '<h3>' + esc(d.name) + '</h3><div class="list">' + d.items.map(function (it) {
          var x = exById(it[0]); if (!x) return '';
          return '<div class="item" data-ex="' + x.id + '"><div class="row"><span class="planrow"><span class="thumb">' + A.still(x) + '</span><span><b>' + esc(x.name) + '</b><div class="muted">' + esc(catName(x.cat)) + '</div></span></span><b class="nowrap">' + esc(it[1]) + '</b></div></div>';
        }).join('') + '</div>';
      }).join('') + '<p class="muted">Tap an exercise to see the animation and how to do it. Rest 60–90 seconds between sets.</p>';
    $('#pseg').onclick = function (e) { var b = e.target.closest('button'); if (b) { wk.plan = b.getAttribute('data-p'); plansView(body); } };
    body.onclick = function (e) { var c = e.target.closest('.item[data-ex]'); if (c) showExercise(c.getAttribute('data-ex')); };
  }

  // ---------- Reports ----------
  function renderReports() {
    var t = store.today();
    if (!reportState.from) { reportState.from = C.monthStart(t); reportState.to = t; }
    view.innerHTML = back() + '<h2>Reports</h2><div class="seg" id="seg">' +
      [['revenue', 'Revenue'], ['expiry', 'Expiry'], ['attendance', 'Attendance']].map(function (x) { return '<button data-r="' + x[0] + '" class="' + (reportTab === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') +
      '</div><div id="rbody"></div>';
    $('#seg').onclick = function (e) { var b = e.target.closest('button'); if (!b) return; reportTab = b.getAttribute('data-r'); renderReports(); };
    var body = $('#rbody');
    if (reportTab === 'revenue') revenueView(body); else if (reportTab === 'expiry') expiryView(body); else attendanceView(body);
  }
  function rangeControls(withMember) {
    var h = '<div class="row"><div style="flex:1"><label>From</label><input type="date" id="rf" value="' + reportState.from + '"></div><div style="flex:1"><label>To</label><input type="date" id="rt" value="' + reportState.to + '"></div></div>';
    if (withMember) {
      h += '<label>Member</label><select id="rm"><option value="">Whole gym</option>' + sortedMembers().map(function (m) {
        return '<option value="' + esc(m.id) + '"' + (reportState.member === m.id ? ' selected' : '') + '>' + esc(m.name) + '</option>';
      }).join('') + '</select>';
    }
    return h;
  }
  function bindRange(body) {
    var f = $('#rf', body), t = $('#rt', body), m = $('#rm', body);
    function chg() { reportState.from = f.value; reportState.to = t.value; if (m) reportState.member = m.value; renderReports(); }
    f.onchange = chg; t.onchange = chg; if (m) m.onchange = chg;
  }
  function bars(items, valueKey, labelFn, fmt) {
    var max = Math.max.apply(null, items.map(function (i) { return i[valueKey]; }).concat([1]));
    return '<div class="bars">' + items.map(function (i) {
      return '<div class="b"><span class="l">' + esc(labelFn(i)) + '</span><div class="bar" style="width:' + Math.max(3, Math.round(i[valueKey] / max * 55)) + '%"></div><span class="v">' + fmt(i[valueKey]) + '</span></div>';
    }).join('') + '</div>';
  }
  function revenueView(body) {
    var r = store.revenueReport(reportState.from, reportState.to);
    body.innerHTML = rangeControls(false) +
      '<div class="card" style="margin-top:12px"><div class="muted">Total income</div><div class="big">' + C.inr(r.total) + '</div><div class="muted">' + r.count + ' payment(s)</div></div>' +
      '<h3>By payment method</h3>' + (r.by_method.length ? '<div class="card">' + bars(r.by_method, 'amount', function (i) { return i.method; }, C.inr) + '</div>' : '<div class="empty">No payments in this range.</div>') +
      '<h3>By day</h3>' + (r.by_day.length ? '<div class="card">' + bars(r.by_day, 'amount', function (i) { return C.fmtDate(i.date).slice(0, 6); }, C.inr) + '</div>' : '<div class="empty">Nothing to show.</div>');
    bindRange(body);
  }
  function expiryView(body) {
    var rows = store.expiryReport(reportState.days, reportState.mode);
    body.innerHTML = '<div class="seg" id="emode"><button data-m="soon" class="' + (reportState.mode === 'soon' ? 'on' : '') + '">Expiring soon</button><button data-m="expired" class="' + (reportState.mode === 'expired' ? 'on' : '') + '">Already expired</button></div>' +
      (reportState.mode === 'soon' ? '<label>Within next (days)</label><input type="number" id="ed" min="0" max="365" inputmode="numeric" value="' + reportState.days + '">' : '') +
      '<h3>' + rows.length + ' member(s)</h3><div class="list">' + (rows.length ? rows.map(function (r) {
        var tag = reportState.mode === 'expired' ? '<span class="badge expired">' + Math.abs(r.days_left) + 'd ago</span>' : '<span class="badge soon">' + (r.days_left === 0 ? 'today' : r.days_left + 'd left') + '</span>';
        return '<div class="item" data-id="' + esc(r.member_id) + '"><div class="row"><span class="name">' + esc(r.name) + '</span>' + tag + '</div><div class="muted">' + esc(r.plan) + ' · ends ' + C.fmtDate(r.end_date) + ' · ' + esc(r.phone) + '</div></div>';
      }).join('') : '<div class="empty">Nothing here.</div>') + '</div>';
    $('#emode', body).onclick = function (e) { var b = e.target.closest('button'); if (b) { reportState.mode = b.getAttribute('data-m'); renderReports(); } };
    var d = $('#ed', body); if (d) d.onchange = function () { reportState.days = Math.max(0, parseInt(d.value, 10) || 0); renderReports(); };
    $('.list', body).onclick = function (e) { var it = e.target.closest('.item[data-id]'); if (it) showMember(it.getAttribute('data-id')); };
  }
  function attendanceView(body) {
    var r = store.attendanceReport(reportState.from, reportState.to, reportState.member || null);
    body.innerHTML = rangeControls(true) +
      '<div class="card" style="margin-top:12px"><div class="muted">Total visits</div><div class="big">' + r.total_visits + '</div></div>' +
      (reportState.member ? '' : '<h3>By member</h3>' + (r.by_member.length ? '<div class="card">' + bars(r.by_member.slice(0, 10), 'visits', function (i) { return i.name.split(' ')[0]; }, String) + '</div>' : '<div class="empty">No visits.</div>')) +
      '<h3>By day</h3>' + (r.by_day.length ? '<div class="card">' + bars(r.by_day.slice(-14), 'visits', function (i) { return C.fmtDate(i.date).slice(0, 6); }, String) + '</div>' : '<div class="empty">No visits in this range.</div>');
    bindRange(body);
  }

  // ---------- Register ----------
  function renderRegister(result, draft) {
    draft = draft || {};
    if (result && result.ok) {
      var m = result.member, ms = result.membership;
      view.innerHTML = back() + '<div class="card result ok"><div class="icon">&#10003;</div><h2>Registration successful</h2><p class="muted">' + (result.code === 'renewed_existing' ? 'Existing member — new membership added.' : 'New member created.') + ' No payment was recorded.</p>' +
        '<div class="kv"><div><span class="muted">Name</span><b>' + esc(m.name) + '</b></div><div><span class="muted">Phone</span><b>' + esc(m.phone) + '</b></div><div><span class="muted">Plan</span><b>' + esc(result.plan.name) + '</b></div><div><span class="muted">Starts</span><b>' + C.fmtDate(ms.start_date) + '</b></div><div><span class="muted">Ends</span><b>' + C.fmtDate(ms.end_date) + '</b></div></div>' +
        '<button class="btn" id="qrBtn">Show member QR card</button><button class="btn ghost" id="payBtn">Record payment</button><button class="btn ghost" id="again">Register another member</button></div>';
      $('#again').onclick = function () { renderRegister(); };
      $('#qrBtn').onclick = function () { showQrCard(m.id); };
      $('#payBtn').onclick = function () { pay.member = m.id; pay.plan = result.plan.id; pay.amount = String(result.plan.price); pay.renew = false; pay.pending = null; go('payments'); };
      return;
    }
    var plans = store.state.plans.filter(function (p) { return p.active; });
    var err = '';
    if (result && !result.ok) {
      err = '<div class="card result bad" style="padding:14px"><b>' + (result.code === 'duplicate' ? 'Already registered' : 'Please fix the following') + '</b><ul class="errs">' + result.errors.map(function (e) { return '<li>' + esc(e) + '</li>'; }).join('') + '</ul></div>';
    }
    view.innerHTML = back() + '<h2>New member registration</h2>' + err +
      '<form id="regForm" novalidate><label>Full name</label><input name="name" autocomplete="name" value="' + esc(draft.name) + '">' +
      '<label>Phone (10 digits)</label><input name="phone" inputmode="tel" autocomplete="tel" value="' + esc(draft.phone) + '">' +
      '<label>Email</label><input name="email" type="email" inputmode="email" autocomplete="email" value="' + esc(draft.email) + '">' +
      '<label>Plan</label><select name="plan_id">' + plans.map(function (p) { return '<option value="' + esc(p.id) + '"' + (draft.plan_id === p.id ? ' selected' : '') + '>' + esc(p.name) + ' — ' + C.inr(p.price) + ' / ' + p.duration_days + ' days</option>'; }).join('') + '</select>' +
      '<p class="muted">Membership starts today and runs for the plan’s number of days. Gym: ' + esc(C.GYM.name) + '.</p><button class="btn" type="submit">Register member</button></form>';
    $('#regForm').onsubmit = function (e) {
      e.preventDefault();
      var f = e.target, d = { name: f.name.value, phone: f.phone.value, email: f.email.value, plan_id: f.plan_id.value };
      renderRegister(store.register(d), d);
    };
  }

  // ---------- Payments ----------
  function payTarget() { return store.member(pay.member); }
  function renderPayments(msg) {
    var st = store.state.settings, plans = store.state.plans.filter(function (p) { return p.active; });
    var members = pay.q ? store.searchMembers(pay.q) : sortedMembers().slice(0, 10);
    if (pay.member && !members.some(function (m) { return m.id === pay.member; }) && store.member(pay.member)) members.unshift(store.member(pay.member));
    var h = back() + '<h2>Payments</h2>' + (msg ? '<div class="res ok">' + esc(msg) + '</div>' : '');
    if (!st.upi_id) {
      h += '<div class="card"><b>Set the gym’s UPI ID</b><div class="muted">Needed to take Google Pay / UPI payments. Money goes to this UPI ID.</div>' +
        '<label>UPI ID</label><input id="sUpi" placeholder="yourname@bank" autocapitalize="none" autocomplete="off"><label>Name shown when paying</label><input id="sName" value="' + esc(st.payee_name) + '">' +
        '<button class="btn" id="sSave">Save UPI ID</button><div id="sErr" class="errtxt"></div></div>';
    } else {
      h += '<div class="card row"><div><div class="muted">Receiving UPI ID</div><b>' + esc(st.upi_id) + '</b></div><button class="btn small ghost" data-go="settings">Change</button></div>';
    }
    h += '<label>Member</label><input id="pq" type="search" placeholder="Search name or phone" value="' + esc(pay.q) + '" autocomplete="off">' +
      '<select id="pm" style="margin-top:8px"><option value="">Choose a member…</option>' + members.map(function (m) { return '<option value="' + esc(m.id) + '"' + (pay.member === m.id ? ' selected' : '') + '>' + esc(m.name) + ' — ' + esc(m.phone) + '</option>'; }).join('') + '</select>' +
      '<label>Plan</label><select id="pp"><option value="">Custom amount</option>' + plans.map(function (p) { return '<option value="' + esc(p.id) + '"' + (pay.plan === p.id ? ' selected' : '') + '>' + esc(p.name) + ' — ' + C.inr(p.price) + '</option>'; }).join('') + '</select>' +
      '<label>Amount (₹)</label><input id="pa" type="number" inputmode="decimal" min="1" step="0.01" value="' + esc(pay.amount) + '">' +
      '<label class="chk"><input type="checkbox" id="pr"' + (pay.renew ? ' checked' : '') + (pay.plan ? '' : ' disabled') + '> Renew membership with this plan when recorded</label>' +
      '<label>Pay with</label><div class="seg" id="pmeth">' + [['upi', 'Google Pay / UPI'], ['cash', 'Cash'], ['card', 'Card']].map(function (x) { return '<button data-m="' + x[0] + '" class="' + (pay.method === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div>' +
      '<label>Note / UPI reference (optional)</label><input id="pn" value="' + esc(pay.note) + '" placeholder="e.g. UPI ref no.">';
    if (pay.method === 'upi') {
      h += '<button class="btn gpay" id="goGpay">Pay with Google Pay</button><button class="btn ghost" id="goUpi">Other UPI apps</button><button class="btn ghost" id="goQr">' + (pay.showQr ? 'Hide' : 'Show') + ' UPI QR</button>';
      if (pay.showQr) {
        var up = upiParams();
        h += up.o ? '<div class="qrcard">' + qrSvg(C.upiLink(up.o)) + '<p class="muted">Scan with Google Pay, PhonePe, Paytm or any UPI app.</p></div>' : '<p class="muted">' + esc(up.err) + ' Then the QR appears here.</p>';
      }
    } else {
      h += '<button class="btn" id="goRec">Record ' + (pay.method === 'cash' ? 'cash' : 'card') + ' payment</button>';
    }
    h += '<div id="pErr" class="errtxt"></div>';
    if (pay.pending) {
      h += '<div class="card pend"><b>Did the payment go through?</b><div class="muted">' + C.inr(pay.pending.amount) + ' to ' + esc(store.state.settings.payee_name) + ' for ' + esc(payTargetName(pay.pending.member)) + '. Check the Google Pay success screen or your bank SMS, then confirm.</div>' +
        '<label>UPI reference (optional)</label><input id="pref" placeholder="12-digit UPI ref" value="' + esc(pay.pending.ref || '') + '"><button class="btn" id="pYes">Yes, record payment</button><button class="btn ghost" id="pNo">No / cancel</button></div>';
    }
    var recent = store.recentPayments(8);
    h += '<h3>Recent payments</h3><div class="list">' + (recent.length ? recent.map(function (p) {
      return '<div class="item plain"><div class="row"><span><b>' + esc(p.name) + '</b><div class="muted">' + C.fmtDate(p.paid_at) + ' · ' + esc(p.method) + (p.ref ? ' · ' + esc(p.ref) : '') + '</div></span><b>' + C.inr(p.amount) + '</b></div></div>'; }).join('') : '<div class="empty">No payments yet.</div>') + '</div>';
    view.innerHTML = h;
    bindPayments();
  }
  function payTargetName(id) { var m = store.member(id); return m ? m.name : 'member'; }
  function readForm() {
    var q = $('#pq'); if (!q) return;
    pay.q = q.value; pay.member = $('#pm').value; pay.plan = $('#pp').value; pay.amount = $('#pa').value; pay.renew = $('#pr').checked && !!pay.plan; pay.note = $('#pn').value;
  }
  function planById(id) { return store.state.plans.filter(function (p) { return p.id === id; })[0]; }
  // UPI parameters built from the saved form state only (never touches the DOM).
  function upiParams() {
    var st = store.state.settings, err = '';
    if (!st.upi_id) err = 'Save the gym’s UPI ID first.';
    else if (!payTarget()) err = 'Choose a member.';
    else if (!C.validAmount(pay.amount)) err = 'Enter a valid amount.';
    if (err) return { err: err };
    var plan = planById(pay.plan);
    return { o: { pa: st.upi_id, pn: st.payee_name, am: Number(pay.amount), tn: ((plan ? plan.name : 'Gym fee') + ' ' + payTarget().name).slice(0, 50), tr: 'GF' + Date.now().toString(36).toUpperCase() } };
  }
  // Reads the on-screen form, then validates; shows the problem under the buttons.
  function upiInputs() {
    readForm();
    var r = upiParams();
    if (r.err) { if ($('#pErr')) $('#pErr').textContent = r.err; return null; }
    return r.o;
  }
  function launchUpi(kind) {
    var o = upiInputs(); if (!o) return;
    pay.pending = { member: pay.member, plan: pay.plan, renew: pay.renew, amount: o.am, ref: '' };
    renderPayments();
    if (kind === 'upi') { window.location.href = C.upiLink(o); return; }
    // Google Pay first; if nothing took over the screen, fall back to the normal UPI app chooser.
    var left = false;
    function gone() { left = true; }
    document.addEventListener('visibilitychange', gone, { once: true });
    window.addEventListener('blur', gone, { once: true });
    window.location.href = C.gpayLink(o);
    setTimeout(function () { if (!left) window.location.href = C.upiLink(o); }, 1500);
  }
  function finishPayment(method, ref) {
    var data = pay.pending || { member: pay.member, plan: pay.plan, renew: pay.renew, amount: pay.amount };
    var r = store.recordPayment({ member_id: data.member, amount: data.amount, method: method, ref: ref || pay.note, plan_id: data.plan, renew: data.renew && !!data.plan, note: '' });
    if (!r.ok) { if ($('#pErr')) $('#pErr').textContent = r.error; return; }
    var who = payTargetName(data.member), extra = r.membership ? ' Membership runs ' + C.fmtDate(r.membership.start_date) + ' to ' + C.fmtDate(r.membership.end_date) + '.' : '';
    pay.pending = null; pay.amount = ''; pay.plan = ''; pay.renew = false; pay.note = ''; pay.showQr = false;
    renderPayments('Recorded ' + C.inr(r.payment.amount) + ' (' + method + ') for ' + who + '.' + extra);
  }
  function bindPayments() {
    var on = function (id, fn) { var el = $(id); if (el) el.onclick = fn; };
    on('#sSave', function () {
      try { store.setSettings({ upi_id: $('#sUpi').value, payee_name: $('#sName').value }); if (!store.state.settings.upi_id) throw new Error('Enter the UPI ID.'); renderPayments('UPI ID saved.'); }
      catch (e) { $('#sErr').textContent = e.message; }
    });
    $('#pq').oninput = function () {
      pay.q = this.value; var list = pay.q ? store.searchMembers(pay.q) : sortedMembers().slice(0, 10), sel = $('#pm');
      sel.innerHTML = '<option value="">Choose a member…</option>' + list.map(function (m) { return '<option value="' + esc(m.id) + '">' + esc(m.name) + ' — ' + esc(m.phone) + '</option>'; }).join('');
      if (list.length === 1) { sel.value = list[0].id; pay.member = list[0].id; } else pay.member = '';
    };
    $('#pm').onchange = function () { pay.member = this.value; };
    $('#pp').onchange = function () { readForm(); var p = planById(pay.plan); if (p) pay.amount = String(p.price); pay.renew = !!p && pay.renew; renderPayments(); };
    $('#pa').oninput = function () { pay.amount = this.value; };
    $('#pn').oninput = function () { pay.note = this.value; };
    $('#pr').onchange = function () { pay.renew = this.checked; };
    $('#pmeth').onclick = function (e) { var b = e.target.closest('button'); if (b) { readForm(); pay.method = b.getAttribute('data-m'); pay.pending = null; renderPayments(); } };
    on('#goGpay', function () { launchUpi('gpay'); });
    on('#goUpi', function () { launchUpi('upi'); });
    on('#goQr', function () { readForm(); pay.showQr = !pay.showQr; renderPayments(); });
    on('#goRec', function () {
      readForm();
      if (!payTarget()) { $('#pErr').textContent = 'Choose a member.'; return; }
      pay.pending = null; finishPayment(pay.method, pay.note);
    });
    on('#pYes', function () { finishPayment('upi', $('#pref').value); });
    on('#pNo', function () { pay.pending = null; renderPayments(); });
  }

  // ---------- FAQ ----------
  function renderFaq(q) {
    q = (q || '').toLowerCase();
    var all = K.FAQ.map(function (f) { return { q: f.q, a: f.a, custom: false }; }).concat(store.state.faqs.map(function (f) { return { id: f.id, q: f.q, a: f.a, custom: true }; }));
    var list = all.filter(function (f) { return !q || (f.q + ' ' + f.a).toLowerCase().indexOf(q) !== -1; });
    view.innerHTML = back() + '<h2>FAQ</h2><input id="fq" type="search" placeholder="Search questions" value="' + esc(q) + '" autocomplete="off"><p class="muted" style="margin:8px 2px">' + list.length + ' question(s)</p>' +
      '<div id="faqList">' + (list.length ? list.map(function (f) {
        return '<details class="faq"><summary>' + esc(f.q) + (f.custom ? ' <span class="tag">yours</span>' : '') + '</summary><p>' + esc(f.a) + '</p>' + (f.custom ? '<button class="btn small danger" data-del="' + esc(f.id) + '">Delete</button>' : '') + '</details>';
      }).join('') : '<div class="empty">No matching questions.</div>') + '</div>' +
      '<h3>Add your own question</h3><div class="card"><label>Question</label><input id="nq" placeholder="e.g. What are the gym timings?"><label>Answer</label><textarea id="na" rows="3" placeholder="Write the answer members should see"></textarea><button class="btn" id="addFaq">Add question</button><div id="fErr" class="errtxt"></div></div>';
    $('#fq').oninput = function () { var pos = this.selectionStart; renderFaq(this.value); var i = $('#fq'); i.focus(); try { i.setSelectionRange(pos, pos); } catch (e) { /* ignore */ } };
    $('#addFaq').onclick = function () {
      try { store.addFaq($('#nq').value, $('#na').value); renderFaq(''); }
      catch (e) { $('#fErr').textContent = e.message; }
    };
    $('#faqList').onclick = function (e) {
      var b = e.target.closest('button[data-del]'); if (!b) return;
      if (confirm('Delete this question?')) { store.removeFaq(b.getAttribute('data-del')); renderFaq($('#fq').value); }
    };
  }

  // ---------- Settings ----------
  function renderSettings(msg) {
    var st = store.state.settings;
    view.innerHTML = back() + '<h2>Settings</h2>' + (msg ? '<div class="card" style="background:var(--brand-soft)">' + esc(msg) + '</div>' : '') +
      '<div class="card"><b>' + esc(C.GYM.name) + '</b><div class="muted">' + store.state.members.length + ' members · ' + store.state.memberships.length + ' memberships · ' + store.state.payments.length + ' payments · ' + store.state.attendance.length + ' visits</div></div>' +
      '<h3>Payments (Google Pay / UPI)</h3><div class="card"><label style="margin-top:0">Gym UPI ID</label><input id="sUpi" value="' + esc(st.upi_id) + '" placeholder="yourname@bank" autocapitalize="none" autocomplete="off"><label>Name shown when paying</label><input id="sName" value="' + esc(st.payee_name) + '"><button class="btn" id="sSave">Save</button><div id="sErr" class="errtxt"></div></div>' +
      '<h3>Plans</h3>' + store.state.plans.map(function (p) { return '<div class="card row"><div><b>' + esc(p.name) + '</b><div class="muted">' + p.duration_days + ' days</div></div><b>' + C.inr(p.price) + '</b></div>'; }).join('') +
      '<h3>Data (stored on this phone)</h3>' +
      '<button class="btn ghost" id="copyBackup">Copy backup to clipboard</button>' +
      '<label>Restore from backup (paste JSON)</label><textarea id="importBox" rows="3" placeholder="Paste backup JSON here"></textarea>' +
      '<button class="btn ghost" id="importBtn">Restore backup</button>' +
      '<button class="btn ghost" id="demoBtn">Reset to demo data</button>' +
      '<button class="btn danger" id="clearBtn">Clear all members &amp; records</button>' +
      '<p class="muted" style="margin-top:16px">All data lives only on this device. There is no server or sync.</p>';
    $('#sSave').onclick = function () {
      try { store.setSettings({ upi_id: $('#sUpi').value, payee_name: $('#sName').value }); renderSettings('Payment settings saved.'); }
      catch (e) { $('#sErr').textContent = e.message; }
    };
    $('#copyBackup').onclick = function () {
      var text = store.exportJSON();
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function () { renderSettings('Backup copied. Paste it somewhere safe.'); }, function () { fallbackCopy(text); });
      else fallbackCopy(text);
    };
    function fallbackCopy(text) { var ta = $('#importBox'); ta.value = text; ta.select(); try { document.execCommand('copy'); renderSettings('Backup copied.'); } catch (e) { /* user can copy by hand */ } }
    $('#importBtn').onclick = function () {
      try { store.importJSON($('#importBox').value); bot = new C.Assistant(store); renderSettings('Backup restored.'); }
      catch (e) { renderSettings('Could not restore: ' + e.message); }
    };
    $('#demoBtn').onclick = function () { if (confirm('Replace all data with demo data?')) { store.resetDemo(); bot = new C.Assistant(store); renderSettings('Demo data loaded.'); } };
    $('#clearBtn').onclick = function () { if (confirm('Delete ALL members, memberships, payments and visits? This cannot be undone.')) { store.clearAll(); bot = new C.Assistant(store); renderSettings('All records cleared.'); } };
  }

  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && location.hostname !== 'localhost') {
    navigator.serviceWorker.register('sw.js').catch(function () { /* offline cache is optional */ });
  }
  go('assistant');
})();
