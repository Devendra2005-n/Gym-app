/* GymFlow AI - core logic (data layer, registration, reports, owner assistant).
   No DOM access here, so it can be unit-tested in Node. */
(function (root) {
  'use strict';

  var GYM = { id: 'gym_fitness_arena', name: 'Fitness Arena' };
  var KEY = 'gymflow.v1';

  // ---------- date helpers (India time) ----------
  function todayIST(now) {
    var d = now ? new Date(now) : new Date();
    return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
  }
  function addDays(dateStr, n) {
    var t = new Date(dateStr + 'T00:00:00Z');
    t.setUTCDate(t.getUTCDate() + n);
    return t.toISOString().slice(0, 10);
  }
  function diffDays(a, b) {
    return Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 86400000);
  }
  function monthStart(d) { return d.slice(0, 8) + '01'; }
  function fmtDate(d) {
    if (!d) return '-';
    var p = d.split('-');
    var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][+p[1] - 1];
    return p[2] + ' ' + m + ' ' + p[0];
  }
  function inr(n) { return '₹' + Number(n || 0).toLocaleString('en-IN'); }

  // ---------- input cleaning ----------
  function cleanPhone(raw) {
    var d = String(raw || '').replace(/\D/g, '');
    if (d.length === 12 && d.indexOf('91') === 0) d = d.slice(2);
    else if (d.length === 11 && d.charAt(0) === '0') d = d.slice(1);
    return d;
  }
  function cleanEmail(raw) { return String(raw || '').trim().toLowerCase(); }
  function cleanName(raw) { return String(raw || '').trim().replace(/\s+/g, ' '); }

  // ---------- demo data ----------
  function seedDemo(today) {
    var seed = 7;
    function rnd() { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; }
    var plans = [
      { id: 'plan_monthly', gym_id: GYM.id, name: 'Monthly Basic', duration_days: 30, price: 1000, active: true },
      { id: 'plan_quarterly', gym_id: GYM.id, name: 'Quarterly Plan', duration_days: 90, price: 2700, active: true },
      { id: 'plan_annual', gym_id: GYM.id, name: 'Annual Premium', duration_days: 365, price: 9000, active: true }
    ];
    var people = [
      ['Rohan Patil', 'rohan.patil@example.com'], ['Priya Deshmukh', 'priya.d@example.com'],
      ['Amit Jadhav', 'amit.jadhav@example.com'], ['Sneha Kulkarni', 'sneha.k@example.com'],
      ['Vikram Shinde', 'vikram.s@example.com'], ['Neha More', 'neha.more@example.com'],
      ['Rahul Pawar', 'rahul.pawar@example.com'], ['Pooja Chavan', 'pooja.c@example.com'],
      ['Sagar Mane', 'sagar.mane@example.com'], ['Anjali Kamble', 'anjali.k@example.com'],
      ['Omkar Gaikwad', 'omkar.g@example.com'], ['Kavita Bhosale', 'kavita.b@example.com'],
      ['Suraj Salunkhe', 'suraj.s@example.com'], ['Rutuja Patil', 'rutuja.patil@example.com']
    ];
    // [planIndex, daysAgoStarted]  -> chosen so some are expiring soon / expired
    var layout = [[0, 12], [1, 40], [2, 100], [0, 27], [0, 33], [1, 85], [2, 300], [0, 5],
                  [1, 70], [0, 25], [2, 200], [0, 45], [1, 92], [0, 2]];
    var methods = ['cash', 'upi', 'card'];
    var s = { gym: GYM, plans: plans, members: [], memberships: [], payments: [], attendance: [], seq: 1 };
    var n = 1;
    people.forEach(function (p, i) {
      var mid = 'mem_' + (i + 1);
      s.members.push({
        id: mid, gym_id: GYM.id, name: p[0], phone: '98' + String(10000000 + i * 1371913).slice(0, 8),
        email: p[1], health_notes: i % 4 === 0 ? 'Private note' : '', created_at: addDays(today, -layout[i][1])
      });
      var pl = plans[layout[i][0]];
      var start = addDays(today, -layout[i][1]);
      var msid = 'ms_' + (n++);
      s.memberships.push({ id: msid, member_id: mid, gym_id: GYM.id, plan_id: pl.id, start_date: start, end_date: addDays(start, pl.duration_days), status: 'active' });
      s.payments.push({ id: 'pay_' + msid, member_id: mid, membership_id: msid, gym_id: GYM.id, amount: pl.price, method: methods[Math.floor(rnd() * 3)], paid_at: start });
      // some members also have an older, finished membership
      if (i % 3 === 1) {
        var oldStart = addDays(start, -40), oid = 'ms_' + (n++);
        s.memberships.push({ id: oid, member_id: mid, gym_id: GYM.id, plan_id: plans[0].id, start_date: oldStart, end_date: addDays(oldStart, 30), status: 'active' });
        s.payments.push({ id: 'pay_' + oid, member_id: mid, membership_id: oid, gym_id: GYM.id, amount: plans[0].price, method: methods[Math.floor(rnd() * 3)], paid_at: oldStart });
      }
      // attendance: visits across the active period (up to last 30 days)
      var from = Math.max(Date.parse(start) , Date.parse(addDays(today, -30)));
      var days = Math.round((Date.parse(today) - from) / 86400000);
      for (var d = 0; d <= days; d++) {
        if (rnd() < 0.55) {
          var vd = addDays(today, -d);
          if (vd >= start && vd <= addDays(start, pl.duration_days)) {
            s.attendance.push({ id: 'att_' + (s.seq++), member_id: mid, gym_id: GYM.id, visit_date: vd, check_in: (6 + Math.floor(rnd() * 14)) + ':' + (rnd() < 0.5 ? '00' : '30') });
          }
        }
      }
    });
    return s;
  }

  // ---------- store ----------
  function Store(storage, nowFn) {
    this.storage = storage;
    this.now = nowFn || function () { return new Date(); };
    this.state = null;
    this.load();
  }
  Store.prototype.today = function () { return todayIST(this.now()); };
  Store.prototype.load = function () {
    var raw = null;
    try { raw = this.storage && this.storage.getItem(KEY); } catch (e) { raw = null; }
    if (raw) { try { this.state = JSON.parse(raw); } catch (e) { this.state = null; } }
    if (!this.state) { this.state = seedDemo(this.today()); this.save(); }
  };
  Store.prototype.save = function () {
    try { if (this.storage) this.storage.setItem(KEY, JSON.stringify(this.state)); } catch (e) { /* storage full/blocked */ }
  };
  Store.prototype.resetDemo = function () { this.state = seedDemo(this.today()); this.save(); };
  Store.prototype.clearAll = function () {
    var plans = this.state.plans;
    this.state = { gym: GYM, plans: plans, members: [], memberships: [], payments: [], attendance: [], seq: 1 };
    this.save();
  };
  Store.prototype.exportJSON = function () { return JSON.stringify(this.state, null, 2); };
  Store.prototype.importJSON = function (text) {
    var o = JSON.parse(text);
    ['plans', 'members', 'memberships', 'payments', 'attendance'].forEach(function (k) {
      if (!Array.isArray(o[k])) throw new Error('Missing "' + k + '" list');
    });
    o.gym = GYM; o.seq = o.seq || 1;
    this.state = o; this.save();
  };
  Store.prototype.plan = function (id) { return this.state.plans.filter(function (p) { return p.id === id; })[0]; };
  Store.prototype.member = function (id) { return this.state.members.filter(function (m) { return m.id === id; })[0]; };
  Store.prototype.msStatus = function (ms) {
    var t = this.today();
    if (ms.end_date < t) return 'expired';
    if (ms.start_date > t) return 'upcoming';
    return 'active';
  };
  Store.prototype.hasActive = function (memberId) {
    var self = this;
    return this.state.memberships.some(function (ms) { return ms.member_id === memberId && self.msStatus(ms) !== 'expired'; });
  };
  function nextId(prefix) { return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

  // ---------- 1. New member registration ----------
  Store.prototype.register = function (form) {
    var name = cleanName(form.name), phone = cleanPhone(form.phone), email = cleanEmail(form.email);
    var errors = [];
    if (name.length < 2) errors.push('Enter the member’s full name.');
    if (!/^[6-9]\d{9}$/.test(phone)) errors.push('Phone must be a valid 10-digit Indian mobile number.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('Enter a valid email address.');
    var plan = this.state.plans.filter(function (p) { return p.id === form.plan_id && p.active; })[0];
    if (!plan) errors.push('Choose one of the active plans.');
    if (errors.length) return { ok: false, code: 'invalid', errors: errors };

    var self = this;
    var existing = this.state.members.filter(function (m) { return m.gym_id === GYM.id && m.phone === phone; })[0];
    if (existing && this.hasActive(existing.id)) {
      return { ok: false, code: 'duplicate', errors: ['Already registered — this phone number has an active membership.'], member: existing };
    }
    var today = this.today();
    var member = existing;
    var created = false;
    if (!member) {
      member = { id: nextId('mem'), gym_id: GYM.id, name: name, phone: phone, email: email, health_notes: '', created_at: today };
      this.state.members.push(member);
      created = true;
    }
    var ms = { id: nextId('ms'), member_id: member.id, gym_id: GYM.id, plan_id: plan.id, start_date: today, end_date: addDays(today, plan.duration_days), status: 'active' };
    this.state.memberships.push(ms);
    // Note: no payment record is created here, by design.
    this.save();
    return { ok: true, code: created ? 'created' : 'renewed_existing', member: member, membership: ms, plan: plan };
  };

  // ---------- 3. Member search ----------
  Store.prototype.searchMembers = function (q) {
    q = String(q || '').trim().toLowerCase();
    if (!q) return [];
    var digits = q.replace(/\D/g, '');
    var tokens = q.split(/\s+/).filter(Boolean);
    return this.state.members.filter(function (m) {
      var name = m.name.toLowerCase();
      if (tokens.every(function (t) { return name.indexOf(t) !== -1; })) return true;
      if (digits.length >= 3 && m.phone.indexOf(digits) !== -1) return true;
      return m.email.toLowerCase().indexOf(q) !== -1;
    }).slice(0, 10);
  };

  // ---------- 4. Membership lookup ----------
  Store.prototype.membershipLookup = function (memberId) {
    var self = this;
    return this.state.memberships.filter(function (ms) { return ms.member_id === memberId; })
      .sort(function (a, b) { return a.start_date < b.start_date ? 1 : -1; })
      .map(function (ms) {
        var p = self.plan(ms.plan_id);
        var status = self.msStatus(ms);
        return { id: ms.id, plan: p ? p.name : 'Unknown plan', start_date: ms.start_date, end_date: ms.end_date, status: status,
                 days_left: status === 'expired' ? 0 : diffDays(self.today(), ms.end_date) };
      });
  };

  // ---------- 5. Payment lookup ----------
  Store.prototype.paymentLookup = function (memberId) {
    var list = this.state.payments.filter(function (p) { return p.member_id === memberId; })
      .sort(function (a, b) { return a.paid_at < b.paid_at ? 1 : -1; });
    var total = list.reduce(function (s, p) { return s + p.amount; }, 0);
    return { payments: list, total_paid: total, last_payment: list[0] || null };
  };

  // ---------- 6. Revenue report ----------
  Store.prototype.revenueReport = function (from, to) {
    var t = this.today();
    from = from || monthStart(t); to = to || t;
    var list = this.state.payments.filter(function (p) { return p.paid_at >= from && p.paid_at <= to; });
    var byMethod = {}, byDay = {}, total = 0;
    list.forEach(function (p) {
      total += p.amount;
      byMethod[p.method] = (byMethod[p.method] || 0) + p.amount;
      byDay[p.paid_at] = (byDay[p.paid_at] || 0) + p.amount;
    });
    var days = Object.keys(byDay).sort().map(function (d) { return { date: d, amount: byDay[d] }; });
    var methods = Object.keys(byMethod).sort().map(function (m) { return { method: m, amount: byMethod[m] }; });
    return { from: from, to: to, total: total, count: list.length, by_method: methods, by_day: days };
  };

  // ---------- 7. Expiry report ----------
  Store.prototype.expiryReport = function (days, mode) {
    var self = this, t = this.today();
    days = days == null ? 7 : days;
    // consider only each member's latest membership
    var latest = {};
    this.state.memberships.forEach(function (ms) {
      var cur = latest[ms.member_id];
      if (!cur || ms.end_date > cur.end_date) latest[ms.member_id] = ms;
    });
    var rows = Object.keys(latest).map(function (mid) {
      var ms = latest[mid], m = self.member(mid), p = self.plan(ms.plan_id);
      return { member_id: mid, name: m ? m.name : '?', phone: m ? m.phone : '', plan: p ? p.name : '?', end_date: ms.end_date, days_left: diffDays(t, ms.end_date) };
    });
    if (mode === 'expired') return rows.filter(function (r) { return r.days_left < 0; }).sort(function (a, b) { return b.days_left - a.days_left; });
    return rows.filter(function (r) { return r.days_left >= 0 && r.days_left <= days; }).sort(function (a, b) { return a.days_left - b.days_left; });
  };

  // ---------- 8. Attendance report ----------
  Store.prototype.attendanceReport = function (from, to, memberId) {
    var self = this, t = this.today();
    from = from || monthStart(t); to = to || t;
    var list = this.state.attendance.filter(function (a) {
      return a.visit_date >= from && a.visit_date <= to && (!memberId || a.member_id === memberId);
    });
    var perMember = {}, perDay = {};
    list.forEach(function (a) {
      perMember[a.member_id] = (perMember[a.member_id] || 0) + 1;
      perDay[a.visit_date] = (perDay[a.visit_date] || 0) + 1;
    });
    var members = Object.keys(perMember).map(function (id) {
      var m = self.member(id); return { member_id: id, name: m ? m.name : '?', visits: perMember[id] };
    }).sort(function (a, b) { return b.visits - a.visits; });
    var daysArr = Object.keys(perDay).sort().map(function (d) { return { date: d, visits: perDay[d] }; });
    return { from: from, to: to, total_visits: list.length, by_member: members, by_day: daysArr, visits: list };
  };

  // ---------- 2. Operations assistant (read-only, rule-based, offline) ----------
  var WRITE_RE = /\b(register|renew|delete|remove|edit|update|modify|cancel|record|enroll|sign\s*up|add\s+(a\s+|the\s+|new\s+)?(member|payment|membership|visit|check)|create|change|mark)\b/i;
  var STOP = ['show', 'me', 'give', 'tell', 'what', 'whats', "what's", 'is', 'are', 'the', 'a', 'an', 'of', 'for', 'to', 'on', 'in', 'at', 'by', 'and', 'with', 'about', 'please', 'can', 'you',
    'member', 'members', 'membership', 'memberships', 'plan', 'plans', 'payment', 'payments', 'paid', 'pay', 'status', 'details', 'detail', 'info', 'find', 'search', 'lookup', 'look', 'up',
    'when', 'does', 'do', 'did', 'his', 'her', 'their', 'has', 'have', 'how', 'much', 'many', 'total', 'last', 'history', 'current', 'active', 'valid', 'expire', 'expires', 'expiry', 'expiring',
    'attendance', 'visits', 'visit', 'attend', 'attended', 'check-in', 'checkin', 'who', 'whose', 'number', 'phone', 'email', 'my', 'gym', 'this', 'that', 'it', 'month', 'week', 'today', 'year',
    'revenue', 'income', 'days', 'day', 'next', 'past', 'from', 'all', 'list', 'report', 'dues', 'renewal', 'ending', 'come', 'came'];

  function parseRange(text, today) {
    var t = text.toLowerCase(), m;
    if (/\btoday\b/.test(t)) return { from: today, to: today, label: 'today' };
    if (/\byesterday\b/.test(t)) { var y = addDays(today, -1); return { from: y, to: y, label: 'yesterday' }; }
    if (/last month|previous month/.test(t)) {
      var first = monthStart(today), lastDay = addDays(first, -1);
      return { from: monthStart(lastDay), to: lastDay, label: 'last month' };
    }
    if (/this week/.test(t)) {
      var dow = new Date(today + 'T00:00:00Z').getUTCDay(); var back = (dow + 6) % 7;
      return { from: addDays(today, -back), to: today, label: 'this week' };
    }
    if ((m = t.match(/(?:last|past)\s+(\d+)\s+days?/))) return { from: addDays(today, -(+m[1] - 1)), to: today, label: 'the last ' + m[1] + ' days' };
    if (/this year/.test(t)) return { from: today.slice(0, 4) + '-01-01', to: today, label: 'this year' };
    return { from: monthStart(today), to: today, label: 'this month' };
  }

  function Assistant(store) {
    this.store = store;
    this.history = [];   // last 10 messages kept
    this.pending = null; // waiting for the owner to pick a member
  }
  Assistant.prototype._push = function (role, text) {
    this.history.push({ role: role, text: text });
    if (this.history.length > 10) this.history = this.history.slice(-10);
  };
  Assistant.prototype.ask = function (text) {
    this._push('user', text);
    var reply = this._answer(String(text || '').trim());
    this._push('assistant', reply);
    return reply;
  };
  Assistant.prototype._extractQuery = function (text) {
    var phone = text.replace(/[^\d]/g, '');
    if (phone.length >= 6) return phone;
    var email = text.match(/[^\s@]+@[^\s@]+/);
    if (email) return email[0];
    var words = text.toLowerCase().replace(/[?.,!'"]/g, ' ').split(/\s+/).filter(function (w) { return w && STOP.indexOf(w) === -1 && !/^\d+$/.test(w); });
    return words.join(' ');
  };
  Assistant.prototype._pickMember = function (query, intent) {
    var found = this.store.searchMembers(query);
    if (!found.length) { this.pending = null; return { reply: 'I could not find a member matching “' + query + '”.' }; }
    if (found.length > 1) {
      this.pending = { intent: intent, candidates: found };
      var lines = found.map(function (m, i) { return (i + 1) + '. ' + m.name + ' — ' + m.phone; });
      return { reply: 'Several members match. Which one do you mean? Reply with the number, or the phone.\n' + lines.join('\n') };
    }
    this.pending = null;
    return { member: found[0] };
  };
  Assistant.prototype._memberAnswer = function (member, intent, rangeText) {
    var s = this.store, out = '';
    if (intent === 'payments') {
      var p = s.paymentLookup(member.id);
      if (!p.payments.length) return member.name + ' has no payment records.';
      out = 'Payments for ' + member.name + ':\n';
      p.payments.forEach(function (x) { out += '• ' + fmtDate(x.paid_at) + ' — ' + inr(x.amount) + ' (' + x.method + ')\n'; });
      out += 'Total paid: ' + inr(p.total_paid) + '\nLast payment: ' + fmtDate(p.last_payment.paid_at) + ' (' + inr(p.last_payment.amount) + ')';
      return out;
    }
    if (intent === 'attendance') {
      var r = parseRange(rangeText || '', s.today());
      var a = s.attendanceReport(r.from, r.to, member.id);
      return member.name + ' visited ' + a.total_visits + ' time(s) in ' + r.label + ' (' + fmtDate(r.from) + ' – ' + fmtDate(r.to) + ').';
    }
    if (intent === 'memberships') {
      var list = s.membershipLookup(member.id);
      if (!list.length) return member.name + ' has no memberships.';
      out = 'Memberships for ' + member.name + ':\n';
      list.forEach(function (m) {
        out += '• ' + m.plan + ': ' + fmtDate(m.start_date) + ' → ' + fmtDate(m.end_date) + ' [' + m.status + (m.status === 'active' ? ', ' + m.days_left + ' days left' : '') + ']\n';
      });
      return out.trim();
    }
    return member.name + '\nPhone: ' + member.phone + '\nEmail: ' + member.email + '\n' + this._memberAnswer(member, 'memberships');
  };
  Assistant.prototype._answer = function (text) {
    var s = this.store, t = text.toLowerCase(), today = s.today();

    // follow-up to "which member?"
    if (this.pending) {
      var c = this.pending.candidates, chosen = null, num = t.match(/^\s*(\d+)\s*$/);
      if (num && c[+num[1] - 1] && num[1].length < 3) chosen = c[+num[1] - 1];
      if (!chosen) {
        var q = this._extractQuery(text), hit = q ? c.filter(function (m) {
          return m.phone.indexOf(q.replace(/\D/g, '')) !== -1 && q.replace(/\D/g, '').length >= 4 || m.name.toLowerCase().indexOf(q) !== -1;
        }) : [];
        if (hit.length === 1) chosen = hit[0];
      }
      if (chosen) { var intent = this.pending.intent; this.pending = null; return this._memberAnswer(chosen, intent, ''); }
      if (!WRITE_RE.test(text) && t.length < 25) return 'Please reply with one of the numbers above (or the member’s phone).';
      this.pending = null;
    }

    if (WRITE_RE.test(text)) {
      return 'I’m read-only, so I can’t register, renew, edit, record or delete anything. Use the Register tab for new members. I can look up members, memberships, payments, revenue, expiries and attendance.';
    }
    if (/health|medical|injur|illness|disease|condition|allerg/.test(t)) {
      return 'Health notes are private and I don’t share them.';
    }
    if (/\b(help|what can you do|hello|hi|hey)\b/.test(t) && t.length < 30) {
      return 'Ask me things like:\n• Revenue this month / last 7 days\n• Who expires in the next 10 days?\n• Show expired members\n• Attendance this week\n• Find Rohan\n• Payments of Priya\n• Membership status of 98xxxxxx';
    }
    if (/revenue|income|earn|collection|collected|how much.*(made|got)/.test(t)) {
      var r = parseRange(text, today), rep = s.revenueReport(r.from, r.to);
      var out = 'Revenue for ' + r.label + ' (' + fmtDate(r.from) + ' – ' + fmtDate(r.to) + '): ' + inr(rep.total) + ' from ' + rep.count + ' payment(s).';
      if (rep.by_method.length) out += '\nBy method: ' + rep.by_method.map(function (m) { return m.method + ' ' + inr(m.amount); }).join(', ');
      return out;
    }
    if (/expir|ending soon|renewal due|due for renewal|lapsed/.test(t)) {
      var mode = /already|expired|lapsed|overdue/.test(t) && !/expiring|will expire/.test(t) ? 'expired' : 'soon';
      var dm = t.match(/(\d+)\s*days?/), days = dm ? +dm[1] : 7;
      var rows = s.expiryReport(days, mode);
      if (!rows.length) return mode === 'expired' ? 'No expired memberships.' : 'No memberships expiring in the next ' + days + ' days.';
      var head = mode === 'expired' ? 'Expired memberships (' + rows.length + '):\n' : 'Expiring in the next ' + days + ' days (' + rows.length + '):\n';
      return head + rows.map(function (x) {
        return '• ' + x.name + ' (' + x.phone + ') — ' + x.plan + ', ' + (mode === 'expired' ? 'ended ' + fmtDate(x.end_date) : (x.days_left === 0 ? 'ends today' : 'ends ' + fmtDate(x.end_date) + ' (' + x.days_left + 'd)'));
      }).join('\n');
    }
    var q = this._extractQuery(text);
    if (/attend|visit|check-?in|\bcame\b/.test(t)) {
      if (q) {
        var pk = this._pickMember(q, 'attendance'); if (pk.reply) return pk.reply;
        return this._memberAnswer(pk.member, 'attendance', text);
      }
      var rg = parseRange(text, today), at = s.attendanceReport(rg.from, rg.to);
      var o = 'Attendance for ' + rg.label + ': ' + at.total_visits + ' visit(s).';
      if (at.by_member.length) o += '\nMost regular: ' + at.by_member.slice(0, 5).map(function (m) { return m.name + ' (' + m.visits + ')'; }).join(', ');
      return o;
    }
    if (/payment|paid|\bpay\b|dues/.test(t)) {
      if (!q) return 'Whose payments? Give me a name or phone number.';
      var pm = this._pickMember(q, 'payments'); if (pm.reply) return pm.reply;
      return this._memberAnswer(pm.member, 'payments');
    }
    if (q) {
      var intent = /membership|plan|status|valid|active|expire|when/.test(t) ? 'memberships' : 'profile';
      var mm = this._pickMember(q, intent); if (mm.reply) return mm.reply;
      return this._memberAnswer(mm.member, intent);
    }
    return 'I can answer questions about members, memberships, payments, revenue, expiries and attendance. Try “Revenue this month” or “Who expires in 7 days?”.';
  };

  var api = {
    GYM: GYM, Store: Store, Assistant: Assistant, todayIST: todayIST, addDays: addDays, diffDays: diffDays,
    fmtDate: fmtDate, inr: inr, cleanPhone: cleanPhone, cleanEmail: cleanEmail, monthStart: monthStart, parseRange: parseRange, seedDemo: seedDemo
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.GymCore = api;
})(typeof window !== 'undefined' ? window : this);
