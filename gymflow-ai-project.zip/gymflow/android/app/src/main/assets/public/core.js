/* GYM Flow - core logic (data layer, registration, reports, owner assistant).
   No DOM access here, so it can be unit-tested in Node. */
(function (root) {
  'use strict';

  var GYM = { id: 'gym_fitness_arena', name: 'Fitness Arena' };
  var KEY = 'gymflow.v1';

  // ---------- date helpers (India time) ----------
  function todayIST(now) {
    var d = now ? new Date(now) : new Date();
    return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
  }
  function timeIST(now) {
    var d = now ? new Date(now) : new Date();
    return new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(d);
  }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function addDays(dateStr, n) {
    var t = new Date(dateStr + 'T00:00:00Z');
    t.setUTCDate(t.getUTCDate() + n);
    return t.toISOString().slice(0, 10);
  }
  function diffDays(a, b) {
    return Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 86400000);
  }
  function monthStart(d) { return d.slice(0, 8) + '01'; }
  function fmtDate(d) {
    if (!d) return '-';
    var p = d.split('-');
    var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][+p[1] - 1];
    return p[2] + ' ' + m + ' ' + p[0];
  }
  function inr(n) { return '₹' + Number(n || 0).toLocaleString('en-IN'); }

  // ---------- input cleaning ----------
  function cleanPhone(raw) {
    var d = String(raw || '').replace(/\D/g, '');
    if (d.length === 12 && d.indexOf('91') === 0) d = d.slice(2);
    else if (d.length === 11 && d.charAt(0) === '0') d = d.slice(1);
    return d;
  }
  function cleanEmail(raw) { return String(raw || '').trim().toLowerCase(); }
  function cleanName(raw) { return String(raw || '').trim().replace(/\s+/g, ' '); }

  function defaultSettings() { return { upi_id: '', payee_name: GYM.name }; }

  // ---------- demo data ----------
  function seedDemo(today) {
    var seed = 7;
    function rnd() { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; }
    var plans = [
      { id: 'plan_monthly', gym_id: GYM.id, name: 'Monthly Basic', duration_days: 30, price: 1000, active: true },
      { id: 'plan_quarterly', gym_id: GYM.id, name: 'Quarterly Plan', duration_days: 90, price: 2700, active: true },
      { id: 'plan_annual', gym_id: GYM.id, name: 'Annual Premium', duration_days: 365, price: 9000, active: true }
    ];
    var people = [
      ['Rohan Patil', 'rohan.patil@example.com'], ['Priya Deshmukh', 'priya.d@example.com'],
      ['Amit Jadhav', 'amit.jadhav@example.com'], ['Sneha Kulkarni', 'sneha.k@example.com'],
      ['Vikram Shinde', 'vikram.s@example.com'], ['Neha More', 'neha.more@example.com'],
      ['Rahul Pawar', 'rahul.pawar@example.com'], ['Pooja Chavan', 'pooja.c@example.com'],
      ['Sagar Mane', 'sagar.mane@example.com'], ['Anjali Kamble', 'anjali.k@example.com'],
      ['Omkar Gaikwad', 'omkar.g@example.com'], ['Kavita Bhosale', 'kavita.b@example.com'],
      ['Suraj Salunkhe', 'suraj.s@example.com'], ['Rutuja Patil', 'rutuja.patil@example.com']
    ];
    // [planIndex, daysAgoStarted]  -> chosen so some are expiring soon / expired
    var layout = [[0, 12], [1, 40], [2, 100], [0, 27], [0, 33], [1, 85], [2, 300], [0, 5],
                  [1, 70], [0, 25], [2, 200], [0, 45], [1, 92], [0, 2]];
    var methods = ['cash', 'upi', 'card'];
    var s = { gym: GYM, plans: plans, members: [], memberships: [], payments: [], attendance: [], seq: 1, settings: defaultSettings(), faqs: [] };
    var n = 1;
    people.forEach(function (p, i) {
      var mid = 'mem_' + (i + 1);
      s.members.push({
        id: mid, gym_id: GYM.id, name: p[0], phone: '98' + String(10000000 + i * 1371913).slice(0, 8),
        email: p[1], health_notes: i % 4 === 0 ? 'Private note' : '', created_at: addDays(today, -layout[i][1])
      });
      var pl = plans[layout[i][0]];
      var start = addDays(today, -layout[i][1]);
      var msid = 'ms_' + (n++);
      s.memberships.push({ id: msid, member_id: mid, gym_id: GYM.id, plan_id: pl.id, start_date: start, end_date: addDays(start, pl.duration_days), status: 'active' });
      s.payments.push({ id: 'pay_' + msid, member_id: mid, membership_id: msid, gym_id: GYM.id, amount: pl.price, method: methods[Math.floor(rnd() * 3)], paid_at: start });
      // some members also have an older, finished membership
      if (i % 3 === 1) {
        var oldStart = addDays(start, -40), oid = 'ms_' + (n++);
        s.memberships.push({ id: oid, member_id: mid, gym_id: GYM.id, plan_id: plans[0].id, start_date: oldStart, end_date: addDays(oldStart, 30), status: 'active' });
        s.payments.push({ id: 'pay_' + oid, member_id: mid, membership_id: oid, gym_id: GYM.id, amount: plans[0].price, method: methods[Math.floor(rnd() * 3)], paid_at: oldStart });
      }
      // attendance: visits across the active period (up to last 30 days)
      var from = Math.max(Date.parse(start) , Date.parse(addDays(today, -30)));
      var days = Math.round((Date.parse(today) - from) / 86400000);
      for (var d = 0; d <= days; d++) {
        if (rnd() < 0.55) {
          var vd = addDays(today, -d);
          if (vd >= start && vd <= addDays(start, pl.duration_days)) {
            s.attendance.push({ id: 'att_' + (s.seq++), member_id: mid, gym_id: GYM.id, visit_date: vd, check_in: pad2(6 + Math.floor(rnd() * 14)) + ':' + pad2(Math.floor(rnd() * 60)) });
          }
        }
      }
    });
    return s;
  }

  // ---------- store ----------
  function Store(storage, nowFn) {
    this.storage = storage;
    this.now = nowFn || function () { return new Date(); };
    this.state = null;
    this.load();
  }
  Store.prototype.today = function () { return todayIST(this.now()); };
  Store.prototype.load = function () {
    var raw = null;
    try { raw = this.storage && this.storage.getItem(KEY); } catch (e) { raw = null; }
    if (raw) { try { this.state = JSON.parse(raw); } catch (e) { this.state = null; } }
    if (!this.state) { this.state = seedDemo(this.today()); this.save(); }
    this.ensureShape();
  };
  // Older saved data (v1) has no settings / faqs: add them without touching anything else.
  Store.prototype.ensureShape = function () {
    var s = this.state;
    if (!s.settings) s.settings = defaultSettings();
    if (!Array.isArray(s.faqs)) s.faqs = [];
    if (!Array.isArray(s.sales)) s.sales = [];
    if (!Array.isArray(s.bookings)) s.bookings = [];
    if (!s.gym) s.gym = GYM;
  };
  Store.prototype.save = function () {
    try { if (this.storage) this.storage.setItem(KEY, JSON.stringify(this.state)); } catch (e) { /* storage full/blocked */ }
  };
  Store.prototype.resetDemo = function () {
    var keep = { settings: this.state.settings, faqs: this.state.faqs };
    this.state = seedDemo(this.today());
    this.state.settings = keep.settings; this.state.faqs = keep.faqs; this.state.sales = []; this.state.bookings = [];
    this.save();
  };
  Store.prototype.clearAll = function () {
    var keep = this.state;
    this.state = { gym: GYM, plans: keep.plans, members: [], memberships: [], payments: [], attendance: [], seq: 1, settings: keep.settings, faqs: keep.faqs, sales: [], bookings: [] };
    this.save();
  };
  Store.prototype.exportJSON = function () { return JSON.stringify(this.state, null, 2); };
  Store.prototype.importJSON = function (text) {
    var o = JSON.parse(text);
    ['plans', 'members', 'memberships', 'payments', 'attendance'].forEach(function (k) {
      if (!Array.isArray(o[k])) throw new Error('Missing "' + k + '" list');
    });
    o.gym = GYM; o.seq = o.seq || 1;
    this.state = o; this.ensureShape(); this.save();
  };
  Store.prototype.plan = function (id) { return this.state.plans.filter(function (p) { return p.id === id; })[0]; };
  Store.prototype.member = function (id) { return this.state.members.filter(function (m) { return m.id === id; })[0]; };
  Store.prototype.msStatus = function (ms) {
    var t = this.today();
    if (ms.end_date < t) return 'expired';
    if (ms.start_date > t) return 'upcoming';
    return 'active';
  };
  Store.prototype.hasActive = function (memberId) {
    var self = this;
    return this.state.memberships.some(function (ms) { return ms.member_id === memberId && self.msStatus(ms) !== 'expired'; });
  };
  function nextId(prefix) { return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

  // ---------- 1. New member registration ----------
  Store.prototype.register = function (form) {
    var name = cleanName(form.name), phone = cleanPhone(form.phone), email = cleanEmail(form.email);
    var errors = [];
    if (name.length < 2) errors.push('Enter the member’s full name.');
    if (!/^[6-9]\d{9}$/.test(phone)) errors.push('Phone must be a valid 10-digit Indian mobile number.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('Enter a valid email address.');
    var plan = this.state.plans.filter(function (p) { return p.id === form.plan_id && p.active; })[0];
    if (!plan) errors.push('Choose one of the active plans.');
    if (errors.length) return { ok: false, code: 'invalid', errors: errors };

    var self = this;
    var existing = this.state.members.filter(function (m) { return m.gym_id === GYM.id && m.phone === phone; })[0];
    if (existing && this.hasActive(existing.id)) {
      return { ok: false, code: 'duplicate', errors: ['Already registered — this phone number has an active membership.'], member: existing };
    }
    var today = this.today();
    var member = existing;
    var created = false;
    if (!member) {
      member = { id: nextId('mem'), gym_id: GYM.id, name: name, phone: phone, email: email, health_notes: '', created_at: today };
      this.state.members.push(member);
      created = true;
    }
    var ms = { id: nextId('ms'), member_id: member.id, gym_id: GYM.id, plan_id: plan.id, start_date: today, end_date: addDays(today, plan.duration_days), status: 'active' };
    this.state.memberships.push(ms);
    // Note: no payment record is created here, by design.
    this.save();
    return { ok: true, code: created ? 'created' : 'renewed_existing', member: member, membership: ms, plan: plan };
  };

  // ---------- 3. Member search ----------
  Store.prototype.searchMembers = function (q) {
    q = String(q || '').trim().toLowerCase();
    if (!q) return [];
    var digits = q.replace(/\D/g, '');
    var tokens = q.split(/\s+/).filter(Boolean);
    return this.state.members.filter(function (m) {
      var name = m.name.toLowerCase();
      if (tokens.every(function (t) { return name.indexOf(t) !== -1; })) return true;
      if (digits.length >= 3 && m.phone.indexOf(digits) !== -1) return true;
      return m.email.toLowerCase().indexOf(q) !== -1;
    }).slice(0, 10);
  };

  // ---------- 4. Membership lookup ----------
  Store.prototype.membershipLookup = function (memberId) {
    var self = this;
    return this.state.memberships.filter(function (ms) { return ms.member_id === memberId; })
      .sort(function (a, b) { return a.start_date < b.start_date ? 1 : -1; })
      .map(function (ms) {
        var p = self.plan(ms.plan_id);
        var status = self.msStatus(ms);
        return { id: ms.id, plan: p ? p.name : 'Unknown plan', start_date: ms.start_date, end_date: ms.end_date, status: status,
                 days_left: status === 'expired' ? 0 : diffDays(self.today(), ms.end_date) };
      });
  };

  // ---------- 5. Payment lookup ----------
  Store.prototype.paymentLookup = function (memberId) {
    var list = this.state.payments.filter(function (p) { return p.member_id === memberId; })
      .sort(function (a, b) { return a.paid_at < b.paid_at ? 1 : -1; });
    var total = list.reduce(function (s, p) { return s + p.amount; }, 0);
    return { payments: list, total_paid: total, last_payment: list[0] || null };
  };

  // ---------- 6. Revenue report ----------
  Store.prototype.revenueReport = function (from, to) {
    var t = this.today();
    from = from || monthStart(t); to = to || t;
    var list = this.state.payments.filter(function (p) { return p.paid_at >= from && p.paid_at <= to; });
    var byMethod = {}, byDay = {}, total = 0;
    list.forEach(function (p) {
      total += p.amount;
      byMethod[p.method] = (byMethod[p.method] || 0) + p.amount;
      byDay[p.paid_at] = (byDay[p.paid_at] || 0) + p.amount;
    });
    var days = Object.keys(byDay).sort().map(function (d) { return { date: d, amount: byDay[d] }; });
    var methods = Object.keys(byMethod).sort().map(function (m) { return { method: m, amount: byMethod[m] }; });
    return { from: from, to: to, total: total, count: list.length, by_method: methods, by_day: days };
  };

  // ---------- 7. Expiry report ----------
  Store.prototype.expiryReport = function (days, mode) {
    var self = this, t = this.today();
    days = days == null ? 7 : days;
    // consider only each member's latest membership
    var latest = {};
    this.state.memberships.forEach(function (ms) {
      var cur = latest[ms.member_id];
      if (!cur || ms.end_date > cur.end_date) latest[ms.member_id] = ms;
    });
    var rows = Object.keys(latest).map(function (mid) {
      var ms = latest[mid], m = self.member(mid), p = self.plan(ms.plan_id);
      return { member_id: mid, name: m ? m.name : '?', phone: m ? m.phone : '', plan: p ? p.name : '?', end_date: ms.end_date, days_left: diffDays(t, ms.end_date) };
    });
    if (mode === 'expired') return rows.filter(function (r) { return r.days_left < 0; }).sort(function (a, b) { return b.days_left - a.days_left; });
    return rows.filter(function (r) { return r.days_left >= 0 && r.days_left <= days; }).sort(function (a, b) { return a.days_left - b.days_left; });
  };

  // ---------- 8. Attendance report ----------
  Store.prototype.attendanceReport = function (from, to, memberId) {
    var self = this, t = this.today();
    from = from || monthStart(t); to = to || t;
    var list = this.state.attendance.filter(function (a) {
      return a.visit_date >= from && a.visit_date <= to && (!memberId || a.member_id === memberId);
    });
    var perMember = {}, perDay = {};
    list.forEach(function (a) {
      perMember[a.member_id] = (perMember[a.member_id] || 0) + 1;
      perDay[a.visit_date] = (perDay[a.visit_date] || 0) + 1;
    });
    var members = Object.keys(perMember).map(function (id) {
      var m = self.member(id); return { member_id: id, name: m ? m.name : '?', visits: perMember[id] };
    }).sort(function (a, b) { return b.visits - a.visits; });
    var daysArr = Object.keys(perDay).sort().map(function (d) { return { date: d, visits: perDay[d] }; });
    var byHour = []; for (var h = 0; h < 24; h++) byHour.push(0);
    list.forEach(function (a) { var hr = parseInt(String(a.check_in || '').split(':')[0], 10); if (hr >= 0 && hr < 24) byHour[hr]++; });
    return { from: from, to: to, total_visits: list.length, by_member: members, by_day: daysArr, by_hour: byHour, visits: list };
  };

  // ---------- QR attendance (check-in at the gym desk) ----------
  // A member's QR card holds "GF1|<member id>|<phone>". The desk phone scans it and records the visit.
  function memberQRText(m) { return 'GF1|' + m.id + '|' + m.phone; }
  Store.prototype.parseQR = function (text) {
    var p = String(text || '').trim().split('|');
    if (p.length !== 3 || p[0] !== 'GF1') return null;
    var m = this.member(p[1]);
    return m && m.phone === p[2] ? m : null;
  };
  Store.prototype.checkIn = function (memberId, opts) {
    opts = opts || {};
    var m = this.member(memberId);
    if (!m) return { ok: false, code: 'not_found' };
    var today = this.today();
    var same = this.state.attendance.filter(function (a) { return a.member_id === memberId && a.visit_date === today; })[0];
    if (same) return { ok: false, code: 'already', member: m, time: same.check_in };
    var active = this.hasActive(memberId);
    if (!active && !opts.force) return { ok: false, code: 'expired', member: m };
    var rec = { id: nextId('att'), member_id: memberId, gym_id: GYM.id, visit_date: today, check_in: timeIST(this.now()) };
    this.state.attendance.push(rec);
    this.save();
    return { ok: true, code: 'checked_in', member: m, time: rec.check_in, expired: !active };
  };
  Store.prototype.scanCheckIn = function (text, opts) {
    var t = String(text || '').trim();
    if (t.indexOf('GFC1|') === 0) return this.passCheckIn(t, opts);   // pass shown by a member after scanning the gym QR
    var m = this.parseQR(t);
    if (!m) return { ok: false, code: 'invalid_qr' };
    return this.checkIn(m.id, opts);
  };

  // ---------- Gym QR + member pass (works with no server) ----------
  // Owner phone shows a QR holding a code that changes every 5 minutes (derived from a secret kept on the owner phone).
  // A member scans it, their phone shows a pass "GFC1|<phone>|<code>", and the owner phone scans that pass.
  // The owner phone accepts the current code and the two before it (about 15 minutes).
  function cyrb53(str, seed) {
    var h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
    for (var i = 0, ch; i < str.length; i++) { ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
  }
  var ROTATE_MS = 5 * 60 * 1000, ACCEPT_BUCKETS = 3;
  function bucketOf(ms) { return Math.floor(ms / ROTATE_MS); }
  function gymCode(secret, bucket) {
    var s = cyrb53(secret + ':' + bucket, 7).toString(16).toUpperCase();
    while (s.length < 8) s = '0' + s;
    return s.slice(-8);
  }
  function normalizeCode(v) {
    var s = String(v || '').toUpperCase().replace(/[^0-9A-F]/g, '');
    return s.length === 8 ? s : '';
  }
  function randomSecret() {
    var a = '';
    try { var u = new Uint32Array(4); (root.crypto || require('crypto').webcrypto).getRandomValues(u); for (var i = 0; i < u.length; i++) a += u[i].toString(16); } catch (e) { a = ''; }
    return a || (Math.random().toString(16).slice(2) + Date.now().toString(16) + Math.random().toString(16).slice(2));
  }
  Store.prototype.ensureGymSecret = function () {
    var s = this.state.settings;
    if (!s.gym_secret) { s.gym_secret = randomSecret(); this.save(); }
    return s.gym_secret;
  };
  Store.prototype.gymQR = function () {
    var ms = +this.now(), b = bucketOf(ms), code = gymCode(this.ensureGymSecret(), b);
    return { text: 'GFG1|' + GYM.name.replace(/\|/g, '') + '|' + b + '|' + code, code: code, bucket: b, seconds_left: Math.max(0, Math.ceil(((b + 1) * ROTATE_MS - ms) / 1000)) };
  };
  Store.prototype.validGymCode = function (code) {
    code = normalizeCode(code);
    if (!code) return false;
    var secret = this.ensureGymSecret(), b = bucketOf(+this.now());
    for (var i = 0; i < ACCEPT_BUCKETS; i++) if (gymCode(secret, b - i) === code) return true;
    return false;
  };
  Store.prototype.passCheckIn = function (text, opts) {
    var p = String(text || '').trim().split('|');
    if (p.length !== 3 || p[0] !== 'GFC1') return { ok: false, code: 'invalid_qr' };
    var phone = cleanPhone(p[1]);
    var m = this.state.members.filter(function (x) { return x.phone === phone; })[0];
    if (!m) return { ok: false, code: 'not_found', phone: phone };
    if (!this.validGymCode(p[2])) return { ok: false, code: 'bad_code', member: m };
    return this.checkIn(m.id, opts);
  };

  // Member side (runs on the member's own phone; knows nothing about the gym's records).
  var MK_KEY = 'gymflow.member.v1';
  var MemberKit = {
    parseGymQR: function (text, nowMs) {
      var p = String(text || '').trim().split('|');
      if (p.length !== 4 || p[0] !== 'GFG1') return null;
      var bucket = parseInt(p[2], 10), code = normalizeCode(p[3]);
      if (!isFinite(bucket) || !code) return null;
      var cur = bucketOf(nowMs == null ? Date.now() : nowMs);
      return { gym: p[1], bucket: bucket, code: code, fresh: bucket >= cur - 2 && bucket <= cur + 1 };
    },
    normalizeCode: normalizeCode,
    buildPass: function (phone, code) { return 'GFC1|' + phone + '|' + normalizeCode(code); },
    get: function (storage) {
      var o = null; try { o = JSON.parse(storage.getItem(MK_KEY)); } catch (e) { o = null; }
      return o && typeof o === 'object' ? { phone: o.phone || '', visits: Array.isArray(o.visits) ? o.visits : [] } : { phone: '', visits: [] };
    },
    save: function (storage, prof) { try { storage.setItem(MK_KEY, JSON.stringify(prof)); } catch (e) { /* storage blocked */ } },
    linkPhone: function (storage, raw) {
      var phone = cleanPhone(raw);
      if (!/^[6-9]\d{9}$/.test(phone)) return { ok: false, error: 'Enter your 10-digit mobile number.' };
      var prof = MemberKit.get(storage); prof.phone = phone; MemberKit.save(storage, prof);
      return { ok: true, phone: phone };
    },
    addVisit: function (storage, v) {
      var prof = MemberKit.get(storage); prof.visits.unshift(v); prof.visits = prof.visits.slice(0, 60); MemberKit.save(storage, prof);
    }
  };
  // ---------- Goals: personal multi-day goals kept on this phone ----------
  var GOAL_KEY = 'gymflow.goals.v1', MAX_GOALS = 30;
  function goalLoad(storage) {
    var o = null; try { o = JSON.parse(storage.getItem(GOAL_KEY)); } catch (e) { o = null; }
    return Array.isArray(o) ? o.filter(function (g) { return g && g.id && g.start && g.days >= 1; }) : [];
  }
  function goalSave(storage, list) { try { storage.setItem(GOAL_KEY, JSON.stringify(list)); } catch (e) { /* storage blocked */ } }
  var GoalKit = {
    list: goalLoad,
    create: function (storage, o, today) {
      var title = String(o.title || '').trim().replace(/\s+/g, ' '), days = Number(o.days);
      if (title.length < 2) return { ok: false, error: 'Give your goal a name (at least 2 letters).' };
      if (!isFinite(days) || Math.floor(days) !== days || days < 1 || days > 365) return { ok: false, error: 'Days must be a whole number from 1 to 365.' };
      var list = goalLoad(storage);
      if (list.length >= MAX_GOALS) return { ok: false, error: 'You can keep up to ' + MAX_GOALS + ' goals. Delete an old one first.' };
      var g = { id: 'goal_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), title: title.slice(0, 60), note: String(o.note || '').trim().slice(0, 120), days: days, start: today, done: {} };
      list.unshift(g); goalSave(storage, list);
      return { ok: true, goal: g };
    },
    get: function (storage, id) { return goalLoad(storage).filter(function (g) { return g.id === id; })[0] || null; },
    // Tick or untick one day. Only days inside the goal and not in the future can be changed.
    setDay: function (storage, id, date, done, today) {
      var list = goalLoad(storage), g = list.filter(function (x) { return x.id === id; })[0];
      if (!g) return { ok: false, error: 'Goal not found.' };
      var end = addDays(g.start, g.days - 1);
      if (date < g.start || date > end) return { ok: false, error: 'That day is outside this goal.' };
      if (date > today) return { ok: false, error: 'You cannot tick a day that has not come yet.' };
      if (done) g.done[date] = 1; else delete g.done[date];
      goalSave(storage, list);
      return { ok: true, goal: g };
    },
    remove: function (storage, id) { goalSave(storage, goalLoad(storage).filter(function (g) { return g.id !== id; })); },
    restart: function (storage, id, today) {
      var g = GoalKit.get(storage, id); if (!g) return { ok: false, error: 'Goal not found.' };
      return GoalKit.create(storage, { title: g.title, days: g.days, note: g.note }, today);
    },
    stats: function (g, today) {
      var end = addDays(g.start, g.days - 1), idx = diffDays(g.start, today) + 1;   // idx = which day of the goal today is (1-based)
      var done = 0, cells = [], run = 0, best = 0, missed = 0;
      for (var i = 0; i < g.days; i++) {
        var d = addDays(g.start, i), isDone = !!g.done[d], state;
        if (isDone) { state = 'done'; done++; run++; if (run > best) best = run; }
        else { run = 0; state = d < today ? 'missed' : d === today ? 'today' : 'future'; if (state === 'missed') missed++; }
        cells.push({ n: i + 1, date: d, state: state, today: d === today });
      }
      // current streak: consecutive done days ending today, or yesterday if today is still open
      var streak = 0, cur = g.done[today] ? today : addDays(today, -1);
      while (cur >= g.start && cur <= end && g.done[cur]) { streak++; cur = addDays(cur, -1); }
      var status = done === g.days ? 'achieved' : today > end ? 'ended' : idx < 1 ? 'upcoming' : 'active';
      return { end: end, day_no: Math.max(0, Math.min(idx, g.days)), done: done, missed: missed, percent: Math.round(done / g.days * 100), streak: streak, best: best,
        days_left: status === 'active' ? g.days - idx + 1 : 0, today_done: !!g.done[today], status: status, cells: cells };
    }
  };

  // ---------- Diet: the plan a member follows, meal times and ticks, kept on this phone ----------
  var DIET_KEY = 'gymflow.diet.v1', DIET_SLOTS = ['breakfast', 'lunch', 'snack', 'dinner'];
  var DIET_TIMES = { breakfast: '08:00', lunch: '13:00', snack: '17:00', dinner: '20:30' };
  function parseHM(v) {
    var m = /^([01]?\d|2[0-3]):([0-5]\d)$/.exec(String(v || '').trim());
    return m ? { hour: +m[1], minute: +m[2] } : null;
  }
  function dietLoad(storage) {
    var o = null; try { o = JSON.parse(storage.getItem(DIET_KEY)); } catch (e) { o = null; }
    o = o && typeof o === 'object' ? o : {};
    var times = {}; DIET_SLOTS.forEach(function (k) { times[k] = parseHM(o.times && o.times[k]) ? o.times[k] : DIET_TIMES[k]; });
    return { plan_id: typeof o.plan_id === 'string' ? o.plan_id : '', started: o.started || '', times: times, remind: o.remind !== false, done: o.done && typeof o.done === 'object' ? o.done : {} };
  }
  function dietSave(storage, d) { try { storage.setItem(DIET_KEY, JSON.stringify(d)); } catch (e) { /* storage blocked */ } }
  var DietKit = {
    SLOTS: DIET_SLOTS, DEFAULT_TIMES: DIET_TIMES, parseHM: parseHM, get: dietLoad,
    start: function (storage, planId, today) {
      if (!planId) return { ok: false, error: 'Choose a plan.' };
      var d = dietLoad(storage); d.plan_id = planId; d.started = today; d.done = {}; dietSave(storage, d);
      return { ok: true, diet: d };
    },
    stop: function (storage) { var d = dietLoad(storage); d.plan_id = ''; d.started = ''; d.done = {}; dietSave(storage, d); },
    setTime: function (storage, slot, value) {
      if (DIET_SLOTS.indexOf(slot) === -1) return { ok: false, error: 'Unknown meal.' };
      var t = parseHM(value); if (!t) return { ok: false, error: 'Enter a time like 08:30.' };
      var d = dietLoad(storage); d.times[slot] = (t.hour < 10 ? '0' : '') + t.hour + ':' + (t.minute < 10 ? '0' : '') + t.minute; dietSave(storage, d);
      return { ok: true, diet: d };
    },
    setRemind: function (storage, on) { var d = dietLoad(storage); d.remind = !!on; dietSave(storage, d); return d; },
    toggleMeal: function (storage, date, slot) {
      if (DIET_SLOTS.indexOf(slot) === -1) return { ok: false, error: 'Unknown meal.' };
      var d = dietLoad(storage); if (!d.plan_id) return { ok: false, error: 'Start a plan first.' };
      var day = d.done[date] || {}; if (day[slot]) delete day[slot]; else day[slot] = 1;
      if (Object.keys(day).length) d.done[date] = day; else delete d.done[date];
      dietSave(storage, d); return { ok: true, diet: d };
    },
    summary: function (d, today) {
      var dayNo = d.started ? diffDays(d.started, today) + 1 : 0, t = d.done[today] || {}, week = 0;
      for (var i = 0; i < 7; i++) { var x = d.done[addDays(today, -i)]; if (x) week += Object.keys(x).length; }
      var possible = 0; for (var j = 0; j < 7; j++) if (d.started && addDays(today, -j) >= d.started) possible += 4;
      return { day_no: dayNo, today_done: Object.keys(t).length, week_done: week, week_possible: possible, week_percent: possible ? Math.round(week / possible * 100) : 0 };
    },
    // Meal that comes next after "HH:MM" now, or null when all of today's meals are past.
    nextMeal: function (d, nowHM) {
      var best = null;
      DIET_SLOTS.forEach(function (k) { if (d.times[k] >= nowHM && (!best || d.times[k] < d.times[best])) best = k; });
      return best;
    }
  };

  Store.prototype.todayAttendance = function () {
    var self = this, today = this.today();
    var list = this.state.attendance.filter(function (a) { return a.visit_date === today; })
      .sort(function (a, b) { return a.check_in < b.check_in ? -1 : 1; })
      .map(function (a) { var m = self.member(a.member_id); return { member_id: a.member_id, name: m ? m.name : '?', time: a.check_in }; });
    return { date: today, count: list.length, list: list };
  };

  // ---------- Payments (Google Pay / UPI deep links, cash, card) ----------
  function validUpiId(v) { return /^[a-zA-Z0-9._\-]{2,256}@[a-zA-Z][a-zA-Z0-9.\-]{1,63}$/.test(String(v || '').trim()); }
  function validAmount(a) { a = Number(a); return isFinite(a) && a > 0 && a <= 1000000 && Math.round(a * 100) === a * 100; }
  function upiQuery(o) {
    var parts = ['pa=' + encodeURIComponent(o.pa).replace(/%40/g, '@'), 'pn=' + encodeURIComponent(o.pn || ''), 'am=' + Number(o.am).toFixed(2), 'cu=INR'];
    if (o.tn) parts.push('tn=' + encodeURIComponent(o.tn));
    if (o.tr) parts.push('tr=' + encodeURIComponent(o.tr));
    return parts.join('&');
  }
  function upiLink(o) { return 'upi://pay?' + upiQuery(o); }
  function gpayLink(o) { return 'tez://upi/pay?' + upiQuery(o); }

  Store.prototype.setSettings = function (o) {
    var upi = String(o.upi_id || '').trim(), name = String(o.payee_name || '').trim();
    if (upi && !validUpiId(upi)) throw new Error('UPI ID looks wrong. It should look like name@bank.');
    if (!name) throw new Error('Enter the name shown to people when they pay.');
    var next = {}; for (var k in this.state.settings) next[k] = this.state.settings[k];   // keeps gym_secret
    next.upi_id = upi; next.payee_name = name.slice(0, 40);
    this.state.settings = next;
    this.save();
  };
  Store.prototype.renewMembership = function (memberId, planId) {
    var plan = this.state.plans.filter(function (p) { return p.id === planId && p.active; })[0];
    if (!plan) throw new Error('Choose an active plan.');
    var today = this.today();
    var latest = null;
    this.state.memberships.forEach(function (ms) { if (ms.member_id === memberId && (!latest || ms.end_date > latest.end_date)) latest = ms; });
    var start = latest && latest.end_date >= today ? addDays(latest.end_date, 1) : today;
    var ms = { id: nextId('ms'), member_id: memberId, gym_id: GYM.id, plan_id: plan.id, start_date: start, end_date: addDays(start, plan.duration_days), status: 'active' };
    this.state.memberships.push(ms);
    return ms;
  };
  Store.prototype.recordPayment = function (p) {
    if (!this.member(p.member_id)) return { ok: false, error: 'Choose a member.' };
    if (!validAmount(p.amount)) return { ok: false, error: 'Enter a valid amount (up to 2 decimals).' };
    if (['upi', 'cash', 'card'].indexOf(p.method) === -1) return { ok: false, error: 'Choose a payment method.' };
    var ms = null;
    if (p.renew && p.plan_id) {
      try { ms = this.renewMembership(p.member_id, p.plan_id); } catch (e) { return { ok: false, error: e.message }; }
    } else {
      this.state.memberships.forEach(function (x) { if (x.member_id === p.member_id && (!ms || x.end_date > ms.end_date)) ms = x; });
    }
    var pay = { id: nextId('pay'), member_id: p.member_id, membership_id: ms ? ms.id : null, gym_id: GYM.id, amount: Number(p.amount), method: p.method, paid_at: this.today(), ref: String(p.ref || '').trim().slice(0, 40), note: String(p.note || '').trim().slice(0, 80) };
    this.state.payments.push(pay);
    this.save();
    return { ok: true, payment: pay, membership: p.renew ? ms : null };
  };
  Store.prototype.recentPayments = function (n) {
    var self = this;
    return this.state.payments.slice().sort(function (a, b) { return a.paid_at < b.paid_at ? 1 : a.paid_at > b.paid_at ? -1 : (a.id < b.id ? 1 : -1); }).slice(0, n || 10)
      .map(function (p) { var m = self.member(p.member_id); return { id: p.id, name: m ? m.name : '?', amount: p.amount, method: p.method, paid_at: p.paid_at, ref: p.ref || '' }; });
  };

  // ---------- Product sales (shop) ----------
  // items: [{id, name, price, qty}] . Kept apart from membership payments so fee reports stay unchanged.
  Store.prototype.recordSale = function (o) {
    var items = (o.items || []).map(function (i) { return { id: String(i.id), name: String(i.name || '').slice(0, 80), price: Number(i.price), qty: Math.floor(Number(i.qty)) }; });
    if (!items.length) return { ok: false, error: 'Cart is empty.' };
    for (var k = 0; k < items.length; k++) {
      if (!validAmount(items[k].price)) return { ok: false, error: 'Bad price for ' + items[k].name + '.' };
      if (!(items[k].qty >= 1 && items[k].qty <= 99)) return { ok: false, error: 'Quantity must be 1 to 99.' };
    }
    if (['upi', 'cash', 'card'].indexOf(o.method) === -1) return { ok: false, error: 'Choose a payment method.' };
    var member = o.member_id ? this.member(o.member_id) : null;
    if (o.member_id && !member) return { ok: false, error: 'Member not found.' };
    var total = 0; items.forEach(function (i) { total += Math.round(i.price * 100) * i.qty; });
    total = total / 100;
    var sale = { id: nextId('sale'), member_id: member ? member.id : null, customer: member ? member.name : (String(o.customer || '').trim().slice(0, 60) || 'Walk-in'),
      items: items, total: total, method: o.method, paid_at: this.today(), ref: String(o.ref || '').trim().slice(0, 40) };
    this.state.sales.push(sale); this.save();
    return { ok: true, sale: sale };
  };
  Store.prototype.recentSales = function (n) {
    return this.state.sales.slice().sort(function (a, b) { return a.paid_at < b.paid_at ? 1 : a.paid_at > b.paid_at ? -1 : (a.id < b.id ? 1 : -1); }).slice(0, n || 10);
  };
  Store.prototype.salesSummary = function (from, to) {
    var list = this.state.sales.filter(function (x) { return (!from || x.paid_at >= from) && (!to || x.paid_at <= to); }), total = 0, units = 0;
    list.forEach(function (x) { total += x.total; x.items.forEach(function (i) { units += i.qty; }); });
    return { count: list.length, units: units, total: Math.round(total * 100) / 100 };
  };

  // ---------- Trainer bookings ----------
  Store.prototype.recordBooking = function (o) {
    var today = this.today(), member = o.member_id ? this.member(o.member_id) : null;
    if (o.member_id && !member) return { ok: false, error: 'Member not found.' };
    var name = member ? member.name : String(o.customer || '').trim().replace(/\s+/g, ' ').slice(0, 60);
    var phone = member ? member.phone : cleanPhone(o.phone);
    if (name.length < 2) return { ok: false, error: 'Enter your name.' };
    if (!/^[6-9]\d{9}$/.test(phone)) return { ok: false, error: 'Enter a valid 10-digit mobile number.' };
    if (!o.trainer_id || !o.trainer_name) return { ok: false, error: 'Choose a trainer.' };
    if (!o.slot) return { ok: false, error: 'Choose a time slot.' };
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(o.start_date || '')) || o.start_date < today) return { ok: false, error: 'Choose a start date from today onwards.' };
    if (!validAmount(o.amount)) return { ok: false, error: 'Bad amount.' };
    if (['upi', 'cash', 'card', 'later'].indexOf(o.method) === -1) return { ok: false, error: 'Choose how you will pay.' };
    var b = { id: nextId('bk'), trainer_id: o.trainer_id, trainer_name: String(o.trainer_name).slice(0, 60), package: String(o.package || '').slice(0, 60), sessions: Math.max(1, Math.floor(Number(o.sessions) || 1)),
      amount: Number(o.amount), slot: String(o.slot).slice(0, 40), start_date: o.start_date, goal: String(o.goal || '').slice(0, 40), notes: String(o.notes || '').trim().slice(0, 160),
      member_id: member ? member.id : null, customer: name, phone: phone, method: o.method, ref: String(o.ref || '').trim().slice(0, 40),
      status: o.method === 'later' ? 'pay_later' : 'paid', created: today };
    this.state.bookings.push(b); this.save();
    return { ok: true, booking: b };
  };
  Store.prototype.recentBookings = function (n) {
    return this.state.bookings.slice().sort(function (a, b) { return a.created < b.created ? 1 : a.created > b.created ? -1 : (a.id < b.id ? 1 : -1); }).slice(0, n || 20);
  };
  Store.prototype.cancelBooking = function (id) {
    var b = this.state.bookings.filter(function (x) { return x.id === id; })[0];
    if (!b) return { ok: false, error: 'Booking not found.' };
    b.status = 'cancelled'; this.save(); return { ok: true, booking: b };
  };
  Store.prototype.setContact = function (raw) {
    var p = cleanPhone(raw);
    if (p && !/^[6-9]\d{9}$/.test(p)) throw new Error('Enter a 10-digit mobile number (or leave empty).');
    var next = {}; for (var k in this.state.settings) next[k] = this.state.settings[k];
    next.gym_phone = p; this.state.settings = next; this.save();
  };

  // ---------- FAQ (owner can add own questions) ----------
  Store.prototype.addFaq = function (q, a) {
    q = String(q || '').trim(); a = String(a || '').trim();
    if (q.length < 5) throw new Error('Write the question (at least 5 characters).');
    if (a.length < 3) throw new Error('Write the answer.');
    var f = { id: nextId('faq'), q: q.slice(0, 200), a: a.slice(0, 1000) };
    this.state.faqs.push(f); this.save(); return f;
  };
  Store.prototype.removeFaq = function (id) {
    this.state.faqs = this.state.faqs.filter(function (f) { return f.id !== id; }); this.save();
  };

  // ---------- 2. Operations assistant (read-only, rule-based, offline) ----------
  var WRITE_RE = /\b(register|renew|delete|remove|edit|update|modify|cancel|record|enroll|sign\s*up|add\s+(a\s+|the\s+|new\s+)?(member|payment|membership|visit|check)|create|change|mark)\b/i;
  var STOP = ['show', 'me', 'give', 'tell', 'what', 'whats', "what's", 'is', 'are', 'the', 'a', 'an', 'of', 'for', 'to', 'on', 'in', 'at', 'by', 'and', 'with', 'about', 'please', 'can', 'you',
    'member', 'members', 'membership', 'memberships', 'plan', 'plans', 'payment', 'payments', 'paid', 'pay', 'status', 'details', 'detail', 'info', 'find', 'search', 'lookup', 'look', 'up',
    'when', 'does', 'do', 'did', 'his', 'her', 'their', 'has', 'have', 'how', 'much', 'many', 'total', 'last', 'history', 'current', 'active', 'valid', 'expire', 'expires', 'expiry', 'expiring',
    'attendance', 'visits', 'visit', 'attend', 'attended', 'check-in', 'checkin', 'who', 'whose', 'number', 'phone', 'email', 'my', 'gym', 'this', 'that', 'it', 'month', 'week', 'today', 'year',
    'revenue', 'income', 'days', 'day', 'next', 'past', 'from', 'all', 'list', 'report', 'dues', 'renewal', 'ending', 'come', 'came'];

  function parseRange(text, today) {
    var t = text.toLowerCase(), m;
    if (/\btoday\b/.test(t)) return { from: today, to: today, label: 'today' };
    if (/\byesterday\b/.test(t)) { var y = addDays(today, -1); return { from: y, to: y, label: 'yesterday' }; }
    if (/last month|previous month/.test(t)) {
      var first = monthStart(today), lastDay = addDays(first, -1);
      return { from: monthStart(lastDay), to: lastDay, label: 'last month' };
    }
    if (/this week/.test(t)) {
      var dow = new Date(today + 'T00:00:00Z').getUTCDay(); var back = (dow + 6) % 7;
      return { from: addDays(today, -back), to: today, label: 'this week' };
    }
    if ((m = t.match(/(?:last|past)\s+(\d+)\s+days?/))) return { from: addDays(today, -(+m[1] - 1)), to: today, label: 'the last ' + m[1] + ' days' };
    if (/this year/.test(t)) return { from: today.slice(0, 4) + '-01-01', to: today, label: 'this year' };
    return { from: monthStart(today), to: today, label: 'this month' };
  }

  function Assistant(store) {
    this.store = store;
    this.history = [];   // last 10 messages kept
    this.pending = null; // waiting for the owner to pick a member
  }
  Assistant.prototype._push = function (role, text) {
    this.history.push({ role: role, text: text });
    if (this.history.length > 10) this.history = this.history.slice(-10);
  };
  Assistant.prototype.ask = function (text) {
    this._push('user', text);
    var reply = this._answer(String(text || '').trim());
    this._push('assistant', reply);
    return reply;
  };
  Assistant.prototype._extractQuery = function (text) {
    var phone = text.replace(/[^\d]/g, '');
    if (phone.length >= 6) return phone;
    var email = text.match(/[^\s@]+@[^\s@]+/);
    if (email) return email[0];
    var words = text.toLowerCase().replace(/[?.,!'"]/g, ' ').split(/\s+/).filter(function (w) { return w && STOP.indexOf(w) === -1 && !/^\d+$/.test(w); });
    return words.join(' ');
  };
  Assistant.prototype._pickMember = function (query, intent) {
    var found = this.store.searchMembers(query);
    if (!found.length) { this.pending = null; return { reply: 'I could not find a member matching “' + query + '”.' }; }
    if (found.length > 1) {
      this.pending = { intent: intent, candidates: found };
      var lines = found.map(function (m, i) { return (i + 1) + '. ' + m.name + ' — ' + m.phone; });
      return { reply: 'Several members match. Which one do you mean? Reply with the number, or the phone.\n' + lines.join('\n') };
    }
    this.pending = null;
    return { member: found[0] };
  };
  Assistant.prototype._memberAnswer = function (member, intent, rangeText) {
    var s = this.store, out = '';
    if (intent === 'payments') {
      var p = s.paymentLookup(member.id);
      if (!p.payments.length) return member.name + ' has no payment records.';
      out = 'Payments for ' + member.name + ':\n';
      p.payments.forEach(function (x) { out += '• ' + fmtDate(x.paid_at) + ' — ' + inr(x.amount) + ' (' + x.method + ')\n'; });
      out += 'Total paid: ' + inr(p.total_paid) + '\nLast payment: ' + fmtDate(p.last_payment.paid_at) + ' (' + inr(p.last_payment.amount) + ')';
      return out;
    }
    if (intent === 'attendance') {
      var r = parseRange(rangeText || '', s.today());
      var a = s.attendanceReport(r.from, r.to, member.id);
      return member.name + ' visited ' + a.total_visits + ' time(s) in ' + r.label + ' (' + fmtDate(r.from) + ' – ' + fmtDate(r.to) + ').';
    }
    if (intent === 'memberships') {
      var list = s.membershipLookup(member.id);
      if (!list.length) return member.name + ' has no memberships.';
      out = 'Memberships for ' + member.name + ':\n';
      list.forEach(function (m) {
        out += '• ' + m.plan + ': ' + fmtDate(m.start_date) + ' → ' + fmtDate(m.end_date) + ' [' + m.status + (m.status === 'active' ? ', ' + m.days_left + ' days left' : '') + ']\n';
      });
      return out.trim();
    }
    return member.name + '\nPhone: ' + member.phone + '\nEmail: ' + member.email + '\n' + this._memberAnswer(member, 'memberships');
  };
  Assistant.prototype._answer = function (text) {
    var s = this.store, t = text.toLowerCase(), today = s.today();

    // follow-up to "which member?"
    if (this.pending) {
      var c = this.pending.candidates, chosen = null, num = t.match(/^\s*(\d+)\s*$/);
      if (num && c[+num[1] - 1] && num[1].length < 3) chosen = c[+num[1] - 1];
      if (!chosen) {
        var q = this._extractQuery(text), hit = q ? c.filter(function (m) {
          return m.phone.indexOf(q.replace(/\D/g, '')) !== -1 && q.replace(/\D/g, '').length >= 4 || m.name.toLowerCase().indexOf(q) !== -1;
        }) : [];
        if (hit.length === 1) chosen = hit[0];
      }
      if (chosen) { var intent = this.pending.intent; this.pending = null; return this._memberAnswer(chosen, intent, ''); }
      if (!WRITE_RE.test(text) && t.length < 25) return 'Please reply with one of the numbers above (or the member’s phone).';
      this.pending = null;
    }

    if (WRITE_RE.test(text)) {
      return 'I’m read-only, so I can’t register, renew, edit, record or delete anything. Use the Register tab for new members. I can look up members, memberships, payments, revenue, expiries and attendance.';
    }
    if (/health|medical|injur|illness|disease|condition|allerg/.test(t)) {
      return 'Health notes are private and I don’t share them.';
    }
    if (/\b(help|what can you do|hello|hi|hey)\b/.test(t) && t.length < 30) {
      return 'Ask me things like:\n• Revenue this month / last 7 days\n• Who expires in the next 10 days?\n• Show expired members\n• Attendance this week\n• Find Rohan\n• Payments of Priya\n• Membership status of 98xxxxxx';
    }
    if (/revenue|income|earn|collection|collected|how much.*(made|got)/.test(t)) {
      var r = parseRange(text, today), rep = s.revenueReport(r.from, r.to);
      var out = 'Revenue for ' + r.label + ' (' + fmtDate(r.from) + ' – ' + fmtDate(r.to) + '): ' + inr(rep.total) + ' from ' + rep.count + ' payment(s).';
      if (rep.by_method.length) out += '\nBy method: ' + rep.by_method.map(function (m) { return m.method + ' ' + inr(m.amount); }).join(', ');
      return out;
    }
    if (/expir|ending soon|renewal due|due for renewal|lapsed/.test(t)) {
      var mode = /already|expired|lapsed|overdue/.test(t) && !/expiring|will expire/.test(t) ? 'expired' : 'soon';
      var dm = t.match(/(\d+)\s*days?/), days = dm ? +dm[1] : 7;
      var rows = s.expiryReport(days, mode);
      if (!rows.length) return mode === 'expired' ? 'No expired memberships.' : 'No memberships expiring in the next ' + days + ' days.';
      var head = mode === 'expired' ? 'Expired memberships (' + rows.length + '):\n' : 'Expiring in the next ' + days + ' days (' + rows.length + '):\n';
      return head + rows.map(function (x) {
        return '• ' + x.name + ' (' + x.phone + ') — ' + x.plan + ', ' + (mode === 'expired' ? 'ended ' + fmtDate(x.end_date) : (x.days_left === 0 ? 'ends today' : 'ends ' + fmtDate(x.end_date) + ' (' + x.days_left + 'd)'));
      }).join('\n');
    }
    var q = this._extractQuery(text);
    if (/attend|visit|check-?in|\bcame\b/.test(t)) {
      if (q) {
        var pk = this._pickMember(q, 'attendance'); if (pk.reply) return pk.reply;
        return this._memberAnswer(pk.member, 'attendance', text);
      }
      var rg = parseRange(text, today), at = s.attendanceReport(rg.from, rg.to);
      var o = 'Attendance for ' + rg.label + ': ' + at.total_visits + ' visit(s).';
      if (at.by_member.length) o += '\nMost regular: ' + at.by_member.slice(0, 5).map(function (m) { return m.name + ' (' + m.visits + ')'; }).join(', ');
      return o;
    }
    if (/payment|paid|\bpay\b|dues/.test(t)) {
      if (!q) return 'Whose payments? Give me a name or phone number.';
      var pm = this._pickMember(q, 'payments'); if (pm.reply) return pm.reply;
      return this._memberAnswer(pm.member, 'payments');
    }
    if (q) {
      var intent = /membership|plan|status|valid|active|expire|when/.test(t) ? 'memberships' : 'profile';
      var mm = this._pickMember(q, intent); if (mm.reply) return mm.reply;
      return this._memberAnswer(mm.member, intent);
    }
    return 'I can answer questions about members, memberships, payments, revenue, expiries and attendance. Try “Revenue this month” or “Who expires in 7 days?”.';
  };

  var api = {
    GYM: GYM, Store: Store, Assistant: Assistant, todayIST: todayIST, addDays: addDays, diffDays: diffDays,
    fmtDate: fmtDate, inr: inr, cleanPhone: cleanPhone, cleanEmail: cleanEmail, monthStart: monthStart, parseRange: parseRange, seedDemo: seedDemo,
    timeIST: timeIST, MemberKit: MemberKit, GoalKit: GoalKit, DietKit: DietKit, bucketOf: bucketOf, ROTATE_MS: ROTATE_MS, memberQRText: memberQRText, validUpiId: validUpiId, validAmount: validAmount, upiLink: upiLink, gpayLink: gpayLink
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.GymCore = api;
})(typeof window !== 'undefined' ? window : this);
