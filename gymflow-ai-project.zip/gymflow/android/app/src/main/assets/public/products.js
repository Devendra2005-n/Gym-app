/* GYM Flow - sample product catalog (shop) and original product illustrations.
   Names and prices are sample data. Edit the PRODUCTS list to match what the gym really sells.
   Images are drawn in code (no downloads, work offline). */
(function (root) {
  'use strict';

  var CATS = [
    { id: 'protein', name: 'Protein' },
    { id: 'supplements', name: 'Supplements' },
    { id: 'accessories', name: 'Accessories' },
    { id: 'equipment', name: 'Equipment' },
    { id: 'clothing', name: 'Clothing' },
    { id: 'shoes', name: 'Shoes' }
  ];

  // ---- illustrations: 120x120 viewBox, c = main colour, ink/white for details ----
  var INK = '#1a1a1a', WHT = '#ffffff';
  function shade(hex, amt) {
    var n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    function f(v) { return Math.max(0, Math.min(255, Math.round(v + amt))); }
    return '#' + ((1 << 24) + (f(r) << 16) + (f(g) << 8) + f(b)).toString(16).slice(1);
  }
  function label(c, y, h) { return '<rect x="32" y="' + y + '" width="56" height="' + h + '" rx="4" fill="' + WHT + '"/><rect x="37" y="' + (y + 5) + '" width="46" height="5" rx="2" fill="' + c + '"/><rect x="37" y="' + (y + 14) + '" width="30" height="4" rx="2" fill="' + INK + '" opacity=".6"/>'; }
  var ART = {
    tub: function (c) { return '<rect x="26" y="30" width="68" height="70" rx="9" fill="' + c + '"/><rect x="22" y="18" width="76" height="16" rx="6" fill="' + INK + '"/><rect x="26" y="34" width="68" height="6" fill="' + shade(c, -35) + '"/>' + label(c, 50, 34); },
    jar: function (c) { return '<rect x="30" y="38" width="60" height="62" rx="12" fill="' + c + '"/><rect x="34" y="22" width="52" height="18" rx="5" fill="' + INK + '"/>' + label(c, 54, 30); },
    bottle: function (c) { return '<rect x="50" y="10" width="20" height="14" rx="3" fill="' + INK + '"/><path d="M46 24h28l6 12v58a8 8 0 0 1-8 8H48a8 8 0 0 1-8-8V36z" fill="' + c + '"/><rect x="45" y="52" width="30" height="34" rx="3" fill="' + WHT + '"/><rect x="49" y="58" width="22" height="4" rx="2" fill="' + c + '"/><rect x="49" y="67" width="14" height="3" rx="1.5" fill="' + INK + '" opacity=".6"/>'; },
    shaker: function (c) { return '<rect x="40" y="8" width="40" height="10" rx="4" fill="' + INK + '"/><path d="M36 18h48l-5 80a8 8 0 0 1-8 8H49a8 8 0 0 1-8-8z" fill="' + c + '" opacity=".92"/><path d="M38 44h44M40 62h40M42 80h36" stroke="' + WHT + '" stroke-width="2.5" opacity=".7"/><path d="M84 28q14 4 12 18" fill="none" stroke="' + INK + '" stroke-width="4" stroke-linecap="round"/>'; },
    flask: function (c) { return '<rect x="44" y="8" width="32" height="12" rx="4" fill="' + INK + '"/><rect x="38" y="20" width="44" height="88" rx="12" fill="' + c + '"/><rect x="38" y="46" width="44" height="6" fill="' + shade(c, -35) + '"/><rect x="50" y="66" width="20" height="22" rx="3" fill="' + WHT + '" opacity=".9"/>'; },
    box: function (c) { return '<rect x="14" y="36" width="92" height="56" rx="6" fill="' + c + '"/><rect x="14" y="36" width="92" height="12" rx="6" fill="' + shade(c, -35) + '"/><rect x="26" y="56" width="68" height="22" rx="4" fill="' + WHT + '"/><rect x="32" y="62" width="40" height="5" rx="2" fill="' + c + '"/><rect x="32" y="71" width="24" height="3" rx="1.5" fill="' + INK + '" opacity=".6"/>'; },
    gloves: function (c) { return '<path d="M28 46q0-14 10-14t10 8v-12q0-8 8-8t8 8v14q4-12 12-8t4 12v34q0 18-26 22-30-4-26-24z" fill="' + c + '"/><rect x="34" y="92" width="44" height="14" rx="4" fill="' + INK + '"/><path d="M42 60q14 10 28 0" stroke="' + WHT + '" stroke-width="3" fill="none" opacity=".6"/>'; },
    belt: function (c) { return '<path d="M8 46h104v28H8z" fill="' + c + '"/><rect x="8" y="46" width="104" height="8" fill="' + shade(c, -35) + '"/><rect x="48" y="40" width="26" height="40" rx="4" fill="#c9c9c9" stroke="' + INK + '" stroke-width="3"/><rect x="56" y="52" width="10" height="16" rx="2" fill="' + INK + '"/><rect x="82" y="56" width="22" height="6" rx="3" fill="' + INK + '" opacity=".6"/>'; },
    straps: function (c) { return '<path d="M30 14q-14 40 4 84" stroke="' + c + '" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M84 14q14 40-4 84" stroke="' + c + '" stroke-width="12" fill="none" stroke-linecap="round"/><circle cx="34" cy="98" r="10" fill="none" stroke="' + INK + '" stroke-width="5"/><circle cx="80" cy="98" r="10" fill="none" stroke="' + INK + '" stroke-width="5"/>'; },
    bands: function (c) { return '<ellipse cx="60" cy="86" rx="44" ry="14" fill="none" stroke="' + shade(c, 40) + '" stroke-width="9"/><ellipse cx="60" cy="68" rx="38" ry="14" fill="none" stroke="' + c + '" stroke-width="9"/><ellipse cx="60" cy="50" rx="32" ry="14" fill="none" stroke="' + shade(c, -45) + '" stroke-width="9"/><ellipse cx="60" cy="32" rx="26" ry="12" fill="none" stroke="' + INK + '" stroke-width="9"/>'; },
    rope: function (c) { return '<path d="M30 20v-4a8 8 0 0 1 16 0v22M74 38V16a8 8 0 0 1 16 0v4" fill="none" stroke="' + INK + '" stroke-width="0"/><rect x="24" y="12" width="14" height="42" rx="7" fill="' + INK + '"/><rect x="82" y="12" width="14" height="42" rx="7" fill="' + INK + '"/><path d="M31 54q-6 56 29 56t29-56" fill="none" stroke="' + c + '" stroke-width="5" stroke-linecap="round"/>'; },
    mat: function (c) { return '<rect x="14" y="36" width="92" height="52" rx="6" fill="' + c + '"/><circle cx="106" cy="62" r="16" fill="' + shade(c, -30) + '"/><circle cx="106" cy="62" r="7" fill="' + shade(c, 50) + '"/><path d="M24 52h70M24 62h70M24 72h70" stroke="' + WHT + '" stroke-width="2" opacity=".35"/>'; },
    towel: function (c) { return '<path d="M26 18h68v78q-34 14-68 0z" fill="' + c + '"/><path d="M26 30h68M26 36h68" stroke="' + WHT + '" stroke-width="3" opacity=".7"/><path d="M26 96q34 14 68 0v6q-34 14-68 0z" fill="' + shade(c, -35) + '"/>'; },
    bag: function (c) { return '<path d="M36 30q24-30 48 0" fill="none" stroke="' + INK + '" stroke-width="6"/><rect x="12" y="34" width="96" height="62" rx="18" fill="' + c + '"/><rect x="12" y="56" width="96" height="6" fill="' + shade(c, -35) + '"/><rect x="50" y="52" width="20" height="14" rx="3" fill="' + INK + '"/><rect x="20" y="70" width="30" height="18" rx="5" fill="' + shade(c, 30) + '"/>'; },
    sleeve: function (c) { return '<path d="M38 10h44l4 42-6 56H40l-6-56z" fill="' + c + '"/><path d="M38 52h44M36 70h48" stroke="' + WHT + '" stroke-width="3" opacity=".5"/><rect x="38" y="10" width="44" height="8" fill="' + INK + '"/><rect x="40" y="100" width="40" height="8" fill="' + INK + '"/>'; },
    wrap: function (c) { return '<rect x="10" y="44" width="100" height="26" rx="13" fill="' + c + '"/><circle cx="26" cy="57" r="6" fill="' + WHT + '"/><rect x="72" y="44" width="38" height="26" rx="13" fill="' + shade(c, -45) + '"/><path d="M76 52h26M76 62h26" stroke="' + WHT + '" stroke-width="2.5" opacity=".6"/><path d="M40 44v26M52 44v26M64 44v26" stroke="' + WHT + '" stroke-width="2" opacity=".35"/><ellipse cx="60" cy="92" rx="44" ry="6" fill="' + INK + '" opacity=".12"/>'; },
    roller: function (c) { return '<rect x="12" y="38" width="96" height="44" rx="22" fill="' + c + '"/><path d="M30 38v44M46 38v44M62 38v44M78 38v44M94 38v44" stroke="' + shade(c, -45) + '" stroke-width="5"/><ellipse cx="108" cy="60" rx="8" ry="22" fill="' + shade(c, -30) + '"/>'; },
    wheel: function (c) { return '<rect x="12" y="52" width="14" height="16" rx="3" fill="' + INK + '" transform="translate(0 0)"/><rect x="94" y="52" width="14" height="16" rx="3" fill="' + INK + '"/><rect x="26" y="58" width="68" height="4" fill="' + INK + '"/><circle cx="60" cy="60" r="34" fill="' + INK + '"/><circle cx="60" cy="60" r="26" fill="' + c + '"/><circle cx="60" cy="60" r="8" fill="' + WHT + '"/>'; },
    dumbbell: function (c) { return '<rect x="8" y="42" width="14" height="36" rx="4" fill="' + c + '"/><rect x="22" y="34" width="14" height="52" rx="4" fill="' + c + '"/><rect x="36" y="56" width="48" height="8" rx="3" fill="#8a8a8a"/><rect x="84" y="34" width="14" height="52" rx="4" fill="' + c + '"/><rect x="98" y="42" width="14" height="36" rx="4" fill="' + c + '"/>'; },
    hexdb: function (c) { return '<path d="M8 40l10-8 10 8v40l-10 8-10-8zM92 40l10-8 10 8v40l-10 8-10-8z" fill="' + c + '"/><rect x="28" y="54" width="64" height="12" rx="4" fill="#9a9a9a"/><path d="M12 54h12M96 54h12" stroke="' + WHT + '" stroke-width="3" opacity=".6"/>'; },
    kettlebell: function (c) { return '<path d="M38 52q-2-34 22-34t22 34" fill="none" stroke="' + c + '" stroke-width="10" stroke-linecap="round"/><circle cx="60" cy="76" r="32" fill="' + c + '"/><circle cx="60" cy="76" r="14" fill="' + WHT + '" opacity=".85"/><text x="60" y="82" text-anchor="middle" font-size="16" font-weight="700" fill="' + INK + '" font-family="sans-serif">KG</text>'; },
    plates: function (c) { return '<circle cx="46" cy="64" r="40" fill="' + INK + '"/><circle cx="46" cy="64" r="32" fill="' + c + '"/><circle cx="46" cy="64" r="8" fill="' + WHT + '"/><circle cx="78" cy="56" r="32" fill="' + shade(c, -40) + '"/><circle cx="78" cy="56" r="25" fill="' + shade(c, -15) + '"/><circle cx="78" cy="56" r="6" fill="' + WHT + '"/>'; },
    pullup: function (c) { return '<rect x="8" y="26" width="104" height="10" rx="5" fill="' + c + '"/><rect x="8" y="22" width="10" height="26" rx="3" fill="' + INK + '"/><rect x="102" y="22" width="10" height="26" rx="3" fill="' + INK + '"/><rect x="14" y="48" width="92" height="48" rx="6" fill="none" stroke="' + c + '" stroke-width="3" stroke-dasharray="6 6" opacity=".5"/>'; },
    pushbars: function (c) { return '<rect x="14" y="40" width="40" height="12" rx="6" fill="' + INK + '"/><rect x="18" y="52" width="10" height="46" rx="3" fill="' + c + '"/><rect x="40" y="52" width="10" height="46" rx="3" fill="' + c + '"/><rect x="12" y="96" width="42" height="10" rx="4" fill="' + shade(c, -45) + '"/><rect x="66" y="40" width="40" height="12" rx="6" fill="' + INK + '"/><rect x="70" y="52" width="10" height="46" rx="3" fill="' + c + '"/><rect x="92" y="52" width="10" height="46" rx="3" fill="' + c + '"/><rect x="64" y="96" width="42" height="10" rx="4" fill="' + shade(c, -45) + '"/>'; },
    gripper: function (c) { return '<path d="M44 14q-22 30-4 60l12 26" fill="none" stroke="' + c + '" stroke-width="12" stroke-linecap="round"/><path d="M76 14q22 30 4 60L68 100" fill="none" stroke="' + INK + '" stroke-width="12" stroke-linecap="round"/><path d="M44 78q16 10 32 0" fill="none" stroke="#9a9a9a" stroke-width="5"/>'; },
    tee: function (c) { return '<path d="M40 14q20 14 40 0l30 18-12 20-14-6v62H36V46l-14 6L10 32z" fill="' + c + '"/><path d="M40 14q20 14 40 0" fill="none" stroke="' + shade(c, -45) + '" stroke-width="4"/><rect x="48" y="60" width="24" height="6" rx="3" fill="' + WHT + '" opacity=".85"/>'; },
    tank: function (c) { return '<path d="M38 12q-2 24-14 34l8 6v56h56V52l8-6Q82 36 82 12h-10q-2 20-12 20T48 12z" fill="' + c + '"/><rect x="46" y="64" width="28" height="6" rx="3" fill="' + WHT + '" opacity=".85"/>'; },
    shorts: function (c) { return '<path d="M20 22h80l8 74H66l-6-36-6 36H12z" fill="' + c + '"/><rect x="20" y="22" width="80" height="10" fill="' + shade(c, -40) + '"/><path d="M60 34v26" stroke="' + shade(c, -40) + '" stroke-width="3"/><path d="M14 90l36-2M106 90l-36-2" stroke="' + WHT + '" stroke-width="3" opacity=".7"/>'; },
    joggers: function (c) { return '<path d="M30 10h60l8 100H66l-6-62-6 62H22z" fill="' + c + '"/><rect x="30" y="10" width="60" height="10" fill="' + shade(c, -40) + '"/><rect x="20" y="100" width="34" height="10" rx="4" fill="' + shade(c, -45) + '"/><rect x="66" y="100" width="34" height="10" rx="4" fill="' + shade(c, -45) + '"/><path d="M60 22v26" stroke="' + shade(c, -40) + '" stroke-width="3"/>'; },
    hoodie: function (c) { return '<path d="M42 10q18 14 36 0l12 6 22 30-12 14-10-8v58H30V52l-10 8L8 46l22-30z" fill="' + c + '"/><path d="M42 10q18 22 36 0" fill="none" stroke="' + shade(c, -50) + '" stroke-width="5"/><rect x="42" y="74" width="36" height="22" rx="5" fill="' + shade(c, -30) + '"/><path d="M54 30v16M66 30v16" stroke="' + WHT + '" stroke-width="3"/>'; },
    cap: function (c) { return '<path d="M20 70q0-44 40-44t40 44z" fill="' + c + '"/><path d="M20 70q40 10 86 6-8-14-36-6z" fill="' + shade(c, -45) + '"/><circle cx="60" cy="26" r="4" fill="' + INK + '"/><path d="M60 30v30" stroke="' + shade(c, -35) + '" stroke-width="3"/>'; },
    socks: function (c) { return '<path d="M40 10h22v56l30 14q10 10-2 22l-12 6H40z" fill="' + c + '"/><rect x="40" y="10" width="22" height="12" fill="' + shade(c, -45) + '"/><path d="M40 28h22M40 36h22" stroke="' + WHT + '" stroke-width="3" opacity=".7"/>'; },
    shoe: function (c) { return '<path d="M10 78q0-10 10-14l22-6 14-18 12 6q8 14 26 20l20 8q8 4 8 14v6H10z" fill="' + c + '"/><path d="M10 90h108v10q0 6-8 6H18q-8 0-8-6z" fill="' + INK + '"/><path d="M48 58l14 10M56 50l14 10M64 44l14 10" stroke="' + WHT + '" stroke-width="3" stroke-linecap="round"/><path d="M24 76h28" stroke="' + WHT + '" stroke-width="3" opacity=".6"/>'; },
    slides: function (c) { return '<path d="M12 70q0-14 14-14h30q16 0 16 14v20H12z" fill="' + c + '"/><path d="M64 80q0-14 14-14h26q8 0 8 14v10H64z" fill="' + c + '" opacity=".85"/><path d="M12 90h60v8H12zM64 90h48v8H64z" fill="' + INK + '"/><path d="M22 66h34" stroke="' + WHT + '" stroke-width="5" stroke-linecap="round"/>'; }
  };

  function art(type, color, sizePx) {
    var f = ART[type] || ART.box, c = color || '#6b6b6b';
    return '<svg viewBox="0 0 120 120" ' + (sizePx ? 'width="' + sizePx + '" height="' + sizePx + '" ' : 'width="100%" ') + 'role="img" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">' + f(c) + '</svg>';
  }

  // id, name, cat, price (INR), art type, colour, short description, size/variant
  function P(id, name, cat, price, type, color, desc, variant) { return { id: id, name: name, cat: cat, price: price, art: type, color: color, desc: desc, variant: variant || '' }; }
  var PRODUCTS = [
    // Protein
    P('p01', 'Arena Whey Gold – Chocolate', 'protein', 2899, 'tub', '#6b3f2a', 'Whey protein blend with about 24 g protein per scoop. Mixes smoothly in water or milk.', '1 kg'),
    P('p02', 'Arena Whey Gold – Vanilla', 'protein', 4999, 'tub', '#d8b86a', 'Same whey blend in a larger tub for regular lifters. Light vanilla taste.', '2 kg'),
    P('p03', 'Lean Isolate – Cookies & Cream', 'protein', 3799, 'tub', '#3a3a3a', 'Whey isolate with low carbs and fat. Good for a cutting phase.', '1 kg'),
    P('p04', 'PlantFuel Vegan Protein', 'protein', 2499, 'tub', '#3f7d4e', 'Pea and rice protein blend with no dairy. Mild earthy flavour.', '900 g'),
    P('p05', 'Mass Builder Gainer', 'protein', 3299, 'tub', '#b4452f', 'High-calorie gainer with carbs and protein for hard gainers.', '3 kg'),
    P('p06', 'Protein Bars – Peanut Crunch', 'protein', 749, 'box', '#c98a2b', 'Box of 6 bars, about 20 g protein each. Easy snack after training.', 'Box of 6'),
    // Supplements
    P('p07', 'Pure Creatine Monohydrate', 'supplements', 1199, 'jar', '#2f5d8a', 'Micronised creatine for strength and power. Unflavoured, mixes in any drink.', '250 g'),
    P('p08', 'Ignite Pre-Workout – Fruit Punch', 'supplements', 1599, 'tub', '#c2185b', 'Caffeine and citrulline pre-workout for energy and pump.', '300 g'),
    P('p09', 'BCAA Recovery – Lemon', 'supplements', 1349, 'bottle', '#e0b400', 'Amino acid mix to sip during training or recovery.', '250 g'),
    P('p10', 'Daily Multivitamin', 'supplements', 529, 'bottle', '#e07a1f', 'Vitamins and minerals for everyday nutrition gaps.', '60 tablets'),
    P('p11', 'Omega-3 Fish Oil', 'supplements', 699, 'bottle', '#1b7f8c', 'Fish oil capsules with EPA and DHA for general wellbeing.', '90 capsules'),
    P('p12', 'Glutamine Powder', 'supplements', 999, 'jar', '#6a4fb3', 'L-glutamine powder often used for post-workout recovery.', '250 g'),
    P('p13', 'Electrolyte Hydration Mix', 'supplements', 399, 'box', '#2a9d8f', 'Sachets with salts and glucose to replace sweat losses. Box of 10.', 'Box of 10'),
    // Accessories
    P('p14', 'Classic Shaker Bottle', 'accessories', 249, 'shaker', '#1f1f1f', 'Leak-proof 700 ml shaker with mixing ball and measuring marks.', '700 ml'),
    P('p15', 'Steel Water Flask', 'accessories', 649, 'flask', '#5b6770', 'Insulated stainless steel flask that keeps drinks cold for hours.', '1 L'),
    P('p16', 'Padded Gym Gloves', 'accessories', 429, 'gloves', '#2c2c2c', 'Palm padding and wrist strap for better grip on bars and dumbbells.', 'M / L / XL'),
    P('p17', 'Leather Lifting Belt', 'accessories', 1899, 'belt', '#6a3d1f', 'Firm back support for heavy squats and deadlifts.', '10 cm wide'),
    P('p18', 'Lifting Wrist Straps', 'accessories', 299, 'straps', '#c62828', 'Cotton straps that help hold the bar during pulls.', 'Pair'),
    P('p19', 'Resistance Band Set', 'accessories', 879, 'bands', '#e6762e', 'Four bands from light to heavy for warm-ups and home workouts.', 'Set of 4'),
    P('p20', 'Speed Skipping Rope', 'accessories', 279, 'rope', '#d32f2f', 'Adjustable cable rope with ball bearings for smooth cardio.', 'Adjustable'),
    P('p21', 'Yoga & Exercise Mat', 'accessories', 599, 'mat', '#7b5ea7', 'Non-slip 6 mm mat for stretching, abs and floor work.', '6 mm'),
    P('p22', 'Microfibre Gym Towel', 'accessories', 199, 'towel', '#2e86c1', 'Quick-dry sweat towel that folds small in your bag.', '40 x 100 cm'),
    P('p23', 'Duffel Gym Bag', 'accessories', 1299, 'bag', '#263238', 'Roomy bag with a shoe pocket and a wet-clothes pocket.', '35 L'),
    P('p24', 'Knee Support Sleeves', 'accessories', 949, 'sleeve', '#3b3b3b', 'Neoprene sleeves for warmth and support during squats.', 'Pair'),
    P('p25', 'Wrist Wraps', 'accessories', 469, 'wrap', '#1565c0', 'Stretchy wraps to support wrists on pressing days.', 'Pair'),
    P('p26', 'Foam Roller', 'accessories', 799, 'roller', '#455a64', 'Textured roller to loosen tight muscles after training.', '33 cm'),
    P('p27', 'Ab Wheel Roller', 'accessories', 349, 'wheel', '#f9a825', 'Dual-grip wheel for core strength, with knee pad.', 'Standard'),
    // Equipment
    P('p28', 'Rubber Dumbbell Pair', 'equipment', 1799, 'dumbbell', '#37474f', 'Rubber-coated dumbbells with chrome handles. Sold as a pair.', '2 x 5 kg'),
    P('p29', 'Hex Dumbbell', 'equipment', 1499, 'hexdb', '#212121', 'Hex heads that do not roll. Good for home use.', '10 kg'),
    P('p30', 'Cast Iron Kettlebell', 'equipment', 1399, 'kettlebell', '#1a1a1a', 'Wide handle kettlebell for swings, cleans and goblet squats.', '12 kg'),
    P('p31', 'Weight Plate Set', 'equipment', 3499, 'plates', '#c62828', 'Pair of 5 kg and pair of 2.5 kg plates for a 28 mm bar.', '15 kg set'),
    P('p32', 'Doorway Pull-up Bar', 'equipment', 1249, 'pullup', '#546e7a', 'Fits most doorways with no screws. Foam grips.', 'Up to 120 kg'),
    P('p33', 'Push-up Bars', 'equipment', 419, 'pushbars', '#ef6c00', 'Raised handles for deeper push-ups and less wrist strain.', 'Pair'),
    P('p34', 'Hand Gripper', 'equipment', 179, 'gripper', '#455a64', 'Adjustable gripper to build forearm and grip strength.', '10–40 kg'),
    // Clothing
    P('p35', 'Dry-Fit Training T-Shirt', 'clothing', 649, 'tee', '#1f3a5f', 'Light breathable tee that wicks sweat. Regular fit.', 'S / M / L / XL'),
    P('p36', 'Stringer Tank Top', 'clothing', 449, 'tank', '#111111', 'Deep-cut tank for full shoulder movement.', 'S / M / L / XL'),
    P('p37', 'Training Shorts', 'clothing', 579, 'shorts', '#37474f', 'Stretch shorts with a zip pocket and drawcord.', 'S / M / L / XL'),
    P('p38', 'Slim Fit Joggers', 'clothing', 849, 'joggers', '#2b2b2b', 'Tapered joggers with ankle cuffs for gym and daily wear.', 'S / M / L / XL'),
    P('p39', 'Fleece Hoodie', 'clothing', 1599, 'hoodie', '#6d6d6d', 'Warm hoodie with kangaroo pocket for warm-ups and travel.', 'M / L / XL'),
    P('p40', 'Compression Tee', 'clothing', 799, 'tee', '#c62828', 'Close-fit top that stays in place during intense sets.', 'S / M / L / XL'),
    P('p41', 'Sports Cap', 'clothing', 279, 'cap', '#0d47a1', 'Lightweight adjustable cap with sweatband.', 'Free size'),
    P('p42', 'Cushioned Gym Socks', 'clothing', 329, 'socks', '#9e9e9e', 'Pack of 3 pairs with arch support and cushioned sole.', 'Pack of 3'),
    // Shoes
    P('p43', 'FlexTrain Gym Shoes', 'shoes', 2699, 'shoe', '#37474f', 'Flat stable sole for lifting and circuit training.', 'UK 6–11'),
    P('p44', 'AirRun Running Shoes', 'shoes', 2999, 'shoe', '#e64a19', 'Cushioned mesh shoes for treadmill and road runs.', 'UK 6–11'),
    P('p45', 'PowerLift Shoes', 'shoes', 3999, 'shoe', '#212121', 'Raised heel and firm sole for deep squats and Olympic lifts.', 'UK 6–11'),
    P('p46', 'Recovery Slides', 'shoes', 729, 'slides', '#1b5e20', 'Soft foam slides for the locker room and recovery days.', 'UK 6–11')
  ];

  var api = { CATS: CATS, PRODUCTS: PRODUCTS, art: art, byId: function (id) { return PRODUCTS.filter(function (p) { return p.id === id; })[0]; } };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.GymShop = api;
})(typeof window !== 'undefined' ? window : globalThis);
