/* Paste your Google "Web application" OAuth client ID here (see GOOGLE_SIGNIN_SETUP.md).
   Leave it empty and the app still works, using the owner PIN and "Continue without Google". */
window.GYM_CONFIG = { googleWebClientId: '' };
