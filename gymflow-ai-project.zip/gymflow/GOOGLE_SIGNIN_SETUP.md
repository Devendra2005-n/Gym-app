# Google sign-in setup (one time, about 15 minutes)

The app already has the "Sign in with Google" button. It starts working after you create two Google client IDs and paste one of them into `www/config.js`. Until then the owner uses the PIN and members use "Continue without Google".

## Why the signing key matters
Google checks the app's package name (`com.gymflow.ai`) and the SHA-1 fingerprint of the key that signed the APK. GitHub Actions used to create a new random debug key on every build, so the fingerprint kept changing. This zip now signs every build with a fixed key (`android/app/gymflow-debug.keystore`), so the fingerprint stays the same:

    SHA-1:  F3:9F:66:61:D8:C1:9C:C0:4B:2C:38:32:C2:C4:71:95:0C:CF:A4:0E

Because the signing key changed, uninstall the old GYM Flow app once (back up data first in Settings), then install the new APK.
Before you publish on Google Play, create your own private release keystore and add its SHA-1 as another Android client.

## Steps
1. Open https://console.cloud.google.com and create a project (name: GYM Flow).
2. APIs and Services > OAuth consent screen: choose External, app name GYM Flow, your email as support and developer contact. Save. (Keep it in Testing and add owner and member Gmail IDs as test users, or press Publish app so anyone can sign in.)
3. APIs and Services > Credentials > Create credentials > OAuth client ID:
   - Application type **Android**: package name `com.gymflow.ai`, SHA-1 as above. Create.
   - Create another one, Application type **Web application**: name "GYM Flow web". Create and copy its **Client ID** (ends with `.apps.googleusercontent.com`).
4. Open `www/config.js` and paste the Web client ID:

        window.GYM_CONFIG = { googleWebClientId: 'XXXX.apps.googleusercontent.com' };

5. Upload the zip again and build the APK. The phone needs at least one Google account added.

## How roles work
- On first launch the user chooses Owner or Member.
- The first Google account that signs in as Owner becomes the gym's owner account on that phone. Any other Google account is refused as owner.
- Owners see: Dashboard, Members, Check-in desk, Payments, Reports, Register, Assistant, Settings, FAQ.
- Members see: Dashboard, Check-in (scan the gym QR), Workouts, Weekly Report, Goals, Trainers, Diet, Clubs, Products, FAQ.
- Sign out is under More.

## Important limit
Roles are enforced inside the app on each phone. The data is also stored on each phone. This keeps owner screens away from members in normal use, but it is not protection against someone who tampers with their own phone. Real protection needs a server and database rules (Phase 1 in the quotation roadmap).
